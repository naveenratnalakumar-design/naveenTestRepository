import { f as dt, g as Zt, i as _t, p as pt } from "@nf-internal/chunk-P223Q223";
import "@nf-internal/chunk-ITP4ZIB2";
import "@nf-internal/chunk-HXIDEVWT";
import "@nf-internal/chunk-73GXGGDE";
import { a as ot, b as at } from "@nf-internal/chunk-VP6KNDS4";
import { a as lt } from "@nf-internal/chunk-7N7HFQKY";
import { b as O, d as y } from "@nf-internal/chunk-OIQ2QPHM";
import "@nf-internal/chunk-DQM2BKPX";
import { a as ct } from "@nf-internal/chunk-G25BAKAM";
import "@nf-internal/chunk-OI5KCOOP";
import { c as V } from "@nf-internal/chunk-3C63DHR6";
import { a as z, c as w } from "@nf-internal/chunk-JYXTBF5A";
import { a as ht } from "@nf-internal/chunk-FSAIB72R";
import "@nf-internal/chunk-66YHNWRR";
import * as d from "@angular/core";
import { signal as It, inject as c, NgZone as Y, DOCUMENT as xt, RendererFactory2 as Ct, InjectionToken as P, ElementRef as X, booleanAttribute as b, ViewContainerRef as jt, ChangeDetectorRef as Tt, EventEmitter as v, Injector as qt, afterNextRender as $t, numberAttribute as Kt, TemplateRef as kt } from "@angular/core";
import { Subject as p, Subscription as I, interval as Yt, animationFrameScheduler as Xt, Observable as Ot, merge as J, BehaviorSubject as Jt } from "rxjs";
import { takeUntil as L, map as Qt, take as te, tap as ee, switchMap as ie, startWith as Lt } from "rxjs/operators";
import "@angular/common";
function U(r) { let e = r.cloneNode(!0), t = e.querySelectorAll("[id]"), i = r.nodeName.toLowerCase(); e.removeAttribute("id"); for (let s = 0; s < t.length; s++)
    t[s].removeAttribute("id"); return i === "canvas" ? ft(r, e) : (i === "input" || i === "select" || i === "textarea") && ut(r, e), gt("canvas", r, e, ft), gt("input, textarea, select", r, e, ut), e; }
function gt(r, e, t, i) { let s = e.querySelectorAll(r); if (s.length) {
    let n = t.querySelectorAll(r);
    for (let o = 0; o < s.length; o++)
        i(s[o], n[o]);
} }
var se = 0;
function ut(r, e) { e.type !== "file" && (e.value = r.value), e.type === "radio" && e.name && (e.name = `mat-clone-${e.name}-${se++}`); }
function ft(r, e) { let t = e.getContext("2d"); if (t)
    try {
        t.drawImage(r, 0, 0);
    }
    catch { } }
function Q(r) { let e = r.getBoundingClientRect(); return { top: e.top, right: e.right, bottom: e.bottom, left: e.left, width: e.width, height: e.height, x: e.x, y: e.y }; }
function W(r, e, t) { let { top: i, bottom: s, left: n, right: o } = r; return t >= i && t <= s && e >= n && e <= o; }
function ne(r, e) { let t = e.left < r.left, i = e.left + e.width > r.right, s = e.top < r.top, n = e.top + e.height > r.bottom; return t || i || s || n; }
function x(r, e, t) { r.top += e, r.bottom = r.top + r.height, r.left += t, r.right = r.left + r.width; }
function mt(r, e, t, i) { let { top: s, right: n, bottom: o, left: a, width: l, height: h } = r, _ = l * e, u = h * e; return i > s - u && i < o + u && t > a - _ && t < n + _; }
var N = class {
    _document;
    positions = new Map;
    constructor(e) { this._document = e; }
    clear() { this.positions.clear(); }
    cache(e) { this.clear(), this.positions.set(this._document, { scrollPosition: this.getViewportScrollPosition() }), e.forEach(t => { this.positions.set(t, { scrollPosition: { top: t.scrollTop, left: t.scrollLeft }, clientRect: Q(t) }); }); }
    handleScroll(e) { let t = y(e), i = this.positions.get(t); if (!i)
        return null; let s = i.scrollPosition, n, o; if (t === this._document) {
        let h = this.getViewportScrollPosition();
        n = h.top, o = h.left;
    }
    else
        n = t.scrollTop, o = t.scrollLeft; let a = s.top - n, l = s.left - o; return this.positions.forEach((h, _) => { h.clientRect && t !== _ && t.contains(_) && x(h.clientRect, a, l); }), s.top = n, s.left = o, { top: a, left: l }; }
    getViewportScrollPosition() { return { top: window.scrollY, left: window.scrollX }; }
};
function Nt(r, e) { let t = r.rootNodes; if (t.length === 1 && t[0].nodeType === e.ELEMENT_NODE)
    return t[0]; let i = e.createElement("div"); return t.forEach(s => i.appendChild(s)), i; }
function tt(r, e, t) { for (let i in e)
    if (e.hasOwnProperty(i)) {
        let s = e[i];
        s ? r.setProperty(i, s, t?.has(i) ? "important" : "") : r.removeProperty(i);
    } return r; }
function S(r, e) { let t = e ? "" : "none"; tt(r.style, { "touch-action": e ? "" : "none", "-webkit-user-drag": e ? "" : "none", "-webkit-tap-highlight-color": e ? "" : "transparent", "user-select": t, "-ms-user-select": t, "-webkit-user-select": t, "-moz-user-select": t }); }
function vt(r, e, t) { tt(r.style, { position: e ? "" : "fixed", top: e ? "" : "0", opacity: e ? "" : "0", left: e ? "" : "-999em" }, t); }
function M(r, e) { return e && e != "none" ? r + " " + e : r; }
function Dt(r, e) { r.style.width = `${e.width}px`, r.style.height = `${e.height}px`, r.style.transform = C(e.left, e.top); }
function C(r, e) { return `translate3d(${Math.round(r)}px, ${Math.round(e)}px, 0)`; }
function wt(r) { let e = r.toLowerCase().indexOf("ms") > -1 ? 1 : 1e3; return parseFloat(r) * e; }
function re(r) { let e = getComputedStyle(r), t = B(e, "transition-property"), i = t.find(a => a === "transform" || a === "all"); if (!i)
    return 0; let s = t.indexOf(i), n = B(e, "transition-duration"), o = B(e, "transition-delay"); return wt(n[s]) + wt(o[s]); }
function B(r, e) { return r.getPropertyValue(e).split(",").map(i => i.trim()); }
var oe = new Set(["position"]), Z = class {
    _document;
    _rootElement;
    _direction;
    _initialDomRect;
    _previewTemplate;
    _previewClass;
    _pickupPositionOnPage;
    _initialTransform;
    _zIndex;
    _renderer;
    _previewEmbeddedView;
    _preview;
    get element() { return this._preview; }
    constructor(e, t, i, s, n, o, a, l, h, _) { this._document = e, this._rootElement = t, this._direction = i, this._initialDomRect = s, this._previewTemplate = n, this._previewClass = o, this._pickupPositionOnPage = a, this._initialTransform = l, this._zIndex = h, this._renderer = _; }
    attach(e) { this._preview = this._createPreview(), e.appendChild(this._preview), bt(this._preview) && this._preview.showPopover(); }
    destroy() { this._preview.remove(), this._previewEmbeddedView?.destroy(), this._preview = this._previewEmbeddedView = null; }
    setTransform(e) { this._preview.style.transform = e; }
    getBoundingClientRect() { return this._preview.getBoundingClientRect(); }
    addClass(e) { this._preview.classList.add(e); }
    getTransitionDuration() { return re(this._preview); }
    addEventListener(e, t) { return this._renderer.listen(this._preview, e, t); }
    _createPreview() { let e = this._previewTemplate, t = this._previewClass, i = e ? e.template : null, s; if (i && e) {
        let n = e.matchSize ? this._initialDomRect : null, o = e.viewContainer.createEmbeddedView(i, e.context);
        o.detectChanges(), s = Nt(o, this._document), this._previewEmbeddedView = o, e.matchSize ? Dt(s, n) : s.style.transform = C(this._pickupPositionOnPage.x, this._pickupPositionOnPage.y);
    }
    else
        s = U(this._rootElement), Dt(s, this._initialDomRect), this._initialTransform && (s.style.transform = this._initialTransform); return tt(s.style, { "pointer-events": "none", margin: bt(s) ? "0 auto 0 0" : "0", position: "fixed", top: "0", left: "0", "z-index": this._zIndex + "" }, oe), S(s, !1), s.classList.add("cdk-drag-preview"), s.setAttribute("popover", "manual"), s.setAttribute("dir", this._direction), t && (Array.isArray(t) ? t.forEach(n => s.classList.add(n)) : s.classList.add(t)), s; }
};
function bt(r) { return "showPopover" in r; }
var ae = { passive: !0 }, Pt = { passive: !1 }, le = { passive: !1, capture: !0 }, he = 800, St = "cdk-drag-placeholder", yt = new Set(["position"]), j = class {
    _config;
    _document;
    _ngZone;
    _viewportRuler;
    _dragDropRegistry;
    _renderer;
    _rootElementCleanups;
    _cleanupShadowRootSelectStart;
    _preview;
    _previewContainer;
    _placeholderRef;
    _placeholder;
    _pickupPositionInElement;
    _pickupPositionOnPage;
    _marker;
    _anchor = null;
    _passiveTransform = { x: 0, y: 0 };
    _activeTransform = { x: 0, y: 0 };
    _initialTransform;
    _hasStartedDragging = It(!1);
    _hasMoved;
    _initialContainer;
    _initialIndex;
    _parentPositions;
    _moveEvents = new p;
    _pointerDirectionDelta;
    _pointerPositionAtLastDirectionChange;
    _lastKnownPointerPosition;
    _rootElement;
    _ownerSVGElement;
    _rootElementTapHighlight;
    _pointerMoveSubscription = I.EMPTY;
    _pointerUpSubscription = I.EMPTY;
    _scrollSubscription = I.EMPTY;
    _resizeSubscription = I.EMPTY;
    _lastTouchEventTime;
    _dragStartTime;
    _boundaryElement = null;
    _nativeInteractionsEnabled = !0;
    _initialDomRect;
    _previewRect;
    _boundaryRect;
    _previewTemplate;
    _placeholderTemplate;
    _handles = [];
    _disabledHandles = new Set;
    _dropContainer;
    _direction = "ltr";
    _parentDragRef;
    _cachedShadowRoot;
    lockAxis;
    dragStartDelay = 0;
    previewClass;
    scale = 1;
    get disabled() { return this._disabled || !!(this._dropContainer && this._dropContainer.disabled); }
    set disabled(e) { e !== this._disabled && (this._disabled = e, this._toggleNativeDragInteractions(), this._handles.forEach(t => S(t, e))); }
    _disabled = !1;
    beforeStarted = new p;
    started = new p;
    released = new p;
    ended = new p;
    entered = new p;
    exited = new p;
    dropped = new p;
    moved = this._moveEvents;
    data;
    constrainPosition;
    constructor(e, t, i, s, n, o, a) { this._config = t, this._document = i, this._ngZone = s, this._viewportRuler = n, this._dragDropRegistry = o, this._renderer = a, this.withRootElement(e).withParent(t.parentDragRef || null), this._parentPositions = new N(i), o.registerDragItem(this); }
    getPlaceholderElement() { return this._placeholder; }
    getRootElement() { return this._rootElement; }
    getVisibleElement() { return this.isDragging() ? this.getPlaceholderElement() : this.getRootElement(); }
    withHandles(e) { this._handles = e.map(i => w(i)), this._handles.forEach(i => S(i, this.disabled)), this._toggleNativeDragInteractions(); let t = new Set; return this._disabledHandles.forEach(i => { this._handles.indexOf(i) > -1 && t.add(i); }), this._disabledHandles = t, this; }
    withPreviewTemplate(e) { return this._previewTemplate = e, this; }
    withPlaceholderTemplate(e) { return this._placeholderTemplate = e, this; }
    withRootElement(e) { let t = w(e); if (t !== this._rootElement) {
        this._removeRootElementListeners();
        let i = this._renderer;
        this._rootElementCleanups = this._ngZone.runOutsideAngular(() => [i.listen(t, "mousedown", this._pointerDown, Pt), i.listen(t, "touchstart", this._pointerDown, ae), i.listen(t, "dragstart", this._nativeDragStart, Pt)]), this._initialTransform = void 0, this._rootElement = t;
    } return typeof SVGElement < "u" && this._rootElement instanceof SVGElement && (this._ownerSVGElement = this._rootElement.ownerSVGElement), this; }
    withBoundaryElement(e) { return this._boundaryElement = e ? w(e) : null, this._resizeSubscription.unsubscribe(), e && (this._resizeSubscription = this._viewportRuler.change(10).subscribe(() => this._containInsideBoundaryOnResize())), this; }
    withParent(e) { return this._parentDragRef = e, this; }
    dispose() { this._removeRootElementListeners(), this.isDragging() && this._rootElement?.remove(), this._marker?.remove(), this._destroyPreview(), this._destroyPlaceholder(), this._dragDropRegistry.removeDragItem(this), this._removeListeners(), this.beforeStarted.complete(), this.started.complete(), this.released.complete(), this.ended.complete(), this.entered.complete(), this.exited.complete(), this.dropped.complete(), this._moveEvents.complete(), this._handles = [], this._disabledHandles.clear(), this._dropContainer = void 0, this._resizeSubscription.unsubscribe(), this._parentPositions.clear(), this._boundaryElement = this._rootElement = this._ownerSVGElement = this._placeholderTemplate = this._previewTemplate = this._marker = this._parentDragRef = null; }
    isDragging() { return this._hasStartedDragging() && this._dragDropRegistry.isDragging(this); }
    reset() { this._rootElement.style.transform = this._initialTransform || "", this._activeTransform = { x: 0, y: 0 }, this._passiveTransform = { x: 0, y: 0 }; }
    resetToBoundary() { if (this._boundaryElement && this._rootElement && ne(this._boundaryElement.getBoundingClientRect(), this._rootElement.getBoundingClientRect())) {
        let e = this._boundaryElement.getBoundingClientRect(), t = this._rootElement.getBoundingClientRect(), i = 0, s = 0;
        t.left < e.left ? i = e.left - t.left : t.right > e.right && (i = e.right - t.right), t.top < e.top ? s = e.top - t.top : t.bottom > e.bottom && (s = e.bottom - t.bottom);
        let n = this._activeTransform.x, o = this._activeTransform.y, a = n + i, l = o + s;
        this._rootElement.style.transform = C(a, l), this._activeTransform = { x: a, y: l }, this._passiveTransform = { x: a, y: l };
    } }
    disableHandle(e) { !this._disabledHandles.has(e) && this._handles.indexOf(e) > -1 && (this._disabledHandles.add(e), S(e, !0)); }
    enableHandle(e) { this._disabledHandles.has(e) && (this._disabledHandles.delete(e), S(e, this.disabled)); }
    withDirection(e) { return this._direction = e, this; }
    _withDropContainer(e) { this._dropContainer = e; }
    getFreeDragPosition() { let e = this.isDragging() ? this._activeTransform : this._passiveTransform; return { x: e.x, y: e.y }; }
    setFreeDragPosition(e) { return this._activeTransform = { x: 0, y: 0 }, this._passiveTransform.x = e.x, this._passiveTransform.y = e.y, this._dropContainer || this._applyRootElementTransform(e.x, e.y), this; }
    withPreviewContainer(e) { return this._previewContainer = e, this; }
    _sortFromLastPointerPosition() { let e = this._lastKnownPointerPosition; e && this._dropContainer && this._updateActiveDropContainer(this._getConstrainedPointerPosition(e), e); }
    _removeListeners() { this._pointerMoveSubscription.unsubscribe(), this._pointerUpSubscription.unsubscribe(), this._scrollSubscription.unsubscribe(), this._cleanupShadowRootSelectStart?.(), this._cleanupShadowRootSelectStart = void 0; }
    _destroyPreview() { this._preview?.destroy(), this._preview = null; }
    _destroyPlaceholder() { this._anchor?.remove(), this._placeholder?.remove(), this._placeholderRef?.destroy(), this._placeholder = this._anchor = this._placeholderRef = null; }
    _pointerDown = e => { if (this.beforeStarted.next(), this._handles.length) {
        let t = this._getTargetHandle(e);
        t && !this._disabledHandles.has(t) && !this.disabled && this._initializeDragSequence(t, e);
    }
    else
        this.disabled || this._initializeDragSequence(this._rootElement, e); };
    _pointerMove = e => { let t = this._getPointerPositionOnPage(e); if (!this._hasStartedDragging()) {
        let s = Math.abs(t.x - this._pickupPositionOnPage.x), n = Math.abs(t.y - this._pickupPositionOnPage.y);
        if (s + n >= this._config.dragStartThreshold) {
            let a = Date.now() >= this._dragStartTime + this._getDragStartDelay(e), l = this._dropContainer;
            if (!a) {
                this._endDragSequence(e);
                return;
            }
            (!l || !l.isDragging() && !l.isReceiving()) && (e.cancelable && e.preventDefault(), this._hasStartedDragging.set(!0), this._ngZone.run(() => this._startDragSequence(e)));
        }
        return;
    } e.cancelable && e.preventDefault(); let i = this._getConstrainedPointerPosition(t); if (this._hasMoved = !0, this._lastKnownPointerPosition = t, this._updatePointerDirectionDelta(i), this._dropContainer)
        this._updateActiveDropContainer(i, t);
    else {
        let s = this.constrainPosition ? this._initialDomRect : this._pickupPositionOnPage, n = this._activeTransform;
        n.x = i.x - s.x + this._passiveTransform.x, n.y = i.y - s.y + this._passiveTransform.y, this._applyRootElementTransform(n.x, n.y);
    } this._moveEvents.observers.length && this._ngZone.run(() => { this._moveEvents.next({ source: this, pointerPosition: i, event: e, distance: this._getDragDistance(i), delta: this._pointerDirectionDelta }); }); };
    _pointerUp = e => { this._endDragSequence(e); };
    _endDragSequence(e) { if (this._dragDropRegistry.isDragging(this) && (this._removeListeners(), this._dragDropRegistry.stopDragging(this), this._toggleNativeDragInteractions(), this._handles && (this._rootElement.style.webkitTapHighlightColor = this._rootElementTapHighlight), !!this._hasStartedDragging()))
        if (this.released.next({ source: this, event: e }), this._dropContainer)
            this._dropContainer._stopScrolling(), this._animatePreviewToPlaceholder().then(() => { this._cleanupDragArtifacts(e), this._cleanupCachedDimensions(), this._dragDropRegistry.stopDragging(this); });
        else {
            this._passiveTransform.x = this._activeTransform.x;
            let t = this._getPointerPositionOnPage(e);
            this._passiveTransform.y = this._activeTransform.y, this._ngZone.run(() => { this.ended.next({ source: this, distance: this._getDragDistance(t), dropPoint: t, event: e }); }), this._cleanupCachedDimensions(), this._dragDropRegistry.stopDragging(this);
        } }
    _startDragSequence(e) { R(e) && (this._lastTouchEventTime = Date.now()), this._toggleNativeDragInteractions(); let t = this._getShadowRoot(), i = this._dropContainer; if (t && this._ngZone.runOutsideAngular(() => { this._cleanupShadowRootSelectStart = this._renderer.listen(t, "selectstart", ce, le); }), i) {
        let s = this._rootElement, n = s.parentNode, o = this._placeholder = this._createPlaceholderElement(), a = this._marker = this._marker || this._document.createComment("");
        n.insertBefore(a, s), this._initialTransform = s.style.transform || "", this._preview = new Z(this._document, this._rootElement, this._direction, this._initialDomRect, this._previewTemplate || null, this.previewClass || null, this._pickupPositionOnPage, this._initialTransform, this._config.zIndex || 1e3, this._renderer), this._preview.attach(this._getPreviewInsertionPoint(n, t)), vt(s, !1, yt), this._document.body.appendChild(n.replaceChild(o, s)), this.started.next({ source: this, event: e }), i.start(), this._initialContainer = i, this._initialIndex = i.getItemIndex(this);
    }
    else
        this.started.next({ source: this, event: e }), this._initialContainer = this._initialIndex = void 0; this._parentPositions.cache(i ? i.getScrollableParents() : []); }
    _initializeDragSequence(e, t) { this._parentDragRef && t.stopPropagation(); let i = this.isDragging(), s = R(t), n = !s && t.button !== 0, o = this._rootElement, a = y(t), l = !s && this._lastTouchEventTime && this._lastTouchEventTime + he > Date.now(), h = s ? at(t) : ot(t); if (a && a.draggable && t.type === "mousedown" && t.preventDefault(), i || n || l || h)
        return; if (this._handles.length) {
        let D = o.style;
        this._rootElementTapHighlight = D.webkitTapHighlightColor || "", D.webkitTapHighlightColor = "transparent";
    } this._hasMoved = !1, this._hasStartedDragging.set(this._hasMoved), this._removeListeners(), this._initialDomRect = this._rootElement.getBoundingClientRect(), this._pointerMoveSubscription = this._dragDropRegistry.pointerMove.subscribe(this._pointerMove), this._pointerUpSubscription = this._dragDropRegistry.pointerUp.subscribe(this._pointerUp), this._scrollSubscription = this._dragDropRegistry.scrolled(this._getShadowRoot()).subscribe(D => this._updateOnScroll(D)), this._boundaryElement && (this._boundaryRect = Q(this._boundaryElement)); let _ = this._previewTemplate; this._pickupPositionInElement = _ && _.template && !_.matchSize ? { x: 0, y: 0 } : this._getPointerPositionInElement(this._initialDomRect, e, t); let u = this._pickupPositionOnPage = this._lastKnownPointerPosition = this._getPointerPositionOnPage(t); this._pointerDirectionDelta = { x: 0, y: 0 }, this._pointerPositionAtLastDirectionChange = { x: u.x, y: u.y }, this._dragStartTime = Date.now(), this._dragDropRegistry.startDragging(this, t); }
    _cleanupDragArtifacts(e) { vt(this._rootElement, !0, yt), this._marker.parentNode.replaceChild(this._rootElement, this._marker), this._destroyPreview(), this._destroyPlaceholder(), this._initialDomRect = this._boundaryRect = this._previewRect = this._initialTransform = void 0, this._ngZone.run(() => { let t = this._dropContainer, i = t.getItemIndex(this), s = this._getPointerPositionOnPage(e), n = this._getDragDistance(s), o = t._isOverContainer(s.x, s.y); this.ended.next({ source: this, distance: n, dropPoint: s, event: e }), this.dropped.next({ item: this, currentIndex: i, previousIndex: this._initialIndex, container: t, previousContainer: this._initialContainer, isPointerOverContainer: o, distance: n, dropPoint: s, event: e }), t.drop(this, i, this._initialIndex, this._initialContainer, o, n, s, e), this._dropContainer = this._initialContainer; }); }
    _updateActiveDropContainer({ x: e, y: t }, { x: i, y: s }) { let n = this._initialContainer._getSiblingContainerFromPosition(this, e, t); !n && this._dropContainer !== this._initialContainer && this._initialContainer._isOverContainer(e, t) && (n = this._initialContainer), n && n !== this._dropContainer && this._ngZone.run(() => { let o = this._dropContainer.getItemIndex(this), a = this._dropContainer.getItemAtIndex(o + 1)?.getVisibleElement() || null; this.exited.next({ item: this, container: this._dropContainer }), this._dropContainer.exit(this), this._conditionallyInsertAnchor(n, this._dropContainer, a), this._dropContainer = n, this._dropContainer.enter(this, e, t, n === this._initialContainer && n.sortingDisabled ? this._initialIndex : void 0), this.entered.next({ item: this, container: n, currentIndex: n.getItemIndex(this) }); }), this.isDragging() && (this._dropContainer._startScrollingIfNecessary(i, s), this._dropContainer._sortItem(this, e, t, this._pointerDirectionDelta), this.constrainPosition ? this._applyPreviewTransform(e, t) : this._applyPreviewTransform(e - this._pickupPositionInElement.x, t - this._pickupPositionInElement.y)); }
    _animatePreviewToPlaceholder() { if (!this._hasMoved)
        return Promise.resolve(); let e = this._placeholder.getBoundingClientRect(); this._preview.addClass("cdk-drag-animating"), this._applyPreviewTransform(e.left, e.top); let t = this._preview.getTransitionDuration(); return t === 0 ? Promise.resolve() : this._ngZone.runOutsideAngular(() => new Promise(i => { let s = a => { (!a || this._preview && y(a) === this._preview.element && a.propertyName === "transform") && (o(), i(), clearTimeout(n)); }, n = setTimeout(s, t * 1.5), o = this._preview.addEventListener("transitionend", s); })); }
    _createPlaceholderElement() { let e = this._placeholderTemplate, t = e ? e.template : null, i; return t ? (this._placeholderRef = e.viewContainer.createEmbeddedView(t, e.context), this._placeholderRef.detectChanges(), i = Nt(this._placeholderRef, this._document)) : i = U(this._rootElement), i.style.pointerEvents = "none", i.classList.add(St), i; }
    _getPointerPositionInElement(e, t, i) { let s = t === this._rootElement ? null : t, n = s ? s.getBoundingClientRect() : e, o = R(i) ? i.targetTouches[0] : i, a = this._getViewportScrollPosition(), l = o.pageX - n.left - a.left, h = o.pageY - n.top - a.top; return { x: n.left - e.left + l, y: n.top - e.top + h }; }
    _getPointerPositionOnPage(e) { let t = this._getViewportScrollPosition(), i = R(e) ? e.touches[0] || e.changedTouches[0] || { pageX: 0, pageY: 0 } : e, s = i.pageX - t.left, n = i.pageY - t.top; if (this._ownerSVGElement) {
        let o = this._ownerSVGElement.getScreenCTM();
        if (o) {
            let a = this._ownerSVGElement.createSVGPoint();
            return a.x = s, a.y = n, a.matrixTransform(o.inverse());
        }
    } return { x: s, y: n }; }
    _getConstrainedPointerPosition(e) { let t = this._dropContainer ? this._dropContainer.lockAxis : null, { x: i, y: s } = this.constrainPosition ? this.constrainPosition(e, this, this._initialDomRect, this._pickupPositionInElement) : e; if (this.lockAxis === "x" || t === "x" ? s = this._pickupPositionOnPage.y - (this.constrainPosition ? this._pickupPositionInElement.y : 0) : (this.lockAxis === "y" || t === "y") && (i = this._pickupPositionOnPage.x - (this.constrainPosition ? this._pickupPositionInElement.x : 0)), this._boundaryRect) {
        let { x: n, y: o } = this.constrainPosition ? { x: 0, y: 0 } : this._pickupPositionInElement, a = this._boundaryRect, { width: l, height: h } = this._getPreviewRect(), _ = a.top + o, u = a.bottom - (h - o), D = a.left + n, F = a.right - (l - n);
        i = Rt(i, D, F), s = Rt(s, _, u);
    } return { x: i, y: s }; }
    _updatePointerDirectionDelta(e) { let { x: t, y: i } = e, s = this._pointerDirectionDelta, n = this._pointerPositionAtLastDirectionChange, o = Math.abs(t - n.x), a = Math.abs(i - n.y); return o > this._config.pointerDirectionChangeThreshold && (s.x = t > n.x ? 1 : -1, n.x = t), a > this._config.pointerDirectionChangeThreshold && (s.y = i > n.y ? 1 : -1, n.y = i), s; }
    _toggleNativeDragInteractions() { if (!this._rootElement || !this._handles)
        return; let e = this._handles.length > 0 || !this.isDragging(); e !== this._nativeInteractionsEnabled && (this._nativeInteractionsEnabled = e, S(this._rootElement, e)); }
    _removeRootElementListeners() { this._rootElementCleanups?.forEach(e => e()), this._rootElementCleanups = void 0; }
    _applyRootElementTransform(e, t) { let i = 1 / this.scale, s = C(e * i, t * i), n = this._rootElement.style; this._initialTransform == null && (this._initialTransform = n.transform && n.transform != "none" ? n.transform : ""), n.transform = M(s, this._initialTransform); }
    _applyPreviewTransform(e, t) { let i = this._previewTemplate?.template ? void 0 : this._initialTransform, s = C(e, t); this._preview.setTransform(M(s, i)); }
    _getDragDistance(e) { let t = this._pickupPositionOnPage; return t ? { x: e.x - t.x, y: e.y - t.y } : { x: 0, y: 0 }; }
    _cleanupCachedDimensions() { this._boundaryRect = this._previewRect = void 0, this._parentPositions.clear(); }
    _containInsideBoundaryOnResize() { let { x: e, y: t } = this._passiveTransform; if (e === 0 && t === 0 || this.isDragging() || !this._boundaryElement)
        return; let i = this._rootElement.getBoundingClientRect(), s = this._boundaryElement.getBoundingClientRect(); if (s.width === 0 && s.height === 0 || i.width === 0 && i.height === 0)
        return; let n = s.left - i.left, o = i.right - s.right, a = s.top - i.top, l = i.bottom - s.bottom; s.width > i.width ? (n > 0 && (e += n), o > 0 && (e -= o)) : e = 0, s.height > i.height ? (a > 0 && (t += a), l > 0 && (t -= l)) : t = 0, (e !== this._passiveTransform.x || t !== this._passiveTransform.y) && this.setFreeDragPosition({ y: t, x: e }); }
    _getDragStartDelay(e) { let t = this.dragStartDelay; return typeof t == "number" ? t : R(e) ? t.touch : t ? t.mouse : 0; }
    _updateOnScroll(e) { let t = this._parentPositions.handleScroll(e); if (t) {
        let i = y(e);
        this._boundaryRect && i !== this._boundaryElement && i.contains(this._boundaryElement) && x(this._boundaryRect, t.top, t.left), this._pickupPositionOnPage.x += t.left, this._pickupPositionOnPage.y += t.top, this._dropContainer || (this._activeTransform.x -= t.left, this._activeTransform.y -= t.top, this._applyRootElementTransform(this._activeTransform.x, this._activeTransform.y));
    } }
    _getViewportScrollPosition() { return this._parentPositions.positions.get(this._document)?.scrollPosition || this._parentPositions.getViewportScrollPosition(); }
    _getShadowRoot() { return this._cachedShadowRoot === void 0 && (this._cachedShadowRoot = O(this._rootElement)), this._cachedShadowRoot; }
    _getPreviewInsertionPoint(e, t) { let i = this._previewContainer || "global"; if (i === "parent")
        return e; if (i === "global") {
        let s = this._document;
        return t || s.fullscreenElement || s.webkitFullscreenElement || s.mozFullScreenElement || s.msFullscreenElement || s.body;
    } return w(i); }
    _getPreviewRect() { return (!this._previewRect || !this._previewRect.width && !this._previewRect.height) && (this._previewRect = this._preview ? this._preview.getBoundingClientRect() : this._initialDomRect), this._previewRect; }
    _nativeDragStart = e => { if (this._handles.length) {
        let t = this._getTargetHandle(e);
        t && !this._disabledHandles.has(t) && !this.disabled && e.preventDefault();
    }
    else
        this.disabled || e.preventDefault(); };
    _getTargetHandle(e) { return this._handles.find(t => e.target && (e.target === t || t.contains(e.target))); }
    _conditionallyInsertAnchor(e, t, i) { if (e === this._initialContainer)
        this._anchor?.remove(), this._anchor = null;
    else if (t === this._initialContainer && t.hasAnchor) {
        let s = this._anchor ??= U(this._placeholder);
        s.classList.remove(St), s.classList.add("cdk-drag-anchor"), s.style.transform = "", i ? i.before(s) : w(t.element).appendChild(s);
    } }
};
function Rt(r, e, t) { return Math.max(e, Math.min(t, r)); }
function R(r) { return r.type[0] === "t"; }
function ce(r) { r.preventDefault(); }
function Mt(r, e, t) { let i = T(e, r.length - 1), s = T(t, r.length - 1); if (i === s)
    return; let n = r[i], o = s < i ? -1 : 1; for (let a = i; a !== s; a += o)
    r[a] = r[a + o]; r[s] = n; }
function Ae(r, e, t, i) { let s = T(t, r.length - 1), n = T(i, e.length); r.length && e.splice(n, 0, r.splice(s, 1)[0]); }
function Fe(r, e, t, i) { let s = T(i, e.length); r.length && e.splice(s, 0, r[t]); }
function T(r, e) { return Math.max(0, Math.min(e, r)); }
var A = class {
    _dragDropRegistry;
    _element;
    _sortPredicate;
    _itemPositions = [];
    _activeDraggables;
    orientation = "vertical";
    direction;
    constructor(e) { this._dragDropRegistry = e; }
    _previousSwap = { drag: null, delta: 0, overlaps: !1 };
    start(e) { this.withItems(e); }
    sort(e, t, i, s) { let n = this._itemPositions, o = this._getItemIndexFromPointerPosition(e, t, i, s); if (o === -1 && n.length > 0)
        return null; let a = this.orientation === "horizontal", l = n.findIndex(f => f.drag === e), h = n[o], _ = n[l].clientRect, u = h.clientRect, D = l > o ? 1 : -1, F = this._getItemOffsetPx(_, u, D), Gt = this._getSiblingOffsetPx(l, n, D), Ut = n.slice(); return Mt(n, l, o), n.forEach((f, Wt) => { if (Ut[Wt] === f)
        return; let st = f.drag === e, H = st ? F : Gt, nt = st ? e.getPlaceholderElement() : f.drag.getRootElement(); f.offset += H; let rt = Math.round(f.offset * (1 / f.drag.scale)); a ? (nt.style.transform = M(`translate3d(${rt}px, 0, 0)`, f.initialTransform), x(f.clientRect, 0, H)) : (nt.style.transform = M(`translate3d(0, ${rt}px, 0)`, f.initialTransform), x(f.clientRect, H, 0)); }), this._previousSwap.overlaps = W(u, t, i), this._previousSwap.drag = h.drag, this._previousSwap.delta = a ? s.x : s.y, { previousIndex: l, currentIndex: o }; }
    enter(e, t, i, s) { let n = s == null || s < 0 ? this._getItemIndexFromPointerPosition(e, t, i) : s, o = this._activeDraggables, a = o.indexOf(e), l = e.getPlaceholderElement(), h = o[n]; if (h === e && (h = o[n + 1]), !h && (n == null || n === -1 || n < o.length - 1) && this._shouldEnterAsFirstChild(t, i) && (h = o[0]), a > -1 && o.splice(a, 1), h && !this._dragDropRegistry.isDragging(h)) {
        let _ = h.getRootElement();
        _.parentElement.insertBefore(l, _), o.splice(n, 0, e);
    }
    else
        this._element.appendChild(l), o.push(e); l.style.transform = "", this._cacheItemPositions(); }
    withItems(e) { this._activeDraggables = e.slice(), this._cacheItemPositions(); }
    withSortPredicate(e) { this._sortPredicate = e; }
    reset() { this._activeDraggables?.forEach(e => { let t = e.getRootElement(); if (t) {
        let i = this._itemPositions.find(s => s.drag === e)?.initialTransform;
        t.style.transform = i || "";
    } }), this._itemPositions = [], this._activeDraggables = [], this._previousSwap.drag = null, this._previousSwap.delta = 0, this._previousSwap.overlaps = !1; }
    getActiveItemsSnapshot() { return this._activeDraggables; }
    getItemIndex(e) { return this._getVisualItemPositions().findIndex(t => t.drag === e); }
    getItemAtIndex(e) { return this._getVisualItemPositions()[e]?.drag || null; }
    updateOnScroll(e, t) { this._itemPositions.forEach(({ clientRect: i }) => { x(i, e, t); }), this._itemPositions.forEach(({ drag: i }) => { this._dragDropRegistry.isDragging(i) && i._sortFromLastPointerPosition(); }); }
    withElementContainer(e) { this._element = e; }
    _cacheItemPositions() { let e = this.orientation === "horizontal"; this._itemPositions = this._activeDraggables.map(t => { let i = t.getVisibleElement(); return { drag: t, offset: 0, initialTransform: i.style.transform || "", clientRect: Q(i) }; }).sort((t, i) => e ? t.clientRect.left - i.clientRect.left : t.clientRect.top - i.clientRect.top); }
    _getVisualItemPositions() { return this.orientation === "horizontal" && this.direction === "rtl" ? this._itemPositions.slice().reverse() : this._itemPositions; }
    _getItemOffsetPx(e, t, i) { let s = this.orientation === "horizontal", n = s ? t.left - e.left : t.top - e.top; return i === -1 && (n += s ? t.width - e.width : t.height - e.height), n; }
    _getSiblingOffsetPx(e, t, i) { let s = this.orientation === "horizontal", n = t[e].clientRect, o = t[e + i * -1], a = n[s ? "width" : "height"] * i; if (o) {
        let l = s ? "left" : "top", h = s ? "right" : "bottom";
        i === -1 ? a -= o.clientRect[l] - n[h] : a += n[l] - o.clientRect[h];
    } return a; }
    _shouldEnterAsFirstChild(e, t) { if (!this._activeDraggables.length)
        return !1; let i = this._itemPositions, s = this.orientation === "horizontal"; if (i[0].drag !== this._activeDraggables[0]) {
        let o = i[i.length - 1].clientRect;
        return s ? e >= o.right : t >= o.bottom;
    }
    else {
        let o = i[0].clientRect;
        return s ? e <= o.left : t <= o.top;
    } }
    _getItemIndexFromPointerPosition(e, t, i, s) { let n = this.orientation === "horizontal", o = this._itemPositions.findIndex(({ drag: a, clientRect: l }) => { if (a === e)
        return !1; if (s) {
        let h = n ? s.x : s.y;
        if (a === this._previousSwap.drag && this._previousSwap.overlaps && h === this._previousSwap.delta)
            return !1;
    } return n ? t >= Math.floor(l.left) && t < Math.floor(l.right) : i >= Math.floor(l.top) && i < Math.floor(l.bottom); }); return o === -1 || !this._sortPredicate(o, e) ? -1 : o; }
}, q = class {
    _document;
    _dragDropRegistry;
    _element;
    _sortPredicate;
    _rootNode;
    _activeItems;
    _previousSwap = { drag: null, deltaX: 0, deltaY: 0, overlaps: !1 };
    _relatedNodes = [];
    constructor(e, t) { this._document = e, this._dragDropRegistry = t; }
    start(e) { let t = this._element.childNodes; this._relatedNodes = []; for (let i = 0; i < t.length; i++) {
        let s = t[i];
        this._relatedNodes.push([s, s.nextSibling]);
    } this.withItems(e); }
    sort(e, t, i, s) { let n = this._getItemIndexFromPointerPosition(e, t, i), o = this._previousSwap; if (n === -1 || this._activeItems[n] === e)
        return null; let a = this._activeItems[n]; if (o.drag === a && o.overlaps && o.deltaX === s.x && o.deltaY === s.y)
        return null; let l = this.getItemIndex(e), h = e.getPlaceholderElement(), _ = a.getRootElement(); n > l ? _.after(h) : _.before(h), Mt(this._activeItems, l, n); let u = this._getRootNode().elementFromPoint(t, i); return o.deltaX = s.x, o.deltaY = s.y, o.drag = a, o.overlaps = _ === u || _.contains(u), { previousIndex: l, currentIndex: n }; }
    enter(e, t, i, s) { let n = this._activeItems.indexOf(e); n > -1 && this._activeItems.splice(n, 1); let o = s == null || s < 0 ? this._getItemIndexFromPointerPosition(e, t, i) : s; o === -1 && (o = this._getClosestItemIndexToPointer(e, t, i)); let a = this._activeItems[o]; a && !this._dragDropRegistry.isDragging(a) ? (this._activeItems.splice(o, 0, e), a.getRootElement().before(e.getPlaceholderElement())) : (this._activeItems.push(e), this._element.appendChild(e.getPlaceholderElement())); }
    withItems(e) { this._activeItems = e.slice(); }
    withSortPredicate(e) { this._sortPredicate = e; }
    reset() { let e = this._element, t = this._previousSwap; for (let i = this._relatedNodes.length - 1; i > -1; i--) {
        let [s, n] = this._relatedNodes[i];
        s.parentNode === e && s.nextSibling !== n && (n === null ? e.appendChild(s) : n.parentNode === e && e.insertBefore(s, n));
    } this._relatedNodes = [], this._activeItems = [], t.drag = null, t.deltaX = t.deltaY = 0, t.overlaps = !1; }
    getActiveItemsSnapshot() { return this._activeItems; }
    getItemIndex(e) { return this._activeItems.indexOf(e); }
    getItemAtIndex(e) { return this._activeItems[e] || null; }
    updateOnScroll() { this._activeItems.forEach(e => { this._dragDropRegistry.isDragging(e) && e._sortFromLastPointerPosition(); }); }
    withElementContainer(e) { e !== this._element && (this._element = e, this._rootNode = void 0); }
    _getItemIndexFromPointerPosition(e, t, i) { let s = this._getRootNode().elementFromPoint(Math.floor(t), Math.floor(i)), n = s ? this._activeItems.findIndex(o => { let a = o.getRootElement(); return s === a || a.contains(s); }) : -1; return n === -1 || !this._sortPredicate(n, e) ? -1 : n; }
    _getRootNode() { return this._rootNode || (this._rootNode = O(this._element) || this._document), this._rootNode; }
    _getClosestItemIndexToPointer(e, t, i) { if (this._activeItems.length === 0)
        return -1; if (this._activeItems.length === 1)
        return 0; let s = 1 / 0, n = -1; for (let o = 0; o < this._activeItems.length; o++) {
        let a = this._activeItems[o];
        if (a !== e) {
            let { x: l, y: h } = a.getRootElement().getBoundingClientRect(), _ = Math.hypot(t - l, i - h);
            _ < s && (s = _, n = o);
        }
    } return n; }
}, Et = .05, At = .05, m = (function (r) { return r[r.NONE = 0] = "NONE", r[r.UP = 1] = "UP", r[r.DOWN = 2] = "DOWN", r; })(m || {}), g = (function (r) { return r[r.NONE = 0] = "NONE", r[r.LEFT = 1] = "LEFT", r[r.RIGHT = 2] = "RIGHT", r; })(g || {}), $ = class {
    _dragDropRegistry;
    _ngZone;
    _viewportRuler;
    element;
    disabled = !1;
    sortingDisabled = !1;
    lockAxis;
    autoScrollDisabled = !1;
    autoScrollStep = 2;
    hasAnchor = !1;
    enterPredicate = () => !0;
    sortPredicate = () => !0;
    beforeStarted = new p;
    entered = new p;
    exited = new p;
    dropped = new p;
    sorted = new p;
    receivingStarted = new p;
    receivingStopped = new p;
    data;
    _container;
    _isDragging = !1;
    _parentPositions;
    _sortStrategy;
    _domRect;
    _draggables = [];
    _siblings = [];
    _activeSiblings = new Set;
    _viewportScrollSubscription = I.EMPTY;
    _verticalScrollDirection = m.NONE;
    _horizontalScrollDirection = g.NONE;
    _scrollNode;
    _stopScrollTimers = new p;
    _cachedShadowRoot = null;
    _document;
    _scrollableElements = [];
    _initialScrollSnap;
    _direction = "ltr";
    constructor(e, t, i, s, n) { this._dragDropRegistry = t, this._ngZone = s, this._viewportRuler = n; let o = this.element = w(e); this._document = i, this.withOrientation("vertical").withElementContainer(o), t.registerDropContainer(this), this._parentPositions = new N(i); }
    dispose() { this._stopScrolling(), this._stopScrollTimers.complete(), this._viewportScrollSubscription.unsubscribe(), this.beforeStarted.complete(), this.entered.complete(), this.exited.complete(), this.dropped.complete(), this.sorted.complete(), this.receivingStarted.complete(), this.receivingStopped.complete(), this._activeSiblings.clear(), this._scrollNode = null, this._parentPositions.clear(), this._dragDropRegistry.removeDropContainer(this); }
    isDragging() { return this._isDragging; }
    start() { this._draggingStarted(), this._notifyReceivingSiblings(); }
    enter(e, t, i, s) { this._draggingStarted(), s == null && this.sortingDisabled && (s = this._draggables.indexOf(e)), this._sortStrategy.enter(e, t, i, s), this._cacheParentPositions(), this._notifyReceivingSiblings(), this.entered.next({ item: e, container: this, currentIndex: this.getItemIndex(e) }); }
    exit(e) { this._reset(), this.exited.next({ item: e, container: this }); }
    drop(e, t, i, s, n, o, a, l = {}) { this._reset(), this.dropped.next({ item: e, currentIndex: t, previousIndex: i, container: this, previousContainer: s, isPointerOverContainer: n, distance: o, dropPoint: a, event: l }); }
    withItems(e) { let t = this._draggables; return this._draggables = e, e.forEach(i => i._withDropContainer(this)), this.isDragging() && (t.filter(s => s.isDragging()).every(s => e.indexOf(s) === -1) ? this._reset() : this._sortStrategy.withItems(this._draggables)), this; }
    withDirection(e) { return this._direction = e, this._sortStrategy instanceof A && (this._sortStrategy.direction = e), this; }
    connectedTo(e) { return this._siblings = e.slice(), this; }
    withOrientation(e) { if (e === "mixed")
        this._sortStrategy = new q(this._document, this._dragDropRegistry);
    else {
        let t = new A(this._dragDropRegistry);
        t.direction = this._direction, t.orientation = e, this._sortStrategy = t;
    } return this._sortStrategy.withElementContainer(this._container), this._sortStrategy.withSortPredicate((t, i) => this.sortPredicate(t, i, this)), this; }
    withScrollableParents(e) { let t = this._container; return this._scrollableElements = e.indexOf(t) === -1 ? [t, ...e] : e.slice(), this; }
    withElementContainer(e) { if (e === this._container)
        return this; let t = w(this.element), i = this._scrollableElements.indexOf(this._container), s = this._scrollableElements.indexOf(e); return i > -1 && this._scrollableElements.splice(i, 1), s > -1 && this._scrollableElements.splice(s, 1), this._sortStrategy && this._sortStrategy.withElementContainer(e), this._cachedShadowRoot = null, this._scrollableElements.unshift(e), this._container = e, this; }
    getScrollableParents() { return this._scrollableElements; }
    getItemIndex(e) { return this._isDragging ? this._sortStrategy.getItemIndex(e) : this._draggables.indexOf(e); }
    getItemAtIndex(e) { return this._isDragging ? this._sortStrategy.getItemAtIndex(e) : this._draggables[e] || null; }
    isReceiving() { return this._activeSiblings.size > 0; }
    _sortItem(e, t, i, s) { if (this.sortingDisabled || !this._domRect || !mt(this._domRect, Et, t, i))
        return; let n = this._sortStrategy.sort(e, t, i, s); n && this.sorted.next({ previousIndex: n.previousIndex, currentIndex: n.currentIndex, container: this, item: e }); }
    _startScrollingIfNecessary(e, t) { if (this.autoScrollDisabled)
        return; let i, s = m.NONE, n = g.NONE; if (this._parentPositions.positions.forEach((o, a) => { a === this._document || !o.clientRect || i || mt(o.clientRect, Et, e, t) && ([s, n] = de(a, o.clientRect, this._direction, e, t), (s || n) && (i = a)); }), !s && !n) {
        let { width: o, height: a } = this._viewportRuler.getViewportSize(), l = { width: o, height: a, top: 0, right: o, bottom: a, left: 0 };
        s = Ft(l, t), n = Ht(l, e), i = window;
    } i && (s !== this._verticalScrollDirection || n !== this._horizontalScrollDirection || i !== this._scrollNode) && (this._verticalScrollDirection = s, this._horizontalScrollDirection = n, this._scrollNode = i, (s || n) && i ? this._ngZone.runOutsideAngular(this._startScrollInterval) : this._stopScrolling()); }
    _stopScrolling() { this._stopScrollTimers.next(); }
    _draggingStarted() { let e = this._container.style; this.beforeStarted.next(), this._isDragging = !0, this._initialScrollSnap = e.msScrollSnapType || e.scrollSnapType || "", e.scrollSnapType = e.msScrollSnapType = "none", this._sortStrategy.start(this._draggables), this._cacheParentPositions(), this._viewportScrollSubscription.unsubscribe(), this._listenToScrollEvents(); }
    _cacheParentPositions() { this._parentPositions.cache(this._scrollableElements), this._domRect = this._parentPositions.positions.get(this._container).clientRect; }
    _reset() { this._isDragging = !1; let e = this._container.style; e.scrollSnapType = e.msScrollSnapType = this._initialScrollSnap, this._siblings.forEach(t => t._stopReceiving(this)), this._sortStrategy.reset(), this._stopScrolling(), this._viewportScrollSubscription.unsubscribe(), this._parentPositions.clear(); }
    _startScrollInterval = () => { this._stopScrolling(), Yt(0, Xt).pipe(L(this._stopScrollTimers)).subscribe(() => { let e = this._scrollNode, t = this.autoScrollStep; this._verticalScrollDirection === m.UP ? e.scrollBy(0, -t) : this._verticalScrollDirection === m.DOWN && e.scrollBy(0, t), this._horizontalScrollDirection === g.LEFT ? e.scrollBy(-t, 0) : this._horizontalScrollDirection === g.RIGHT && e.scrollBy(t, 0); }); };
    _isOverContainer(e, t) { return this._domRect != null && W(this._domRect, e, t); }
    _getSiblingContainerFromPosition(e, t, i) { return this._siblings.find(s => s._canReceive(e, t, i)); }
    _canReceive(e, t, i) { if (!this._domRect || !W(this._domRect, t, i) || !this.enterPredicate(e, this))
        return !1; let s = this._getShadowRoot().elementFromPoint(t, i); return s ? s === this._container || this._container.contains(s) : !1; }
    _startReceiving(e, t) { let i = this._activeSiblings; !i.has(e) && t.every(s => this.enterPredicate(s, this) || this._draggables.indexOf(s) > -1) && (i.add(e), this._cacheParentPositions(), this._listenToScrollEvents(), this.receivingStarted.next({ initiator: e, receiver: this, items: t })); }
    _stopReceiving(e) { this._activeSiblings.delete(e), this._viewportScrollSubscription.unsubscribe(), this.receivingStopped.next({ initiator: e, receiver: this }); }
    _listenToScrollEvents() { this._viewportScrollSubscription = this._dragDropRegistry.scrolled(this._getShadowRoot()).subscribe(e => { if (this.isDragging()) {
        let t = this._parentPositions.handleScroll(e);
        t && this._sortStrategy.updateOnScroll(t.top, t.left);
    }
    else
        this.isReceiving() && this._cacheParentPositions(); }); }
    _getShadowRoot() { if (!this._cachedShadowRoot) {
        let e = O(this._container);
        this._cachedShadowRoot = e || this._document;
    } return this._cachedShadowRoot; }
    _notifyReceivingSiblings() { let e = this._sortStrategy.getActiveItemsSnapshot().filter(t => t.isDragging()); this._siblings.forEach(t => t._startReceiving(this, e)); }
};
function Ft(r, e) { let { top: t, bottom: i, height: s } = r, n = s * At; return e >= t - n && e <= t + n ? m.UP : e >= i - n && e <= i + n ? m.DOWN : m.NONE; }
function Ht(r, e) { let { left: t, right: i, width: s } = r, n = s * At; return e >= t - n && e <= t + n ? g.LEFT : e >= i - n && e <= i + n ? g.RIGHT : g.NONE; }
function de(r, e, t, i, s) { let n = Ft(e, s), o = Ht(e, i), a = m.NONE, l = g.NONE; if (n) {
    let h = r.scrollTop;
    n === m.UP ? h > 0 && (a = m.UP) : r.scrollHeight - h > r.clientHeight && (a = m.DOWN);
} if (o) {
    let h = r.scrollLeft;
    t === "rtl" ? o === g.RIGHT ? h < 0 && (l = g.RIGHT) : r.scrollWidth + h > r.clientWidth && (l = g.LEFT) : o === g.LEFT ? h > 0 && (l = g.LEFT) : r.scrollWidth - h > r.clientWidth && (l = g.RIGHT);
} return [a, l]; }
var E = { capture: !0 }, G = { passive: !1, capture: !0 }, _e = (() => {
    class r {
        static \u0275fac = function (i) { return new (i || r); };
        static \u0275cmp = d.\u0275\u0275defineComponent({ type: r, selectors: [["ng-component"]], hostAttrs: ["cdk-drag-resets-container", ""], decls: 0, vars: 0, template: function (i, s) { }, styles: [`@layer cdk-resets{.cdk-drag-preview{background:none;border:none;padding:0;color:inherit;inset:auto}}.cdk-drag-placeholder *,.cdk-drag-preview *{pointer-events:none !important}
`], encapsulation: 2, changeDetection: 0 });
    }
    return r;
})(), et = (() => { class r {
    _ngZone = c(Y);
    _document = c(xt);
    _styleLoader = c(lt);
    _renderer = c(Ct).createRenderer(null, null);
    _cleanupDocumentTouchmove;
    _scroll = new p;
    _dropInstances = new Set;
    _dragInstances = new Set;
    _activeDragInstances = It([]);
    _globalListeners;
    _draggingPredicate = t => t.isDragging();
    _domNodesToDirectives = null;
    pointerMove = new p;
    pointerUp = new p;
    constructor() { }
    registerDropContainer(t) { this._dropInstances.has(t) || this._dropInstances.add(t); }
    registerDragItem(t) { this._dragInstances.add(t), this._dragInstances.size === 1 && this._ngZone.runOutsideAngular(() => { this._cleanupDocumentTouchmove?.(), this._cleanupDocumentTouchmove = this._renderer.listen(this._document, "touchmove", this._persistentTouchmoveListener, G); }); }
    removeDropContainer(t) { this._dropInstances.delete(t); }
    removeDragItem(t) { this._dragInstances.delete(t), this.stopDragging(t), this._dragInstances.size === 0 && this._cleanupDocumentTouchmove?.(); }
    startDragging(t, i) { if (!(this._activeDragInstances().indexOf(t) > -1) && (this._styleLoader.load(_e), this._activeDragInstances.update(s => [...s, t]), this._activeDragInstances().length === 1)) {
        let s = i.type.startsWith("touch"), n = a => this.pointerUp.next(a), o = [["scroll", a => this._scroll.next(a), E], ["selectstart", this._preventDefaultWhileDragging, G]];
        s ? o.push(["touchend", n, E], ["touchcancel", n, E]) : o.push(["mouseup", n, E]), s || o.push(["mousemove", a => this.pointerMove.next(a), G]), this._ngZone.runOutsideAngular(() => { this._globalListeners = o.map(([a, l, h]) => this._renderer.listen(this._document, a, l, h)); });
    } }
    stopDragging(t) { this._activeDragInstances.update(i => { let s = i.indexOf(t); return s > -1 ? (i.splice(s, 1), [...i]) : i; }), this._activeDragInstances().length === 0 && this._clearGlobalListeners(); }
    isDragging(t) { return this._activeDragInstances().indexOf(t) > -1; }
    scrolled(t) { let i = [this._scroll]; return t && t !== this._document && i.push(new Ot(s => this._ngZone.runOutsideAngular(() => { let n = this._renderer.listen(t, "scroll", o => { this._activeDragInstances().length && s.next(o); }, E); return () => { n(); }; }))), J(...i); }
    registerDirectiveNode(t, i) { this._domNodesToDirectives ??= new WeakMap, this._domNodesToDirectives.set(t, i); }
    removeDirectiveNode(t) { this._domNodesToDirectives?.delete(t); }
    getDragDirectiveForNode(t) { return this._domNodesToDirectives?.get(t) || null; }
    ngOnDestroy() { this._dragInstances.forEach(t => this.removeDragItem(t)), this._dropInstances.forEach(t => this.removeDropContainer(t)), this._domNodesToDirectives = null, this._clearGlobalListeners(), this.pointerMove.complete(), this.pointerUp.complete(); }
    _preventDefaultWhileDragging = t => { this._activeDragInstances().length > 0 && t.preventDefault(); };
    _persistentTouchmoveListener = t => { this._activeDragInstances().length > 0 && (this._activeDragInstances().some(this._draggingPredicate) && t.preventDefault(), this.pointerMove.next(t)); };
    _clearGlobalListeners() { this._globalListeners?.forEach(t => t()), this._globalListeners = void 0; }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = d.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })(), pe = { dragStartThreshold: 5, pointerDirectionChangeThreshold: 5 }, it = (() => { class r {
    _document = c(xt);
    _ngZone = c(Y);
    _viewportRuler = c(_t);
    _dragDropRegistry = c(et);
    _renderer = c(Ct).createRenderer(null, null);
    constructor() { }
    createDrag(t, i = pe) { return new j(t, i, this._document, this._ngZone, this._viewportRuler, this._dragDropRegistry, this._renderer); }
    createDropList(t) { return new $(t, this._dragDropRegistry, this._document, this._ngZone, this._viewportRuler); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = d.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })(), k = new P("CDK_DRAG_PARENT");
var zt = new P("CdkDragHandle"), He = (() => { class r {
    element = c(X);
    _parentDrag = c(k, { optional: !0, skipSelf: !0 });
    _dragDropRegistry = c(et);
    _stateChanges = new p;
    get disabled() { return this._disabled; }
    set disabled(t) { this._disabled = t, this._stateChanges.next(this); }
    _disabled = !1;
    constructor() { this._parentDrag?._addHandle(this); }
    ngAfterViewInit() { if (!this._parentDrag) {
        let t = this.element.nativeElement.parentElement;
        for (; t;) {
            let i = this._dragDropRegistry.getDragDirectiveForNode(t);
            if (i) {
                this._parentDrag = i, i._addHandle(this);
                break;
            }
            t = t.parentElement;
        }
    } }
    ngOnDestroy() { this._parentDrag?._removeHandle(this), this._stateChanges.complete(); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = d.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdkDragHandle", ""]], hostAttrs: [1, "cdk-drag-handle"], inputs: { disabled: [2, "cdkDragHandleDisabled", "disabled", b] }, features: [d.\u0275\u0275ProvidersFeature([{ provide: zt, useExisting: r }])] });
} return r; })(), Vt = new P("CDK_DRAG_CONFIG"), Bt = new P("CdkDropList"), ze = (() => { class r {
    element = c(X);
    dropContainer = c(Bt, { optional: !0, skipSelf: !0 });
    _ngZone = c(Y);
    _viewContainerRef = c(jt);
    _dir = c(V, { optional: !0 });
    _changeDetectorRef = c(Tt);
    _selfHandle = c(zt, { optional: !0, self: !0 });
    _parentDrag = c(k, { optional: !0, skipSelf: !0 });
    _dragDropRegistry = c(et);
    _destroyed = new p;
    _handles = new Jt([]);
    _previewTemplate;
    _placeholderTemplate;
    _dragRef;
    data;
    lockAxis;
    rootElementSelector;
    boundaryElement;
    dragStartDelay;
    freeDragPosition;
    get disabled() { return this._disabled || !!(this.dropContainer && this.dropContainer.disabled); }
    set disabled(t) { this._disabled = t, this._dragRef.disabled = this._disabled; }
    _disabled;
    constrainPosition;
    previewClass;
    previewContainer;
    scale = 1;
    started = new v;
    released = new v;
    ended = new v;
    entered = new v;
    exited = new v;
    dropped = new v;
    moved = new Ot(t => { let i = this._dragRef.moved.pipe(Qt(s => ({ source: this, pointerPosition: s.pointerPosition, event: s.event, delta: s.delta, distance: s.distance }))).subscribe(t); return () => { i.unsubscribe(); }; });
    _injector = c(qt);
    constructor() { let t = this.dropContainer, i = c(Vt, { optional: !0 }), s = c(it); this._dragRef = s.createDrag(this.element, { dragStartThreshold: i && i.dragStartThreshold != null ? i.dragStartThreshold : 5, pointerDirectionChangeThreshold: i && i.pointerDirectionChangeThreshold != null ? i.pointerDirectionChangeThreshold : 5, zIndex: i?.zIndex }), this._dragRef.data = this, this._dragDropRegistry.registerDirectiveNode(this.element.nativeElement, this), i && this._assignDefaults(i), t && (t.addItem(this), t._dropListRef.beforeStarted.pipe(L(this._destroyed)).subscribe(() => { this._dragRef.scale = this.scale; })), this._syncInputs(this._dragRef), this._handleEvents(this._dragRef); }
    getPlaceholderElement() { return this._dragRef.getPlaceholderElement(); }
    getRootElement() { return this._dragRef.getRootElement(); }
    reset() { this._dragRef.reset(); }
    resetToBoundary() { this._dragRef.resetToBoundary(); }
    getFreeDragPosition() { return this._dragRef.getFreeDragPosition(); }
    setFreeDragPosition(t) { this._dragRef.setFreeDragPosition(t); }
    ngAfterViewInit() { $t(() => { this._updateRootElement(), this._setupHandlesListener(), this._dragRef.scale = this.scale, this.freeDragPosition && this._dragRef.setFreeDragPosition(this.freeDragPosition); }, { injector: this._injector }); }
    ngOnChanges(t) { let i = t.rootElementSelector, s = t.freeDragPosition; i && !i.firstChange && this._updateRootElement(), this._dragRef.scale = this.scale, s && !s.firstChange && this.freeDragPosition && this._dragRef.setFreeDragPosition(this.freeDragPosition); }
    ngOnDestroy() { this.dropContainer && this.dropContainer.removeItem(this), this._dragDropRegistry.removeDirectiveNode(this.element.nativeElement), this._ngZone.runOutsideAngular(() => { this._handles.complete(), this._destroyed.next(), this._destroyed.complete(), this._dragRef.dispose(); }); }
    _addHandle(t) { let i = this._handles.getValue(); i.push(t), this._handles.next(i); }
    _removeHandle(t) { let i = this._handles.getValue(), s = i.indexOf(t); s > -1 && (i.splice(s, 1), this._handles.next(i)); }
    _setPreviewTemplate(t) { this._previewTemplate = t; }
    _resetPreviewTemplate(t) { t === this._previewTemplate && (this._previewTemplate = null); }
    _setPlaceholderTemplate(t) { this._placeholderTemplate = t; }
    _resetPlaceholderTemplate(t) { t === this._placeholderTemplate && (this._placeholderTemplate = null); }
    _updateRootElement() { let t = this.element.nativeElement, i = t; this.rootElementSelector && (i = t.closest !== void 0 ? t.closest(this.rootElementSelector) : t.parentElement?.closest(this.rootElementSelector)), this._dragRef.withRootElement(i || t); }
    _getBoundaryElement() { let t = this.boundaryElement; return t ? typeof t == "string" ? this.element.nativeElement.closest(t) : w(t) : null; }
    _syncInputs(t) { t.beforeStarted.subscribe(() => { if (!t.isDragging()) {
        let i = this._dir, s = this.dragStartDelay, n = this._placeholderTemplate ? { template: this._placeholderTemplate.templateRef, context: this._placeholderTemplate.data, viewContainer: this._viewContainerRef } : null, o = this._previewTemplate ? { template: this._previewTemplate.templateRef, context: this._previewTemplate.data, matchSize: this._previewTemplate.matchSize, viewContainer: this._viewContainerRef } : null;
        t.disabled = this.disabled, t.lockAxis = this.lockAxis, t.scale = this.scale, t.dragStartDelay = typeof s == "object" && s ? s : z(s), t.constrainPosition = this.constrainPosition, t.previewClass = this.previewClass, t.withBoundaryElement(this._getBoundaryElement()).withPlaceholderTemplate(n).withPreviewTemplate(o).withPreviewContainer(this.previewContainer || "global"), i && t.withDirection(i.value);
    } }), t.beforeStarted.pipe(te(1)).subscribe(() => { if (this._parentDrag) {
        t.withParent(this._parentDrag._dragRef);
        return;
    } let i = this.element.nativeElement.parentElement; for (; i;) {
        let s = this._dragDropRegistry.getDragDirectiveForNode(i);
        if (s) {
            t.withParent(s._dragRef);
            break;
        }
        i = i.parentElement;
    } }); }
    _handleEvents(t) { t.started.subscribe(i => { this.started.emit({ source: this, event: i.event }), this._changeDetectorRef.markForCheck(); }), t.released.subscribe(i => { this.released.emit({ source: this, event: i.event }); }), t.ended.subscribe(i => { this.ended.emit({ source: this, distance: i.distance, dropPoint: i.dropPoint, event: i.event }), this._changeDetectorRef.markForCheck(); }), t.entered.subscribe(i => { this.entered.emit({ container: i.container.data, item: this, currentIndex: i.currentIndex }); }), t.exited.subscribe(i => { this.exited.emit({ container: i.container.data, item: this }); }), t.dropped.subscribe(i => { this.dropped.emit({ previousIndex: i.previousIndex, currentIndex: i.currentIndex, previousContainer: i.previousContainer.data, container: i.container.data, isPointerOverContainer: i.isPointerOverContainer, item: this, distance: i.distance, dropPoint: i.dropPoint, event: i.event }); }); }
    _assignDefaults(t) { let { lockAxis: i, dragStartDelay: s, constrainPosition: n, previewClass: o, boundaryElement: a, draggingDisabled: l, rootElementSelector: h, previewContainer: _ } = t; this.disabled = l ?? !1, this.dragStartDelay = s || 0, i && (this.lockAxis = i), n && (this.constrainPosition = n), o && (this.previewClass = o), a && (this.boundaryElement = a), h && (this.rootElementSelector = h), _ && (this.previewContainer = _); }
    _setupHandlesListener() { this._handles.pipe(ee(t => { let i = t.map(s => s.element); this._selfHandle && this.rootElementSelector && i.push(this.element), this._dragRef.withHandles(i); }), ie(t => J(...t.map(i => i._stateChanges.pipe(Lt(i))))), L(this._destroyed)).subscribe(t => { let i = this._dragRef, s = t.element.nativeElement; t.disabled ? i.disableHandle(s) : i.enableHandle(s); }); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = d.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdkDrag", ""]], hostAttrs: [1, "cdk-drag"], hostVars: 4, hostBindings: function (i, s) { i & 2 && d.\u0275\u0275classProp("cdk-drag-disabled", s.disabled)("cdk-drag-dragging", s._dragRef.isDragging()); }, inputs: { data: [0, "cdkDragData", "data"], lockAxis: [0, "cdkDragLockAxis", "lockAxis"], rootElementSelector: [0, "cdkDragRootElement", "rootElementSelector"], boundaryElement: [0, "cdkDragBoundary", "boundaryElement"], dragStartDelay: [0, "cdkDragStartDelay", "dragStartDelay"], freeDragPosition: [0, "cdkDragFreeDragPosition", "freeDragPosition"], disabled: [2, "cdkDragDisabled", "disabled", b], constrainPosition: [0, "cdkDragConstrainPosition", "constrainPosition"], previewClass: [0, "cdkDragPreviewClass", "previewClass"], previewContainer: [0, "cdkDragPreviewContainer", "previewContainer"], scale: [2, "cdkDragScale", "scale", Kt] }, outputs: { started: "cdkDragStarted", released: "cdkDragReleased", ended: "cdkDragEnded", entered: "cdkDragEntered", exited: "cdkDragExited", dropped: "cdkDragDropped", moved: "cdkDragMoved" }, exportAs: ["cdkDrag"], features: [d.\u0275\u0275ProvidersFeature([{ provide: k, useExisting: r }]), d.\u0275\u0275NgOnChangesFeature] });
} return r; })(), K = new P("CdkDropListGroup"), Ve = (() => { class r {
    _items = new Set;
    disabled = !1;
    ngOnDestroy() { this._items.clear(); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = d.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdkDropListGroup", ""]], inputs: { disabled: [2, "cdkDropListGroupDisabled", "disabled", b] }, exportAs: ["cdkDropListGroup"], features: [d.\u0275\u0275ProvidersFeature([{ provide: K, useExisting: r }])] });
} return r; })(), Be = (() => { class r {
    element = c(X);
    _changeDetectorRef = c(Tt);
    _scrollDispatcher = c(dt);
    _dir = c(V, { optional: !0 });
    _group = c(K, { optional: !0, skipSelf: !0 });
    _latestSortedRefs;
    _destroyed = new p;
    _scrollableParentsResolved;
    static _dropLists = [];
    _dropListRef;
    connectedTo = [];
    data;
    orientation;
    id = c(ct).getId("cdk-drop-list-");
    lockAxis;
    get disabled() { return this._disabled || !!this._group && this._group.disabled; }
    set disabled(t) { this._dropListRef.disabled = this._disabled = t; }
    _disabled;
    sortingDisabled;
    enterPredicate = () => !0;
    sortPredicate = () => !0;
    autoScrollDisabled;
    autoScrollStep;
    elementContainerSelector;
    hasAnchor;
    dropped = new v;
    entered = new v;
    exited = new v;
    sorted = new v;
    _unsortedItems = new Set;
    constructor() { let t = c(it), i = c(Vt, { optional: !0 }); this._dropListRef = t.createDropList(this.element), this._dropListRef.data = this, i && this._assignDefaults(i), this._dropListRef.enterPredicate = (s, n) => this.enterPredicate(s.data, n.data), this._dropListRef.sortPredicate = (s, n, o) => this.sortPredicate(s, n.data, o.data), this._setupInputSyncSubscription(this._dropListRef), this._handleEvents(this._dropListRef), r._dropLists.push(this), this._group && this._group._items.add(this); }
    addItem(t) { this._unsortedItems.add(t), t._dragRef._withDropContainer(this._dropListRef), this._dropListRef.isDragging() && this._syncItemsWithRef(this.getSortedItems().map(i => i._dragRef)); }
    removeItem(t) { if (this._unsortedItems.delete(t), this._latestSortedRefs) {
        let i = this._latestSortedRefs.indexOf(t._dragRef);
        i > -1 && (this._latestSortedRefs.splice(i, 1), this._syncItemsWithRef(this._latestSortedRefs));
    } }
    getSortedItems() { return Array.from(this._unsortedItems).sort((t, i) => t._dragRef.getVisibleElement().compareDocumentPosition(i._dragRef.getVisibleElement()) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1); }
    ngOnDestroy() { let t = r._dropLists.indexOf(this); t > -1 && r._dropLists.splice(t, 1), this._group && this._group._items.delete(this), this._latestSortedRefs = void 0, this._unsortedItems.clear(), this._dropListRef.dispose(), this._destroyed.next(), this._destroyed.complete(); }
    _setupInputSyncSubscription(t) { this._dir && this._dir.change.pipe(Lt(this._dir.value), L(this._destroyed)).subscribe(i => t.withDirection(i)), t.beforeStarted.subscribe(() => { let i = ht(this.connectedTo).map(s => { if (typeof s == "string") {
        let n = r._dropLists.find(o => o.id === s);
        return n;
    } return s; }); if (this._group && this._group._items.forEach(s => { i.indexOf(s) === -1 && i.push(s); }), !this._scrollableParentsResolved) {
        let s = this._scrollDispatcher.getAncestorScrollContainers(this.element).map(n => n.getElementRef().nativeElement);
        this._dropListRef.withScrollableParents(s), this._scrollableParentsResolved = !0;
    } if (this.elementContainerSelector) {
        let s = this.element.nativeElement.querySelector(this.elementContainerSelector);
        t.withElementContainer(s);
    } t.disabled = this.disabled, t.lockAxis = this.lockAxis, t.sortingDisabled = this.sortingDisabled, t.autoScrollDisabled = this.autoScrollDisabled, t.autoScrollStep = z(this.autoScrollStep, 2), t.hasAnchor = this.hasAnchor, t.connectedTo(i.filter(s => s && s !== this).map(s => s._dropListRef)).withOrientation(this.orientation); }); }
    _handleEvents(t) { t.beforeStarted.subscribe(() => { this._syncItemsWithRef(this.getSortedItems().map(i => i._dragRef)), this._changeDetectorRef.markForCheck(); }), t.entered.subscribe(i => { this.entered.emit({ container: this, item: i.item.data, currentIndex: i.currentIndex }); }), t.exited.subscribe(i => { this.exited.emit({ container: this, item: i.item.data }), this._changeDetectorRef.markForCheck(); }), t.sorted.subscribe(i => { this.sorted.emit({ previousIndex: i.previousIndex, currentIndex: i.currentIndex, container: this, item: i.item.data }); }), t.dropped.subscribe(i => { this.dropped.emit({ previousIndex: i.previousIndex, currentIndex: i.currentIndex, previousContainer: i.previousContainer.data, container: i.container.data, item: i.item.data, isPointerOverContainer: i.isPointerOverContainer, distance: i.distance, dropPoint: i.dropPoint, event: i.event }), this._changeDetectorRef.markForCheck(); }), J(t.receivingStarted, t.receivingStopped).subscribe(() => this._changeDetectorRef.markForCheck()); }
    _assignDefaults(t) { let { lockAxis: i, draggingDisabled: s, sortingDisabled: n, listAutoScrollDisabled: o, listOrientation: a } = t; this.disabled = s ?? !1, this.sortingDisabled = n ?? !1, this.autoScrollDisabled = o ?? !1, this.orientation = a || "vertical", i && (this.lockAxis = i); }
    _syncItemsWithRef(t) { this._latestSortedRefs = t, this._dropListRef.withItems(t); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = d.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdkDropList", ""], ["cdk-drop-list"]], hostAttrs: [1, "cdk-drop-list"], hostVars: 7, hostBindings: function (i, s) { i & 2 && (d.\u0275\u0275attribute("id", s.id), d.\u0275\u0275classProp("cdk-drop-list-disabled", s.disabled)("cdk-drop-list-dragging", s._dropListRef.isDragging())("cdk-drop-list-receiving", s._dropListRef.isReceiving())); }, inputs: { connectedTo: [0, "cdkDropListConnectedTo", "connectedTo"], data: [0, "cdkDropListData", "data"], orientation: [0, "cdkDropListOrientation", "orientation"], id: "id", lockAxis: [0, "cdkDropListLockAxis", "lockAxis"], disabled: [2, "cdkDropListDisabled", "disabled", b], sortingDisabled: [2, "cdkDropListSortingDisabled", "sortingDisabled", b], enterPredicate: [0, "cdkDropListEnterPredicate", "enterPredicate"], sortPredicate: [0, "cdkDropListSortPredicate", "sortPredicate"], autoScrollDisabled: [2, "cdkDropListAutoScrollDisabled", "autoScrollDisabled", b], autoScrollStep: [0, "cdkDropListAutoScrollStep", "autoScrollStep"], elementContainerSelector: [0, "cdkDropListElementContainer", "elementContainerSelector"], hasAnchor: [2, "cdkDropListHasAnchor", "hasAnchor", b] }, outputs: { dropped: "cdkDropListDropped", entered: "cdkDropListEntered", exited: "cdkDropListExited", sorted: "cdkDropListSorted" }, exportAs: ["cdkDropList"], features: [d.\u0275\u0275ProvidersFeature([{ provide: K, useValue: void 0 }, { provide: Bt, useExisting: r }])] });
} return r; })(), ge = new P("CdkDragPreview"), Ge = (() => { class r {
    templateRef = c(kt);
    _drag = c(k, { optional: !0 });
    data;
    matchSize = !1;
    constructor() { this._drag?._setPreviewTemplate(this); }
    ngOnDestroy() { this._drag?._resetPreviewTemplate(this); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = d.\u0275\u0275defineDirective({ type: r, selectors: [["ng-template", "cdkDragPreview", ""]], inputs: { data: "data", matchSize: [2, "matchSize", "matchSize", b] }, features: [d.\u0275\u0275ProvidersFeature([{ provide: ge, useExisting: r }])] });
} return r; })(), ue = new P("CdkDragPlaceholder"), Ue = (() => { class r {
    templateRef = c(kt);
    _drag = c(k, { optional: !0 });
    data;
    constructor() { this._drag?._setPlaceholderTemplate(this); }
    ngOnDestroy() { this._drag?._resetPlaceholderTemplate(this); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = d.\u0275\u0275defineDirective({ type: r, selectors: [["ng-template", "cdkDragPlaceholder", ""]], inputs: { data: "data" }, features: [d.\u0275\u0275ProvidersFeature([{ provide: ue, useExisting: r }])] });
} return r; })();
var We = (() => { class r {
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275mod = d.\u0275\u0275defineNgModule({ type: r });
    static \u0275inj = d.\u0275\u0275defineInjector({ providers: [it], imports: [pt] });
} return r; })();
export { Vt as CDK_DRAG_CONFIG, zt as CDK_DRAG_HANDLE, k as CDK_DRAG_PARENT, ue as CDK_DRAG_PLACEHOLDER, ge as CDK_DRAG_PREVIEW, Bt as CDK_DROP_LIST, K as CDK_DROP_LIST_GROUP, ze as CdkDrag, He as CdkDragHandle, Ue as CdkDragPlaceholder, Ge as CdkDragPreview, Be as CdkDropList, Ve as CdkDropListGroup, it as DragDrop, We as DragDropModule, et as DragDropRegistry, j as DragRef, $ as DropListRef, Fe as copyArrayItem, Mt as moveItemInArray, Ae as transferArrayItem, Zt as \u0275\u0275CdkScrollable };
