function n(r) { return r == null ? "" : typeof r == "string" ? r : `${r}px`; }
export { n as a };
