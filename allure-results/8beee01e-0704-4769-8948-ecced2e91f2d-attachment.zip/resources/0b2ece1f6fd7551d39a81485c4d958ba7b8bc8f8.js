import { a as t } from "@nf-internal/chunk-JLNKCSJ3";
var e = class extends t {
    setActiveItem(i) { this.activeItem && this.activeItem.setInactiveStyles(), super.setActiveItem(i), this.activeItem && this.activeItem.setActiveStyles(); }
};
export { e as a };
