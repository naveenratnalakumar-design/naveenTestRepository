import { a as T } from "@nf-internal/chunk-PJPD4VSJ";
import { c as it, f as st, k as ot } from "@nf-internal/chunk-NPG5RFMM";
import { f as L, i as x, q as I } from "@nf-internal/chunk-P223Q223";
import { b as nt } from "@nf-internal/chunk-ITP4ZIB2";
import { a as A } from "@nf-internal/chunk-7N7HFQKY";
import { d as D } from "@nf-internal/chunk-OIQ2QPHM";
import { a as tt } from "@nf-internal/chunk-SVIUGILY";
import { k as kt } from "@nf-internal/chunk-N26NRATF";
import { a as B } from "@nf-internal/chunk-DQM2BKPX";
import { a as Q } from "@nf-internal/chunk-G25BAKAM";
import { b as et } from "@nf-internal/chunk-OI5KCOOP";
import { c as X } from "@nf-internal/chunk-3C63DHR6";
import { a as p } from "@nf-internal/chunk-K3GOACLW";
import { a as Y } from "@nf-internal/chunk-FSAIB72R";
import { a as E, b as J } from "@nf-internal/chunk-66YHNWRR";
import * as f from "@angular/core";
import { DOCUMENT as P, NgZone as S, inject as d, Injector as C, RendererFactory2 as K, afterNextRender as rt, ElementRef as G, ApplicationRef as St, Renderer2 as Ct, ANIMATION_MODULE_TYPE as xt, EnvironmentInjector as Rt, InjectionToken as Pt, EventEmitter as b, TemplateRef as Et, ViewContainerRef as Dt, booleanAttribute as w } from "@angular/core";
import { Location as Bt } from "@angular/common";
import { Subject as O, Subscription as k } from "rxjs";
import { filter as Mt, takeWhile as At } from "rxjs/operators";
var at = nt();
function Yt(s) { return new V(s.get(x), s.get(P)); }
var V = class {
    _viewportRuler;
    _previousHTMLStyles = { top: "", left: "" };
    _previousScrollPosition;
    _isEnabled = !1;
    _document;
    constructor(t, e) { this._viewportRuler = t, this._document = e; }
    attach() { }
    enable() { if (this._canBeEnabled()) {
        let t = this._document.documentElement;
        this._previousScrollPosition = this._viewportRuler.getViewportScrollPosition(), this._previousHTMLStyles.left = t.style.left || "", this._previousHTMLStyles.top = t.style.top || "", t.style.left = p(-this._previousScrollPosition.left), t.style.top = p(-this._previousScrollPosition.top), t.classList.add("cdk-global-scrollblock"), this._isEnabled = !0;
    } }
    disable() { if (this._isEnabled) {
        let t = this._document.documentElement, e = this._document.body, i = t.style, o = e.style, n = i.scrollBehavior || "", r = o.scrollBehavior || "";
        this._isEnabled = !1, i.left = this._previousHTMLStyles.left, i.top = this._previousHTMLStyles.top, t.classList.remove("cdk-global-scrollblock"), at && (i.scrollBehavior = o.scrollBehavior = "auto"), window.scroll(this._previousScrollPosition.left, this._previousScrollPosition.top), at && (i.scrollBehavior = n, o.scrollBehavior = r);
    } }
    _canBeEnabled() { if (this._document.documentElement.classList.contains("cdk-global-scrollblock") || this._isEnabled)
        return !1; let e = this._document.documentElement, i = this._viewportRuler.getViewportSize(); return e.scrollHeight > i.height || e.scrollWidth > i.width; }
};
function Xt(s, t) { return new H(s.get(L), s.get(S), s.get(x), t); }
var H = class {
    _scrollDispatcher;
    _ngZone;
    _viewportRuler;
    _config;
    _scrollSubscription = null;
    _overlayRef;
    _initialScrollPosition;
    constructor(t, e, i, o) { this._scrollDispatcher = t, this._ngZone = e, this._viewportRuler = i, this._config = o; }
    attach(t) { this._overlayRef, this._overlayRef = t; }
    enable() { if (this._scrollSubscription)
        return; let t = this._scrollDispatcher.scrolled(0).pipe(Mt(e => !e || !this._overlayRef.overlayElement.contains(e.getElementRef().nativeElement))); this._config && this._config.threshold && this._config.threshold > 1 ? (this._initialScrollPosition = this._viewportRuler.getViewportScrollPosition().top, this._scrollSubscription = t.subscribe(() => { let e = this._viewportRuler.getViewportScrollPosition().top; Math.abs(e - this._initialScrollPosition) > this._config.threshold ? this._detach() : this._overlayRef.updatePosition(); })) : this._scrollSubscription = t.subscribe(this._detach); }
    disable() { this._scrollSubscription && (this._scrollSubscription.unsubscribe(), this._scrollSubscription = null); }
    detach() { this.disable(), this._overlayRef = null; }
    _detach = () => { this.disable(), this._overlayRef.hasAttached() && this._ngZone.run(() => this._overlayRef.detach()); };
};
function ve() { return new R; }
var R = class {
    enable() { }
    disable() { }
    attach() { }
};
function F(s, t) { return t.some(e => { let i = s.bottom < e.top, o = s.top > e.bottom, n = s.right < e.left, r = s.left > e.right; return i || o || n || r; }); }
function lt(s, t) { return t.some(e => { let i = s.top < e.top, o = s.bottom > e.bottom, n = s.left < e.left, r = s.right > e.right; return i || o || n || r; }); }
function q(s, t) { return new W(s.get(L), s.get(x), s.get(S), t); }
var W = class {
    _scrollDispatcher;
    _viewportRuler;
    _ngZone;
    _config;
    _scrollSubscription = null;
    _overlayRef;
    constructor(t, e, i, o) { this._scrollDispatcher = t, this._viewportRuler = e, this._ngZone = i, this._config = o; }
    attach(t) { this._overlayRef, this._overlayRef = t; }
    enable() { if (!this._scrollSubscription) {
        let t = this._config ? this._config.scrollThrottle : 0;
        this._scrollSubscription = this._scrollDispatcher.scrolled(t).subscribe(() => { if (this._overlayRef.updatePosition(), this._config && this._config.autoClose) {
            let e = this._overlayRef.overlayElement.getBoundingClientRect(), { width: i, height: o } = this._viewportRuler.getViewportSize();
            F(e, [{ width: i, height: o, bottom: o, right: i, top: 0, left: 0 }]) && (this.disable(), this._ngZone.run(() => this._overlayRef.detach()));
        } });
    } }
    disable() { this._scrollSubscription && (this._scrollSubscription.unsubscribe(), this._scrollSubscription = null); }
    detach() { this.disable(), this._overlayRef = null; }
}, Tt = (() => { class s {
    _injector = d(C);
    constructor() { }
    noop = () => new R;
    close = e => Xt(this._injector, e);
    block = () => Yt(this._injector);
    reposition = e => q(this._injector, e);
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), M = class {
    positionStrategy;
    scrollStrategy = new R;
    panelClass = "";
    hasBackdrop = !1;
    backdropClass = "cdk-overlay-dark-backdrop";
    disableAnimations;
    width;
    height;
    minWidth;
    minHeight;
    maxWidth;
    maxHeight;
    direction;
    disposeOnNavigation = !1;
    constructor(t) { if (t) {
        let e = Object.keys(t);
        for (let i of e)
            t[i] !== void 0 && (this[i] = t[i]);
    } }
}, ht = class {
    offsetX;
    offsetY;
    panelClass;
    originX;
    originY;
    overlayX;
    overlayY;
    constructor(t, e, i, o, n) { this.offsetX = i, this.offsetY = o, this.panelClass = n, this.originX = t.originX, this.originY = t.originY, this.overlayX = e.overlayX, this.overlayY = e.overlayY; }
}, ct = class {
    isOriginClipped;
    isOriginOutsideView;
    isOverlayClipped;
    isOverlayOutsideView;
}, N = class {
    connectionPair;
    scrollableViewProperties;
    constructor(t, e) { this.connectionPair = t, this.scrollableViewProperties = e; }
};
function me(s, t) { if (t !== "top" && t !== "bottom" && t !== "center")
    throw Error(`ConnectedPosition: Invalid ${s} "${t}". Expected "top", "bottom" or "center".`); }
function be(s, t) { if (t !== "start" && t !== "end" && t !== "center")
    throw Error(`ConnectedPosition: Invalid ${s} "${t}". Expected "start", "end" or "center".`); }
var yt = (() => { class s {
    _attachedOverlays = [];
    _document = d(P);
    _isAttached;
    constructor() { }
    ngOnDestroy() { this.detach(); }
    add(e) { this.remove(e), this._attachedOverlays.push(e); }
    remove(e) { let i = this._attachedOverlays.indexOf(e); i > -1 && this._attachedOverlays.splice(i, 1), this._attachedOverlays.length === 0 && this.detach(); }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), Lt = (() => { class s extends yt {
    _ngZone = d(S);
    _renderer = d(K).createRenderer(null, null);
    _cleanupKeydown;
    add(e) { super.add(e), this._isAttached || (this._ngZone.runOutsideAngular(() => { this._cleanupKeydown = this._renderer.listen("body", "keydown", this._keydownListener); }), this._isAttached = !0); }
    detach() { this._isAttached && (this._cleanupKeydown?.(), this._isAttached = !1); }
    _keydownListener = e => { let i = this._attachedOverlays; for (let o = i.length - 1; o > -1; o--)
        if (i[o]._keydownEvents.observers.length > 0) {
            this._ngZone.run(() => i[o]._keydownEvents.next(e));
            break;
        } };
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = f.\u0275\u0275getInheritedFactory(s)))(o || s); }; })();
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), It = (() => { class s extends yt {
    _platform = d(B);
    _ngZone = d(S);
    _renderer = d(K).createRenderer(null, null);
    _cursorOriginalValue;
    _cursorStyleIsSet = !1;
    _pointerDownEventTarget;
    _cleanups;
    add(e) { if (super.add(e), !this._isAttached) {
        let i = this._document.body, o = { capture: !0 }, n = this._renderer;
        this._cleanups = this._ngZone.runOutsideAngular(() => [n.listen(i, "pointerdown", this._pointerDownListener, o), n.listen(i, "click", this._clickListener, o), n.listen(i, "auxclick", this._clickListener, o), n.listen(i, "contextmenu", this._clickListener, o)]), this._platform.IOS && !this._cursorStyleIsSet && (this._cursorOriginalValue = i.style.cursor, i.style.cursor = "pointer", this._cursorStyleIsSet = !0), this._isAttached = !0;
    } }
    detach() { this._isAttached && (this._cleanups?.forEach(e => e()), this._cleanups = void 0, this._platform.IOS && this._cursorStyleIsSet && (this._document.body.style.cursor = this._cursorOriginalValue, this._cursorStyleIsSet = !1), this._isAttached = !1); }
    _pointerDownListener = e => { this._pointerDownEventTarget = D(e); };
    _clickListener = e => { let i = D(e), o = e.type === "click" && this._pointerDownEventTarget ? this._pointerDownEventTarget : i; this._pointerDownEventTarget = null; let n = this._attachedOverlays.slice(); for (let r = n.length - 1; r > -1; r--) {
        let a = n[r];
        if (a._outsidePointerEvents.observers.length < 1 || !a.hasAttached())
            continue;
        if (dt(a.overlayElement, i) || dt(a.overlayElement, o))
            break;
        let h = a._outsidePointerEvents;
        this._ngZone ? this._ngZone.run(() => h.next(e)) : h.next(e);
    } };
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = f.\u0275\u0275getInheritedFactory(s)))(o || s); }; })();
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })();
function dt(s, t) { let e = typeof ShadowRoot < "u" && ShadowRoot, i = t; for (; i;) {
    if (i === s)
        return !0;
    i = e && i instanceof ShadowRoot ? i.host : i.parentNode;
} return !1; }
var vt = (() => {
    class s {
        static \u0275fac = function (i) { return new (i || s); };
        static \u0275cmp = f.\u0275\u0275defineComponent({ type: s, selectors: [["ng-component"]], hostAttrs: ["cdk-overlay-style-loader", ""], decls: 0, vars: 0, template: function (i, o) { }, styles: [`.cdk-overlay-container,.cdk-global-overlay-wrapper{pointer-events:none;top:0;left:0;height:100%;width:100%}.cdk-overlay-container{position:fixed}@layer cdk-overlay{.cdk-overlay-container{z-index:1000}}.cdk-overlay-container:empty{display:none}.cdk-global-overlay-wrapper{display:flex;position:absolute}@layer cdk-overlay{.cdk-global-overlay-wrapper{z-index:1000}}.cdk-overlay-pane{position:absolute;pointer-events:auto;box-sizing:border-box;display:flex;max-width:100%;max-height:100%}@layer cdk-overlay{.cdk-overlay-pane{z-index:1000}}.cdk-overlay-backdrop{position:absolute;top:0;bottom:0;left:0;right:0;pointer-events:auto;-webkit-tap-highlight-color:rgba(0,0,0,0);opacity:0;touch-action:manipulation}@layer cdk-overlay{.cdk-overlay-backdrop{z-index:1000;transition:opacity 400ms cubic-bezier(0.25, 0.8, 0.25, 1)}}@media(prefers-reduced-motion){.cdk-overlay-backdrop{transition-duration:1ms}}.cdk-overlay-backdrop-showing{opacity:1}@media(forced-colors: active){.cdk-overlay-backdrop-showing{opacity:.6}}@layer cdk-overlay{.cdk-overlay-dark-backdrop{background:rgba(0,0,0,.32)}}.cdk-overlay-transparent-backdrop{transition:visibility 1ms linear,opacity 1ms linear;visibility:hidden;opacity:1}.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing,.cdk-high-contrast-active .cdk-overlay-transparent-backdrop{opacity:0;visibility:visible}.cdk-overlay-backdrop-noop-animation{transition:none}.cdk-overlay-connected-position-bounding-box{position:absolute;display:flex;flex-direction:column;min-width:1px;min-height:1px}@layer cdk-overlay{.cdk-overlay-connected-position-bounding-box{z-index:1000}}.cdk-global-scrollblock{position:fixed;width:100%;overflow-y:scroll}
`], encapsulation: 2, changeDetection: 0 });
    }
    return s;
})(), mt = (() => { class s {
    _platform = d(B);
    _containerElement;
    _document = d(P);
    _styleLoader = d(A);
    constructor() { }
    ngOnDestroy() { this._containerElement?.remove(); }
    getContainerElement() { return this._loadStyles(), this._containerElement || this._createContainer(), this._containerElement; }
    _createContainer() { let e = "cdk-overlay-container"; if (this._platform.isBrowser || T()) {
        let o = this._document.querySelectorAll(`.${e}[platform="server"], .${e}[platform="test"]`);
        for (let n = 0; n < o.length; n++)
            o[n].remove();
    } let i = this._document.createElement("div"); i.classList.add(e), T() ? i.setAttribute("platform", "test") : this._platform.isBrowser || i.setAttribute("platform", "server"), this._document.body.appendChild(i), this._containerElement = i; }
    _loadStyles() { this._styleLoader.load(vt); }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), z = class {
    _renderer;
    _ngZone;
    element;
    _cleanupClick;
    _cleanupTransitionEnd;
    _fallbackTimeout;
    constructor(t, e, i, o) { this._renderer = e, this._ngZone = i, this.element = t.createElement("div"), this.element.classList.add("cdk-overlay-backdrop"), this._cleanupClick = e.listen(this.element, "click", o); }
    detach() { this._ngZone.runOutsideAngular(() => { let t = this.element; clearTimeout(this._fallbackTimeout), this._cleanupTransitionEnd?.(), this._cleanupTransitionEnd = this._renderer.listen(t, "transitionend", this.dispose), this._fallbackTimeout = setTimeout(this.dispose, 500), t.style.pointerEvents = "none", t.classList.remove("cdk-overlay-backdrop-showing"); }); }
    dispose = () => { clearTimeout(this._fallbackTimeout), this._cleanupClick?.(), this._cleanupTransitionEnd?.(), this._cleanupClick = this._cleanupTransitionEnd = this._fallbackTimeout = void 0, this.element.remove(); };
}, Z = class {
    _portalOutlet;
    _host;
    _pane;
    _config;
    _ngZone;
    _keyboardDispatcher;
    _document;
    _location;
    _outsideClickDispatcher;
    _animationsDisabled;
    _injector;
    _renderer;
    _backdropClick = new O;
    _attachments = new O;
    _detachments = new O;
    _positionStrategy;
    _scrollStrategy;
    _locationChanges = k.EMPTY;
    _backdropRef = null;
    _detachContentMutationObserver;
    _detachContentAfterRenderRef;
    _previousHostParent;
    _keydownEvents = new O;
    _outsidePointerEvents = new O;
    _afterNextRenderRef;
    constructor(t, e, i, o, n, r, a, h, c, l = !1, _, v) { this._portalOutlet = t, this._host = e, this._pane = i, this._config = o, this._ngZone = n, this._keyboardDispatcher = r, this._document = a, this._location = h, this._outsideClickDispatcher = c, this._animationsDisabled = l, this._injector = _, this._renderer = v, o.scrollStrategy && (this._scrollStrategy = o.scrollStrategy, this._scrollStrategy.attach(this)), this._positionStrategy = o.positionStrategy; }
    get overlayElement() { return this._pane; }
    get backdropElement() { return this._backdropRef?.element || null; }
    get hostElement() { return this._host; }
    attach(t) { !this._host.parentElement && this._previousHostParent && this._previousHostParent.appendChild(this._host); let e = this._portalOutlet.attach(t); return this._positionStrategy && this._positionStrategy.attach(this), this._updateStackingOrder(), this._updateElementSize(), this._updateElementDirection(), this._scrollStrategy && this._scrollStrategy.enable(), this._afterNextRenderRef?.destroy(), this._afterNextRenderRef = rt(() => { this.hasAttached() && this.updatePosition(); }, { injector: this._injector }), this._togglePointerEvents(!0), this._config.hasBackdrop && this._attachBackdrop(), this._config.panelClass && this._toggleClasses(this._pane, this._config.panelClass, !0), this._attachments.next(), this._completeDetachContent(), this._keyboardDispatcher.add(this), this._config.disposeOnNavigation && (this._locationChanges = this._location.subscribe(() => this.dispose())), this._outsideClickDispatcher.add(this), typeof e?.onDestroy == "function" && e.onDestroy(() => { this.hasAttached() && this._ngZone.runOutsideAngular(() => Promise.resolve().then(() => this.detach())); }), e; }
    detach() { if (!this.hasAttached())
        return; this.detachBackdrop(), this._togglePointerEvents(!1), this._positionStrategy && this._positionStrategy.detach && this._positionStrategy.detach(), this._scrollStrategy && this._scrollStrategy.disable(); let t = this._portalOutlet.detach(); return this._detachments.next(), this._completeDetachContent(), this._keyboardDispatcher.remove(this), this._detachContentWhenEmpty(), this._locationChanges.unsubscribe(), this._outsideClickDispatcher.remove(this), t; }
    dispose() { let t = this.hasAttached(); this._positionStrategy && this._positionStrategy.dispose(), this._disposeScrollStrategy(), this._backdropRef?.dispose(), this._locationChanges.unsubscribe(), this._keyboardDispatcher.remove(this), this._portalOutlet.dispose(), this._attachments.complete(), this._backdropClick.complete(), this._keydownEvents.complete(), this._outsidePointerEvents.complete(), this._outsideClickDispatcher.remove(this), this._host?.remove(), this._afterNextRenderRef?.destroy(), this._previousHostParent = this._pane = this._host = this._backdropRef = null, t && this._detachments.next(), this._detachments.complete(), this._completeDetachContent(); }
    hasAttached() { return this._portalOutlet.hasAttached(); }
    backdropClick() { return this._backdropClick; }
    attachments() { return this._attachments; }
    detachments() { return this._detachments; }
    keydownEvents() { return this._keydownEvents; }
    outsidePointerEvents() { return this._outsidePointerEvents; }
    getConfig() { return this._config; }
    updatePosition() { this._positionStrategy && this._positionStrategy.apply(); }
    updatePositionStrategy(t) { t !== this._positionStrategy && (this._positionStrategy && this._positionStrategy.dispose(), this._positionStrategy = t, this.hasAttached() && (t.attach(this), this.updatePosition())); }
    updateSize(t) { this._config = E(E({}, this._config), t), this._updateElementSize(); }
    setDirection(t) { this._config = J(E({}, this._config), { direction: t }), this._updateElementDirection(); }
    addPanelClass(t) { this._pane && this._toggleClasses(this._pane, t, !0); }
    removePanelClass(t) { this._pane && this._toggleClasses(this._pane, t, !1); }
    getDirection() { let t = this._config.direction; return t ? typeof t == "string" ? t : t.value : "ltr"; }
    updateScrollStrategy(t) { t !== this._scrollStrategy && (this._disposeScrollStrategy(), this._scrollStrategy = t, this.hasAttached() && (t.attach(this), t.enable())); }
    _updateElementDirection() { this._host.setAttribute("dir", this.getDirection()); }
    _updateElementSize() { if (!this._pane)
        return; let t = this._pane.style; t.width = p(this._config.width), t.height = p(this._config.height), t.minWidth = p(this._config.minWidth), t.minHeight = p(this._config.minHeight), t.maxWidth = p(this._config.maxWidth), t.maxHeight = p(this._config.maxHeight); }
    _togglePointerEvents(t) { this._pane.style.pointerEvents = t ? "" : "none"; }
    _attachBackdrop() { let t = "cdk-overlay-backdrop-showing"; this._backdropRef?.dispose(), this._backdropRef = new z(this._document, this._renderer, this._ngZone, e => { this._backdropClick.next(e); }), this._animationsDisabled && this._backdropRef.element.classList.add("cdk-overlay-backdrop-noop-animation"), this._config.backdropClass && this._toggleClasses(this._backdropRef.element, this._config.backdropClass, !0), this._host.parentElement.insertBefore(this._backdropRef.element, this._host), !this._animationsDisabled && typeof requestAnimationFrame < "u" ? this._ngZone.runOutsideAngular(() => { requestAnimationFrame(() => this._backdropRef?.element.classList.add(t)); }) : this._backdropRef.element.classList.add(t); }
    _updateStackingOrder() { this._host.nextSibling && this._host.parentNode.appendChild(this._host); }
    detachBackdrop() { this._animationsDisabled ? (this._backdropRef?.dispose(), this._backdropRef = null) : this._backdropRef?.detach(); }
    _toggleClasses(t, e, i) { let o = Y(e || []).filter(n => !!n); o.length && (i ? t.classList.add(...o) : t.classList.remove(...o)); }
    _detachContentWhenEmpty() { let t = !1; try {
        this._detachContentAfterRenderRef = rt(() => { t = !0, this._detachContent(); }, { injector: this._injector });
    }
    catch (e) {
        if (t)
            throw e;
        this._detachContent();
    } globalThis.MutationObserver && this._pane && (this._detachContentMutationObserver ||= new globalThis.MutationObserver(() => { this._detachContent(); }), this._detachContentMutationObserver.observe(this._pane, { childList: !0 })); }
    _detachContent() { (!this._pane || !this._host || this._pane.children.length === 0) && (this._pane && this._config.panelClass && this._toggleClasses(this._pane, this._config.panelClass, !1), this._host && this._host.parentElement && (this._previousHostParent = this._host.parentElement, this._host.remove()), this._completeDetachContent()); }
    _completeDetachContent() { this._detachContentAfterRenderRef?.destroy(), this._detachContentAfterRenderRef = void 0, this._detachContentMutationObserver?.disconnect(); }
    _disposeScrollStrategy() { let t = this._scrollStrategy; t?.disable(), t?.detach?.(); }
}, _t = "cdk-overlay-connected-position-bounding-box", Vt = /([A-Za-z%]+)$/;
function bt(s, t) { return new j(t, s.get(x), s.get(P), s.get(B), s.get(mt)); }
var j = class {
    _viewportRuler;
    _document;
    _platform;
    _overlayContainer;
    _overlayRef;
    _isInitialRender;
    _lastBoundingBoxSize = { width: 0, height: 0 };
    _isPushed = !1;
    _canPush = !0;
    _growAfterOpen = !1;
    _hasFlexibleDimensions = !0;
    _positionLocked = !1;
    _originRect;
    _overlayRect;
    _viewportRect;
    _containerRect;
    _viewportMargin = 0;
    _scrollables = [];
    _preferredPositions = [];
    _origin;
    _pane;
    _isDisposed;
    _boundingBox;
    _lastPosition;
    _lastScrollVisibility;
    _positionChanges = new O;
    _resizeSubscription = k.EMPTY;
    _offsetX = 0;
    _offsetY = 0;
    _transformOriginSelector;
    _appliedPanelClasses = [];
    _previousPushAmount;
    positionChanges = this._positionChanges;
    get positions() { return this._preferredPositions; }
    constructor(t, e, i, o, n) { this._viewportRuler = e, this._document = i, this._platform = o, this._overlayContainer = n, this.setOrigin(t); }
    attach(t) { this._overlayRef && this._overlayRef, this._validatePositions(), t.hostElement.classList.add(_t), this._overlayRef = t, this._boundingBox = t.hostElement, this._pane = t.overlayElement, this._isDisposed = !1, this._isInitialRender = !0, this._lastPosition = null, this._resizeSubscription.unsubscribe(), this._resizeSubscription = this._viewportRuler.change().subscribe(() => { this._isInitialRender = !0, this.apply(); }); }
    apply() { if (this._isDisposed || !this._platform.isBrowser)
        return; if (!this._isInitialRender && this._positionLocked && this._lastPosition) {
        this.reapplyLastPosition();
        return;
    } this._clearPanelClasses(), this._resetOverlayElementStyles(), this._resetBoundingBoxStyles(), this._viewportRect = this._getNarrowedViewportRect(), this._originRect = this._getOriginRect(), this._overlayRect = this._pane.getBoundingClientRect(), this._containerRect = this._overlayContainer.getContainerElement().getBoundingClientRect(); let t = this._originRect, e = this._overlayRect, i = this._viewportRect, o = this._containerRect, n = [], r; for (let a of this._preferredPositions) {
        let h = this._getOriginPoint(t, o, a), c = this._getOverlayPoint(h, e, a), l = this._getOverlayFit(c, e, i, a);
        if (l.isCompletelyWithinViewport) {
            this._isPushed = !1, this._applyPosition(a, h);
            return;
        }
        if (this._canFitWithFlexibleDimensions(l, c, i)) {
            n.push({ position: a, origin: h, overlayRect: e, boundingBoxRect: this._calculateBoundingBoxRect(h, a) });
            continue;
        }
        (!r || r.overlayFit.visibleArea < l.visibleArea) && (r = { overlayFit: l, overlayPoint: c, originPoint: h, position: a, overlayRect: e });
    } if (n.length) {
        let a = null, h = -1;
        for (let c of n) {
            let l = c.boundingBoxRect.width * c.boundingBoxRect.height * (c.position.weight || 1);
            l > h && (h = l, a = c);
        }
        this._isPushed = !1, this._applyPosition(a.position, a.origin);
        return;
    } if (this._canPush) {
        this._isPushed = !0, this._applyPosition(r.position, r.originPoint);
        return;
    } this._applyPosition(r.position, r.originPoint); }
    detach() { this._clearPanelClasses(), this._lastPosition = null, this._previousPushAmount = null, this._resizeSubscription.unsubscribe(); }
    dispose() { this._isDisposed || (this._boundingBox && m(this._boundingBox.style, { top: "", left: "", right: "", bottom: "", height: "", width: "", alignItems: "", justifyContent: "" }), this._pane && this._resetOverlayElementStyles(), this._overlayRef && this._overlayRef.hostElement.classList.remove(_t), this.detach(), this._positionChanges.complete(), this._overlayRef = this._boundingBox = null, this._isDisposed = !0); }
    reapplyLastPosition() { if (this._isDisposed || !this._platform.isBrowser)
        return; let t = this._lastPosition; if (t) {
        this._originRect = this._getOriginRect(), this._overlayRect = this._pane.getBoundingClientRect(), this._viewportRect = this._getNarrowedViewportRect(), this._containerRect = this._overlayContainer.getContainerElement().getBoundingClientRect();
        let e = this._getOriginPoint(this._originRect, this._containerRect, t);
        this._applyPosition(t, e);
    }
    else
        this.apply(); }
    withScrollableContainers(t) { return this._scrollables = t, this; }
    withPositions(t) { return this._preferredPositions = t, t.indexOf(this._lastPosition) === -1 && (this._lastPosition = null), this._validatePositions(), this; }
    withViewportMargin(t) { return this._viewportMargin = t, this; }
    withFlexibleDimensions(t = !0) { return this._hasFlexibleDimensions = t, this; }
    withGrowAfterOpen(t = !0) { return this._growAfterOpen = t, this; }
    withPush(t = !0) { return this._canPush = t, this; }
    withLockedPosition(t = !0) { return this._positionLocked = t, this; }
    setOrigin(t) { return this._origin = t, this; }
    withDefaultOffsetX(t) { return this._offsetX = t, this; }
    withDefaultOffsetY(t) { return this._offsetY = t, this; }
    withTransformOriginOn(t) { return this._transformOriginSelector = t, this; }
    _getOriginPoint(t, e, i) { let o; if (i.originX == "center")
        o = t.left + t.width / 2;
    else {
        let r = this._isRtl() ? t.right : t.left, a = this._isRtl() ? t.left : t.right;
        o = i.originX == "start" ? r : a;
    } e.left < 0 && (o -= e.left); let n; return i.originY == "center" ? n = t.top + t.height / 2 : n = i.originY == "top" ? t.top : t.bottom, e.top < 0 && (n -= e.top), { x: o, y: n }; }
    _getOverlayPoint(t, e, i) { let o; i.overlayX == "center" ? o = -e.width / 2 : i.overlayX === "start" ? o = this._isRtl() ? -e.width : 0 : o = this._isRtl() ? 0 : -e.width; let n; return i.overlayY == "center" ? n = -e.height / 2 : n = i.overlayY == "top" ? 0 : -e.height, { x: t.x + o, y: t.y + n }; }
    _getOverlayFit(t, e, i, o) { let n = pt(e), { x: r, y: a } = t, h = this._getOffset(o, "x"), c = this._getOffset(o, "y"); h && (r += h), c && (a += c); let l = 0 - r, _ = r + n.width - i.width, v = 0 - a, u = a + n.height - i.height, g = this._subtractOverflows(n.width, l, _), y = this._subtractOverflows(n.height, v, u), U = g * y; return { visibleArea: U, isCompletelyWithinViewport: n.width * n.height === U, fitsInViewportVertically: y === n.height, fitsInViewportHorizontally: g == n.width }; }
    _canFitWithFlexibleDimensions(t, e, i) { if (this._hasFlexibleDimensions) {
        let o = i.bottom - e.y, n = i.right - e.x, r = ft(this._overlayRef.getConfig().minHeight), a = ft(this._overlayRef.getConfig().minWidth), h = t.fitsInViewportVertically || r != null && r <= o, c = t.fitsInViewportHorizontally || a != null && a <= n;
        return h && c;
    } return !1; }
    _pushOverlayOnScreen(t, e, i) { if (this._previousPushAmount && this._positionLocked)
        return { x: t.x + this._previousPushAmount.x, y: t.y + this._previousPushAmount.y }; let o = pt(e), n = this._viewportRect, r = Math.max(t.x + o.width - n.width, 0), a = Math.max(t.y + o.height - n.height, 0), h = Math.max(n.top - i.top - t.y, 0), c = Math.max(n.left - i.left - t.x, 0), l = 0, _ = 0; return o.width <= n.width ? l = c || -r : l = t.x < this._viewportMargin ? n.left - i.left - t.x : 0, o.height <= n.height ? _ = h || -a : _ = t.y < this._viewportMargin ? n.top - i.top - t.y : 0, this._previousPushAmount = { x: l, y: _ }, { x: t.x + l, y: t.y + _ }; }
    _applyPosition(t, e) { if (this._setTransformOrigin(t), this._setOverlayElementStyles(e, t), this._setBoundingBoxStyles(e, t), t.panelClass && this._addPanelClasses(t.panelClass), this._positionChanges.observers.length) {
        let i = this._getScrollVisibility();
        if (t !== this._lastPosition || !this._lastScrollVisibility || !Ht(this._lastScrollVisibility, i)) {
            let o = new N(t, i);
            this._positionChanges.next(o);
        }
        this._lastScrollVisibility = i;
    } this._lastPosition = t, this._isInitialRender = !1; }
    _setTransformOrigin(t) { if (!this._transformOriginSelector)
        return; let e = this._boundingBox.querySelectorAll(this._transformOriginSelector), i, o = t.overlayY; t.overlayX === "center" ? i = "center" : this._isRtl() ? i = t.overlayX === "start" ? "right" : "left" : i = t.overlayX === "start" ? "left" : "right"; for (let n = 0; n < e.length; n++)
        e[n].style.transformOrigin = `${i} ${o}`; }
    _calculateBoundingBoxRect(t, e) { let i = this._viewportRect, o = this._isRtl(), n, r, a; if (e.overlayY === "top")
        r = t.y, n = i.height - r + this._viewportMargin;
    else if (e.overlayY === "bottom")
        a = i.height - t.y + this._viewportMargin * 2, n = i.height - a + this._viewportMargin;
    else {
        let u = Math.min(i.bottom - t.y + i.top, t.y), g = this._lastBoundingBoxSize.height;
        n = u * 2, r = t.y - u, n > g && !this._isInitialRender && !this._growAfterOpen && (r = t.y - g / 2);
    } let h = e.overlayX === "start" && !o || e.overlayX === "end" && o, c = e.overlayX === "end" && !o || e.overlayX === "start" && o, l, _, v; if (c)
        v = i.width - t.x + this._viewportMargin * 2, l = t.x - this._viewportMargin;
    else if (h)
        _ = t.x, l = i.right - t.x;
    else {
        let u = Math.min(i.right - t.x + i.left, t.x), g = this._lastBoundingBoxSize.width;
        l = u * 2, _ = t.x - u, l > g && !this._isInitialRender && !this._growAfterOpen && (_ = t.x - g / 2);
    } return { top: r, left: _, bottom: a, right: v, width: l, height: n }; }
    _setBoundingBoxStyles(t, e) { let i = this._calculateBoundingBoxRect(t, e); !this._isInitialRender && !this._growAfterOpen && (i.height = Math.min(i.height, this._lastBoundingBoxSize.height), i.width = Math.min(i.width, this._lastBoundingBoxSize.width)); let o = {}; if (this._hasExactPosition())
        o.top = o.left = "0", o.bottom = o.right = o.maxHeight = o.maxWidth = "", o.width = o.height = "100%";
    else {
        let n = this._overlayRef.getConfig().maxHeight, r = this._overlayRef.getConfig().maxWidth;
        o.height = p(i.height), o.top = p(i.top), o.bottom = p(i.bottom), o.width = p(i.width), o.left = p(i.left), o.right = p(i.right), e.overlayX === "center" ? o.alignItems = "center" : o.alignItems = e.overlayX === "end" ? "flex-end" : "flex-start", e.overlayY === "center" ? o.justifyContent = "center" : o.justifyContent = e.overlayY === "bottom" ? "flex-end" : "flex-start", n && (o.maxHeight = p(n)), r && (o.maxWidth = p(r));
    } this._lastBoundingBoxSize = i, m(this._boundingBox.style, o); }
    _resetBoundingBoxStyles() { m(this._boundingBox.style, { top: "0", left: "0", right: "0", bottom: "0", height: "", width: "", alignItems: "", justifyContent: "" }); }
    _resetOverlayElementStyles() { m(this._pane.style, { top: "", left: "", bottom: "", right: "", position: "", transform: "" }); }
    _setOverlayElementStyles(t, e) { let i = {}, o = this._hasExactPosition(), n = this._hasFlexibleDimensions, r = this._overlayRef.getConfig(); if (o) {
        let l = this._viewportRuler.getViewportScrollPosition();
        m(i, this._getExactOverlayY(e, t, l)), m(i, this._getExactOverlayX(e, t, l));
    }
    else
        i.position = "static"; let a = "", h = this._getOffset(e, "x"), c = this._getOffset(e, "y"); h && (a += `translateX(${h}px) `), c && (a += `translateY(${c}px)`), i.transform = a.trim(), r.maxHeight && (o ? i.maxHeight = p(r.maxHeight) : n && (i.maxHeight = "")), r.maxWidth && (o ? i.maxWidth = p(r.maxWidth) : n && (i.maxWidth = "")), m(this._pane.style, i); }
    _getExactOverlayY(t, e, i) { let o = { top: "", bottom: "" }, n = this._getOverlayPoint(e, this._overlayRect, t); if (this._isPushed && (n = this._pushOverlayOnScreen(n, this._overlayRect, i)), t.overlayY === "bottom") {
        let r = this._document.documentElement.clientHeight;
        o.bottom = `${r - (n.y + this._overlayRect.height)}px`;
    }
    else
        o.top = p(n.y); return o; }
    _getExactOverlayX(t, e, i) { let o = { left: "", right: "" }, n = this._getOverlayPoint(e, this._overlayRect, t); this._isPushed && (n = this._pushOverlayOnScreen(n, this._overlayRect, i)); let r; if (this._isRtl() ? r = t.overlayX === "end" ? "left" : "right" : r = t.overlayX === "end" ? "right" : "left", r === "right") {
        let a = this._document.documentElement.clientWidth;
        o.right = `${a - (n.x + this._overlayRect.width)}px`;
    }
    else
        o.left = p(n.x); return o; }
    _getScrollVisibility() { let t = this._getOriginRect(), e = this._pane.getBoundingClientRect(), i = this._scrollables.map(o => o.getElementRef().nativeElement.getBoundingClientRect()); return { isOriginClipped: lt(t, i), isOriginOutsideView: F(t, i), isOverlayClipped: lt(e, i), isOverlayOutsideView: F(e, i) }; }
    _subtractOverflows(t, ...e) { return e.reduce((i, o) => i - Math.max(o, 0), t); }
    _getNarrowedViewportRect() { let t = this._document.documentElement.clientWidth, e = this._document.documentElement.clientHeight, i = this._viewportRuler.getViewportScrollPosition(); return { top: i.top + this._viewportMargin, left: i.left + this._viewportMargin, right: i.left + t - this._viewportMargin, bottom: i.top + e - this._viewportMargin, width: t - 2 * this._viewportMargin, height: e - 2 * this._viewportMargin }; }
    _isRtl() { return this._overlayRef.getDirection() === "rtl"; }
    _hasExactPosition() { return !this._hasFlexibleDimensions || this._isPushed; }
    _getOffset(t, e) { return e === "x" ? t.offsetX == null ? this._offsetX : t.offsetX : t.offsetY == null ? this._offsetY : t.offsetY; }
    _validatePositions() { }
    _addPanelClasses(t) { this._pane && Y(t).forEach(e => { e !== "" && this._appliedPanelClasses.indexOf(e) === -1 && (this._appliedPanelClasses.push(e), this._pane.classList.add(e)); }); }
    _clearPanelClasses() { this._pane && (this._appliedPanelClasses.forEach(t => { this._pane.classList.remove(t); }), this._appliedPanelClasses = []); }
    _getOriginRect() { let t = this._origin; if (t instanceof G)
        return t.nativeElement.getBoundingClientRect(); if (t instanceof Element)
        return t.getBoundingClientRect(); let e = t.width || 0, i = t.height || 0; return { top: t.y, bottom: t.y + i, left: t.x, right: t.x + e, height: i, width: e }; }
};
function m(s, t) { for (let e in t)
    t.hasOwnProperty(e) && (s[e] = t[e]); return s; }
function ft(s) { if (typeof s != "number" && s != null) {
    let [t, e] = s.split(Vt);
    return !e || e === "px" ? parseFloat(t) : null;
} return s || null; }
function pt(s) { return { top: Math.floor(s.top), right: Math.floor(s.right), bottom: Math.floor(s.bottom), left: Math.floor(s.left), width: Math.floor(s.width), height: Math.floor(s.height) }; }
function Ht(s, t) { return s === t ? !0 : s.isOriginClipped === t.isOriginClipped && s.isOriginOutsideView === t.isOriginOutsideView && s.isOverlayClipped === t.isOverlayClipped && s.isOverlayOutsideView === t.isOverlayOutsideView; }
var we = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top" }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom" }, { originX: "end", originY: "bottom", overlayX: "end", overlayY: "top" }, { originX: "end", originY: "top", overlayX: "end", overlayY: "bottom" }], Oe = [{ originX: "end", originY: "top", overlayX: "start", overlayY: "top" }, { originX: "end", originY: "bottom", overlayX: "start", overlayY: "bottom" }, { originX: "start", originY: "top", overlayX: "end", overlayY: "top" }, { originX: "start", originY: "bottom", overlayX: "end", overlayY: "bottom" }], gt = "cdk-global-overlay-wrapper";
function Ft(s) { return new $; }
var $ = class {
    _overlayRef;
    _cssPosition = "static";
    _topOffset = "";
    _bottomOffset = "";
    _alignItems = "";
    _xPosition = "";
    _xOffset = "";
    _width = "";
    _height = "";
    _isDisposed = !1;
    attach(t) { let e = t.getConfig(); this._overlayRef = t, this._width && !e.width && t.updateSize({ width: this._width }), this._height && !e.height && t.updateSize({ height: this._height }), t.hostElement.classList.add(gt), this._isDisposed = !1; }
    top(t = "") { return this._bottomOffset = "", this._topOffset = t, this._alignItems = "flex-start", this; }
    left(t = "") { return this._xOffset = t, this._xPosition = "left", this; }
    bottom(t = "") { return this._topOffset = "", this._bottomOffset = t, this._alignItems = "flex-end", this; }
    right(t = "") { return this._xOffset = t, this._xPosition = "right", this; }
    start(t = "") { return this._xOffset = t, this._xPosition = "start", this; }
    end(t = "") { return this._xOffset = t, this._xPosition = "end", this; }
    width(t = "") { return this._overlayRef ? this._overlayRef.updateSize({ width: t }) : this._width = t, this; }
    height(t = "") { return this._overlayRef ? this._overlayRef.updateSize({ height: t }) : this._height = t, this; }
    centerHorizontally(t = "") { return this.left(t), this._xPosition = "center", this; }
    centerVertically(t = "") { return this.top(t), this._alignItems = "center", this; }
    apply() { if (!this._overlayRef || !this._overlayRef.hasAttached())
        return; let t = this._overlayRef.overlayElement.style, e = this._overlayRef.hostElement.style, i = this._overlayRef.getConfig(), { width: o, height: n, maxWidth: r, maxHeight: a } = i, h = (o === "100%" || o === "100vw") && (!r || r === "100%" || r === "100vw"), c = (n === "100%" || n === "100vh") && (!a || a === "100%" || a === "100vh"), l = this._xPosition, _ = this._xOffset, v = this._overlayRef.getConfig().direction === "rtl", u = "", g = "", y = ""; h ? y = "flex-start" : l === "center" ? (y = "center", v ? g = _ : u = _) : v ? l === "left" || l === "end" ? (y = "flex-end", u = _) : (l === "right" || l === "start") && (y = "flex-start", g = _) : l === "left" || l === "start" ? (y = "flex-start", u = _) : (l === "right" || l === "end") && (y = "flex-end", g = _), t.position = this._cssPosition, t.marginLeft = h ? "0" : u, t.marginTop = c ? "0" : this._topOffset, t.marginBottom = this._bottomOffset, t.marginRight = h ? "0" : g, e.justifyContent = y, e.alignItems = c ? "flex-start" : this._alignItems; }
    dispose() { if (this._isDisposed || !this._overlayRef)
        return; let t = this._overlayRef.overlayElement.style, e = this._overlayRef.hostElement, i = e.style; e.classList.remove(gt), i.justifyContent = i.alignItems = t.marginTop = t.marginBottom = t.marginLeft = t.marginRight = t.position = "", this._overlayRef = null, this._isDisposed = !0; }
}, Wt = (() => { class s {
    _injector = d(C);
    constructor() { }
    global() { return Ft(); }
    flexibleConnectedTo(e) { return bt(this._injector, e); }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })();
function wt(s, t) { s.get(A).load(vt); let e = s.get(mt), i = s.get(P), o = s.get(Q), n = s.get(St), r = s.get(X), a = i.createElement("div"), h = i.createElement("div"); h.id = o.getId("cdk-overlay-"), h.classList.add("cdk-overlay-pane"), a.appendChild(h), e.getContainerElement().appendChild(a); let c = new st(h, n, s), l = new M(t), _ = s.get(Ct, null, { optional: !0 }) || s.get(K).createRenderer(null, null); return l.direction = l.direction || r.value, new Z(c, a, h, l, s.get(S), s.get(Lt), i, s.get(Bt), s.get(It), t?.disableAnimations ?? s.get(xt, null, { optional: !0 }) === "NoopAnimations", s.get(Rt), _); }
var Nt = (() => { class s {
    scrollStrategies = d(Tt);
    _positionBuilder = d(Wt);
    _injector = d(C);
    constructor() { }
    create(e) { return wt(this._injector, e); }
    position() { return this._positionBuilder; }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), zt = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top" }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom" }, { originX: "end", originY: "top", overlayX: "end", overlayY: "bottom" }, { originX: "end", originY: "bottom", overlayX: "end", overlayY: "top" }], Ot = new Pt("cdk-connected-overlay-scroll-strategy", { providedIn: "root", factory: () => { let s = d(C); return () => q(s); } }), ut = (() => { class s {
    elementRef = d(G);
    constructor() { }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275dir = f.\u0275\u0275defineDirective({ type: s, selectors: [["", "cdk-overlay-origin", ""], ["", "overlay-origin", ""], ["", "cdkOverlayOrigin", ""]], exportAs: ["cdkOverlayOrigin"] });
} return s; })(), ke = (() => { class s {
    _dir = d(X, { optional: !0 });
    _injector = d(C);
    _overlayRef;
    _templatePortal;
    _backdropSubscription = k.EMPTY;
    _attachSubscription = k.EMPTY;
    _detachSubscription = k.EMPTY;
    _positionSubscription = k.EMPTY;
    _offsetX;
    _offsetY;
    _position;
    _scrollStrategyFactory = d(Ot);
    _disposeOnNavigation = !1;
    _ngZone = d(S);
    origin;
    positions;
    positionStrategy;
    get offsetX() { return this._offsetX; }
    set offsetX(e) { this._offsetX = e, this._position && this._updatePositionStrategy(this._position); }
    get offsetY() { return this._offsetY; }
    set offsetY(e) { this._offsetY = e, this._position && this._updatePositionStrategy(this._position); }
    width;
    height;
    minWidth;
    minHeight;
    backdropClass;
    panelClass;
    viewportMargin = 0;
    scrollStrategy;
    open = !1;
    disableClose = !1;
    transformOriginSelector;
    hasBackdrop = !1;
    lockPosition = !1;
    flexibleDimensions = !1;
    growAfterOpen = !1;
    push = !1;
    get disposeOnNavigation() { return this._disposeOnNavigation; }
    set disposeOnNavigation(e) { this._disposeOnNavigation = e; }
    backdropClick = new b;
    positionChange = new b;
    attach = new b;
    detach = new b;
    overlayKeydown = new b;
    overlayOutsideClick = new b;
    constructor() { let e = d(Et), i = d(Dt); this._templatePortal = new it(e, i), this.scrollStrategy = this._scrollStrategyFactory(); }
    get overlayRef() { return this._overlayRef; }
    get dir() { return this._dir ? this._dir.value : "ltr"; }
    ngOnDestroy() { this._attachSubscription.unsubscribe(), this._detachSubscription.unsubscribe(), this._backdropSubscription.unsubscribe(), this._positionSubscription.unsubscribe(), this._overlayRef?.dispose(); }
    ngOnChanges(e) { this._position && (this._updatePositionStrategy(this._position), this._overlayRef?.updateSize({ width: this.width, minWidth: this.minWidth, height: this.height, minHeight: this.minHeight }), e.origin && this.open && this._position.apply()), e.open && (this.open ? this.attachOverlay() : this.detachOverlay()); }
    _createOverlay() { (!this.positions || !this.positions.length) && (this.positions = zt); let e = this._overlayRef = wt(this._injector, this._buildConfig()); this._attachSubscription = e.attachments().subscribe(() => this.attach.emit()), this._detachSubscription = e.detachments().subscribe(() => this.detach.emit()), e.keydownEvents().subscribe(i => { this.overlayKeydown.next(i), i.keyCode === 27 && !this.disableClose && !tt(i) && (i.preventDefault(), this.detachOverlay()); }), this._overlayRef.outsidePointerEvents().subscribe(i => { let o = this._getOriginElement(), n = D(i); (!o || o !== n && !o.contains(n)) && this.overlayOutsideClick.next(i); }); }
    _buildConfig() { let e = this._position = this.positionStrategy || this._createPositionStrategy(), i = new M({ direction: this._dir || "ltr", positionStrategy: e, scrollStrategy: this.scrollStrategy, hasBackdrop: this.hasBackdrop, disposeOnNavigation: this.disposeOnNavigation }); return (this.width || this.width === 0) && (i.width = this.width), (this.height || this.height === 0) && (i.height = this.height), (this.minWidth || this.minWidth === 0) && (i.minWidth = this.minWidth), (this.minHeight || this.minHeight === 0) && (i.minHeight = this.minHeight), this.backdropClass && (i.backdropClass = this.backdropClass), this.panelClass && (i.panelClass = this.panelClass), i; }
    _updatePositionStrategy(e) { let i = this.positions.map(o => ({ originX: o.originX, originY: o.originY, overlayX: o.overlayX, overlayY: o.overlayY, offsetX: o.offsetX || this.offsetX, offsetY: o.offsetY || this.offsetY, panelClass: o.panelClass || void 0 })); return e.setOrigin(this._getOrigin()).withPositions(i).withFlexibleDimensions(this.flexibleDimensions).withPush(this.push).withGrowAfterOpen(this.growAfterOpen).withViewportMargin(this.viewportMargin).withLockedPosition(this.lockPosition).withTransformOriginOn(this.transformOriginSelector); }
    _createPositionStrategy() { let e = bt(this._injector, this._getOrigin()); return this._updatePositionStrategy(e), e; }
    _getOrigin() { return this.origin instanceof ut ? this.origin.elementRef : this.origin; }
    _getOriginElement() { return this.origin instanceof ut ? this.origin.elementRef.nativeElement : this.origin instanceof G ? this.origin.nativeElement : typeof Element < "u" && this.origin instanceof Element ? this.origin : null; }
    attachOverlay() { this._overlayRef ? this._overlayRef.getConfig().hasBackdrop = this.hasBackdrop : this._createOverlay(), this._overlayRef.hasAttached() || this._overlayRef.attach(this._templatePortal), this.hasBackdrop ? this._backdropSubscription = this._overlayRef.backdropClick().subscribe(e => { this.backdropClick.emit(e); }) : this._backdropSubscription.unsubscribe(), this._positionSubscription.unsubscribe(), this.positionChange.observers.length > 0 && (this._positionSubscription = this._position.positionChanges.pipe(At(() => this.positionChange.observers.length > 0)).subscribe(e => { this._ngZone.run(() => this.positionChange.emit(e)), this.positionChange.observers.length === 0 && this._positionSubscription.unsubscribe(); })), this.open = !0; }
    detachOverlay() { this._overlayRef?.detach(), this._backdropSubscription.unsubscribe(), this._positionSubscription.unsubscribe(), this.open = !1; }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275dir = f.\u0275\u0275defineDirective({ type: s, selectors: [["", "cdk-connected-overlay", ""], ["", "connected-overlay", ""], ["", "cdkConnectedOverlay", ""]], inputs: { origin: [0, "cdkConnectedOverlayOrigin", "origin"], positions: [0, "cdkConnectedOverlayPositions", "positions"], positionStrategy: [0, "cdkConnectedOverlayPositionStrategy", "positionStrategy"], offsetX: [0, "cdkConnectedOverlayOffsetX", "offsetX"], offsetY: [0, "cdkConnectedOverlayOffsetY", "offsetY"], width: [0, "cdkConnectedOverlayWidth", "width"], height: [0, "cdkConnectedOverlayHeight", "height"], minWidth: [0, "cdkConnectedOverlayMinWidth", "minWidth"], minHeight: [0, "cdkConnectedOverlayMinHeight", "minHeight"], backdropClass: [0, "cdkConnectedOverlayBackdropClass", "backdropClass"], panelClass: [0, "cdkConnectedOverlayPanelClass", "panelClass"], viewportMargin: [0, "cdkConnectedOverlayViewportMargin", "viewportMargin"], scrollStrategy: [0, "cdkConnectedOverlayScrollStrategy", "scrollStrategy"], open: [0, "cdkConnectedOverlayOpen", "open"], disableClose: [0, "cdkConnectedOverlayDisableClose", "disableClose"], transformOriginSelector: [0, "cdkConnectedOverlayTransformOriginOn", "transformOriginSelector"], hasBackdrop: [2, "cdkConnectedOverlayHasBackdrop", "hasBackdrop", w], lockPosition: [2, "cdkConnectedOverlayLockPosition", "lockPosition", w], flexibleDimensions: [2, "cdkConnectedOverlayFlexibleDimensions", "flexibleDimensions", w], growAfterOpen: [2, "cdkConnectedOverlayGrowAfterOpen", "growAfterOpen", w], push: [2, "cdkConnectedOverlayPush", "push", w], disposeOnNavigation: [2, "cdkConnectedOverlayDisposeOnNavigation", "disposeOnNavigation", w] }, outputs: { backdropClick: "backdropClick", positionChange: "positionChange", attach: "attach", detach: "detach", overlayKeydown: "overlayKeydown", overlayOutsideClick: "overlayOutsideClick" }, exportAs: ["cdkConnectedOverlay"], features: [f.\u0275\u0275NgOnChangesFeature] });
} return s; })();
function Zt(s) { let t = d(C); return () => q(t); }
var jt = { provide: Ot, useFactory: Zt }, Se = (() => { class s {
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275mod = f.\u0275\u0275defineNgModule({ type: s });
    static \u0275inj = f.\u0275\u0275defineInjector({ providers: [Nt, jt], imports: [et, ot, I, I] });
} return s; })();
export { Yt as a, V as b, Xt as c, H as d, ve as e, R as f, q as g, W as h, Tt as i, M as j, ht as k, ct as l, N as m, me as n, be as o, Lt as p, It as q, mt as r, Z as s, bt as t, j as u, we as v, Oe as w, Ft as x, $ as y, Wt as z, wt as A, Nt as B, ut as C, ke as D, Se as E };
