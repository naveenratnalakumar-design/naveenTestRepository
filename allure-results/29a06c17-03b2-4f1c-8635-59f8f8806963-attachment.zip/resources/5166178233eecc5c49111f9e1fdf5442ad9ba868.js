import { o as r } from "@nf-internal/chunk-Z6KGCFTG";
import { b as e } from "@nf-internal/chunk-RXMLTE5A";
import { ObserversModule as a } from "@angular/cdk/observers";
import * as t from "@angular/core";
import "@angular/core";
var g = (() => { class o {
    static \u0275fac = function (i) { return new (i || o); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: o });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [e, a, r, e] });
} return o; })();
export { g as a };
