import { a as _, b as R } from "@nf-internal/chunk-66YHNWRR";
import { DOCUMENT as P, \u0275getDOM as $ } from "@angular/common";
import * as i from "@angular/core";
import { InjectionToken as H, \u0275RuntimeError as T, APP_ID as U, CSP_NONCE as L, PLATFORM_ID as j, \u0275getAnimationElementRemovalRegistry as Z, ViewEncapsulation as S, \u0275ANIMATIONS_DISABLED as F, MAX_ANIMATION_TIMEOUT as G, \u0275TracingService as V, RendererStyleFlags2 as E } from "@angular/core";
var X = new H(""), Y = (() => { class o {
    _zone;
    _plugins;
    _eventNameToPlugin = new Map;
    constructor(e, t) { this._zone = t, e.forEach(s => { s.manager = this; }), this._plugins = e.slice().reverse(); }
    addEventListener(e, t, s, r) { return this._findPluginFor(t).addEventListener(e, t, s, r); }
    getZone() { return this._zone; }
    _findPluginFor(e) { let t = this._eventNameToPlugin.get(e); if (t)
        return t; if (t = this._plugins.find(r => r.supports(e)), !t)
        throw new T(5101, !1); return this._eventNameToPlugin.set(e, t), t; }
    static \u0275fac = function (t) { return new (t || o)(i.\u0275\u0275inject(X), i.\u0275\u0275inject(i.NgZone)); };
    static \u0275prov = i.\u0275\u0275defineInjectable({ token: o, factory: o.\u0275fac });
} return o; })(), I = class {
    _doc;
    constructor(n) { this._doc = n; }
    manager;
}, M = "ng-app-id";
function b(o) { for (let n of o)
    n.remove(); }
function N(o, n) { let e = n.createElement("style"); return e.textContent = o, e; }
function z(o, n, e, t) { let s = o.head?.querySelectorAll(`style[${M}="${n}"],link[${M}="${n}"]`); if (s)
    for (let r of s)
        r.removeAttribute(M), r instanceof HTMLLinkElement ? t.set(r.href.slice(r.href.lastIndexOf("/") + 1), { usage: 0, elements: [r] }) : r.textContent && e.set(r.textContent, { usage: 0, elements: [r] }); }
function D(o, n) { let e = n.createElement("link"); return e.setAttribute("rel", "stylesheet"), e.setAttribute("href", o), e; }
var q = (() => { class o {
    doc;
    appId;
    nonce;
    inline = new Map;
    external = new Map;
    hosts = new Set;
    constructor(e, t, s, r = {}) { this.doc = e, this.appId = t, this.nonce = s, z(e, t, this.inline, this.external), this.hosts.add(e.head); }
    addStyles(e, t) { for (let s of e)
        this.addUsage(s, this.inline, N); t?.forEach(s => this.addUsage(s, this.external, D)); }
    removeStyles(e, t) { for (let s of e)
        this.removeUsage(s, this.inline); t?.forEach(s => this.removeUsage(s, this.external)); }
    addUsage(e, t, s) { let r = t.get(e); r ? r.usage++ : t.set(e, { usage: 1, elements: [...this.hosts].map(a => this.addElement(a, s(e, this.doc))) }); }
    removeUsage(e, t) { let s = t.get(e); s && (s.usage--, s.usage <= 0 && (b(s.elements), t.delete(e))); }
    ngOnDestroy() { for (let [, { elements: e }] of [...this.inline, ...this.external])
        b(e); this.hosts.clear(); }
    addHost(e) { this.hosts.add(e); for (let [t, { elements: s }] of this.inline)
        s.push(this.addElement(e, N(t, this.doc))); for (let [t, { elements: s }] of this.external)
        s.push(this.addElement(e, D(t, this.doc))); }
    removeHost(e) { this.hosts.delete(e); }
    addElement(e, t) { return this.nonce && t.setAttribute("nonce", this.nonce), typeof ngServerMode < "u" && ngServerMode && t.setAttribute(M, this.appId), e.appendChild(t); }
    static \u0275fac = function (t) { return new (t || o)(i.\u0275\u0275inject(P), i.\u0275\u0275inject(U), i.\u0275\u0275inject(L, 8), i.\u0275\u0275inject(j)); };
    static \u0275prov = i.\u0275\u0275defineInjectable({ token: o, factory: o.\u0275fac });
} return o; })(), A = { svg: "http://www.w3.org/2000/svg", xhtml: "http://www.w3.org/1999/xhtml", xlink: "http://www.w3.org/1999/xlink", xml: "http://www.w3.org/XML/1998/namespace", xmlns: "http://www.w3.org/2000/xmlns/", math: "http://www.w3.org/1998/Math/MathML" }, O = /%COMP%/g;
var B = "%COMP%", W = `_nghost-${B}`, J = `_ngcontent-${B}`, K = !0, Q = new H("", { providedIn: "root", factory: () => K });
function ee(o) { return J.replace(O, o); }
function te(o) { return W.replace(O, o); }
function k(o, n) { return n.map(e => e.replace(O, o)); }
var ae = (() => { class o {
    eventManager;
    sharedStylesHost;
    appId;
    removeStylesOnCompDestroy;
    doc;
    platformId;
    ngZone;
    nonce;
    animationDisabled;
    maxAnimationTimeout;
    tracingService;
    rendererByCompId = new Map;
    defaultRenderer;
    platformIsServer;
    registry;
    constructor(e, t, s, r, a, d, c, h = null, f, u, l = null) { this.eventManager = e, this.sharedStylesHost = t, this.appId = s, this.removeStylesOnCompDestroy = r, this.doc = a, this.platformId = d, this.ngZone = c, this.nonce = h, this.animationDisabled = f, this.maxAnimationTimeout = u, this.tracingService = l, this.platformIsServer = typeof ngServerMode < "u" && ngServerMode, this.defaultRenderer = new y(e, a, c, this.platformIsServer, this.tracingService, this.registry = Z(), this.maxAnimationTimeout); }
    createRenderer(e, t) { if (!e || !t)
        return this.defaultRenderer; typeof ngServerMode < "u" && ngServerMode && t.encapsulation === S.ShadowDom && (t = R(_({}, t), { encapsulation: S.Emulated })); let s = this.getOrCreateRenderer(e, t); return s instanceof w ? s.applyToHost(e) : s instanceof v && s.applyStyles(), s; }
    getOrCreateRenderer(e, t) { let s = this.rendererByCompId, r = s.get(t.id); if (!r) {
        let a = this.doc, d = this.ngZone, c = this.eventManager, h = this.sharedStylesHost, f = this.removeStylesOnCompDestroy, u = this.platformIsServer, l = this.tracingService;
        switch (t.encapsulation) {
            case S.Emulated:
                r = new w(c, h, t, this.appId, f, a, d, u, l, this.registry, this.animationDisabled, this.maxAnimationTimeout);
                break;
            case S.ShadowDom: return new C(c, h, e, t, a, d, this.nonce, u, l, this.registry, this.maxAnimationTimeout);
            default:
                r = new v(c, h, t, f, a, d, u, l, this.registry, this.animationDisabled, this.maxAnimationTimeout);
                break;
        }
        s.set(t.id, r);
    } return r; }
    ngOnDestroy() { this.rendererByCompId.clear(); }
    componentReplaced(e) { this.rendererByCompId.delete(e); }
    static \u0275fac = function (t) { return new (t || o)(i.\u0275\u0275inject(Y), i.\u0275\u0275inject(q), i.\u0275\u0275inject(U), i.\u0275\u0275inject(Q), i.\u0275\u0275inject(P), i.\u0275\u0275inject(j), i.\u0275\u0275inject(i.NgZone), i.\u0275\u0275inject(L), i.\u0275\u0275inject(F), i.\u0275\u0275inject(G), i.\u0275\u0275inject(V, 8)); };
    static \u0275prov = i.\u0275\u0275defineInjectable({ token: o, factory: o.\u0275fac });
} return o; })(), y = class {
    eventManager;
    doc;
    ngZone;
    platformIsServer;
    tracingService;
    registry;
    maxAnimationTimeout;
    data = Object.create(null);
    throwOnSyntheticProps = !0;
    constructor(n, e, t, s, r, a, d) { this.eventManager = n, this.doc = e, this.ngZone = t, this.platformIsServer = s, this.tracingService = r, this.registry = a, this.maxAnimationTimeout = d; }
    destroy() { }
    destroyNode = null;
    createElement(n, e) { return e ? this.doc.createElementNS(A[e] || e, n) : this.doc.createElement(n); }
    createComment(n) { return this.doc.createComment(n); }
    createText(n) { return this.doc.createTextNode(n); }
    appendChild(n, e) { (x(n) ? n.content : n).appendChild(e); }
    insertBefore(n, e, t) { n && (x(n) ? n.content : n).insertBefore(e, t); }
    removeChild(n, e) { let { elements: t } = this.registry; if (t) {
        t.animate(e, () => e.remove(), this.maxAnimationTimeout);
        return;
    } e.remove(); }
    selectRootElement(n, e) { let t = typeof n == "string" ? this.doc.querySelector(n) : n; if (!t)
        throw new T(-5104, !1); return e || (t.textContent = ""), t; }
    parentNode(n) { return n.parentNode; }
    nextSibling(n) { return n.nextSibling; }
    setAttribute(n, e, t, s) { if (s) {
        e = s + ":" + e;
        let r = A[s];
        r ? n.setAttributeNS(r, e, t) : n.setAttribute(e, t);
    }
    else
        n.setAttribute(e, t); }
    removeAttribute(n, e, t) { if (t) {
        let s = A[t];
        s ? n.removeAttributeNS(s, e) : n.removeAttribute(`${t}:${e}`);
    }
    else
        n.removeAttribute(e); }
    addClass(n, e) { n.classList.add(e); }
    removeClass(n, e) { n.classList.remove(e); }
    setStyle(n, e, t, s) { s & (E.DashCase | E.Important) ? n.style.setProperty(e, t, s & E.Important ? "important" : "") : n.style[e] = t; }
    removeStyle(n, e, t) { t & E.DashCase ? n.style.removeProperty(e) : n.style[e] = ""; }
    setProperty(n, e, t) { n != null && (n[e] = t); }
    setValue(n, e) { n.nodeValue = e; }
    listen(n, e, t, s) { if (typeof n == "string" && (n = $().getGlobalEventTarget(this.doc, n), !n))
        throw new T(5102, !1); let r = this.decoratePreventDefault(t); return this.tracingService?.wrapEventListener && (r = this.tracingService.wrapEventListener(n, e, r)), this.eventManager.addEventListener(n, e, r, s); }
    decoratePreventDefault(n) { return e => { if (e === "__ngUnwrap__")
        return n; (typeof ngServerMode < "u" && ngServerMode ? this.ngZone.runGuarded(() => n(e)) : n(e)) === !1 && e.preventDefault(); }; }
};
function x(o) { return o.tagName === "TEMPLATE" && o.content !== void 0; }
var C = class extends y {
    sharedStylesHost;
    hostEl;
    shadowRoot;
    constructor(n, e, t, s, r, a, d, c, h, f, u) { super(n, r, a, c, h, f, u), this.sharedStylesHost = e, this.hostEl = t, this.shadowRoot = t.attachShadow({ mode: "open" }), this.sharedStylesHost.addHost(this.shadowRoot); let l = s.styles; l = k(s.id, l); for (let g of l) {
        let p = document.createElement("style");
        d && p.setAttribute("nonce", d), p.textContent = g, this.shadowRoot.appendChild(p);
    } let m = s.getExternalStyles?.(); if (m)
        for (let g of m) {
            let p = D(g, r);
            d && p.setAttribute("nonce", d), this.shadowRoot.appendChild(p);
        } }
    nodeOrShadowRoot(n) { return n === this.hostEl ? this.shadowRoot : n; }
    appendChild(n, e) { return super.appendChild(this.nodeOrShadowRoot(n), e); }
    insertBefore(n, e, t) { return super.insertBefore(this.nodeOrShadowRoot(n), e, t); }
    removeChild(n, e) { return super.removeChild(null, e); }
    parentNode(n) { return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(n))); }
    destroy() { this.sharedStylesHost.removeHost(this.shadowRoot); }
}, v = class extends y {
    sharedStylesHost;
    removeStylesOnCompDestroy;
    styles;
    styleUrls;
    _animationDisabled;
    constructor(n, e, t, s, r, a, d, c, h, f, u, l) { super(n, r, a, d, c, h, u), this.sharedStylesHost = e, this.removeStylesOnCompDestroy = s, this._animationDisabled = f; let m = t.styles; this.styles = l ? k(l, m) : m, this.styleUrls = t.getExternalStyles?.(l); }
    applyStyles() { this.sharedStylesHost.addStyles(this.styles, this.styleUrls); }
    destroy() { if (this.removeStylesOnCompDestroy) {
        if ((typeof ngServerMode > "u" || !ngServerMode) && !this._animationDisabled && this.registry.elements) {
            this.ngZone.runOutsideAngular(() => { setTimeout(() => { this.sharedStylesHost.removeStyles(this.styles, this.styleUrls); }, this.maxAnimationTimeout); });
            return;
        }
        this.sharedStylesHost.removeStyles(this.styles, this.styleUrls);
    } }
}, w = class extends v {
    contentAttr;
    hostAttr;
    constructor(n, e, t, s, r, a, d, c, h, f, u, l) { let m = s + "-" + t.id; super(n, e, t, r, a, d, c, h, f, u, l, m), this.contentAttr = ee(m), this.hostAttr = te(m); }
    applyToHost(n) { this.applyStyles(), this.setAttribute(n, this.hostAttr, ""); }
    createElement(n, e) { let t = super.createElement(n, e); return super.setAttribute(t, this.contentAttr, ""), t; }
};
export { X as a, Y as b, I as c, q as d, Q as e, ae as f };
/*! Bundled license information:

@angular/platform-browser/fesm2022/dom_renderer.mjs:
  (**
   * @license Angular v20.2.1
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)
*/
