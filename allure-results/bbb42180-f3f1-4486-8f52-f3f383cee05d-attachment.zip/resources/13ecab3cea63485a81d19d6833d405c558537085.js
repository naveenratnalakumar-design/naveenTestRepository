import * as n from "@angular/core";
import "@angular/core";
var c = (() => {
    class e {
        static \u0275fac = function (t) { return new (t || e); };
        static \u0275cmp = n.\u0275\u0275defineComponent({ type: e, selectors: [["ng-component"]], exportAs: ["cdkVisuallyHidden"], decls: 0, vars: 0, template: function (t, i) { }, styles: [`.cdk-visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;white-space:nowrap;outline:0;-webkit-appearance:none;-moz-appearance:none;left:0}[dir=rtl] .cdk-visually-hidden{left:auto;right:0}
`], encapsulation: 2, changeDetection: 0 });
    }
    return e;
})();
export { c as a };
