import { c as o, d as u, e as _ } from "@nf-internal/chunk-MM6HONEP";
import { e as d } from "@nf-internal/chunk-5KSFOI5Q";
import * as b from "@angular/core";
import { inject as n, DOCUMENT as v, NgZone as D, Injector as R, RendererFactory2 as A } from "@angular/core";
import { Platform as E, _getEventTarget as O } from "@angular/cdk/platform";
var y = { capture: !0 }, I = ["focus", "mousedown", "mouseenter", "touchstart"], p = "mat-ripple-loader-uninitialized", l = "mat-ripple-loader-class-name", f = "mat-ripple-loader-centered", s = "mat-ripple-loader-disabled", M = (() => { class r {
    _document = n(v);
    _animationsDisabled = d();
    _globalRippleOptions = n(_, { optional: !0 });
    _platform = n(E);
    _ngZone = n(D);
    _injector = n(R);
    _eventCleanups;
    _hosts = new Map;
    constructor() { let e = n(A).createRenderer(null, null); this._eventCleanups = this._ngZone.runOutsideAngular(() => I.map(t => e.listen(this._document, t, this._onInteraction, y))); }
    ngOnDestroy() { let e = this._hosts.keys(); for (let t of e)
        this.destroyRipple(t); this._eventCleanups.forEach(t => t()); }
    configureRipple(e, t) { e.setAttribute(p, this._globalRippleOptions?.namespace ?? ""), (t.className || !e.hasAttribute(l)) && e.setAttribute(l, t.className || ""), t.centered && e.setAttribute(f, ""), t.disabled && e.setAttribute(s, ""); }
    setDisabled(e, t) { let i = this._hosts.get(e); i ? (i.target.rippleDisabled = t, !t && !i.hasSetUpEvents && (i.hasSetUpEvents = !0, i.renderer.setupTriggerEvents(e))) : t ? e.setAttribute(s, "") : e.removeAttribute(s); }
    _onInteraction = e => { let t = O(e); if (t instanceof HTMLElement) {
        let i = t.closest(`[${p}="${this._globalRippleOptions?.namespace ?? ""}"]`);
        i && this._createRipple(i);
    } };
    _createRipple(e) { if (!this._document || this._hosts.has(e))
        return; e.querySelector(".mat-ripple")?.remove(); let t = this._document.createElement("span"); t.classList.add("mat-ripple", e.getAttribute(l)), e.append(t); let i = this._globalRippleOptions, g = this._animationsDisabled ? 0 : i?.animation?.enterDuration ?? o.enterDuration, h = this._animationsDisabled ? 0 : i?.animation?.exitDuration ?? o.exitDuration, a = { rippleDisabled: this._animationsDisabled || i?.disabled || e.hasAttribute(s), rippleConfig: { centered: e.hasAttribute(f), terminateOnPointerUp: i?.terminateOnPointerUp, animation: { enterDuration: g, exitDuration: h } } }, c = new u(a, this._ngZone, t, this._platform, this._injector), m = !a.rippleDisabled; m && c.setupTriggerEvents(e), this._hosts.set(e, { target: a, renderer: c, hasSetUpEvents: m }), e.removeAttribute(p); }
    destroyRipple(e) { let t = this._hosts.get(e); t && (t.renderer._removeTriggerEvents(), this._hosts.delete(e)); }
    static \u0275fac = function (t) { return new (t || r); };
    static \u0275prov = b.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })();
export { M as a };
