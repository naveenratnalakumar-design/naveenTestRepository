import "@nf-internal/chunk-66YHNWRR";
import * as p from "@angular/core";
import "@angular/core";
import * as l from "@angular/common/http";
import { HttpEventType as h } from "@angular/common/http";
import { Observable as c } from "rxjs";
import { repeatWhen as d, retryWhen as f, takeWhile as o, delay as u, tap as m } from "rxjs/operators";
var g = { keepAlive: !0, reconnectionDelay: 3e3, responseType: "event" }, E = { observe: "events", reportProgress: !0, responseType: "text" }, S = (() => { class n {
    httpClient;
    sseOptions;
    httpClientOptions;
    url;
    method;
    static SEPARATOR = ":";
    progress = 0;
    chunk = "";
    constructor(t, e, s, i, r) { this.httpClient = t, this.sseOptions = e, this.httpClientOptions = s, this.url = i, this.method = r; }
    createObservable() { return new c(t => { let e = this.subscribeStreamRequest(this.url, this.sseOptions, this.httpClientOptions, this.method, t); return () => e.unsubscribe(); }); }
    subscribeStreamRequest(t, e, s, i, r) { return this.httpClient.request(i, t, s).pipe(d(a => this.repeatWhen(a, e.keepAlive, e.reconnectionDelay))).pipe(f(a => this.retryWhen(a, e.keepAlive, e.reconnectionDelay, r))).subscribe(a => this.parseStreamEvent(a, r)); }
    repeatWhen(t, e, s) { return t.pipe(o(() => e)).pipe(u(s)); }
    retryWhen(t, e, s, i) { return t.pipe(m(r => this.threatRequestError(r, i))).pipe(o(() => e)).pipe(u(s)); }
    threatRequestError(t, e) { this.dispatchStreamData(this.errorEvent(t), e), this.isValidStatus(t.status) || e.error(t); }
    isValidStatus(t) { return t != null && t <= 299; }
    parseStreamEvent(t, e) { if (t.type === h.Sent) {
        this.progress = 0;
        return;
    } if (t.type === h.DownloadProgress) {
        this.onStreamProgress(t.partialText, e);
        return;
    } if (t.type === h.Response) {
        this.onStreamCompleted(t, e);
        return;
    } }
    onStreamProgress(t, e) { t && (t = t.substring(this.progress), this.progress += t.length, t.split(/(\r\n|\r|\n){2}/g).forEach(s => this.parseEventData(s, e))); }
    onStreamCompleted(t, e) { if (this.onStreamProgress(t.body, e), this.dispatchStreamData(this.parseEventChunk(this.chunk), e), this.chunk = "", this.progress = 0, this.sseOptions.keepAlive) {
        let s = `Server response ended, will reconnect in ${this.sseOptions.reconnectionDelay}ms`;
        this.dispatchStreamData(this.errorEvent({ status: 1, message: s }), e);
    }
    else
        e.complete(); }
    parseEventData(t, e) { t.trim().length === 0 ? (this.dispatchStreamData(this.parseEventChunk(this.chunk), e), this.chunk = "") : this.chunk += t; }
    parseEventChunk(t) { if (!t || t.length === 0)
        return; let e = { id: void 0, data: "", event: "message" }; return t.split(/\n|\r\n|\r/).forEach(s => this.parseChunkLine(s.trim(), e)), this.messageEvent(e.event, { lastEventId: e.id, data: e.data }); }
    parseChunkLine(t, e) { let s = t.indexOf(n.SEPARATOR); if (s <= 0)
        return; let i = t.substring(0, s); if (Object.keys(e).findIndex(a => a === i) === -1)
        return; let r = t.substring(s + 1).replace(/^\s/, ""); i === "data" && (r = e.data + r), e[i] = r; }
    dispatchStreamData(t, e) { this.validEvent(t) && (this.sseOptions.responseType === "event" ? e.next(t) : e.next(t.data)); }
    validEvent(t) { return !(!t || t.type === "error" && this.sseOptions.responseType !== "event" || t.type !== "error" && (!t.data || !t.data.length)); }
    messageEvent(t, e) { return new MessageEvent(t, e); }
    errorEvent(t) { let e; return t && t.status > 0 && (e = { error: t, message: t.message }, this.isValidStatus(t.status) || (e.status = t.status, e.statusText = t.statusText)), new ErrorEvent("error", e); }
} return n; })(), k = (() => { class n {
    httpClient;
    constructor(t) { this.httpClient = t; }
    stream(t, e, s, i = "GET") { var r = Object.assign({}, g, e), a = Object.assign({}, s, E); return new S(this.httpClient, r, a, t, i).createObservable(); }
    static \u0275fac = function (e) { return new (e || n)(p.\u0275\u0275inject(l.HttpClient)); };
    static \u0275prov = p.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" });
} return n; })();
export { k as SseClient, E as defaultRequestOptions, g as defaultSseOptions };
