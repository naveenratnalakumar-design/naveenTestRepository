import { a as o, b as u } from "@nf-internal/chunk-66YHNWRR";
import * as E from "@angular/core";
import { untracked as S, isSignal as p, computed as m, assertInInjectionContext as x, inject as w, Injector as j, effect as C, DestroyRef as b, signal as O, linkedSignal as A } from "@angular/core";
var v = Symbol("DEEP_SIGNAL");
function g(t) { return new Proxy(t, { has(e, n) { return !!this.get(e, n, void 0); }, get(e, n) { let i = S(e); return !H(i) || !(n in i) ? (p(e[n]) && e[n][v] && delete e[n], e[n]) : (p(e[n]) || (Object.defineProperty(e, n, { value: m(() => e()[n]), configurable: !0 }), e[n][v] = !0), g(e[n])); } }); }
var F = [WeakSet, WeakMap, Promise, Date, Error, RegExp, ArrayBuffer, DataView, Function];
function H(t) { if (t === null || typeof t != "object" || U(t))
    return !1; let e = Object.getPrototypeOf(t); if (e === Object.prototype)
    return !0; for (; e && e !== Object.prototype;) {
    if (F.includes(e.constructor))
        return !1;
    e = Object.getPrototypeOf(e);
} return e === Object.prototype; }
function U(t) { return typeof t?.[Symbol.iterator] == "function"; }
function Q(t) { return g(m(t)); }
function L(t, e) { e?.injector || x(L); let n = [], i = e?.injector ?? w(j), r = (s, c) => { if (p(s)) {
    let f = _(), l = c?.injector ?? f ?? i, y = C(() => { let d = s(); S(() => t(d)); }, { injector: l });
    return n.push(y), l.get(b).onDestroy(() => { let d = n.indexOf(y); d !== -1 && n.splice(d, 1); }), y;
}
else
    return t(s), { destroy: () => { } }; }; return r.destroy = () => n.forEach(s => s.destroy()), r; }
function _() { try {
    return w(j);
}
catch {
    return;
} }
var R = new WeakMap, a = Symbol("STATE_SOURCE");
function P(t) { return p(t) && "set" in t && "update" in t && typeof t.set == "function" && typeof t.update == "function"; }
function X(t) { let e = t[a]; return Reflect.ownKeys(t[a]).every(n => P(e[n])); }
function Y(t, ...e) { let n = S(() => k(t)), i = e.reduce((c, f) => o(o({}, c), typeof f == "function" ? f(c) : f), n), r = t[a], s = Reflect.ownKeys(t[a]); for (let c of Reflect.ownKeys(i))
    if (s.includes(c)) {
        let f = c;
        n[f] !== i[f] && r[f].set(i[f]);
    } N(t); }
function k(t) { let e = t[a]; return Reflect.ownKeys(t[a]).reduce((n, i) => { let r = e[i](); return u(o({}, n), { [i]: r }); }, {}); }
function G(t, e, n) { n?.injector || x(G); let r = (n?.injector ?? w(j)).get(b); q(t, e), e(k(t)); let s = () => z(t, e); return r.onDestroy(s), { destroy: s }; }
function D(t) { return R.get(t[a]) || []; }
function N(t) { let e = D(t); for (let n of e) {
    let i = S(() => k(t));
    n(i);
} }
function q(t, e) { let n = D(t); R.set(t[a], [...n, e]); }
function z(t, e) { let n = D(t); R.set(t[a], n.filter(i => i !== e)); }
function Z(t) { let e = Reflect.ownKeys(t), n = e.reduce((r, s) => u(o({}, r), { [s]: O(t[s]) }), {}), i = m(() => e.reduce((r, s) => u(o({}, r), { [s]: n[s]() }), {})); Object.defineProperty(i, a, { value: n }); for (let r of e)
    Object.defineProperty(i, r, { value: g(n[r]) }); return i; }
function ee(...t) { let e = [...t], n = typeof e[0] == "function" ? {} : e.shift(), i = e; return (() => { class s {
    constructor() { let f = i.reduce((h, W) => W(h), B()), { stateSignals: l, props: y, methods: d, hooks: T } = f, I = o(o(o({}, l), y), d); this[a] = f[a]; for (let h of Reflect.ownKeys(I))
        this[h] = I[h]; let { onInit: K, onDestroy: M } = T; K && K(), M && w(b).onDestroy(M); }
    static \u0275fac = function (l) { return new (l || s); };
    static \u0275prov = E.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: n.providedIn || null });
} return s; })(); }
function B() { return { [a]: {}, stateSignals: {}, props: {}, methods: {}, hooks: {} }; }
function te(...t) { let e = typeof t[0] == "function" ? t : t.slice(1); return n => e.reduce((i, r) => r(i), n); }
function ne() { }
function V(t) { return e => { let n = t(o(o(o({ [a]: e[a] }, e.stateSignals), e.props), e.methods)); return Reflect.ownKeys(n), u(o({}, e), { props: o(o({}, e.props), n) }); }; }
function oe(t) { return V(e => { let n = t(e); return Reflect.ownKeys(n).reduce((r, s) => { let c = n[s]; return u(o({}, r), { [s]: p(c) ? c : m(c) }); }, {}); }); }
function se(t) { return e => { let n = o(o(o({ [a]: e[a] }, e.stateSignals), e.props), e.methods); return t(n)(e); }; }
function ie(t) { return e => { let n = o(o(o({ [a]: e[a] }, e.stateSignals), e.props), e.methods), i = typeof t == "function" ? t(n) : t, r = s => { let c = i[s], f = e.hooks[s]; return c ? () => { f && f(), c(n); } : f; }; return u(o({}, e), { hooks: { onInit: r("onInit"), onDestroy: r("onDestroy") } }); }; }
function re(t) { return e => { let n = t(o(o({}, e.stateSignals), e.props)), i = Reflect.ownKeys(n), r = e[a], s = {}; for (let c of i) {
    let f = n[c];
    r[c] = P(f) ? f : A(f), s[c] = g(r[c]);
} return u(o({}, e), { stateSignals: o(o({}, e.stateSignals), s) }); }; }
function ce(t) { return e => { let n = t(o(o(o({ [a]: e[a] }, e.stateSignals), e.props), e.methods)); return Reflect.ownKeys(n), u(o({}, e), { methods: o(o({}, e.methods), n) }); }; }
function ae(t) { return e => { let n = typeof t == "function" ? t() : t, i = Reflect.ownKeys(n); let r = e[a], s = {}; for (let c of i)
    r[c] = O(n[c]), s[c] = g(r[c]); return u(o({}, e), { stateSignals: o(o({}, e.stateSignals), s) }); }; }
export { Q as deepComputed, k as getState, X as isWritableStateSource, Y as patchState, L as signalMethod, Z as signalState, ee as signalStore, te as signalStoreFeature, ne as type, G as watchState, oe as withComputed, se as withFeature, ie as withHooks, re as withLinkedState, ce as withMethods, V as withProps, ae as withState };
