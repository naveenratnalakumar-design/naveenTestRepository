import { c as h } from "@nf-internal/chunk-5MXKUS3T";
import "@nf-internal/chunk-66YHNWRR";
import * as i from "@angular/core";
import { InjectionToken as g, EventEmitter as o } from "@angular/core";
import { registerables as p, Chart as c, defaults as l } from "chart.js";
import { BehaviorSubject as f } from "rxjs";
import { distinctUntilChanged as m } from "rxjs/operators";
var u = new g("Configuration for ngCharts");
function x(...n) { return { registerables: [...p, ...n] }; }
function M(...n) { let e = h({}, ...n); return { provide: u, useValue: e }; }
var v = (() => { let e = class e {
    constructor() { this.colorschemesOptions = new f(void 0); }
    setColorschemesOptions(t) { this.pColorschemesOptions = t, this.colorschemesOptions.next(t); }
    getColorschemesOptions() { return this.pColorschemesOptions; }
}; e.\u0275fac = function (s) { return new (s || e); }, e.\u0275prov = i.\u0275\u0275defineInjectable({ token: e, factory: e.\u0275fac, providedIn: "root" }); let n = e; return n; })(), z = (() => { let e = class e {
    constructor(t, s, a, r) { this.zone = s, this.themeService = a, this.type = "bar", this.plugins = [], this.chartClick = new o, this.chartHover = new o, this.subs = [], this.themeOverrides = {}, r?.registerables && c.register(...r.registerables), r?.defaults && l.set(r.defaults), this.ctx = t.nativeElement.getContext("2d"), this.subs.push(this.themeService.colorschemesOptions.pipe(m()).subscribe(d => this.themeChanged(d))); }
    ngOnChanges(t) { let s = ["type"], a = Object.getOwnPropertyNames(t); if (a.some(r => s.includes(r)) || a.every(r => t[r].isFirstChange()))
        this.render();
    else {
        let r = this.getChartConfiguration();
        this.chart && (Object.assign(this.chart.config.data, r.data), this.chart.config.plugins && Object.assign(this.chart.config.plugins, r.plugins), this.chart.config.options && Object.assign(this.chart.config.options, r.options)), this.update();
    } }
    ngOnDestroy() { this.chart && (this.chart.destroy(), this.chart = void 0), this.subs.forEach(t => t.unsubscribe()); }
    render() { return this.chart && this.chart.destroy(), this.zone.runOutsideAngular(() => this.chart = new c(this.ctx, this.getChartConfiguration())); }
    update(t) { this.chart && this.zone.runOutsideAngular(() => this.chart?.update(t)); }
    hideDataset(t, s) { this.chart && (this.chart.getDatasetMeta(t).hidden = s, this.update()); }
    isDatasetHidden(t) { return this.chart?.getDatasetMeta(t)?.hidden; }
    toBase64Image() { return this.chart?.toBase64Image(); }
    themeChanged(t) { this.themeOverrides = t, this.chart && (this.chart.config.options && Object.assign(this.chart.config.options, this.getChartOptions()), this.update()); }
    getChartOptions() { return h({ onHover: (t, s) => { !this.chartHover.observed && !this.chartHover.observers?.length || this.zone.run(() => this.chartHover.emit({ event: t, active: s })); }, onClick: (t, s) => { !this.chartClick.observed && !this.chartClick.observers?.length || this.zone.run(() => this.chartClick.emit({ event: t, active: s })); } }, this.themeOverrides, this.options, { plugins: { legend: { display: this.legend } } }); }
    getChartConfiguration() { return { type: this.type, data: this.getChartData(), options: this.getChartOptions(), plugins: this.plugins }; }
    getChartData() { return this.data ? this.data : { labels: this.labels || [], datasets: this.datasets || [] }; }
}; e.\u0275fac = function (s) { return new (s || e)(i.\u0275\u0275directiveInject(i.ElementRef), i.\u0275\u0275directiveInject(i.NgZone), i.\u0275\u0275directiveInject(v), i.\u0275\u0275directiveInject(u, 8)); }, e.\u0275dir = i.\u0275\u0275defineDirective({ type: e, selectors: [["canvas", "baseChart", ""]], inputs: { type: "type", legend: "legend", data: "data", options: "options", plugins: "plugins", labels: "labels", datasets: "datasets" }, outputs: { chartClick: "chartClick", chartHover: "chartHover" }, exportAs: ["base-chart"], features: [i.\u0275\u0275NgOnChangesFeature] }); let n = e; return n; })();
export { z as BaseChartDirective, u as NG_CHARTS_CONFIGURATION, v as ThemeService, M as provideCharts, x as withDefaultRegisterables };
