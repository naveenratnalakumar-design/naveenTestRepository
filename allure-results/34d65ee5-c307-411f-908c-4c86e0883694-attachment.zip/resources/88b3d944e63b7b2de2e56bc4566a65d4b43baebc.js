import { a as h, b as E } from "@nf-internal/chunk-66YHNWRR";
import * as m from "@angular/core";
import { InjectionToken as M, inject as d, NgZone as z, ElementRef as k } from "@angular/core";
import { DOCUMENT as F } from "@angular/common";
import { coerceElement as P } from "@angular/cdk/coercion";
import { Subject as W, Observable as B, takeWhile as V, switchMap as Y, merge as _, fromEvent as T, take as j, takeUntil as H, finalize as U } from "rxjs";
var A = 4, q = .001, G = 1e-7, Z = 10, g = 11, S = 1 / (g - 1), J = typeof Float32Array == "function";
function v(i, n) { return 1 - 3 * n + 3 * i; }
function b(i, n) { return 3 * n - 6 * i; }
function I(i) { return 3 * i; }
function y(i, n, c) { return ((v(n, c) * i + b(n, c)) * i + I(n)) * i; }
function R(i, n, c) { return 3 * v(n, c) * i * i + 2 * b(n, c) * i + I(n); }
function K(i, n, c, t, e) { let l, r, o = 0; do
    r = n + (c - n) / 2, l = y(r, t, e) - i, l > 0 ? c = r : n = r;
while (Math.abs(l) > G && ++o < Z); return r; }
function Q(i, n, c, t) { for (let e = 0; e < A; ++e) {
    let l = R(n, c, t);
    if (l === 0)
        return n;
    let r = y(n, c, t) - i;
    n -= r / l;
} return n; }
function $(i) { return i; }
function X(i, n, c, t) { if (!(0 <= i && i <= 1 && 0 <= c && c <= 1))
    throw new Error("bezier x values must be in [0, 1] range"); if (i === n && c === t)
    return $; let e = J ? new Float32Array(g) : new Array(g); for (let r = 0; r < g; ++r)
    e[r] = y(r * S, i, c); function l(r) { let o = 0, a = 1, f = g - 1; for (; a !== f && e[a] <= r; ++a)
    o += S; --a; let u = (r - e[a]) / (e[a + 1] - e[a]), s = o + u * S, p = R(s, i, c); return p >= q ? Q(r, s, i, c) : p === 0 ? s : K(r, o, o + S, i, c); } return function (o) { return o === 0 ? 0 : o === 1 ? 1 : y(l(o), n, t); }; }
var L = { duration: 468, easing: { x1: .42, y1: 0, x2: .58, y2: 1 } }, N = new M("SMOOTH_SCROLL_OPTIONS", { providedIn: "root", factory: () => L });
function ot(i) { return [{ provide: N, useValue: h(h({}, L), i) }]; }
var x = (() => { let n = class n {
    constructor() { this.document = d(F), this.zone = d(z), this._defaultOptions = d(N), this.onGoingScrolls = new Map; }
    get now() { return this.document.defaultView.performance?.now?.bind(this.document.defaultView.performance) || Date.now; }
    scrollElement(t, e, l) { t.scrollLeft = e, t.scrollTop = l; }
    getElement(t, e) { return typeof t == "string" ? (e || this.document).querySelector(t) : P(t); }
    getScrollDestroyerRef(t) { return this.onGoingScrolls.has(t) && this.onGoingScrolls.get(t).next(), this.onGoingScrolls.set(t, new W).get(t); }
    step(t) { return new B(e => { let l = (this.now() - t.startTime) / t.duration; l = l > 1 ? 1 : l; let r = t.easing(l); t.currentX = t.startX + (t.x - t.startX) * r, t.currentY = t.startY + (t.y - t.startY) * r, this.scrollElement(t.scrollable, t.currentX, t.currentY), requestAnimationFrame(() => { e.next(), e.complete(); }); }); }
    isReached(t, e) { return t.currentX === t.x && t.currentY === t.y ? (e.next(), !0) : !1; }
    scrolling(t, e) { return this.step(t).pipe(V(() => !this.isReached(t, e)), Y(() => this.scrolling(t, e))); }
    onScrollReached(t, e, l) { l.complete(), this.onGoingScrolls.delete(t), this.zone.run(() => e()); }
    interrupted(t, e) { return _(T(t, "wheel", { passive: !0, capture: !0 }), T(t, "touchmove", { passive: !0, capture: !0 }), e).pipe(j(1)); }
    applyScrollToOptions(t, e) { return e.duration ? new Promise(l => { this.zone.runOutsideAngular(() => { let r = this.getScrollDestroyerRef(t), o = { scrollable: t, startTime: this.now(), startX: t.scrollLeft, startY: t.scrollTop, x: e.left == null ? t.scrollLeft : ~~e.left, y: e.top == null ? t.scrollTop : ~~e.top, duration: e.duration, easing: X(e.easing.x1, e.easing.y1, e.easing.x2, e.easing.y2) }; this.scrolling(o, r).pipe(H(this.interrupted(t, r)), U(() => this.onScrollReached(t, l, r))).subscribe(); }); }) : (this.scrollElement(t, e.left, e.top), Promise.resolve()); }
    scrollTo(t, e) { let l = this.getElement(t), r = getComputedStyle(l).direction === "rtl", o = E(h(h({}, this._defaultOptions), e), { left: e.left == null ? r ? e.end : e.start : e.left, right: e.right == null ? r ? e.start : e.end : e.right }); return o.bottom != null && (o.top = l.scrollHeight - l.clientHeight - o.bottom), r ? (o.left != null && (o.right = l.scrollWidth - l.clientWidth - o.left), o.left = o.right ? -o.right : o.right) : o.right != null && (o.left = l.scrollWidth - l.clientWidth - o.right), this.applyScrollToOptions(l, o); }
    scrollToElement(t, e, l = {}) { let r = this.getElement(t), o = this.getElement(e, r), a = getComputedStyle(r).direction === "rtl"; if (!o || !r)
        return Promise.resolve(); let f = r.getBoundingClientRect(), u = o.getBoundingClientRect(), s = E(h(h({}, this._defaultOptions), l), { top: u.top + r.scrollTop - f.top + (l.top || 0), left: l.left == null ? a ? l.end : l.start : l.left, right: l.right == null ? a ? l.start : l.end : l.right }); if (l.center) {
        let w = f.left + f.width / 2, C = f.top + f.height / 2, D = u.left + u.width / 2, O = u.top + u.height / 2;
        return s.left = D - w + r.scrollLeft, s.top = O - C + r.scrollTop, this.applyScrollToOptions(r, s);
    } if (s.bottom != null) {
        let w = f.height - u.height;
        s.top = u.top + r.scrollTop - f.top - w + (l.bottom || 0);
    } s.left = u.left - f.left + r.scrollLeft + (s.left || 0), s.right != null && (s.left = u.right - f.left + r.scrollLeft - f.width + (s.right || 0)); let p = { top: s.top, left: s.left, easing: s.easing, duration: s.duration }; return this.applyScrollToOptions(r, p); }
}; n.\u0275fac = function (e) { return new (e || n); }, n.\u0275prov = m.\u0275\u0275defineInjectable({ token: n, factory: n.\u0275fac, providedIn: "root" }); let i = n; return i; })(), st = (() => { let n = class n {
    constructor() { this.smoothScroll = d(x), this.element = d(k); }
    scrollTo(t) { return this.smoothScroll.scrollTo(this.element, t); }
    scrollToElement(t, e) { return this.smoothScroll.scrollToElement(this.element, t, e); }
}; n.\u0275fac = function (e) { return new (e || n); }, n.\u0275dir = m.\u0275\u0275defineDirective({ type: n, selectors: [["", "smoothScroll", ""]], exportAs: ["smoothScroll"] }); let i = n; return i; })();
export { N as SMOOTH_SCROLL_OPTIONS, st as SmoothScroll, x as SmoothScrollManager, ot as provideSmoothScrollOptions };
