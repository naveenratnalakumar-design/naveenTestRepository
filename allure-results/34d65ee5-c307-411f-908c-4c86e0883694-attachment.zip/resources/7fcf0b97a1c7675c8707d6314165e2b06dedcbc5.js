import { a as g, b as f, h as w, i as A } from "@nf-internal/chunk-66YHNWRR";
import * as o from "@angular/core";
import { InjectionToken as b } from "@angular/core";
import { WrapperSKU as O, InteractionStatus as C, EventMessageUtils as $, InteractionType as p, BrowserConfigurationAuthError as _, UrlString as U, BrowserUtils as F, StringUtils as D, NavigationClient as z } from "@azure/msal-browser";
import { from as c, ReplaySubject as x, Subject as H, BehaviorSubject as K, of as l, EMPTY as V } from "rxjs";
import * as S from "@angular/common";
import { DOCUMENT as W, CommonModule as Q } from "@angular/common";
import { map as P, concatMap as G, catchError as E, switchMap as m, take as y, filter as j } from "rxjs/operators";
import * as L from "@angular/router";
var k = "@azure/msal-angular", M = "3.1.0", R = new b("MSAL_INSTANCE"), B = new b("MSAL_GUARD_CONFIG"), q = new b("MSAL_INTERCEPTOR_CONFIG"), Y = new b("MSAL_BROADCAST_CONFIG"), v = (() => { class t {
    constructor(e, i) { this.instance = e, this.location = i; let r = this.location.path(!0).split("#").pop(); r && (this.redirectHash = `#${r}`), this.instance.initializeWrapperLibrary(O.Angular, M); }
    initialize() { return c(this.instance.initialize()); }
    acquireTokenPopup(e) { return c(this.instance.acquireTokenPopup(e)); }
    acquireTokenRedirect(e) { return c(this.instance.acquireTokenRedirect(e)); }
    acquireTokenSilent(e) { return c(this.instance.acquireTokenSilent(e)); }
    handleRedirectObservable(e) { return c(this.instance.initialize().then(() => this.instance.handleRedirectPromise(e || this.redirectHash))); }
    loginPopup(e) { return c(this.instance.loginPopup(e)); }
    loginRedirect(e) { return c(this.instance.loginRedirect(e)); }
    logout(e) { return c(this.instance.logout(e)); }
    logoutRedirect(e) { return c(this.instance.logoutRedirect(e)); }
    logoutPopup(e) { return c(this.instance.logoutPopup(e)); }
    ssoSilent(e) { return c(this.instance.ssoSilent(e)); }
    getLogger() { return this.logger || (this.logger = this.instance.getLogger().clone(k, M)), this.logger; }
    setLogger(e) { this.logger = e.clone(k, M), this.instance.setLogger(e); }
} return t.\u0275fac = function (e) { return new (e || t)(o.\u0275\u0275inject(R), o.\u0275\u0275inject(S.Location)); }, t.\u0275prov = o.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac }), t; })(), T = (() => { class t {
    constructor(e, i, r) { this.msalInstance = e, this.authService = i, this.msalBroadcastConfig = r, this.msalBroadcastConfig && this.msalBroadcastConfig.eventsToReplay > 0 ? (this.authService.getLogger().verbose(`BroadcastService - eventsToReplay set on BroadcastConfig, replaying the last ${this.msalBroadcastConfig.eventsToReplay} events`), this._msalSubject = new x(this.msalBroadcastConfig.eventsToReplay)) : this._msalSubject = new H, this.msalSubject$ = this._msalSubject.asObservable(), this._inProgress = new K(C.Startup), this.inProgress$ = this._inProgress.asObservable(), this.msalInstance.addEventCallback(n => { this._msalSubject.next(n); let s = $.getInteractionStatusFromEvent(n, this._inProgress.value); s !== null && (this.authService.getLogger().verbose(`BroadcastService - ${n.eventType} results in setting inProgress from ${this._inProgress.value} to ${s}`), this._inProgress.next(s)); }); }
} return t.\u0275fac = function (e) { return new (e || t)(o.\u0275\u0275inject(R), o.\u0275\u0275inject(v), o.\u0275\u0275inject(Y, 8)); }, t.\u0275prov = o.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac }), t; })(), J = (() => { class t {
    constructor(e, i, r, n, s) { this.msalGuardConfig = e, this.msalBroadcastService = i, this.authService = r, this.location = n, this.router = s, this.msalBroadcastService.inProgress$.subscribe(); }
    parseUrl(e) { return this.router.parseUrl(e); }
    getDestinationUrl(e) { this.authService.getLogger().verbose("Guard - getting destination url"); let i = document.getElementsByTagName("base"), r = this.location.normalize(i.length ? i[0].href : window.location.origin), n = this.location.prepareExternalUrl(e); return n.startsWith("#") ? (this.authService.getLogger().verbose("Guard - destination by hash routing"), `${r}/${n}`) : `${r}${e}`; }
    loginInteractively(e) { let i = typeof this.msalGuardConfig.authRequest == "function" ? this.msalGuardConfig.authRequest(this.authService, e) : g({}, this.msalGuardConfig.authRequest); if (this.msalGuardConfig.interactionType === p.Popup)
        return this.authService.getLogger().verbose("Guard - logging in by popup"), this.authService.loginPopup(i).pipe(P(n => (this.authService.getLogger().verbose("Guard - login by popup successful, can activate, setting active account"), this.authService.instance.setActiveAccount(n.account), !0))); this.authService.getLogger().verbose("Guard - logging in by redirect"); let r = this.getDestinationUrl(e.url); return this.authService.loginRedirect(g({ redirectStartPage: r }, i)).pipe(P(() => !1)); }
    activateHelper(e) { if (this.msalGuardConfig.interactionType !== p.Popup && this.msalGuardConfig.interactionType !== p.Redirect)
        throw new _("invalid_interaction_type", "Invalid interaction type provided to MSAL Guard. InteractionType.Popup or InteractionType.Redirect must be provided in the MsalGuardConfiguration"); if (this.authService.getLogger().verbose("MSAL Guard activated"), typeof window < "u") {
        if (U.hashContainsKnownProperties(window.location.hash) && F.isInIframe() && !this.authService.instance.getConfiguration().system.allowRedirectInIframe)
            return this.authService.getLogger().warning("Guard - redirectUri set to page with MSAL Guard. It is recommended to not set redirectUri to a page that requires authentication."), l(!1);
    }
    else
        return this.authService.getLogger().info("Guard - window is undefined, MSAL does not support server-side token acquisition"), l(!0); this.msalGuardConfig.loginFailedRoute && (this.loginFailedRoute = this.parseUrl(this.msalGuardConfig.loginFailedRoute)); let i = this.location.path(!0); return this.authService.initialize().pipe(G(() => this.authService.handleRedirectObservable()), G(() => { if (!this.authService.instance.getAllAccounts().length)
        return e ? (this.authService.getLogger().verbose("Guard - no accounts retrieved, log in required to activate"), this.loginInteractively(e)) : (this.authService.getLogger().verbose("Guard - no accounts retrieved, no state, cannot load"), l(!1)); if (this.authService.getLogger().verbose("Guard - at least 1 account exists, can activate or load"), e) {
        let r = this.includesCode(e.url), n = !!e.root && !!e.root.fragment && this.includesCode(`#${e.root.fragment}`), s = this.location.prepareExternalUrl(e.url).indexOf("#") === 0;
        if (r && (n || s))
            return this.authService.getLogger().info("Guard - Hash contains known code response, stopping navigation."), i.indexOf("#") > -1 ? l(this.parseUrl(this.location.path())) : l(this.parseUrl(""));
    } return l(!0); }), E(r => (this.authService.getLogger().error("Guard - error while logging in, unable to activate"), this.authService.getLogger().errorPii(`Guard - error: ${r.message}`), this.loginFailedRoute && e ? (this.authService.getLogger().verbose("Guard - loginFailedRoute set, redirecting"), l(this.loginFailedRoute)) : l(!1)))); }
    includesCode(e) { return e.lastIndexOf("/code") > -1 && e.lastIndexOf("/code") === e.length - 5 || e.indexOf("#code=") > -1 || e.indexOf("&code=") > -1; }
    canActivate(e, i) { return this.authService.getLogger().verbose("Guard - canActivate"), this.activateHelper(i); }
    canActivateChild(e, i) { return this.authService.getLogger().verbose("Guard - canActivateChild"), this.activateHelper(i); }
    canMatch() { return this.authService.getLogger().verbose("Guard - canLoad"), this.activateHelper(); }
} return t.\u0275fac = function (e) { return new (e || t)(o.\u0275\u0275inject(B), o.\u0275\u0275inject(T), o.\u0275\u0275inject(v), o.\u0275\u0275inject(S.Location), o.\u0275\u0275inject(L.Router)); }, t.\u0275prov = o.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac }), t; })(), ue = (() => { class t {
    constructor(e, i, r, n, s) { this.msalInterceptorConfig = e, this.authService = i, this.location = r, this.msalBroadcastService = n, this._document = s; }
    intercept(e, i) { if (this.msalInterceptorConfig.interactionType !== p.Popup && this.msalInterceptorConfig.interactionType !== p.Redirect)
        throw new _("invalid_interaction_type", "Invalid interaction type provided to MSAL Interceptor. InteractionType.Popup, InteractionType.Redirect must be provided in the msalInterceptorConfiguration"); this.authService.getLogger().verbose("MSAL Interceptor activated"); let r = this.getScopesForEndpoint(e.url, e.method); if (!r || r.length === 0)
        return this.authService.getLogger().verbose("Interceptor - no scopes for endpoint"), i.handle(e); let n; this.authService.instance.getActiveAccount() ? (this.authService.getLogger().verbose("Interceptor - active account selected"), n = this.authService.instance.getActiveAccount()) : (this.authService.getLogger().verbose("Interceptor - no active account, fallback to first account"), n = this.authService.instance.getAllAccounts()[0]); let s = typeof this.msalInterceptorConfig.authRequest == "function" ? this.msalInterceptorConfig.authRequest(this.authService, e, { account: n }) : f(g({}, this.msalInterceptorConfig.authRequest), { account: n }); return this.authService.getLogger().info(`Interceptor - ${r.length} scopes found for endpoint`), this.authService.getLogger().infoPii(`Interceptor - [${r}] scopes found for ${e.url}`), this.acquireToken(s, r, n).pipe(m(h => { this.authService.getLogger().verbose("Interceptor - setting authorization headers"); let d = e.headers.set("Authorization", `Bearer ${h.accessToken}`), u = e.clone({ headers: d }); return i.handle(u); })); }
    acquireToken(e, i, r) { return this.authService.acquireTokenSilent(f(g({}, e), { scopes: i, account: r })).pipe(E(() => (this.authService.getLogger().error("Interceptor - acquireTokenSilent rejected with error. Invoking interaction to resolve."), this.msalBroadcastService.inProgress$.pipe(y(1), m(n => n === C.None ? this.acquireTokenInteractively(e, i) : this.msalBroadcastService.inProgress$.pipe(j(s => s === C.None), y(1), m(() => this.acquireToken(e, i, r))))))), m(n => n.accessToken ? l(n) : (this.authService.getLogger().error("Interceptor - acquireTokenSilent resolved with null access token. Known issue with B2C tenants, invoking interaction to resolve."), this.msalBroadcastService.inProgress$.pipe(j(s => s === C.None), y(1), m(() => this.acquireTokenInteractively(e, i)))))); }
    acquireTokenInteractively(e, i) { if (this.msalInterceptorConfig.interactionType === p.Popup)
        return this.authService.getLogger().verbose("Interceptor - error acquiring token silently, acquiring by popup"), this.authService.acquireTokenPopup(f(g({}, e), { scopes: i })); this.authService.getLogger().verbose("Interceptor - error acquiring token silently, acquiring by redirect"); let r = window.location.href; return this.authService.acquireTokenRedirect(f(g({}, e), { scopes: i, redirectStartPage: r })), V; }
    getScopesForEndpoint(e, i) { this.authService.getLogger().verbose("Interceptor - getting scopes for endpoint"); let r = this.location.normalize(e), n = Array.from(this.msalInterceptorConfig.protectedResourceMap.keys()), s = this.matchResourcesToEndpoint(n, r); return s.length > 0 ? this.matchScopesToEndpoint(this.msalInterceptorConfig.protectedResourceMap, s, i) : null; }
    matchResourcesToEndpoint(e, i) { let r = []; return e.forEach(n => { let s = this.location.normalize(n), h = this.getAbsoluteUrl(s), d = new URL(h), u = this.getAbsoluteUrl(i), I = new URL(u); this.checkUrlComponents(d, I) && r.push(n); }), r; }
    checkUrlComponents(e, i) { let r = ["protocol", "host", "pathname", "search", "hash"]; for (let n of r)
        if (e[n]) {
            let s = decodeURIComponent(e[n]);
            if (!D.matchPattern(s, i[n]))
                return !1;
        } return !0; }
    getAbsoluteUrl(e) { let i = this._document.createElement("a"); return i.href = e, i.href; }
    matchScopesToEndpoint(e, i, r) { let n = []; return i.forEach(s => { let h = [], d = e.get(s); if (d === null) {
        n.push(null);
        return;
    } d.forEach(u => { if (typeof u == "string")
        h.push(u);
    else {
        let I = r.toLowerCase();
        u.httpMethod.toLowerCase() === I && (u.scopes === null ? n.push(null) : u.scopes.forEach(N => { h.push(N); }));
    } }), h.length > 0 && n.push(h); }), n.length > 0 ? (n.length > 1 && this.authService.getLogger().warning("Interceptor - More than 1 matching scopes for endpoint found."), n[0]) : null; }
} return t.\u0275fac = function (e) { return new (e || t)(o.\u0275\u0275inject(q), o.\u0275\u0275inject(v), o.\u0275\u0275inject(S.Location), o.\u0275\u0275inject(T), o.\u0275\u0275inject(W)); }, t.\u0275prov = o.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac }), t; })(), le = (() => { class t {
    constructor(e) { this.authService = e; }
    ngOnInit() { this.authService.getLogger().verbose("MsalRedirectComponent activated"), this.authService.handleRedirectObservable().subscribe(); }
} return t.\u0275fac = function (e) { return new (e || t)(o.\u0275\u0275directiveInject(v)); }, t.\u0275cmp = o.\u0275\u0275defineComponent({ type: t, selectors: [["app-redirect"]], standalone: !1, decls: 0, vars: 0, template: function (e, i) { }, encapsulation: 2 }), t; })(), he = (() => { class t {
    static forRoot(e, i, r) { return { ngModule: t, providers: [{ provide: R, useValue: e }, { provide: B, useValue: i }, { provide: q, useValue: r }, v] }; }
} return t.\u0275fac = function (e) { return new (e || t); }, t.\u0275mod = o.\u0275\u0275defineNgModule({ type: t }), t.\u0275inj = o.\u0275\u0275defineInjector({ providers: [J, T], imports: [Q] }), t; })(), ge = (() => { class t extends z {
    constructor(e, i, r) { super(), this.authService = e, this.router = i, this.location = r; }
    navigateInternal(e, i) { return A(this, null, function* () { if (this.authService.getLogger().trace("MsalCustomNavigationClient called"), this.authService.getLogger().verbose("MsalCustomNavigationClient - navigating"), this.authService.getLogger().verbosePii(`MsalCustomNavigationClient - navigating to url: ${e}`), i.noHistory)
        return w(t.prototype, this, "navigateInternal").call(this, e, i); {
        let r = new U(e).getUrlComponents(), n = r.QueryString ? `${r.AbsolutePath}?${r.QueryString}` : this.location.normalize(r.AbsolutePath);
        yield this.router.navigateByUrl(n, { replaceUrl: i.noHistory });
    } return Promise.resolve(i.noHistory); }); }
} return t.\u0275fac = function (e) { return new (e || t)(o.\u0275\u0275inject(v), o.\u0275\u0275inject(L.Router), o.\u0275\u0275inject(S.Location)); }, t.\u0275prov = o.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac }), t; })();
export { Y as MSAL_BROADCAST_CONFIG, B as MSAL_GUARD_CONFIG, R as MSAL_INSTANCE, q as MSAL_INTERCEPTOR_CONFIG, T as MsalBroadcastService, ge as MsalCustomNavigationClient, J as MsalGuard, ue as MsalInterceptor, he as MsalModule, le as MsalRedirectComponent, v as MsalService, M as version };
