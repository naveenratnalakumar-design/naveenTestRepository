import "@nf-internal/chunk-66YHNWRR";
import * as i from "@angular/core";
import { inject as s, contentChild as a, effect as p, untracked as u } from "@angular/core";
import { CdkVirtualScrollViewport as c } from "@angular/cdk/scrolling";
import { NgScrollbarExt as f } from "ngx-scrollbar";
var h = (() => { let e = class e {
    constructor() { this.scrollbar = s(f, { self: !0 }), this.virtualScrollViewportRef = a(c), this.scrollbar.skipInit = !0, p(() => { let t = this.virtualScrollViewportRef(); u(() => { if (t) {
        let r = t.elementRef.nativeElement, l = t._contentWrapper.nativeElement, n = t.elementRef.nativeElement.querySelector(".cdk-virtual-scroll-spacer");
        this.scrollbar.initialize(r, l, n);
    } }); }); }
}; e.\u0275fac = function (r) { return new (r || e); }, e.\u0275dir = i.\u0275\u0275defineDirective({ type: e, selectors: [["ng-scrollbar", "cdkVirtualScrollViewport", ""]], contentQueries: function (r, l, n) { r & 1 && i.\u0275\u0275contentQuerySignal(n, l.virtualScrollViewportRef, c, 5), r & 2 && i.\u0275\u0275queryAdvance(); } }); let o = e; return o; })();
export { h as NgScrollbarCdkVirtualScroll };
