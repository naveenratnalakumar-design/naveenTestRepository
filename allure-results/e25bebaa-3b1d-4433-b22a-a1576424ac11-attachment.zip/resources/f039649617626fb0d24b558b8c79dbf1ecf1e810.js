import { a as p } from "@nf-internal/chunk-66YHNWRR";
import M from "quill";
var v = M.import("blots/embed"), C = class extends Event {
    constructor(t, e) { super(t, e), this.value = {}, this.event = new Event(t); }
};
function L(r) { return typeof r == "object" && r !== null && "value" in r && typeof r.value == "string" && "denotationChar" in r && typeof r.denotationChar == "string"; }
var k = (() => { class r extends v {
    constructor(e, n) { super(e, n), this.mounted = !1; }
    static create(e) { let n = super.create(); if (!L(e) || !(n instanceof HTMLElement))
        return n; let i = document.createElement("span"); return i.className = "ql-mention-denotation-char", i.innerText = e.denotationChar, n.appendChild(i), typeof this.render == "function" ? n.appendChild(this.render(e)) : n.innerText += e.value, r.setDataValues(n, e); }
    static setDataValues(e, n) { let i = e; return Object.keys(n).forEach(o => { i.dataset[o] = n[o]; }), i; }
    static value(e) { return e.dataset; }
    attach() { super.attach(), this.mounted || (this.mounted = !0, this.clickHandler = this.getClickHandler(), this.hoverHandler = this.getHoverHandler(), this.domNode.addEventListener("click", this.clickHandler, !1), this.domNode.addEventListener("mouseenter", this.hoverHandler, !1)); }
    detach() { super.detach(), this.mounted = !1, this.clickHandler && (this.domNode.removeEventListener("click", this.clickHandler), this.clickHandler = void 0); }
    getClickHandler() { return e => { let n = this.buildEvent("mention-clicked", e); window.dispatchEvent(n), e.preventDefault(); }; }
    getHoverHandler() { return e => { let n = this.buildEvent("mention-hovered", e); window.dispatchEvent(n), e.preventDefault(); }; }
    buildEvent(e, n) { let i = new C(e, { bubbles: !0, cancelable: !0 }); return i.value = Object.assign({}, this.domNode.dataset), i.event = n, i; }
} return r.blotName = "mention", r.tagName = "span", r.className = "mention", r; })();
import c from "quill";
var l = { TAB: "Tab", ENTER: "Enter", ESCAPE: "Escape", UP: "ArrowUp", DOWN: "ArrowDown" };
function b(r, t, e) { let n = r; return Object.keys(t).forEach(i => { e.indexOf(i) > -1 ? n.dataset[i] = t[i] : delete n.dataset[i]; }), n; }
function g(r, t) { t !== null && (typeof t == "object" ? r.appendChild(t) : r.innerText = t); }
function I(r, t, e, n) { return t.reduce((i, o) => { let s; if (e && n) {
    let h = new RegExp(`^${o}|\\s${o}`, "g"), a = (r.match(h) || []).pop();
    if (!a)
        return { mentionChar: i.mentionChar, mentionCharIndex: i.mentionCharIndex };
    s = a !== o ? r.lastIndexOf(a) + a.length - o.length : 0;
}
else
    s = r.lastIndexOf(o); return s > i.mentionCharIndex ? { mentionChar: o, mentionCharIndex: s } : { mentionChar: i.mentionChar, mentionCharIndex: i.mentionCharIndex }; }, { mentionChar: null, mentionCharIndex: -1 }); }
function E(r, t) { return t.test(r); }
function T(r, t, e, n) { if (r === -1)
    return !1; if (!e)
    return !0; let i = r ? t[r - 1] : n; return !i || !!i.match(/\s/); }
var y = c.import("core/module"), x = class r extends y {
    constructor(t, e) { super(t, e), this.isOpen = !1, this.itemIndex = 0, this.values = [], this.suspendMouseEnter = !1, Array.isArray(e?.dataAttributes) && (this.options.dataAttributes = this.options.dataAttributes ? this.options.dataAttributes.concat(e.dataAttributes) : e.dataAttributes); for (let n in this.options) {
        let i = n, o = this.options[i];
        typeof o == "function" && (this.options[i] = o.bind(this));
    } this.mentionContainer = document.createElement("div"), this.mentionContainer.className = this.options.mentionContainerClass ? this.options.mentionContainerClass : "", this.mentionContainer.style.cssText = "display: none; position: absolute;", this.mentionContainer.onmousemove = this.onContainerMouseMove.bind(this), this.options.fixMentionsToQuill && (this.mentionContainer.style.width = "auto"), this.mentionList = document.createElement("ul"), this.mentionList.id = "quill-mention-list", t.root.setAttribute("aria-owns", "quill-mention-list"), this.mentionList.className = this.options.mentionListClass ? this.options.mentionListClass : "", this.mentionContainer.appendChild(this.mentionList), t.on("text-change", this.onTextChange.bind(this)), t.on("selection-change", this.onSelectionChange.bind(this)), t.container.addEventListener("paste", () => { setTimeout(() => { let n = t.getSelection(); this.onSelectionChange(n); }); }), t.keyboard.addBinding({ key: l.TAB }, this.selectHandler.bind(this)), t.keyboard.bindings[l.TAB].unshift(t.keyboard.bindings[l.TAB].pop()); for (let n of this.options.selectKeys ?? [])
        t.keyboard.addBinding({ key: n }, this.selectHandler.bind(this)); t.keyboard.bindings[l.ENTER].unshift(t.keyboard.bindings[l.ENTER].pop()), t.keyboard.addBinding({ key: l.ESCAPE }, this.escapeHandler.bind(this)), t.keyboard.addBinding({ key: l.UP }, this.upHandler.bind(this)), t.keyboard.addBinding({ key: l.DOWN }, this.downHandler.bind(this)); }
    selectHandler() { return this.isOpen && !this.existingSourceExecutionToken ? (this.selectItem(), !1) : !0; }
    escapeHandler() { return this.isOpen ? (this.existingSourceExecutionToken && (this.existingSourceExecutionToken.abandoned = !0), this.hideMentionList(), !1) : !0; }
    upHandler() { return this.isOpen && !this.existingSourceExecutionToken ? (this.prevItem(), !1) : !0; }
    downHandler() { return this.isOpen && !this.existingSourceExecutionToken ? (this.nextItem(), !1) : !0; }
    showMentionList() { this.options.positioningStrategy === "fixed" ? document.body.appendChild(this.mentionContainer) : this.quill.container.appendChild(this.mentionContainer), this.mentionContainer.style.visibility = "hidden", this.mentionContainer.style.display = "", this.mentionContainer.scrollTop = 0, this.setMentionContainerPosition(), this.setIsOpen(!0); }
    hideMentionList() { this.options.onBeforeClose && this.options.onBeforeClose(), this.mentionContainer.style.display = "none", this.mentionContainer.remove(), this.setIsOpen(!1), this.quill.root.removeAttribute("aria-activedescendant"); }
    highlightItem(t = !0) { for (let n = 0; n < this.mentionList.childNodes.length; n += 1) {
        let i = this.mentionList.childNodes[n];
        i instanceof HTMLElement && i.classList.remove("selected");
    } let e = this.mentionList.childNodes[this.itemIndex]; if (!(this.itemIndex === -1 || e.dataset.disabled === "true") && (e.classList.add("selected"), this.quill.root.setAttribute("aria-activedescendant", e.id), t)) {
        let n = e.offsetHeight, i = e.offsetTop, o = this.mentionContainer.scrollTop, s = o + this.mentionContainer.offsetHeight;
        i < o ? this.mentionContainer.scrollTop = i : i > s - n && (this.mentionContainer.scrollTop += i - s + n);
    } }
    onContainerMouseMove() { this.suspendMouseEnter = !1; }
    selectItem() { if (this.itemIndex === -1)
        return; let e = this.mentionList.childNodes[this.itemIndex].dataset; e.disabled || (this.options.onSelect?.(e, (n, i = !1, o = {}) => this.insertItem(n, i, o)), this.hideMentionList()); }
    insertItem(t, e, n = {}) { let i = t; if (i === null || this.mentionCharPos === void 0 || this.cursorPos === void 0)
        return; let o = p(p({}, this.options), n); o.showDenotationChar || (i.denotationChar = ""); let s; e ? s = this.cursorPos : (s = this.mentionCharPos, this.quill.deleteText(this.mentionCharPos, this.cursorPos - this.mentionCharPos, c.sources.USER)); let h = this.quill.insertEmbed(s, o.blotName ?? r.DEFAULTS.blotName, i, c.sources.USER); return o.spaceAfterInsert ? (this.quill.insertText(s + 1, " ", c.sources.USER), this.quill.setSelection(s + 2, c.sources.USER)) : this.quill.setSelection(s + 1, c.sources.USER), this.hideMentionList(), h; }
    onItemMouseEnter(t) { if (this.suspendMouseEnter || !(t.target instanceof HTMLElement))
        return; let e = Number(t.target?.dataset.index); !Number.isNaN(e) && e !== this.itemIndex && (this.itemIndex = e, this.highlightItem(!1)); }
    onDisabledItemMouseEnter() { this.suspendMouseEnter || (this.itemIndex = -1, this.highlightItem(!1)); }
    onItemClick(t) { t.preventDefault(), t.stopImmediatePropagation(), t.currentTarget instanceof HTMLElement && (this.itemIndex = t.currentTarget?.dataset.index ? Number.parseInt(t.currentTarget.dataset.index) : -1, this.highlightItem(), this.selectItem()); }
    onItemMouseDown(t) { t.preventDefault(), t.stopImmediatePropagation(); }
    renderLoading() { let t = this.options.renderLoading?.() ?? void 0; if (t === void 0)
        return; if (this.mentionContainer.getElementsByClassName("ql-mention-loading").length > 0) {
        this.showMentionList();
        return;
    } this.mentionList.innerHTML = ""; let e = document.createElement("div"); e.className = "ql-mention-loading", g(e, t), this.mentionContainer.append(e), this.showMentionList(); }
    removeLoading() { let t = this.mentionContainer.getElementsByClassName("ql-mention-loading"); t.length > 0 && t[0].remove(); }
    renderList(t, e, n) { if (e && e.length > 0) {
        this.removeLoading(), this.values = e, this.mentionList.innerText = "";
        let i = -1;
        for (let o = 0; o < e.length; o += 1) {
            let s = document.createElement("li");
            s.id = "quill-mention-item-" + o, s.className = this.options.listItemClass ? this.options.listItemClass : "", e[o].disabled ? (s.className += " disabled", s.setAttribute("aria-hidden", "true")) : i === -1 && (i = o), s.dataset.index = o.toString();
            let h = this.options.renderItem(e[o], n);
            g(s, h), e[o].disabled ? s.onmouseenter = this.onDisabledItemMouseEnter.bind(this) : (s.onmouseenter = this.onItemMouseEnter.bind(this), s.onmouseup = this.onItemClick.bind(this), s.onmousedown = this.onItemMouseDown.bind(this)), s.dataset.denotationChar = t, this.mentionList.appendChild(b(s, e[o], this.options.dataAttributes));
        }
        this.itemIndex = i, this.highlightItem(), this.showMentionList();
    }
    else
        this.hideMentionList(); }
    nextItem() { let t = 0, e, n; do
        if (t++, e = (this.itemIndex + t) % this.values.length, n = this.mentionList.childNodes[e].dataset.disabled === "true", t === this.values.length + 1) {
            e = -1;
            break;
        }
    while (n); this.itemIndex = e, this.suspendMouseEnter = !0, this.highlightItem(); }
    prevItem() { let t = 0, e, n; do
        if (t++, e = (this.itemIndex + this.values.length - t) % this.values.length, n = this.mentionList.childNodes[e].dataset.disabled === "true", t === this.values.length + 1) {
            e = -1;
            break;
        }
    while (n); this.itemIndex = e, this.suspendMouseEnter = !0, this.highlightItem(); }
    containerBottomIsNotVisible(t, e) { return t + this.mentionContainer.offsetHeight + e.top > window.scrollY + window.innerHeight; }
    containerRightIsNotVisible(t, e) { if (this.options.fixMentionsToQuill)
        return !1; let n = t + this.mentionContainer.offsetWidth + e.left, i = window.scrollX + document.documentElement.clientWidth; return n > i; }
    setIsOpen(t) { this.isOpen !== t && (t ? this.options.onOpen?.() : this.options.onClose?.(), this.isOpen = t); }
    setMentionContainerPosition() { this.options.positioningStrategy === "fixed" ? this.setMentionContainerPosition_Fixed() : this.setMentionContainerPosition_Normal(); }
    setMentionContainerPosition_Normal() { if (this.mentionCharPos === void 0)
        return; let t = this.quill.container.getBoundingClientRect(), e = this.quill.getBounds(this.mentionCharPos); if (e === null)
        return; let n = this.mentionContainer.offsetHeight, i = this.options.offsetTop, o = this.options.offsetLeft; if (this.options.fixMentionsToQuill ? this.mentionContainer.style.right = "0px" : o += e.left, this.containerRightIsNotVisible(o, t)) {
        let s = this.mentionContainer.offsetWidth + this.options.offsetLeft;
        o = t.width - s;
    } if (this.options.defaultMenuOrientation === "top") {
        if (this.options.fixMentionsToQuill ? i = -1 * (n + this.options.offsetTop) : i = e.top - (n + this.options.offsetTop), i + t.top <= 0) {
            let s = this.options.offsetTop;
            this.options.fixMentionsToQuill ? s += t.height : s += e.bottom, i = s;
        }
    }
    else if (this.options.fixMentionsToQuill ? i += t.height : i += e.bottom, this.containerBottomIsNotVisible(i, t)) {
        let s = this.options.offsetTop * -1;
        this.options.fixMentionsToQuill || (s += e.top), i = s - n;
    } i >= 0 ? this.options.mentionContainerClass?.split(" ").forEach(s => { this.mentionContainer.classList.add(`${s}-bottom`), this.mentionContainer.classList.remove(`${s}-top`); }) : this.options.mentionContainerClass?.split(" ").forEach(s => { this.mentionContainer.classList.add(`${s}-top`), this.mentionContainer.classList.remove(`${s}-bottom`); }), this.mentionContainer.style.top = `${i}px`, this.mentionContainer.style.left = `${o}px`, this.mentionContainer.style.visibility = "visible"; }
    setMentionContainerPosition_Fixed() { if (this.mentionCharPos === void 0)
        return; this.mentionContainer.style.position = "fixed", this.mentionContainer.style.height = ""; let t = this.quill.container.getBoundingClientRect(), e = this.quill.getBounds(this.mentionCharPos); if (e === null)
        return; let n = { right: t.right - e.right, left: t.left + e.left, top: t.top + e.top, width: 0, height: e.height }, i = this.options.fixMentionsToQuill ? t : n, o = this.options.offsetTop, s = this.options.offsetLeft; if (this.options.fixMentionsToQuill) {
        let d = i.right;
        this.mentionContainer.style.right = `${d}px`;
    }
    else
        s += i.left, s + this.mentionContainer.offsetWidth > document.documentElement.clientWidth && (s -= s + this.mentionContainer.offsetWidth - document.documentElement.clientWidth); let h = i.top, a = document.documentElement.clientHeight - (i.top + i.height), m = this.mentionContainer.offsetHeight <= a, f = this.mentionContainer.offsetHeight <= h, u; this.options.defaultMenuOrientation === "top" && f ? u = "top" : this.options.defaultMenuOrientation === "bottom" && m ? u = "bottom" : u = a > h ? "bottom" : "top", u === "bottom" ? (o = i.top + i.height, m || (this.mentionContainer.style.height = a - 3 + "px"), this.options.mentionContainerClass?.split(" ").forEach(d => { this.mentionContainer.classList.add(`${d}-bottom`), this.mentionContainer.classList.remove(`${d}-top`); })) : (o = i.top - this.mentionContainer.offsetHeight, f || (this.mentionContainer.style.height = h - 3 + "px", o = 3), this.options.mentionContainerClass?.split(" ").forEach(d => { this.mentionContainer.classList.add(`${d}-top`), this.mentionContainer.classList.remove(`${d}-bottom`); })), this.mentionContainer.style.top = `${o}px`, this.mentionContainer.style.left = `${s}px`, this.mentionContainer.style.visibility = "visible"; }
    getTextBeforeCursor() { let t = Math.max(0, (this.cursorPos ?? 0) - this.options.maxChars); return this.quill.getText(t, (this.cursorPos ?? 0) - t); }
    onSomethingChange() { let t = this.quill.getSelection(); if (t == null)
        return; this.cursorPos = t.index; let e = this.getTextBeforeCursor(), n = Math.max(0, this.cursorPos - this.options.maxChars), i = n ? this.quill.getText(n - 1, n) : "", { mentionChar: o, mentionCharIndex: s } = I(e, this.options.mentionDenotationChars, this.options.isolateCharacter, this.options.allowInlineMentionChar); if (o !== null && T(s, e, this.options.isolateCharacter, i)) {
        let h = this.cursorPos - (e.length - s);
        this.mentionCharPos = h;
        let a = e.substring(s + o.length);
        if (a.length >= this.options.minChars && E(a, this.getAllowedCharsRegex(o))) {
            this.existingSourceExecutionToken && (this.existingSourceExecutionToken.abandoned = !0), this.renderLoading();
            let m = { abandoned: !1 };
            this.existingSourceExecutionToken = m, this.options.source?.(a, (f, u) => { m.abandoned || (this.existingSourceExecutionToken = void 0, this.renderList(o, f, u)); }, o);
        }
        else
            this.existingSourceExecutionToken && (this.existingSourceExecutionToken.abandoned = !0), this.hideMentionList();
    }
    else
        this.existingSourceExecutionToken && (this.existingSourceExecutionToken.abandoned = !0), this.hideMentionList(); }
    getAllowedCharsRegex(t) { return this.options.allowedChars instanceof RegExp ? this.options.allowedChars : this.options.allowedChars?.(t) ?? /^[a-zA-Z0-9_]*$/; }
    onTextChange(t, e, n) { n === "user" && setTimeout(this.onSomethingChange.bind(this), 50); }
    onSelectionChange(t) { t !== null && t.length === 0 ? this.onSomethingChange() : this.hideMentionList(); }
    openMenu(t) { let e = this.quill.getSelection(!0); this.quill.insertText(e.index, t), this.quill.blur(), this.quill.focus(); }
};
x.DEFAULTS = { mentionDenotationChars: ["@"], showDenotationChar: !0, allowedChars: /^[a-zA-Z0-9_]*$/, minChars: 0, maxChars: 31, offsetTop: 2, offsetLeft: 0, isolateCharacter: !1, allowInlineMentionChar: !1, fixMentionsToQuill: !1, positioningStrategy: "normal", defaultMenuOrientation: "bottom", blotName: "mention", dataAttributes: ["id", "value", "denotationChar", "link", "target", "disabled"], linkTarget: "_blank", listItemClass: "ql-mention-list-item", mentionContainerClass: "ql-mention-list-container", mentionListClass: "ql-mention-list", spaceAfterInsert: !0, selectKeys: [l.ENTER], source: (r, t, e) => { t([], r); }, renderItem: ({ value: r }) => `${r}`, onSelect: (r, t) => t(r), onOpen: () => !0, onBeforeClose: () => !0, onClose: () => !0, renderLoading: () => null };
export { C as a, L as b, k as c, x as d };
