var n = class a {
    constructor(e, r) { this.correlationId = r, this.measureName = a.makeMeasureName(e, r), this.startMark = a.makeStartMark(e, r), this.endMark = a.makeEndMark(e, r); }
    static makeMeasureName(e, r) { return `msal.measure.${e}.${r}`; }
    static makeStartMark(e, r) { return `msal.start.${e}.${r}`; }
    static makeEndMark(e, r) { return `msal.end.${e}.${r}`; }
    static supportsBrowserPerformance() { return typeof window < "u" && typeof window.performance < "u" && typeof window.performance.mark == "function" && typeof window.performance.measure == "function" && typeof window.performance.clearMarks == "function" && typeof window.performance.clearMeasures == "function" && typeof window.performance.getEntriesByName == "function"; }
    static flushMeasurements(e, r) { if (a.supportsBrowserPerformance())
        try {
            r.forEach(s => { let t = a.makeMeasureName(s.name, e); window.performance.getEntriesByName(t, "measure").length > 0 && (window.performance.clearMeasures(t), window.performance.clearMarks(a.makeStartMark(t, e)), window.performance.clearMarks(a.makeEndMark(t, e))); });
        }
        catch { } }
    startMeasurement() { if (a.supportsBrowserPerformance())
        try {
            window.performance.mark(this.startMark);
        }
        catch { } }
    endMeasurement() { if (a.supportsBrowserPerformance())
        try {
            window.performance.mark(this.endMark), window.performance.measure(this.measureName, this.startMark, this.endMark);
        }
        catch { } }
    flushMeasurement() { if (a.supportsBrowserPerformance())
        try {
            let e = window.performance.getEntriesByName(this.measureName, "measure");
            if (e.length > 0) {
                let r = e[0].duration;
                return window.performance.clearMeasures(this.measureName), window.performance.clearMarks(this.startMark), window.performance.clearMarks(this.endMark), r;
            }
        }
        catch { } return null; }
};
export { n as a };
/*! Bundled license information:

@azure/msal-browser/dist/telemetry/BrowserPerformanceMeasurement.mjs:
  (*! @azure/msal-browser v3.28.1 2025-01-14 *)
*/
