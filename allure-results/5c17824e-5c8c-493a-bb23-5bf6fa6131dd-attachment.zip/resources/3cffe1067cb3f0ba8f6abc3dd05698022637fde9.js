import { a as L, b as Ut, d as Xs, e as Ft, f as jc, g as ot } from "@nf-internal/chunk-66YHNWRR";
var al = Ft((A2, ol) => { var at = -1, Z = 1, P = 0; function cr(r, t, e, s, n) { if (r === t)
    return r ? [[P, r]] : []; if (e != null) {
    var i = _g(r, t, e);
    if (i)
        return i;
} var o = dn(r, t), a = r.substring(0, o); r = r.substring(o), t = t.substring(o), o = is(r, t); var l = r.substring(r.length - o); r = r.substring(0, r.length - o), t = t.substring(0, t.length - o); var u = Eg(r, t); return a && u.unshift([P, a]), l && u.push([P, l]), pn(u, n), s && wg(u), u; } function Eg(r, t) { var e; if (!r)
    return [[Z, t]]; if (!t)
    return [[at, r]]; var s = r.length > t.length ? r : t, n = r.length > t.length ? t : r, i = s.indexOf(n); if (i !== -1)
    return e = [[Z, s.substring(0, i)], [P, n], [Z, s.substring(i + n.length)]], r.length > t.length && (e[0][0] = e[2][0] = at), e; if (n.length === 1)
    return [[at, r], [Z, t]]; var o = Ng(r, t); if (o) {
    var a = o[0], l = o[1], u = o[2], c = o[3], f = o[4], h = cr(a, u), p = cr(l, c);
    return h.concat([[P, f]], p);
} return Tg(r, t); } function Tg(r, t) { for (var e = r.length, s = t.length, n = Math.ceil((e + s) / 2), i = n, o = 2 * n, a = new Array(o), l = new Array(o), u = 0; u < o; u++)
    a[u] = -1, l[u] = -1; a[i + 1] = 0, l[i + 1] = 0; for (var c = e - s, f = c % 2 !== 0, h = 0, p = 0, m = 0, y = 0, v = 0; v < n; v++) {
    for (var g = -v + h; g <= v - p; g += 2) {
        var A = i + g, E;
        g === -v || g !== v && a[A - 1] < a[A + 1] ? E = a[A + 1] : E = a[A - 1] + 1;
        for (var T = E - g; E < e && T < s && r.charAt(E) === t.charAt(T);)
            E++, T++;
        if (a[A] = E, E > e)
            p += 2;
        else if (T > s)
            h += 2;
        else if (f) {
            var N = i + c - g;
            if (N >= 0 && N < o && l[N] !== -1) {
                var _ = e - l[N];
                if (E >= _)
                    return Qa(r, t, E, T);
            }
        }
    }
    for (var Y = -v + m; Y <= v - y; Y += 2) {
        var N = i + Y, _;
        Y === -v || Y !== v && l[N - 1] < l[N + 1] ? _ = l[N + 1] : _ = l[N - 1] + 1;
        for (var mt = _ - Y; _ < e && mt < s && r.charAt(e - _ - 1) === t.charAt(s - mt - 1);)
            _++, mt++;
        if (l[N] = _, _ > e)
            y += 2;
        else if (mt > s)
            m += 2;
        else if (!f) {
            var A = i + c - Y;
            if (A >= 0 && A < o && a[A] !== -1) {
                var E = a[A], T = i + E - A;
                if (_ = e - _, E >= _)
                    return Qa(r, t, E, T);
            }
        }
    }
} return [[at, r], [Z, t]]; } function Qa(r, t, e, s) { var n = r.substring(0, e), i = t.substring(0, s), o = r.substring(e), a = t.substring(s), l = cr(n, i), u = cr(o, a); return l.concat(u); } function dn(r, t) { if (!r || !t || r.charAt(0) !== t.charAt(0))
    return 0; for (var e = 0, s = Math.min(r.length, t.length), n = s, i = 0; e < n;)
    r.substring(i, n) == t.substring(i, n) ? (e = n, i = e) : s = n, n = Math.floor((s - e) / 2 + e); return rl(r.charCodeAt(n - 1)) && n--, n; } function Ya(r, t) { var e = r.length, s = t.length; if (e == 0 || s == 0)
    return 0; e > s ? r = r.substring(e - s) : e < s && (t = t.substring(0, e)); var n = Math.min(e, s); if (r == t)
    return n; for (var i = 0, o = 1;;) {
    var a = r.substring(n - o), l = t.indexOf(a);
    if (l == -1)
        return i;
    o += l, (l == 0 || r.substring(n - o) == t.substring(0, o)) && (i = o, o++);
} } function is(r, t) { if (!r || !t || r.slice(-1) !== t.slice(-1))
    return 0; for (var e = 0, s = Math.min(r.length, t.length), n = s, i = 0; e < n;)
    r.substring(r.length - n, r.length - i) == t.substring(t.length - n, t.length - i) ? (e = n, i = e) : s = n, n = Math.floor((s - e) / 2 + e); return sl(r.charCodeAt(r.length - n)) && n--, n; } function Ng(r, t) { var e = r.length > t.length ? r : t, s = r.length > t.length ? t : r; if (e.length < 4 || s.length * 2 < e.length)
    return null; function n(p, m, y) { for (var v = p.substring(y, y + Math.floor(p.length / 4)), g = -1, A = "", E, T, N, _; (g = m.indexOf(v, g + 1)) !== -1;) {
    var Y = dn(p.substring(y), m.substring(g)), mt = is(p.substring(0, y), m.substring(0, g));
    A.length < mt + Y && (A = m.substring(g - mt, g) + m.substring(g, g + Y), E = p.substring(0, y - mt), T = p.substring(y + Y), N = m.substring(0, g - mt), _ = m.substring(g + Y));
} return A.length * 2 >= p.length ? [E, T, N, _, A] : null; } var i = n(e, s, Math.ceil(e.length / 4)), o = n(e, s, Math.ceil(e.length / 2)), a; if (!i && !o)
    return null; o ? i ? a = i[4].length > o[4].length ? i : o : a = o : a = i; var l, u, c, f; r.length > t.length ? (l = a[0], u = a[1], c = a[2], f = a[3]) : (c = a[0], f = a[1], l = a[2], u = a[3]); var h = a[4]; return [l, u, c, f, h]; } function wg(r) { for (var t = !1, e = [], s = 0, n = null, i = 0, o = 0, a = 0, l = 0, u = 0; i < r.length;)
    r[i][0] == P ? (e[s++] = i, o = l, a = u, l = 0, u = 0, n = r[i][1]) : (r[i][0] == Z ? l += r[i][1].length : u += r[i][1].length, n && n.length <= Math.max(o, a) && n.length <= Math.max(l, u) && (r.splice(e[s - 1], 0, [at, n]), r[e[s - 1] + 1][0] = Z, s--, s--, i = s > 0 ? e[s - 1] : -1, o = 0, a = 0, l = 0, u = 0, n = null, t = !0)), i++; for (t && pn(r), Og(r), i = 1; i < r.length;) {
    if (r[i - 1][0] == at && r[i][0] == Z) {
        var c = r[i - 1][1], f = r[i][1], h = Ya(c, f), p = Ya(f, c);
        h >= p ? (h >= c.length / 2 || h >= f.length / 2) && (r.splice(i, 0, [P, f.substring(0, h)]), r[i - 1][1] = c.substring(0, c.length - h), r[i + 1][1] = f.substring(h), i++) : (p >= c.length / 2 || p >= f.length / 2) && (r.splice(i, 0, [P, c.substring(0, p)]), r[i - 1][0] = Z, r[i - 1][1] = f.substring(0, f.length - p), r[i + 1][0] = at, r[i + 1][1] = c.substring(p), i++), i++;
    }
    i++;
} } var Ja = /[^a-zA-Z0-9]/, tl = /\s/, el = /[\r\n]/, Sg = /\n\r?\n$/, Lg = /^\r?\n\r?\n/; function Og(r) { function t(p, m) { if (!p || !m)
    return 6; var y = p.charAt(p.length - 1), v = m.charAt(0), g = y.match(Ja), A = v.match(Ja), E = g && y.match(tl), T = A && v.match(tl), N = E && y.match(el), _ = T && v.match(el), Y = N && p.match(Sg), mt = _ && m.match(Lg); return Y || mt ? 5 : N || _ ? 4 : g && !E && T ? 3 : E || T ? 2 : g || A ? 1 : 0; } for (var e = 1; e < r.length - 1;) {
    if (r[e - 1][0] == P && r[e + 1][0] == P) {
        var s = r[e - 1][1], n = r[e][1], i = r[e + 1][1], o = is(s, n);
        if (o) {
            var a = n.substring(n.length - o);
            s = s.substring(0, s.length - o), n = a + n.substring(0, n.length - o), i = a + i;
        }
        for (var l = s, u = n, c = i, f = t(s, n) + t(n, i); n.charAt(0) === i.charAt(0);) {
            s += n.charAt(0), n = n.substring(1) + i.charAt(0), i = i.substring(1);
            var h = t(s, n) + t(n, i);
            h >= f && (f = h, l = s, u = n, c = i);
        }
        r[e - 1][1] != l && (l ? r[e - 1][1] = l : (r.splice(e - 1, 1), e--), r[e][1] = u, c ? r[e + 1][1] = c : (r.splice(e + 1, 1), e--));
    }
    e++;
} } function pn(r, t) { r.push([P, ""]); for (var e = 0, s = 0, n = 0, i = "", o = "", a; e < r.length;) {
    if (e < r.length - 1 && !r[e][1]) {
        r.splice(e, 1);
        continue;
    }
    switch (r[e][0]) {
        case Z:
            n++, o += r[e][1], e++;
            break;
        case at:
            s++, i += r[e][1], e++;
            break;
        case P:
            var l = e - n - s - 1;
            if (t) {
                if (l >= 0 && il(r[l][1])) {
                    var u = r[l][1].slice(-1);
                    if (r[l][1] = r[l][1].slice(0, -1), i = u + i, o = u + o, !r[l][1]) {
                        r.splice(l, 1), e--;
                        var c = l - 1;
                        r[c] && r[c][0] === Z && (n++, o = r[c][1] + o, c--), r[c] && r[c][0] === at && (s++, i = r[c][1] + i, c--), l = c;
                    }
                }
                if (nl(r[e][1])) {
                    var u = r[e][1].charAt(0);
                    r[e][1] = r[e][1].slice(1), i += u, o += u;
                }
            }
            if (e < r.length - 1 && !r[e][1]) {
                r.splice(e, 1);
                break;
            }
            if (i.length > 0 || o.length > 0) {
                i.length > 0 && o.length > 0 && (a = dn(o, i), a !== 0 && (l >= 0 ? r[l][1] += o.substring(0, a) : (r.splice(0, 0, [P, o.substring(0, a)]), e++), o = o.substring(a), i = i.substring(a)), a = is(o, i), a !== 0 && (r[e][1] = o.substring(o.length - a) + r[e][1], o = o.substring(0, o.length - a), i = i.substring(0, i.length - a)));
                var f = n + s;
                i.length === 0 && o.length === 0 ? (r.splice(e - f, f), e = e - f) : i.length === 0 ? (r.splice(e - f, f, [Z, o]), e = e - f + 1) : o.length === 0 ? (r.splice(e - f, f, [at, i]), e = e - f + 1) : (r.splice(e - f, f, [at, i], [Z, o]), e = e - f + 2);
            }
            e !== 0 && r[e - 1][0] === P ? (r[e - 1][1] += r[e][1], r.splice(e, 1)) : e++, n = 0, s = 0, i = "", o = "";
            break;
    }
} r[r.length - 1][1] === "" && r.pop(); var h = !1; for (e = 1; e < r.length - 1;)
    r[e - 1][0] === P && r[e + 1][0] === P && (r[e][1].substring(r[e][1].length - r[e - 1][1].length) === r[e - 1][1] ? (r[e][1] = r[e - 1][1] + r[e][1].substring(0, r[e][1].length - r[e - 1][1].length), r[e + 1][1] = r[e - 1][1] + r[e + 1][1], r.splice(e - 1, 1), h = !0) : r[e][1].substring(0, r[e + 1][1].length) == r[e + 1][1] && (r[e - 1][1] += r[e + 1][1], r[e][1] = r[e][1].substring(r[e + 1][1].length) + r[e + 1][1], r.splice(e + 1, 1), h = !0)), e++; h && pn(r, t); } function rl(r) { return r >= 55296 && r <= 56319; } function sl(r) { return r >= 56320 && r <= 57343; } function nl(r) { return sl(r.charCodeAt(0)); } function il(r) { return rl(r.charCodeAt(r.length - 1)); } function Cg(r) { for (var t = [], e = 0; e < r.length; e++)
    r[e][1].length > 0 && t.push(r[e]); return t; } function hn(r, t, e, s) { return il(r) || nl(s) ? null : Cg([[P, r], [at, t], [Z, e], [P, s]]); } function _g(r, t, e) { var s = typeof e == "number" ? { index: e, length: 0 } : e.oldRange, n = typeof e == "number" ? null : e.newRange, i = r.length, o = t.length; if (s.length === 0 && (n === null || n.length === 0)) {
    var a = s.index, l = r.slice(0, a), u = r.slice(a), c = n ? n.index : null;
    t: {
        var f = a + o - i;
        if (c !== null && c !== f || f < 0 || f > o)
            break t;
        var h = t.slice(0, f), p = t.slice(f);
        if (p !== u)
            break t;
        var m = Math.min(a, f), y = l.slice(0, m), v = h.slice(0, m);
        if (y !== v)
            break t;
        var g = l.slice(m), A = h.slice(m);
        return hn(y, g, A, u);
    }
    t: {
        if (c !== null && c !== a)
            break t;
        var E = a, h = t.slice(0, E), p = t.slice(E);
        if (h !== l)
            break t;
        var T = Math.min(i - E, o - E), N = u.slice(u.length - T), _ = p.slice(p.length - T);
        if (N !== _)
            break t;
        var g = u.slice(0, u.length - T), A = p.slice(0, p.length - T);
        return hn(l, g, A, N);
    }
} if (s.length > 0 && n && n.length === 0)
    t: {
        var y = r.slice(0, s.index), N = r.slice(s.index + s.length), m = y.length, T = N.length;
        if (o < m + T)
            break t;
        var v = t.slice(0, m), _ = t.slice(o - T);
        if (y !== v || N !== _)
            break t;
        var g = r.slice(m, i - T), A = t.slice(m, o - T);
        return hn(y, g, A, N);
    } return null; } function os(r, t, e, s) { return cr(r, t, e, s, !0); } os.INSERT = Z; os.DELETE = at; os.EQUAL = P; ol.exports = os; });
var Cn = Ft((fr, He) => { var qg = 200, xl = "__lodash_hash_undefined__", vl = 9007199254740991, En = "[object Arguments]", Ig = "[object Array]", Al = "[object Boolean]", El = "[object Date]", kg = "[object Error]", Tn = "[object Function]", Tl = "[object GeneratorFunction]", as = "[object Map]", Nl = "[object Number]", Nn = "[object Object]", ll = "[object Promise]", wl = "[object RegExp]", ls = "[object Set]", Sl = "[object String]", Ll = "[object Symbol]", gn = "[object WeakMap]", Ol = "[object ArrayBuffer]", us = "[object DataView]", Cl = "[object Float32Array]", _l = "[object Float64Array]", ql = "[object Int8Array]", Il = "[object Int16Array]", kl = "[object Int32Array]", Rl = "[object Uint8Array]", Bl = "[object Uint8ClampedArray]", Ml = "[object Uint16Array]", Dl = "[object Uint32Array]", Rg = /[\\^$.*+?()[\]{}|]/g, Bg = /\w*$/, Mg = /^\[object .+?Constructor\]$/, Dg = /^(?:0|[1-9]\d*)$/, S = {}; S[En] = S[Ig] = S[Ol] = S[us] = S[Al] = S[El] = S[Cl] = S[_l] = S[ql] = S[Il] = S[kl] = S[as] = S[Nl] = S[Nn] = S[wl] = S[ls] = S[Sl] = S[Ll] = S[Rl] = S[Bl] = S[Ml] = S[Dl] = !0; S[kg] = S[Tn] = S[gn] = !1; var jg = typeof global == "object" && global && global.Object === Object && global, Pg = typeof self == "object" && self && self.Object === Object && self, _t = jg || Pg || Function("return this")(), jl = typeof fr == "object" && fr && !fr.nodeType && fr, ul = jl && typeof He == "object" && He && !He.nodeType && He, Ug = ul && ul.exports === jl; function Fg(r, t) { return r.set(t[0], t[1]), r; } function Hg(r, t) { return r.add(t), r; } function zg(r, t) { for (var e = -1, s = r ? r.length : 0; ++e < s && t(r[e], e, r) !== !1;)
    ; return r; } function $g(r, t) { for (var e = -1, s = t.length, n = r.length; ++e < s;)
    r[n + e] = t[e]; return r; } function Pl(r, t, e, s) { var n = -1, i = r ? r.length : 0; for (s && i && (e = r[++n]); ++n < i;)
    e = t(e, r[n], n, r); return e; } function Kg(r, t) { for (var e = -1, s = Array(r); ++e < r;)
    s[e] = t(e); return s; } function Gg(r, t) { return r?.[t]; } function Ul(r) { var t = !1; if (r != null && typeof r.toString != "function")
    try {
        t = !!(r + "");
    }
    catch { } return t; } function cl(r) { var t = -1, e = Array(r.size); return r.forEach(function (s, n) { e[++t] = [n, s]; }), e; } function wn(r, t) { return function (e) { return r(t(e)); }; } function fl(r) { var t = -1, e = Array(r.size); return r.forEach(function (s) { e[++t] = s; }), e; } var Vg = Array.prototype, Wg = Function.prototype, cs = Object.prototype, mn = _t["__core-js_shared__"], hl = (function () { var r = /[^.]+$/.exec(mn && mn.keys && mn.keys.IE_PROTO || ""); return r ? "Symbol(src)_1." + r : ""; })(), Fl = Wg.toString, Qt = cs.hasOwnProperty, fs = cs.toString, Zg = RegExp("^" + Fl.call(Qt).replace(Rg, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"), dl = Ug ? _t.Buffer : void 0, pl = _t.Symbol, ml = _t.Uint8Array, Xg = wn(Object.getPrototypeOf, Object), Qg = Object.create, Yg = cs.propertyIsEnumerable, Jg = Vg.splice, gl = Object.getOwnPropertySymbols, t1 = dl ? dl.isBuffer : void 0, e1 = wn(Object.keys, Object), bn = Ke(_t, "DataView"), hr = Ke(_t, "Map"), yn = Ke(_t, "Promise"), xn = Ke(_t, "Set"), vn = Ke(_t, "WeakMap"), dr = Ke(Object, "create"), r1 = he(bn), s1 = he(hr), n1 = he(yn), i1 = he(xn), o1 = he(vn), bl = pl ? pl.prototype : void 0, yl = bl ? bl.valueOf : void 0; function fe(r) { var t = -1, e = r ? r.length : 0; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} } function a1() { this.__data__ = dr ? dr(null) : {}; } function l1(r) { return this.has(r) && delete this.__data__[r]; } function u1(r) { var t = this.__data__; if (dr) {
    var e = t[r];
    return e === xl ? void 0 : e;
} return Qt.call(t, r) ? t[r] : void 0; } function c1(r) { var t = this.__data__; return dr ? t[r] !== void 0 : Qt.call(t, r); } function f1(r, t) { var e = this.__data__; return e[r] = dr && t === void 0 ? xl : t, this; } fe.prototype.clear = a1; fe.prototype.delete = l1; fe.prototype.get = u1; fe.prototype.has = c1; fe.prototype.set = f1; function qt(r) { var t = -1, e = r ? r.length : 0; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} } function h1() { this.__data__ = []; } function d1(r) { var t = this.__data__, e = hs(t, r); if (e < 0)
    return !1; var s = t.length - 1; return e == s ? t.pop() : Jg.call(t, e, 1), !0; } function p1(r) { var t = this.__data__, e = hs(t, r); return e < 0 ? void 0 : t[e][1]; } function m1(r) { return hs(this.__data__, r) > -1; } function g1(r, t) { var e = this.__data__, s = hs(e, r); return s < 0 ? e.push([r, t]) : e[s][1] = t, this; } qt.prototype.clear = h1; qt.prototype.delete = d1; qt.prototype.get = p1; qt.prototype.has = m1; qt.prototype.set = g1; function ze(r) { var t = -1, e = r ? r.length : 0; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} } function b1() { this.__data__ = { hash: new fe, map: new (hr || qt), string: new fe }; } function y1(r) { return ds(this, r).delete(r); } function x1(r) { return ds(this, r).get(r); } function v1(r) { return ds(this, r).has(r); } function A1(r, t) { return ds(this, r).set(r, t), this; } ze.prototype.clear = b1; ze.prototype.delete = y1; ze.prototype.get = x1; ze.prototype.has = v1; ze.prototype.set = A1; function $e(r) { this.__data__ = new qt(r); } function E1() { this.__data__ = new qt; } function T1(r) { return this.__data__.delete(r); } function N1(r) { return this.__data__.get(r); } function w1(r) { return this.__data__.has(r); } function S1(r, t) { var e = this.__data__; if (e instanceof qt) {
    var s = e.__data__;
    if (!hr || s.length < qg - 1)
        return s.push([r, t]), this;
    e = this.__data__ = new ze(s);
} return e.set(r, t), this; } $e.prototype.clear = E1; $e.prototype.delete = T1; $e.prototype.get = N1; $e.prototype.has = w1; $e.prototype.set = S1; function L1(r, t) { var e = Ln(r) || Q1(r) ? Kg(r.length, String) : [], s = e.length, n = !!s; for (var i in r)
    (t || Qt.call(r, i)) && !(n && (i == "length" || V1(i, s))) && e.push(i); return e; } function Hl(r, t, e) { var s = r[t]; (!(Qt.call(r, t) && Gl(s, e)) || e === void 0 && !(t in r)) && (r[t] = e); } function hs(r, t) { for (var e = r.length; e--;)
    if (Gl(r[e][0], t))
        return e; return -1; } function O1(r, t) { return r && zl(t, On(t), r); } function An(r, t, e, s, n, i, o) { var a; if (s && (a = i ? s(r, n, i, o) : s(r)), a !== void 0)
    return a; if (!ps(r))
    return r; var l = Ln(r); if (l) {
    if (a = $1(r), !t)
        return F1(r, a);
}
else {
    var u = ce(r), c = u == Tn || u == Tl;
    if (J1(r))
        return R1(r, t);
    if (u == Nn || u == En || c && !i) {
        if (Ul(r))
            return i ? r : {};
        if (a = K1(c ? {} : r), !t)
            return H1(r, O1(a, r));
    }
    else {
        if (!S[u])
            return i ? r : {};
        a = G1(r, u, An, t);
    }
} o || (o = new $e); var f = o.get(r); if (f)
    return f; if (o.set(r, a), !l)
    var h = e ? z1(r) : On(r); return zg(h || r, function (p, m) { h && (m = p, p = r[m]), Hl(a, m, An(p, t, e, s, m, r, o)); }), a; } function C1(r) { return ps(r) ? Qg(r) : {}; } function _1(r, t, e) { var s = t(r); return Ln(r) ? s : $g(s, e(r)); } function q1(r) { return fs.call(r); } function I1(r) { if (!ps(r) || Z1(r))
    return !1; var t = Wl(r) || Ul(r) ? Zg : Mg; return t.test(he(r)); } function k1(r) { if (!Kl(r))
    return e1(r); var t = []; for (var e in Object(r))
    Qt.call(r, e) && e != "constructor" && t.push(e); return t; } function R1(r, t) { if (t)
    return r.slice(); var e = new r.constructor(r.length); return r.copy(e), e; } function Sn(r) { var t = new r.constructor(r.byteLength); return new ml(t).set(new ml(r)), t; } function B1(r, t) { var e = t ? Sn(r.buffer) : r.buffer; return new r.constructor(e, r.byteOffset, r.byteLength); } function M1(r, t, e) { var s = t ? e(cl(r), !0) : cl(r); return Pl(s, Fg, new r.constructor); } function D1(r) { var t = new r.constructor(r.source, Bg.exec(r)); return t.lastIndex = r.lastIndex, t; } function j1(r, t, e) { var s = t ? e(fl(r), !0) : fl(r); return Pl(s, Hg, new r.constructor); } function P1(r) { return yl ? Object(yl.call(r)) : {}; } function U1(r, t) { var e = t ? Sn(r.buffer) : r.buffer; return new r.constructor(e, r.byteOffset, r.length); } function F1(r, t) { var e = -1, s = r.length; for (t || (t = Array(s)); ++e < s;)
    t[e] = r[e]; return t; } function zl(r, t, e, s) { e || (e = {}); for (var n = -1, i = t.length; ++n < i;) {
    var o = t[n], a = s ? s(e[o], r[o], o, e, r) : void 0;
    Hl(e, o, a === void 0 ? r[o] : a);
} return e; } function H1(r, t) { return zl(r, $l(r), t); } function z1(r) { return _1(r, On, $l); } function ds(r, t) { var e = r.__data__; return W1(t) ? e[typeof t == "string" ? "string" : "hash"] : e.map; } function Ke(r, t) { var e = Gg(r, t); return I1(e) ? e : void 0; } var $l = gl ? wn(gl, Object) : r0, ce = q1; (bn && ce(new bn(new ArrayBuffer(1))) != us || hr && ce(new hr) != as || yn && ce(yn.resolve()) != ll || xn && ce(new xn) != ls || vn && ce(new vn) != gn) && (ce = function (r) { var t = fs.call(r), e = t == Nn ? r.constructor : void 0, s = e ? he(e) : void 0; if (s)
    switch (s) {
        case r1: return us;
        case s1: return as;
        case n1: return ll;
        case i1: return ls;
        case o1: return gn;
    } return t; }); function $1(r) { var t = r.length, e = r.constructor(t); return t && typeof r[0] == "string" && Qt.call(r, "index") && (e.index = r.index, e.input = r.input), e; } function K1(r) { return typeof r.constructor == "function" && !Kl(r) ? C1(Xg(r)) : {}; } function G1(r, t, e, s) { var n = r.constructor; switch (t) {
    case Ol: return Sn(r);
    case Al:
    case El: return new n(+r);
    case us: return B1(r, s);
    case Cl:
    case _l:
    case ql:
    case Il:
    case kl:
    case Rl:
    case Bl:
    case Ml:
    case Dl: return U1(r, s);
    case as: return M1(r, s, e);
    case Nl:
    case Sl: return new n(r);
    case wl: return D1(r);
    case ls: return j1(r, s, e);
    case Ll: return P1(r);
} } function V1(r, t) { return t = t ?? vl, !!t && (typeof r == "number" || Dg.test(r)) && r > -1 && r % 1 == 0 && r < t; } function W1(r) { var t = typeof r; return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? r !== "__proto__" : r === null; } function Z1(r) { return !!hl && hl in r; } function Kl(r) { var t = r && r.constructor, e = typeof t == "function" && t.prototype || cs; return r === e; } function he(r) { if (r != null) {
    try {
        return Fl.call(r);
    }
    catch { }
    try {
        return r + "";
    }
    catch { }
} return ""; } function X1(r) { return An(r, !0, !0); } function Gl(r, t) { return r === t || r !== r && t !== t; } function Q1(r) { return Y1(r) && Qt.call(r, "callee") && (!Yg.call(r, "callee") || fs.call(r) == En); } var Ln = Array.isArray; function Vl(r) { return r != null && t0(r.length) && !Wl(r); } function Y1(r) { return e0(r) && Vl(r); } var J1 = t1 || s0; function Wl(r) { var t = ps(r) ? fs.call(r) : ""; return t == Tn || t == Tl; } function t0(r) { return typeof r == "number" && r > -1 && r % 1 == 0 && r <= vl; } function ps(r) { var t = typeof r; return !!r && (t == "object" || t == "function"); } function e0(r) { return !!r && typeof r == "object"; } function On(r) { return Vl(r) ? L1(r) : k1(r); } function r0() { return []; } function s0() { return !1; } He.exports = X1; });
var Fn = Ft((pr, Ve) => { var n0 = 200, Un = "__lodash_hash_undefined__", Es = 1, ou = 2, au = 9007199254740991, ms = "[object Arguments]", kn = "[object Array]", i0 = "[object AsyncFunction]", lu = "[object Boolean]", uu = "[object Date]", cu = "[object Error]", fu = "[object Function]", o0 = "[object GeneratorFunction]", gs = "[object Map]", hu = "[object Number]", a0 = "[object Null]", Ge = "[object Object]", Zl = "[object Promise]", l0 = "[object Proxy]", du = "[object RegExp]", bs = "[object Set]", pu = "[object String]", u0 = "[object Symbol]", c0 = "[object Undefined]", Rn = "[object WeakMap]", mu = "[object ArrayBuffer]", ys = "[object DataView]", f0 = "[object Float32Array]", h0 = "[object Float64Array]", d0 = "[object Int8Array]", p0 = "[object Int16Array]", m0 = "[object Int32Array]", g0 = "[object Uint8Array]", b0 = "[object Uint8ClampedArray]", y0 = "[object Uint16Array]", x0 = "[object Uint32Array]", v0 = /[\\^$.*+?()[\]{}|]/g, A0 = /^\[object .+?Constructor\]$/, E0 = /^(?:0|[1-9]\d*)$/, C = {}; C[f0] = C[h0] = C[d0] = C[p0] = C[m0] = C[g0] = C[b0] = C[y0] = C[x0] = !0; C[ms] = C[kn] = C[mu] = C[lu] = C[ys] = C[uu] = C[cu] = C[fu] = C[gs] = C[hu] = C[Ge] = C[du] = C[bs] = C[pu] = C[Rn] = !1; var gu = typeof global == "object" && global && global.Object === Object && global, T0 = typeof self == "object" && self && self.Object === Object && self, It = gu || T0 || Function("return this")(), bu = typeof pr == "object" && pr && !pr.nodeType && pr, Xl = bu && typeof Ve == "object" && Ve && !Ve.nodeType && Ve, yu = Xl && Xl.exports === bu, _n = yu && gu.process, Ql = (function () { try {
    return _n && _n.binding && _n.binding("util");
}
catch { } })(), Yl = Ql && Ql.isTypedArray; function N0(r, t) { for (var e = -1, s = r == null ? 0 : r.length, n = 0, i = []; ++e < s;) {
    var o = r[e];
    t(o, e, r) && (i[n++] = o);
} return i; } function w0(r, t) { for (var e = -1, s = t.length, n = r.length; ++e < s;)
    r[n + e] = t[e]; return r; } function S0(r, t) { for (var e = -1, s = r == null ? 0 : r.length; ++e < s;)
    if (t(r[e], e, r))
        return !0; return !1; } function L0(r, t) { for (var e = -1, s = Array(r); ++e < r;)
    s[e] = t(e); return s; } function O0(r) { return function (t) { return r(t); }; } function C0(r, t) { return r.has(t); } function _0(r, t) { return r?.[t]; } function q0(r) { var t = -1, e = Array(r.size); return r.forEach(function (s, n) { e[++t] = [n, s]; }), e; } function I0(r, t) { return function (e) { return r(t(e)); }; } function k0(r) { var t = -1, e = Array(r.size); return r.forEach(function (s) { e[++t] = s; }), e; } var R0 = Array.prototype, B0 = Function.prototype, Ts = Object.prototype, qn = It["__core-js_shared__"], xu = B0.toString, Et = Ts.hasOwnProperty, Jl = (function () { var r = /[^.]+$/.exec(qn && qn.keys && qn.keys.IE_PROTO || ""); return r ? "Symbol(src)_1." + r : ""; })(), vu = Ts.toString, M0 = RegExp("^" + xu.call(Et).replace(v0, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"), tu = yu ? It.Buffer : void 0, xs = It.Symbol, eu = It.Uint8Array, Au = Ts.propertyIsEnumerable, D0 = R0.splice, de = xs ? xs.toStringTag : void 0, ru = Object.getOwnPropertySymbols, j0 = tu ? tu.isBuffer : void 0, P0 = I0(Object.keys, Object), Bn = We(It, "DataView"), mr = We(It, "Map"), Mn = We(It, "Promise"), Dn = We(It, "Set"), jn = We(It, "WeakMap"), gr = We(Object, "create"), U0 = ge(Bn), F0 = ge(mr), H0 = ge(Mn), z0 = ge(Dn), $0 = ge(jn), su = xs ? xs.prototype : void 0, In = su ? su.valueOf : void 0; function pe(r) { var t = -1, e = r == null ? 0 : r.length; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} } function K0() { this.__data__ = gr ? gr(null) : {}, this.size = 0; } function G0(r) { var t = this.has(r) && delete this.__data__[r]; return this.size -= t ? 1 : 0, t; } function V0(r) { var t = this.__data__; if (gr) {
    var e = t[r];
    return e === Un ? void 0 : e;
} return Et.call(t, r) ? t[r] : void 0; } function W0(r) { var t = this.__data__; return gr ? t[r] !== void 0 : Et.call(t, r); } function Z0(r, t) { var e = this.__data__; return this.size += this.has(r) ? 0 : 1, e[r] = gr && t === void 0 ? Un : t, this; } pe.prototype.clear = K0; pe.prototype.delete = G0; pe.prototype.get = V0; pe.prototype.has = W0; pe.prototype.set = Z0; function kt(r) { var t = -1, e = r == null ? 0 : r.length; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} } function X0() { this.__data__ = [], this.size = 0; } function Q0(r) { var t = this.__data__, e = Ns(t, r); if (e < 0)
    return !1; var s = t.length - 1; return e == s ? t.pop() : D0.call(t, e, 1), --this.size, !0; } function Y0(r) { var t = this.__data__, e = Ns(t, r); return e < 0 ? void 0 : t[e][1]; } function J0(r) { return Ns(this.__data__, r) > -1; } function tb(r, t) { var e = this.__data__, s = Ns(e, r); return s < 0 ? (++this.size, e.push([r, t])) : e[s][1] = t, this; } kt.prototype.clear = X0; kt.prototype.delete = Q0; kt.prototype.get = Y0; kt.prototype.has = J0; kt.prototype.set = tb; function me(r) { var t = -1, e = r == null ? 0 : r.length; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} } function eb() { this.size = 0, this.__data__ = { hash: new pe, map: new (mr || kt), string: new pe }; } function rb(r) { var t = ws(this, r).delete(r); return this.size -= t ? 1 : 0, t; } function sb(r) { return ws(this, r).get(r); } function nb(r) { return ws(this, r).has(r); } function ib(r, t) { var e = ws(this, r), s = e.size; return e.set(r, t), this.size += e.size == s ? 0 : 1, this; } me.prototype.clear = eb; me.prototype.delete = rb; me.prototype.get = sb; me.prototype.has = nb; me.prototype.set = ib; function vs(r) { var t = -1, e = r == null ? 0 : r.length; for (this.__data__ = new me; ++t < e;)
    this.add(r[t]); } function ob(r) { return this.__data__.set(r, Un), this; } function ab(r) { return this.__data__.has(r); } vs.prototype.add = vs.prototype.push = ob; vs.prototype.has = ab; function Jt(r) { var t = this.__data__ = new kt(r); this.size = t.size; } function lb() { this.__data__ = new kt, this.size = 0; } function ub(r) { var t = this.__data__, e = t.delete(r); return this.size = t.size, e; } function cb(r) { return this.__data__.get(r); } function fb(r) { return this.__data__.has(r); } function hb(r, t) { var e = this.__data__; if (e instanceof kt) {
    var s = e.__data__;
    if (!mr || s.length < n0 - 1)
        return s.push([r, t]), this.size = ++e.size, this;
    e = this.__data__ = new me(s);
} return e.set(r, t), this.size = e.size, this; } Jt.prototype.clear = lb; Jt.prototype.delete = ub; Jt.prototype.get = cb; Jt.prototype.has = fb; Jt.prototype.set = hb; function db(r, t) { var e = As(r), s = !e && Ob(r), n = !e && !s && Pn(r), i = !e && !s && !n && Ou(r), o = e || s || n || i, a = o ? L0(r.length, String) : [], l = a.length; for (var u in r)
    (t || Et.call(r, u)) && !(o && (u == "length" || n && (u == "offset" || u == "parent") || i && (u == "buffer" || u == "byteLength" || u == "byteOffset") || Tb(u, l))) && a.push(u); return a; } function Ns(r, t) { for (var e = r.length; e--;)
    if (Nu(r[e][0], t))
        return e; return -1; } function pb(r, t, e) { var s = t(r); return As(r) ? s : w0(s, e(r)); } function yr(r) { return r == null ? r === void 0 ? c0 : a0 : de && de in Object(r) ? Ab(r) : Lb(r); } function nu(r) { return br(r) && yr(r) == ms; } function Eu(r, t, e, s, n) { return r === t ? !0 : r == null || t == null || !br(r) && !br(t) ? r !== r && t !== t : mb(r, t, e, s, Eu, n); } function mb(r, t, e, s, n, i) { var o = As(r), a = As(t), l = o ? kn : Yt(r), u = a ? kn : Yt(t); l = l == ms ? Ge : l, u = u == ms ? Ge : u; var c = l == Ge, f = u == Ge, h = l == u; if (h && Pn(r)) {
    if (!Pn(t))
        return !1;
    o = !0, c = !1;
} if (h && !c)
    return i || (i = new Jt), o || Ou(r) ? Tu(r, t, e, s, n, i) : xb(r, t, l, e, s, n, i); if (!(e & Es)) {
    var p = c && Et.call(r, "__wrapped__"), m = f && Et.call(t, "__wrapped__");
    if (p || m) {
        var y = p ? r.value() : r, v = m ? t.value() : t;
        return i || (i = new Jt), n(y, v, e, s, i);
    }
} return h ? (i || (i = new Jt), vb(r, t, e, s, n, i)) : !1; } function gb(r) { if (!Lu(r) || wb(r))
    return !1; var t = wu(r) ? M0 : A0; return t.test(ge(r)); } function bb(r) { return br(r) && Su(r.length) && !!C[yr(r)]; } function yb(r) { if (!Sb(r))
    return P0(r); var t = []; for (var e in Object(r))
    Et.call(r, e) && e != "constructor" && t.push(e); return t; } function Tu(r, t, e, s, n, i) { var o = e & Es, a = r.length, l = t.length; if (a != l && !(o && l > a))
    return !1; var u = i.get(r); if (u && i.get(t))
    return u == t; var c = -1, f = !0, h = e & ou ? new vs : void 0; for (i.set(r, t), i.set(t, r); ++c < a;) {
    var p = r[c], m = t[c];
    if (s)
        var y = o ? s(m, p, c, t, r, i) : s(p, m, c, r, t, i);
    if (y !== void 0) {
        if (y)
            continue;
        f = !1;
        break;
    }
    if (h) {
        if (!S0(t, function (v, g) { if (!C0(h, g) && (p === v || n(p, v, e, s, i)))
            return h.push(g); })) {
            f = !1;
            break;
        }
    }
    else if (!(p === m || n(p, m, e, s, i))) {
        f = !1;
        break;
    }
} return i.delete(r), i.delete(t), f; } function xb(r, t, e, s, n, i, o) { switch (e) {
    case ys:
        if (r.byteLength != t.byteLength || r.byteOffset != t.byteOffset)
            return !1;
        r = r.buffer, t = t.buffer;
    case mu: return !(r.byteLength != t.byteLength || !i(new eu(r), new eu(t)));
    case lu:
    case uu:
    case hu: return Nu(+r, +t);
    case cu: return r.name == t.name && r.message == t.message;
    case du:
    case pu: return r == t + "";
    case gs: var a = q0;
    case bs:
        var l = s & Es;
        if (a || (a = k0), r.size != t.size && !l)
            return !1;
        var u = o.get(r);
        if (u)
            return u == t;
        s |= ou, o.set(r, t);
        var c = Tu(a(r), a(t), s, n, i, o);
        return o.delete(r), c;
    case u0: if (In)
        return In.call(r) == In.call(t);
} return !1; } function vb(r, t, e, s, n, i) { var o = e & Es, a = iu(r), l = a.length, u = iu(t), c = u.length; if (l != c && !o)
    return !1; for (var f = l; f--;) {
    var h = a[f];
    if (!(o ? h in t : Et.call(t, h)))
        return !1;
} var p = i.get(r); if (p && i.get(t))
    return p == t; var m = !0; i.set(r, t), i.set(t, r); for (var y = o; ++f < l;) {
    h = a[f];
    var v = r[h], g = t[h];
    if (s)
        var A = o ? s(g, v, h, t, r, i) : s(v, g, h, r, t, i);
    if (!(A === void 0 ? v === g || n(v, g, e, s, i) : A)) {
        m = !1;
        break;
    }
    y || (y = h == "constructor");
} if (m && !y) {
    var E = r.constructor, T = t.constructor;
    E != T && "constructor" in r && "constructor" in t && !(typeof E == "function" && E instanceof E && typeof T == "function" && T instanceof T) && (m = !1);
} return i.delete(r), i.delete(t), m; } function iu(r) { return pb(r, qb, Eb); } function ws(r, t) { var e = r.__data__; return Nb(t) ? e[typeof t == "string" ? "string" : "hash"] : e.map; } function We(r, t) { var e = _0(r, t); return gb(e) ? e : void 0; } function Ab(r) { var t = Et.call(r, de), e = r[de]; try {
    r[de] = void 0;
    var s = !0;
}
catch { } var n = vu.call(r); return s && (t ? r[de] = e : delete r[de]), n; } var Eb = ru ? function (r) { return r == null ? [] : (r = Object(r), N0(ru(r), function (t) { return Au.call(r, t); })); } : Ib, Yt = yr; (Bn && Yt(new Bn(new ArrayBuffer(1))) != ys || mr && Yt(new mr) != gs || Mn && Yt(Mn.resolve()) != Zl || Dn && Yt(new Dn) != bs || jn && Yt(new jn) != Rn) && (Yt = function (r) { var t = yr(r), e = t == Ge ? r.constructor : void 0, s = e ? ge(e) : ""; if (s)
    switch (s) {
        case U0: return ys;
        case F0: return gs;
        case H0: return Zl;
        case z0: return bs;
        case $0: return Rn;
    } return t; }); function Tb(r, t) { return t = t ?? au, !!t && (typeof r == "number" || E0.test(r)) && r > -1 && r % 1 == 0 && r < t; } function Nb(r) { var t = typeof r; return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? r !== "__proto__" : r === null; } function wb(r) { return !!Jl && Jl in r; } function Sb(r) { var t = r && r.constructor, e = typeof t == "function" && t.prototype || Ts; return r === e; } function Lb(r) { return vu.call(r); } function ge(r) { if (r != null) {
    try {
        return xu.call(r);
    }
    catch { }
    try {
        return r + "";
    }
    catch { }
} return ""; } function Nu(r, t) { return r === t || r !== r && t !== t; } var Ob = nu((function () { return arguments; })()) ? nu : function (r) { return br(r) && Et.call(r, "callee") && !Au.call(r, "callee"); }, As = Array.isArray; function Cb(r) { return r != null && Su(r.length) && !wu(r); } var Pn = j0 || kb; function _b(r, t) { return Eu(r, t); } function wu(r) { if (!Lu(r))
    return !1; var t = yr(r); return t == fu || t == o0 || t == i0 || t == l0; } function Su(r) { return typeof r == "number" && r > -1 && r % 1 == 0 && r <= au; } function Lu(r) { var t = typeof r; return r != null && (t == "object" || t == "function"); } function br(r) { return r != null && typeof r == "object"; } var Ou = Yl ? O0(Yl) : bb; function qb(r) { return Cb(r) ? db(r) : yb(r); } function Ib() { return []; } function kb() { return !1; } Ve.exports = _b; });
var Cu = Ft(zn => {
    "use strict";
    Object.defineProperty(zn, "__esModule", { value: !0 });
    var Rb = Cn(), Bb = Fn(), Hn;
    (function (r) { function t(i = {}, o = {}, a = !1) { typeof i != "object" && (i = {}), typeof o != "object" && (o = {}); let l = Rb(o); a || (l = Object.keys(l).reduce((u, c) => (l[c] != null && (u[c] = l[c]), u), {})); for (let u in i)
        i[u] !== void 0 && o[u] === void 0 && (l[u] = i[u]); return Object.keys(l).length > 0 ? l : void 0; } r.compose = t; function e(i = {}, o = {}) { typeof i != "object" && (i = {}), typeof o != "object" && (o = {}); let a = Object.keys(i).concat(Object.keys(o)).reduce((l, u) => (Bb(i[u], o[u]) || (l[u] = o[u] === void 0 ? null : o[u]), l), {}); return Object.keys(a).length > 0 ? a : void 0; } r.diff = e; function s(i = {}, o = {}) { i = i || {}; let a = Object.keys(o).reduce((l, u) => (o[u] !== i[u] && i[u] !== void 0 && (l[u] = o[u]), l), {}); return Object.keys(i).reduce((l, u) => (i[u] !== o[u] && o[u] === void 0 && (l[u] = null), l), a); } r.invert = s; function n(i, o, a = !1) { if (typeof i != "object")
        return o; if (typeof o != "object")
        return; if (!a)
        return o; let l = Object.keys(o).reduce((u, c) => (i[c] === void 0 && (u[c] = o[c]), u), {}); return Object.keys(l).length > 0 ? l : void 0; } r.transform = n; })(Hn || (Hn = {}));
    zn.default = Hn;
});
var Gn = Ft(Kn => {
    "use strict";
    Object.defineProperty(Kn, "__esModule", { value: !0 });
    var $n;
    (function (r) { function t(e) { return typeof e.delete == "number" ? e.delete : typeof e.retain == "number" ? e.retain : typeof e.retain == "object" && e.retain !== null ? 1 : typeof e.insert == "string" ? e.insert.length : 1; } r.length = t; })($n || ($n = {}));
    Kn.default = $n;
});
var qu = Ft(Wn => {
    "use strict";
    Object.defineProperty(Wn, "__esModule", { value: !0 });
    var _u = Gn(), Vn = class {
        constructor(t) { this.ops = t, this.index = 0, this.offset = 0; }
        hasNext() { return this.peekLength() < 1 / 0; }
        next(t) { t || (t = 1 / 0); let e = this.ops[this.index]; if (e) {
            let s = this.offset, n = _u.default.length(e);
            if (t >= n - s ? (t = n - s, this.index += 1, this.offset = 0) : this.offset += t, typeof e.delete == "number")
                return { delete: t };
            {
                let i = {};
                return e.attributes && (i.attributes = e.attributes), typeof e.retain == "number" ? i.retain = t : typeof e.retain == "object" && e.retain !== null ? i.retain = e.retain : typeof e.insert == "string" ? i.insert = e.insert.substr(s, t) : i.insert = e.insert, i;
            }
        }
        else
            return { retain: 1 / 0 }; }
        peek() { return this.ops[this.index]; }
        peekLength() { return this.ops[this.index] ? _u.default.length(this.ops[this.index]) - this.offset : 1 / 0; }
        peekType() { let t = this.ops[this.index]; return t ? typeof t.delete == "number" ? "delete" : typeof t.retain == "number" || typeof t.retain == "object" && t.retain !== null ? "retain" : "insert" : "retain"; }
        rest() { if (this.hasNext()) {
            if (this.offset === 0)
                return this.ops.slice(this.index);
            {
                let t = this.offset, e = this.index, s = this.next(), n = this.ops.slice(this.index);
                return this.offset = t, this.index = e, [s].concat(n);
            }
        }
        else
            return []; }
    };
    Wn.default = Vn;
});
var lt = Ft((Bt, Ls) => {
    "use strict";
    Object.defineProperty(Bt, "__esModule", { value: !0 });
    Bt.AttributeMap = Bt.OpIterator = Bt.Op = void 0;
    var Ss = al(), Mb = Cn(), Zn = Fn(), be = Cu();
    Bt.AttributeMap = be.default;
    var Rt = Gn();
    Bt.Op = Rt.default;
    var ht = qu();
    Bt.OpIterator = ht.default;
    var Db = "\0", Iu = (r, t) => { if (typeof r != "object" || r === null)
        throw new Error(`cannot retain a ${typeof r}`); if (typeof t != "object" || t === null)
        throw new Error(`cannot retain a ${typeof t}`); let e = Object.keys(r)[0]; if (!e || e !== Object.keys(t)[0])
        throw new Error(`embed types not matched: ${e} != ${Object.keys(t)[0]}`); return [e, r[e], t[e]]; }, Mt = class r {
        constructor(t) { Array.isArray(t) ? this.ops = t : t != null && Array.isArray(t.ops) ? this.ops = t.ops : this.ops = []; }
        static registerEmbed(t, e) { this.handlers[t] = e; }
        static unregisterEmbed(t) { delete this.handlers[t]; }
        static getHandler(t) { let e = this.handlers[t]; if (!e)
            throw new Error(`no handlers for embed type "${t}"`); return e; }
        insert(t, e) { let s = {}; return typeof t == "string" && t.length === 0 ? this : (s.insert = t, e != null && typeof e == "object" && Object.keys(e).length > 0 && (s.attributes = e), this.push(s)); }
        delete(t) { return t <= 0 ? this : this.push({ delete: t }); }
        retain(t, e) { if (typeof t == "number" && t <= 0)
            return this; let s = { retain: t }; return e != null && typeof e == "object" && Object.keys(e).length > 0 && (s.attributes = e), this.push(s); }
        push(t) { let e = this.ops.length, s = this.ops[e - 1]; if (t = Mb(t), typeof s == "object") {
            if (typeof t.delete == "number" && typeof s.delete == "number")
                return this.ops[e - 1] = { delete: s.delete + t.delete }, this;
            if (typeof s.delete == "number" && t.insert != null && (e -= 1, s = this.ops[e - 1], typeof s != "object"))
                return this.ops.unshift(t), this;
            if (Zn(t.attributes, s.attributes)) {
                if (typeof t.insert == "string" && typeof s.insert == "string")
                    return this.ops[e - 1] = { insert: s.insert + t.insert }, typeof t.attributes == "object" && (this.ops[e - 1].attributes = t.attributes), this;
                if (typeof t.retain == "number" && typeof s.retain == "number")
                    return this.ops[e - 1] = { retain: s.retain + t.retain }, typeof t.attributes == "object" && (this.ops[e - 1].attributes = t.attributes), this;
            }
        } return e === this.ops.length ? this.ops.push(t) : this.ops.splice(e, 0, t), this; }
        chop() { let t = this.ops[this.ops.length - 1]; return t && typeof t.retain == "number" && !t.attributes && this.ops.pop(), this; }
        filter(t) { return this.ops.filter(t); }
        forEach(t) { this.ops.forEach(t); }
        map(t) { return this.ops.map(t); }
        partition(t) { let e = [], s = []; return this.forEach(n => { (t(n) ? e : s).push(n); }), [e, s]; }
        reduce(t, e) { return this.ops.reduce(t, e); }
        changeLength() { return this.reduce((t, e) => e.insert ? t + Rt.default.length(e) : e.delete ? t - e.delete : t, 0); }
        length() { return this.reduce((t, e) => t + Rt.default.length(e), 0); }
        slice(t = 0, e = 1 / 0) { let s = [], n = new ht.default(this.ops), i = 0; for (; i < e && n.hasNext();) {
            let o;
            i < t ? o = n.next(t - i) : (o = n.next(e - i), s.push(o)), i += Rt.default.length(o);
        } return new r(s); }
        compose(t) { let e = new ht.default(this.ops), s = new ht.default(t.ops), n = [], i = s.peek(); if (i != null && typeof i.retain == "number" && i.attributes == null) {
            let a = i.retain;
            for (; e.peekType() === "insert" && e.peekLength() <= a;)
                a -= e.peekLength(), n.push(e.next());
            i.retain - a > 0 && s.next(i.retain - a);
        } let o = new r(n); for (; e.hasNext() || s.hasNext();)
            if (s.peekType() === "insert")
                o.push(s.next());
            else if (e.peekType() === "delete")
                o.push(e.next());
            else {
                let a = Math.min(e.peekLength(), s.peekLength()), l = e.next(a), u = s.next(a);
                if (u.retain) {
                    let c = {};
                    if (typeof l.retain == "number")
                        c.retain = typeof u.retain == "number" ? a : u.retain;
                    else if (typeof u.retain == "number")
                        l.retain == null ? c.insert = l.insert : c.retain = l.retain;
                    else {
                        let h = l.retain == null ? "insert" : "retain", [p, m, y] = Iu(l[h], u.retain), v = r.getHandler(p);
                        c[h] = { [p]: v.compose(m, y, h === "retain") };
                    }
                    let f = be.default.compose(l.attributes, u.attributes, typeof l.retain == "number");
                    if (f && (c.attributes = f), o.push(c), !s.hasNext() && Zn(o.ops[o.ops.length - 1], c)) {
                        let h = new r(e.rest());
                        return o.concat(h).chop();
                    }
                }
                else
                    typeof u.delete == "number" && (typeof l.retain == "number" || typeof l.retain == "object" && l.retain !== null) && o.push(u);
            } return o.chop(); }
        concat(t) { let e = new r(this.ops.slice()); return t.ops.length > 0 && (e.push(t.ops[0]), e.ops = e.ops.concat(t.ops.slice(1))), e; }
        diff(t, e) { if (this.ops === t.ops)
            return new r; let s = [this, t].map(l => l.map(u => { if (u.insert != null)
            return typeof u.insert == "string" ? u.insert : Db; let c = l === t ? "on" : "with"; throw new Error("diff() called " + c + " non-document"); }).join("")), n = new r, i = Ss(s[0], s[1], e, !0), o = new ht.default(this.ops), a = new ht.default(t.ops); return i.forEach(l => { let u = l[1].length; for (; u > 0;) {
            let c = 0;
            switch (l[0]) {
                case Ss.INSERT:
                    c = Math.min(a.peekLength(), u), n.push(a.next(c));
                    break;
                case Ss.DELETE:
                    c = Math.min(u, o.peekLength()), o.next(c), n.delete(c);
                    break;
                case Ss.EQUAL:
                    c = Math.min(o.peekLength(), a.peekLength(), u);
                    let f = o.next(c), h = a.next(c);
                    Zn(f.insert, h.insert) ? n.retain(c, be.default.diff(f.attributes, h.attributes)) : n.push(h).delete(c);
                    break;
            }
            u -= c;
        } }), n.chop(); }
        eachLine(t, e = `
`) { let s = new ht.default(this.ops), n = new r, i = 0; for (; s.hasNext();) {
            if (s.peekType() !== "insert")
                return;
            let o = s.peek(), a = Rt.default.length(o) - s.peekLength(), l = typeof o.insert == "string" ? o.insert.indexOf(e, a) - a : -1;
            if (l < 0)
                n.push(s.next());
            else if (l > 0)
                n.push(s.next(l));
            else {
                if (t(n, s.next(1).attributes || {}, i) === !1)
                    return;
                i += 1, n = new r;
            }
        } n.length() > 0 && t(n, {}, i); }
        invert(t) { let e = new r; return this.reduce((s, n) => { if (n.insert)
            e.delete(Rt.default.length(n));
        else {
            if (typeof n.retain == "number" && n.attributes == null)
                return e.retain(n.retain), s + n.retain;
            if (n.delete || typeof n.retain == "number") {
                let i = n.delete || n.retain;
                return t.slice(s, s + i).forEach(a => { n.delete ? e.push(a) : n.retain && n.attributes && e.retain(Rt.default.length(a), be.default.invert(n.attributes, a.attributes)); }), s + i;
            }
            else if (typeof n.retain == "object" && n.retain !== null) {
                let i = t.slice(s, s + 1), o = new ht.default(i.ops).next(), [a, l, u] = Iu(n.retain, o.insert), c = r.getHandler(a);
                return e.retain({ [a]: c.invert(l, u) }, be.default.invert(n.attributes, o.attributes)), s + 1;
            }
        } return s; }, 0), e.chop(); }
        transform(t, e = !1) { if (e = !!e, typeof t == "number")
            return this.transformPosition(t, e); let s = t, n = new ht.default(this.ops), i = new ht.default(s.ops), o = new r; for (; n.hasNext() || i.hasNext();)
            if (n.peekType() === "insert" && (e || i.peekType() !== "insert"))
                o.retain(Rt.default.length(n.next()));
            else if (i.peekType() === "insert")
                o.push(i.next());
            else {
                let a = Math.min(n.peekLength(), i.peekLength()), l = n.next(a), u = i.next(a);
                if (l.delete)
                    continue;
                if (u.delete)
                    o.push(u);
                else {
                    let c = l.retain, f = u.retain, h = typeof f == "object" && f !== null ? f : a;
                    if (typeof c == "object" && c !== null && typeof f == "object" && f !== null) {
                        let p = Object.keys(c)[0];
                        if (p === Object.keys(f)[0]) {
                            let m = r.getHandler(p);
                            m && (h = { [p]: m.transform(c[p], f[p], e) });
                        }
                    }
                    o.retain(h, be.default.transform(l.attributes, u.attributes, e));
                }
            } return o.chop(); }
        transformPosition(t, e = !1) { e = !!e; let s = new ht.default(this.ops), n = 0; for (; s.hasNext() && n <= t;) {
            let i = s.peekLength(), o = s.peekType();
            if (s.next(), o === "delete") {
                t -= Math.min(i, t - n);
                continue;
            }
            else
                o === "insert" && (n < t || !e) && (t += i);
            n += i;
        } return t; }
    };
    Mt.Op = Rt.default;
    Mt.OpIterator = ht.default;
    Mt.AttributeMap = be.default;
    Mt.handlers = {};
    Bt.default = Mt;
    typeof Ls == "object" && (Ls.exports = Mt, Ls.exports.default = Mt);
});
var Bu = Ft((H2, Yn) => {
    "use strict";
    var Hb = Object.prototype.hasOwnProperty, X = "~";
    function xr() { }
    Object.create && (xr.prototype = Object.create(null), new xr().__proto__ || (X = !1));
    function zb(r, t, e) { this.fn = r, this.context = t, this.once = e || !1; }
    function Ru(r, t, e, s, n) { if (typeof e != "function")
        throw new TypeError("The listener must be a function"); var i = new zb(e, s || r, n), o = X ? X + t : t; return r._events[o] ? r._events[o].fn ? r._events[o] = [r._events[o], i] : r._events[o].push(i) : (r._events[o] = i, r._eventsCount++), r; }
    function Os(r, t) { --r._eventsCount === 0 ? r._events = new xr : delete r._events[t]; }
    function G() { this._events = new xr, this._eventsCount = 0; }
    G.prototype.eventNames = function () { var t = [], e, s; if (this._eventsCount === 0)
        return t; for (s in e = this._events)
        Hb.call(e, s) && t.push(X ? s.slice(1) : s); return Object.getOwnPropertySymbols ? t.concat(Object.getOwnPropertySymbols(e)) : t; };
    G.prototype.listeners = function (t) { var e = X ? X + t : t, s = this._events[e]; if (!s)
        return []; if (s.fn)
        return [s.fn]; for (var n = 0, i = s.length, o = new Array(i); n < i; n++)
        o[n] = s[n].fn; return o; };
    G.prototype.listenerCount = function (t) { var e = X ? X + t : t, s = this._events[e]; return s ? s.fn ? 1 : s.length : 0; };
    G.prototype.emit = function (t, e, s, n, i, o) { var a = X ? X + t : t; if (!this._events[a])
        return !1; var l = this._events[a], u = arguments.length, c, f; if (l.fn) {
        switch (l.once && this.removeListener(t, l.fn, void 0, !0), u) {
            case 1: return l.fn.call(l.context), !0;
            case 2: return l.fn.call(l.context, e), !0;
            case 3: return l.fn.call(l.context, e, s), !0;
            case 4: return l.fn.call(l.context, e, s, n), !0;
            case 5: return l.fn.call(l.context, e, s, n, i), !0;
            case 6: return l.fn.call(l.context, e, s, n, i, o), !0;
        }
        for (f = 1, c = new Array(u - 1); f < u; f++)
            c[f - 1] = arguments[f];
        l.fn.apply(l.context, c);
    }
    else {
        var h = l.length, p;
        for (f = 0; f < h; f++)
            switch (l[f].once && this.removeListener(t, l[f].fn, void 0, !0), u) {
                case 1:
                    l[f].fn.call(l[f].context);
                    break;
                case 2:
                    l[f].fn.call(l[f].context, e);
                    break;
                case 3:
                    l[f].fn.call(l[f].context, e, s);
                    break;
                case 4:
                    l[f].fn.call(l[f].context, e, s, n);
                    break;
                default:
                    if (!c)
                        for (p = 1, c = new Array(u - 1); p < u; p++)
                            c[p - 1] = arguments[p];
                    l[f].fn.apply(l[f].context, c);
            }
    } return !0; };
    G.prototype.on = function (t, e, s) { return Ru(this, t, e, s, !1); };
    G.prototype.once = function (t, e, s) { return Ru(this, t, e, s, !0); };
    G.prototype.removeListener = function (t, e, s, n) { var i = X ? X + t : t; if (!this._events[i])
        return this; if (!e)
        return Os(this, i), this; var o = this._events[i]; if (o.fn)
        o.fn === e && (!n || o.once) && (!s || o.context === s) && Os(this, i);
    else {
        for (var a = 0, l = [], u = o.length; a < u; a++)
            (o[a].fn !== e || n && !o[a].once || s && o[a].context !== s) && l.push(o[a]);
        l.length ? this._events[i] = l.length === 1 ? l[0] : l : Os(this, i);
    } return this; };
    G.prototype.removeAllListeners = function (t) { var e; return t ? (e = X ? X + t : t, this._events[e] && Os(this, e)) : (this._events = new xr, this._eventsCount = 0), this; };
    G.prototype.off = G.prototype.removeListener;
    G.prototype.addListener = G.prototype.on;
    G.prefixed = X;
    G.EventEmitter = G;
    typeof Yn < "u" && (Yn.exports = G);
});
var Pc = typeof global == "object" && global && global.Object === Object && global, kr = Pc;
var Uc = typeof self == "object" && self && self.Object === Object && self, Fc = kr || Uc || Function("return this")(), M = Fc;
var Hc = M.Symbol, ct = Hc;
var Pi = Object.prototype, zc = Pi.hasOwnProperty, $c = Pi.toString, er = ct ? ct.toStringTag : void 0;
function Kc(r) { var t = zc.call(r, er), e = r[er]; try {
    r[er] = void 0;
    var s = !0;
}
catch { } var n = $c.call(r); return s && (t ? r[er] = e : delete r[er]), n; }
var Ui = Kc;
var Gc = Object.prototype, Vc = Gc.toString;
function Wc(r) { return Vc.call(r); }
var Fi = Wc;
var Zc = "[object Null]", Xc = "[object Undefined]", Hi = ct ? ct.toStringTag : void 0;
function Qc(r) { return r == null ? r === void 0 ? Xc : Zc : Hi && Hi in Object(r) ? Ui(r) : Fi(r); }
var gt = Qc;
function Yc(r) { return r != null && typeof r == "object"; }
var H = Yc;
var Jc = Array.isArray, ft = Jc;
function tf(r) { var t = typeof r; return r != null && (t == "object" || t == "function"); }
var z = tf;
function ef(r) { return r; }
var Rr = ef;
var rf = "[object AsyncFunction]", sf = "[object Function]", nf = "[object GeneratorFunction]", of = "[object Proxy]";
function af(r) { if (!z(r))
    return !1; var t = gt(r); return t == sf || t == nf || t == rf || t == of; }
var Ae = af;
var lf = M["__core-js_shared__"], Br = lf;
var zi = (function () { var r = /[^.]+$/.exec(Br && Br.keys && Br.keys.IE_PROTO || ""); return r ? "Symbol(src)_1." + r : ""; })();
function uf(r) { return !!zi && zi in r; }
var $i = uf;
var cf = Function.prototype, ff = cf.toString;
function hf(r) { if (r != null) {
    try {
        return ff.call(r);
    }
    catch { }
    try {
        return r + "";
    }
    catch { }
} return ""; }
var wt = hf;
var df = /[\\^$.*+?()[\]{}|]/g, pf = /^\[object .+?Constructor\]$/, mf = Function.prototype, gf = Object.prototype, bf = mf.toString, yf = gf.hasOwnProperty, xf = RegExp("^" + bf.call(yf).replace(df, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
function vf(r) { if (!z(r) || $i(r))
    return !1; var t = Ae(r) ? xf : pf; return t.test(wt(r)); }
var Ki = vf;
function Af(r, t) { return r?.[t]; }
var Gi = Af;
function Ef(r, t) { var e = Gi(r, t); return Ki(e) ? e : void 0; }
var J = Ef;
var Tf = J(M, "WeakMap"), Mr = Tf;
var Vi = Object.create, Nf = (function () { function r() { } return function (t) { if (!z(t))
    return {}; if (Vi)
    return Vi(t); r.prototype = t; var e = new r; return r.prototype = void 0, e; }; })(), Wi = Nf;
function wf(r, t, e) { switch (e.length) {
    case 0: return r.call(t);
    case 1: return r.call(t, e[0]);
    case 2: return r.call(t, e[0], e[1]);
    case 3: return r.call(t, e[0], e[1], e[2]);
} return r.apply(t, e); }
var Zi = wf;
function Sf(r, t) { var e = -1, s = r.length; for (t || (t = Array(s)); ++e < s;)
    t[e] = r[e]; return t; }
var Dr = Sf;
var Lf = 800, Of = 16, Cf = Date.now;
function _f(r) { var t = 0, e = 0; return function () { var s = Cf(), n = Of - (s - e); if (e = s, n > 0) {
    if (++t >= Lf)
        return arguments[0];
}
else
    t = 0; return r.apply(void 0, arguments); }; }
var Xi = _f;
function qf(r) { return function () { return r; }; }
var Qi = qf;
var If = (function () { try {
    var r = J(Object, "defineProperty");
    return r({}, "", {}), r;
}
catch { } })(), Ee = If;
var kf = Ee ? function (r, t) { return Ee(r, "toString", { configurable: !0, enumerable: !1, value: Qi(t), writable: !0 }); } : Rr, Yi = kf;
var Rf = Xi(Yi), Ji = Rf;
function Bf(r, t) { for (var e = -1, s = r == null ? 0 : r.length; ++e < s && t(r[e], e, r) !== !1;)
    ; return r; }
var to = Bf;
var Mf = 9007199254740991, Df = /^(?:0|[1-9]\d*)$/;
function jf(r, t) { var e = typeof r; return t = t ?? Mf, !!t && (e == "number" || e != "symbol" && Df.test(r)) && r > -1 && r % 1 == 0 && r < t; }
var jr = jf;
function Pf(r, t, e) { t == "__proto__" && Ee ? Ee(r, t, { configurable: !0, enumerable: !0, value: e, writable: !0 }) : r[t] = e; }
var Te = Pf;
function Uf(r, t) { return r === t || r !== r && t !== t; }
var yt = Uf;
var Ff = Object.prototype, Hf = Ff.hasOwnProperty;
function zf(r, t, e) { var s = r[t]; (!(Hf.call(r, t) && yt(s, e)) || e === void 0 && !(t in r)) && Te(r, t, e); }
var Pr = zf;
function $f(r, t, e, s) { var n = !e; e || (e = {}); for (var i = -1, o = t.length; ++i < o;) {
    var a = t[i], l = s ? s(e[a], r[a], a, e, r) : void 0;
    l === void 0 && (l = r[a]), n ? Te(e, a, l) : Pr(e, a, l);
} return e; }
var xt = $f;
var eo = Math.max;
function Kf(r, t, e) { return t = eo(t === void 0 ? r.length - 1 : t, 0), function () { for (var s = arguments, n = -1, i = eo(s.length - t, 0), o = Array(i); ++n < i;)
    o[n] = s[t + n]; n = -1; for (var a = Array(t + 1); ++n < t;)
    a[n] = s[n]; return a[t] = e(o), Zi(r, this, a); }; }
var ro = Kf;
function Gf(r, t) { return Ji(ro(r, t, Rr), r + ""); }
var so = Gf;
var Vf = 9007199254740991;
function Wf(r) { return typeof r == "number" && r > -1 && r % 1 == 0 && r <= Vf; }
var Ur = Wf;
function Zf(r) { return r != null && Ur(r.length) && !Ae(r); }
var Ht = Zf;
function Xf(r, t, e) { if (!z(e))
    return !1; var s = typeof t; return (s == "number" ? Ht(e) && jr(t, e.length) : s == "string" && t in e) ? yt(e[t], r) : !1; }
var no = Xf;
function Qf(r) { return so(function (t, e) { var s = -1, n = e.length, i = n > 1 ? e[n - 1] : void 0, o = n > 2 ? e[2] : void 0; for (i = r.length > 3 && typeof i == "function" ? (n--, i) : void 0, o && no(e[0], e[1], o) && (i = n < 3 ? void 0 : i, n = 1), t = Object(t); ++s < n;) {
    var a = e[s];
    a && r(t, a, s, i);
} return t; }); }
var io = Qf;
var Yf = Object.prototype;
function Jf(r) { var t = r && r.constructor, e = typeof t == "function" && t.prototype || Yf; return r === e; }
var Ne = Jf;
function th(r, t) { for (var e = -1, s = Array(r); ++e < r;)
    s[e] = t(e); return s; }
var oo = th;
var eh = "[object Arguments]";
function rh(r) { return H(r) && gt(r) == eh; }
var Qs = rh;
var ao = Object.prototype, sh = ao.hasOwnProperty, nh = ao.propertyIsEnumerable, ih = Qs((function () { return arguments; })()) ? Qs : function (r) { return H(r) && sh.call(r, "callee") && !nh.call(r, "callee"); }, rr = ih;
function oh() { return !1; }
var lo = oh;
var fo = typeof exports == "object" && exports && !exports.nodeType && exports, uo = fo && typeof module == "object" && module && !module.nodeType && module, ah = uo && uo.exports === fo, co = ah ? M.Buffer : void 0, lh = co ? co.isBuffer : void 0, uh = lh || lo, St = uh;
var ch = "[object Arguments]", fh = "[object Array]", hh = "[object Boolean]", dh = "[object Date]", ph = "[object Error]", mh = "[object Function]", gh = "[object Map]", bh = "[object Number]", yh = "[object Object]", xh = "[object RegExp]", vh = "[object Set]", Ah = "[object String]", Eh = "[object WeakMap]", Th = "[object ArrayBuffer]", Nh = "[object DataView]", wh = "[object Float32Array]", Sh = "[object Float64Array]", Lh = "[object Int8Array]", Oh = "[object Int16Array]", Ch = "[object Int32Array]", _h = "[object Uint8Array]", qh = "[object Uint8ClampedArray]", Ih = "[object Uint16Array]", kh = "[object Uint32Array]", O = {};
O[wh] = O[Sh] = O[Lh] = O[Oh] = O[Ch] = O[_h] = O[qh] = O[Ih] = O[kh] = !0;
O[ch] = O[fh] = O[Th] = O[hh] = O[Nh] = O[dh] = O[ph] = O[mh] = O[gh] = O[bh] = O[yh] = O[xh] = O[vh] = O[Ah] = O[Eh] = !1;
function Rh(r) { return H(r) && Ur(r.length) && !!O[gt(r)]; }
var ho = Rh;
function Bh(r) { return function (t) { return r(t); }; }
var we = Bh;
var po = typeof exports == "object" && exports && !exports.nodeType && exports, sr = po && typeof module == "object" && module && !module.nodeType && module, Mh = sr && sr.exports === po, Ys = Mh && kr.process, Dh = (function () { try {
    var r = sr && sr.require && sr.require("util").types;
    return r || Ys && Ys.binding && Ys.binding("util");
}
catch { } })(), Lt = Dh;
var mo = Lt && Lt.isTypedArray, jh = mo ? we(mo) : ho, Se = jh;
var Ph = Object.prototype, Uh = Ph.hasOwnProperty;
function Fh(r, t) { var e = ft(r), s = !e && rr(r), n = !e && !s && St(r), i = !e && !s && !n && Se(r), o = e || s || n || i, a = o ? oo(r.length, String) : [], l = a.length; for (var u in r)
    (t || Uh.call(r, u)) && !(o && (u == "length" || n && (u == "offset" || u == "parent") || i && (u == "buffer" || u == "byteLength" || u == "byteOffset") || jr(u, l))) && a.push(u); return a; }
var Fr = Fh;
function Hh(r, t) { return function (e) { return r(t(e)); }; }
var Hr = Hh;
var zh = Hr(Object.keys, Object), go = zh;
var $h = Object.prototype, Kh = $h.hasOwnProperty;
function Gh(r) { if (!Ne(r))
    return go(r); var t = []; for (var e in Object(r))
    Kh.call(r, e) && e != "constructor" && t.push(e); return t; }
var bo = Gh;
function Vh(r) { return Ht(r) ? Fr(r) : bo(r); }
var Le = Vh;
function Wh(r) { var t = []; if (r != null)
    for (var e in Object(r))
        t.push(e); return t; }
var yo = Wh;
var Zh = Object.prototype, Xh = Zh.hasOwnProperty;
function Qh(r) { if (!z(r))
    return yo(r); var t = Ne(r), e = []; for (var s in r)
    s == "constructor" && (t || !Xh.call(r, s)) || e.push(s); return e; }
var xo = Qh;
function Yh(r) { return Ht(r) ? Fr(r, !0) : xo(r); }
var vt = Yh;
var Jh = J(Object, "create"), Ot = Jh;
function td() { this.__data__ = Ot ? Ot(null) : {}, this.size = 0; }
var vo = td;
function ed(r) { var t = this.has(r) && delete this.__data__[r]; return this.size -= t ? 1 : 0, t; }
var Ao = ed;
var rd = "__lodash_hash_undefined__", sd = Object.prototype, nd = sd.hasOwnProperty;
function id(r) { var t = this.__data__; if (Ot) {
    var e = t[r];
    return e === rd ? void 0 : e;
} return nd.call(t, r) ? t[r] : void 0; }
var Eo = id;
var od = Object.prototype, ad = od.hasOwnProperty;
function ld(r) { var t = this.__data__; return Ot ? t[r] !== void 0 : ad.call(t, r); }
var To = ld;
var ud = "__lodash_hash_undefined__";
function cd(r, t) { var e = this.__data__; return this.size += this.has(r) ? 0 : 1, e[r] = Ot && t === void 0 ? ud : t, this; }
var No = cd;
function Oe(r) { var t = -1, e = r == null ? 0 : r.length; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} }
Oe.prototype.clear = vo;
Oe.prototype.delete = Ao;
Oe.prototype.get = Eo;
Oe.prototype.has = To;
Oe.prototype.set = No;
var Js = Oe;
function fd() { this.__data__ = [], this.size = 0; }
var wo = fd;
function hd(r, t) { for (var e = r.length; e--;)
    if (yt(r[e][0], t))
        return e; return -1; }
var zt = hd;
var dd = Array.prototype, pd = dd.splice;
function md(r) { var t = this.__data__, e = zt(t, r); if (e < 0)
    return !1; var s = t.length - 1; return e == s ? t.pop() : pd.call(t, e, 1), --this.size, !0; }
var So = md;
function gd(r) { var t = this.__data__, e = zt(t, r); return e < 0 ? void 0 : t[e][1]; }
var Lo = gd;
function bd(r) { return zt(this.__data__, r) > -1; }
var Oo = bd;
function yd(r, t) { var e = this.__data__, s = zt(e, r); return s < 0 ? (++this.size, e.push([r, t])) : e[s][1] = t, this; }
var Co = yd;
function Ce(r) { var t = -1, e = r == null ? 0 : r.length; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} }
Ce.prototype.clear = wo;
Ce.prototype.delete = So;
Ce.prototype.get = Lo;
Ce.prototype.has = Oo;
Ce.prototype.set = Co;
var $t = Ce;
var xd = J(M, "Map"), Kt = xd;
function vd() { this.size = 0, this.__data__ = { hash: new Js, map: new (Kt || $t), string: new Js }; }
var _o = vd;
function Ad(r) { var t = typeof r; return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? r !== "__proto__" : r === null; }
var qo = Ad;
function Ed(r, t) { var e = r.__data__; return qo(t) ? e[typeof t == "string" ? "string" : "hash"] : e.map; }
var Gt = Ed;
function Td(r) { var t = Gt(this, r).delete(r); return this.size -= t ? 1 : 0, t; }
var Io = Td;
function Nd(r) { return Gt(this, r).get(r); }
var ko = Nd;
function wd(r) { return Gt(this, r).has(r); }
var Ro = wd;
function Sd(r, t) { var e = Gt(this, r), s = e.size; return e.set(r, t), this.size += e.size == s ? 0 : 1, this; }
var Bo = Sd;
function _e(r) { var t = -1, e = r == null ? 0 : r.length; for (this.clear(); ++t < e;) {
    var s = r[t];
    this.set(s[0], s[1]);
} }
_e.prototype.clear = _o;
_e.prototype.delete = Io;
_e.prototype.get = ko;
_e.prototype.has = Ro;
_e.prototype.set = Bo;
var zr = _e;
function Ld(r, t) { for (var e = -1, s = t.length, n = r.length; ++e < s;)
    r[n + e] = t[e]; return r; }
var $r = Ld;
var Od = Hr(Object.getPrototypeOf, Object), qe = Od;
var Cd = "[object Object]", _d = Function.prototype, qd = Object.prototype, Mo = _d.toString, Id = qd.hasOwnProperty, kd = Mo.call(Object);
function Rd(r) { if (!H(r) || gt(r) != Cd)
    return !1; var t = qe(r); if (t === null)
    return !0; var e = Id.call(t, "constructor") && t.constructor; return typeof e == "function" && e instanceof e && Mo.call(e) == kd; }
var Do = Rd;
function Bd() { this.__data__ = new $t, this.size = 0; }
var jo = Bd;
function Md(r) { var t = this.__data__, e = t.delete(r); return this.size = t.size, e; }
var Po = Md;
function Dd(r) { return this.__data__.get(r); }
var Uo = Dd;
function jd(r) { return this.__data__.has(r); }
var Fo = jd;
var Pd = 200;
function Ud(r, t) { var e = this.__data__; if (e instanceof $t) {
    var s = e.__data__;
    if (!Kt || s.length < Pd - 1)
        return s.push([r, t]), this.size = ++e.size, this;
    e = this.__data__ = new zr(s);
} return e.set(r, t), this.size = e.size, this; }
var Ho = Ud;
function Ie(r) { var t = this.__data__ = new $t(r); this.size = t.size; }
Ie.prototype.clear = jo;
Ie.prototype.delete = Po;
Ie.prototype.get = Uo;
Ie.prototype.has = Fo;
Ie.prototype.set = Ho;
var Vt = Ie;
function Fd(r, t) { return r && xt(t, Le(t), r); }
var zo = Fd;
function Hd(r, t) { return r && xt(t, vt(t), r); }
var $o = Hd;
var Wo = typeof exports == "object" && exports && !exports.nodeType && exports, Ko = Wo && typeof module == "object" && module && !module.nodeType && module, zd = Ko && Ko.exports === Wo, Go = zd ? M.Buffer : void 0, Vo = Go ? Go.allocUnsafe : void 0;
function $d(r, t) { if (t)
    return r.slice(); var e = r.length, s = Vo ? Vo(e) : new r.constructor(e); return r.copy(s), s; }
var Kr = $d;
function Kd(r, t) { for (var e = -1, s = r == null ? 0 : r.length, n = 0, i = []; ++e < s;) {
    var o = r[e];
    t(o, e, r) && (i[n++] = o);
} return i; }
var Zo = Kd;
function Gd() { return []; }
var Gr = Gd;
var Vd = Object.prototype, Wd = Vd.propertyIsEnumerable, Xo = Object.getOwnPropertySymbols, Zd = Xo ? function (r) { return r == null ? [] : (r = Object(r), Zo(Xo(r), function (t) { return Wd.call(r, t); })); } : Gr, ke = Zd;
function Xd(r, t) { return xt(r, ke(r), t); }
var Qo = Xd;
var Qd = Object.getOwnPropertySymbols, Yd = Qd ? function (r) { for (var t = []; r;)
    $r(t, ke(r)), r = qe(r); return t; } : Gr, Vr = Yd;
function Jd(r, t) { return xt(r, Vr(r), t); }
var Yo = Jd;
function tp(r, t, e) { var s = t(r); return ft(r) ? s : $r(s, e(r)); }
var Wr = tp;
function ep(r) { return Wr(r, Le, ke); }
var nr = ep;
function rp(r) { return Wr(r, vt, Vr); }
var Jo = rp;
var sp = J(M, "DataView"), Zr = sp;
var np = J(M, "Promise"), Xr = np;
var ip = J(M, "Set"), Qr = ip;
var ta = "[object Map]", op = "[object Object]", ea = "[object Promise]", ra = "[object Set]", sa = "[object WeakMap]", na = "[object DataView]", ap = wt(Zr), lp = wt(Kt), up = wt(Xr), cp = wt(Qr), fp = wt(Mr), ae = gt;
(Zr && ae(new Zr(new ArrayBuffer(1))) != na || Kt && ae(new Kt) != ta || Xr && ae(Xr.resolve()) != ea || Qr && ae(new Qr) != ra || Mr && ae(new Mr) != sa) && (ae = function (r) { var t = gt(r), e = t == op ? r.constructor : void 0, s = e ? wt(e) : ""; if (s)
    switch (s) {
        case ap: return na;
        case lp: return ta;
        case up: return ea;
        case cp: return ra;
        case fp: return sa;
    } return t; });
var Ct = ae;
var hp = Object.prototype, dp = hp.hasOwnProperty;
function pp(r) { var t = r.length, e = new r.constructor(t); return t && typeof r[0] == "string" && dp.call(r, "index") && (e.index = r.index, e.input = r.input), e; }
var ia = pp;
var mp = M.Uint8Array, Re = mp;
function gp(r) { var t = new r.constructor(r.byteLength); return new Re(t).set(new Re(r)), t; }
var Be = gp;
function bp(r, t) { var e = t ? Be(r.buffer) : r.buffer; return new r.constructor(e, r.byteOffset, r.byteLength); }
var oa = bp;
var yp = /\w*$/;
function xp(r) { var t = new r.constructor(r.source, yp.exec(r)); return t.lastIndex = r.lastIndex, t; }
var aa = xp;
var la = ct ? ct.prototype : void 0, ua = la ? la.valueOf : void 0;
function vp(r) { return ua ? Object(ua.call(r)) : {}; }
var ca = vp;
function Ap(r, t) { var e = t ? Be(r.buffer) : r.buffer; return new r.constructor(e, r.byteOffset, r.length); }
var Yr = Ap;
var Ep = "[object Boolean]", Tp = "[object Date]", Np = "[object Map]", wp = "[object Number]", Sp = "[object RegExp]", Lp = "[object Set]", Op = "[object String]", Cp = "[object Symbol]", _p = "[object ArrayBuffer]", qp = "[object DataView]", Ip = "[object Float32Array]", kp = "[object Float64Array]", Rp = "[object Int8Array]", Bp = "[object Int16Array]", Mp = "[object Int32Array]", Dp = "[object Uint8Array]", jp = "[object Uint8ClampedArray]", Pp = "[object Uint16Array]", Up = "[object Uint32Array]";
function Fp(r, t, e) { var s = r.constructor; switch (t) {
    case _p: return Be(r);
    case Ep:
    case Tp: return new s(+r);
    case qp: return oa(r, e);
    case Ip:
    case kp:
    case Rp:
    case Bp:
    case Mp:
    case Dp:
    case jp:
    case Pp:
    case Up: return Yr(r, e);
    case Np: return new s;
    case wp:
    case Op: return new s(r);
    case Sp: return aa(r);
    case Lp: return new s;
    case Cp: return ca(r);
} }
var fa = Fp;
function Hp(r) { return typeof r.constructor == "function" && !Ne(r) ? Wi(qe(r)) : {}; }
var Jr = Hp;
var zp = "[object Map]";
function $p(r) { return H(r) && Ct(r) == zp; }
var ha = $p;
var da = Lt && Lt.isMap, Kp = da ? we(da) : ha, pa = Kp;
var Gp = "[object Set]";
function Vp(r) { return H(r) && Ct(r) == Gp; }
var ma = Vp;
var ga = Lt && Lt.isSet, Wp = ga ? we(ga) : ma, ba = Wp;
var Zp = 1, Xp = 2, Qp = 4, ya = "[object Arguments]", Yp = "[object Array]", Jp = "[object Boolean]", tm = "[object Date]", em = "[object Error]", xa = "[object Function]", rm = "[object GeneratorFunction]", sm = "[object Map]", nm = "[object Number]", va = "[object Object]", im = "[object RegExp]", om = "[object Set]", am = "[object String]", lm = "[object Symbol]", um = "[object WeakMap]", cm = "[object ArrayBuffer]", fm = "[object DataView]", hm = "[object Float32Array]", dm = "[object Float64Array]", pm = "[object Int8Array]", mm = "[object Int16Array]", gm = "[object Int32Array]", bm = "[object Uint8Array]", ym = "[object Uint8ClampedArray]", xm = "[object Uint16Array]", vm = "[object Uint32Array]", w = {};
w[ya] = w[Yp] = w[cm] = w[fm] = w[Jp] = w[tm] = w[hm] = w[dm] = w[pm] = w[mm] = w[gm] = w[sm] = w[nm] = w[va] = w[im] = w[om] = w[am] = w[lm] = w[bm] = w[ym] = w[xm] = w[vm] = !0;
w[em] = w[xa] = w[um] = !1;
function ts(r, t, e, s, n, i) { var o, a = t & Zp, l = t & Xp, u = t & Qp; if (e && (o = n ? e(r, s, n, i) : e(r)), o !== void 0)
    return o; if (!z(r))
    return r; var c = ft(r); if (c) {
    if (o = ia(r), !a)
        return Dr(r, o);
}
else {
    var f = Ct(r), h = f == xa || f == rm;
    if (St(r))
        return Kr(r, a);
    if (f == va || f == ya || h && !n) {
        if (o = l || h ? {} : Jr(r), !a)
            return l ? Yo(r, $o(o, r)) : Qo(r, zo(o, r));
    }
    else {
        if (!w[f])
            return n ? r : {};
        o = fa(r, f, a);
    }
} i || (i = new Vt); var p = i.get(r); if (p)
    return p; i.set(r, o), ba(r) ? r.forEach(function (v) { o.add(ts(v, t, e, v, r, i)); }) : pa(r) && r.forEach(function (v, g) { o.set(g, ts(v, t, e, g, r, i)); }); var m = u ? l ? Jo : nr : l ? vt : Le, y = c ? void 0 : m(r); return to(y || r, function (v, g) { y && (g = v, v = r[g]), Pr(o, g, ts(v, t, e, g, r, i)); }), o; }
var Aa = ts;
var Am = 1, Em = 4;
function Tm(r) { return Aa(r, Am | Em); }
var At = Tm;
var Nm = "__lodash_hash_undefined__";
function wm(r) { return this.__data__.set(r, Nm), this; }
var Ea = wm;
function Sm(r) { return this.__data__.has(r); }
var Ta = Sm;
function es(r) { var t = -1, e = r == null ? 0 : r.length; for (this.__data__ = new zr; ++t < e;)
    this.add(r[t]); }
es.prototype.add = es.prototype.push = Ea;
es.prototype.has = Ta;
var Na = es;
function Lm(r, t) { for (var e = -1, s = r == null ? 0 : r.length; ++e < s;)
    if (t(r[e], e, r))
        return !0; return !1; }
var wa = Lm;
function Om(r, t) { return r.has(t); }
var Sa = Om;
var Cm = 1, _m = 2;
function qm(r, t, e, s, n, i) { var o = e & Cm, a = r.length, l = t.length; if (a != l && !(o && l > a))
    return !1; var u = i.get(r), c = i.get(t); if (u && c)
    return u == t && c == r; var f = -1, h = !0, p = e & _m ? new Na : void 0; for (i.set(r, t), i.set(t, r); ++f < a;) {
    var m = r[f], y = t[f];
    if (s)
        var v = o ? s(y, m, f, t, r, i) : s(m, y, f, r, t, i);
    if (v !== void 0) {
        if (v)
            continue;
        h = !1;
        break;
    }
    if (p) {
        if (!wa(t, function (g, A) { if (!Sa(p, A) && (m === g || n(m, g, e, s, i)))
            return p.push(A); })) {
            h = !1;
            break;
        }
    }
    else if (!(m === y || n(m, y, e, s, i))) {
        h = !1;
        break;
    }
} return i.delete(r), i.delete(t), h; }
var rs = qm;
function Im(r) { var t = -1, e = Array(r.size); return r.forEach(function (s, n) { e[++t] = [n, s]; }), e; }
var La = Im;
function km(r) { var t = -1, e = Array(r.size); return r.forEach(function (s) { e[++t] = s; }), e; }
var Oa = km;
var Rm = 1, Bm = 2, Mm = "[object Boolean]", Dm = "[object Date]", jm = "[object Error]", Pm = "[object Map]", Um = "[object Number]", Fm = "[object RegExp]", Hm = "[object Set]", zm = "[object String]", $m = "[object Symbol]", Km = "[object ArrayBuffer]", Gm = "[object DataView]", Ca = ct ? ct.prototype : void 0, tn = Ca ? Ca.valueOf : void 0;
function Vm(r, t, e, s, n, i, o) { switch (e) {
    case Gm:
        if (r.byteLength != t.byteLength || r.byteOffset != t.byteOffset)
            return !1;
        r = r.buffer, t = t.buffer;
    case Km: return !(r.byteLength != t.byteLength || !i(new Re(r), new Re(t)));
    case Mm:
    case Dm:
    case Um: return yt(+r, +t);
    case jm: return r.name == t.name && r.message == t.message;
    case Fm:
    case zm: return r == t + "";
    case Pm: var a = La;
    case Hm:
        var l = s & Rm;
        if (a || (a = Oa), r.size != t.size && !l)
            return !1;
        var u = o.get(r);
        if (u)
            return u == t;
        s |= Bm, o.set(r, t);
        var c = rs(a(r), a(t), s, n, i, o);
        return o.delete(r), c;
    case $m: if (tn)
        return tn.call(r) == tn.call(t);
} return !1; }
var _a = Vm;
var Wm = 1, Zm = Object.prototype, Xm = Zm.hasOwnProperty;
function Qm(r, t, e, s, n, i) { var o = e & Wm, a = nr(r), l = a.length, u = nr(t), c = u.length; if (l != c && !o)
    return !1; for (var f = l; f--;) {
    var h = a[f];
    if (!(o ? h in t : Xm.call(t, h)))
        return !1;
} var p = i.get(r), m = i.get(t); if (p && m)
    return p == t && m == r; var y = !0; i.set(r, t), i.set(t, r); for (var v = o; ++f < l;) {
    h = a[f];
    var g = r[h], A = t[h];
    if (s)
        var E = o ? s(A, g, h, t, r, i) : s(g, A, h, r, t, i);
    if (!(E === void 0 ? g === A || n(g, A, e, s, i) : E)) {
        y = !1;
        break;
    }
    v || (v = h == "constructor");
} if (y && !v) {
    var T = r.constructor, N = t.constructor;
    T != N && "constructor" in r && "constructor" in t && !(typeof T == "function" && T instanceof T && typeof N == "function" && N instanceof N) && (y = !1);
} return i.delete(r), i.delete(t), y; }
var qa = Qm;
var Ym = 1, Ia = "[object Arguments]", ka = "[object Array]", ss = "[object Object]", Jm = Object.prototype, Ra = Jm.hasOwnProperty;
function tg(r, t, e, s, n, i) { var o = ft(r), a = ft(t), l = o ? ka : Ct(r), u = a ? ka : Ct(t); l = l == Ia ? ss : l, u = u == Ia ? ss : u; var c = l == ss, f = u == ss, h = l == u; if (h && St(r)) {
    if (!St(t))
        return !1;
    o = !0, c = !1;
} if (h && !c)
    return i || (i = new Vt), o || Se(r) ? rs(r, t, e, s, n, i) : _a(r, t, l, e, s, n, i); if (!(e & Ym)) {
    var p = c && Ra.call(r, "__wrapped__"), m = f && Ra.call(t, "__wrapped__");
    if (p || m) {
        var y = p ? r.value() : r, v = m ? t.value() : t;
        return i || (i = new Vt), n(y, v, e, s, i);
    }
} return h ? (i || (i = new Vt), qa(r, t, e, s, n, i)) : !1; }
var Ba = tg;
function Ma(r, t, e, s, n) { return r === t ? !0 : r == null || t == null || !H(r) && !H(t) ? r !== r && t !== t : Ba(r, t, e, s, Ma, n); }
var Da = Ma;
function eg(r) { return function (t, e, s) { for (var n = -1, i = Object(t), o = s(t), a = o.length; a--;) {
    var l = o[r ? a : ++n];
    if (e(i[l], l, i) === !1)
        break;
} return t; }; }
var ja = eg;
var rg = ja(), Pa = rg;
function sg(r, t, e) { (e !== void 0 && !yt(r[t], e) || e === void 0 && !(t in r)) && Te(r, t, e); }
var ir = sg;
function ng(r) { return H(r) && Ht(r); }
var Ua = ng;
function ig(r, t) { if (!(t === "constructor" && typeof r[t] == "function") && t != "__proto__")
    return r[t]; }
var or = ig;
function og(r) { return xt(r, vt(r)); }
var Fa = og;
function ag(r, t, e, s, n, i, o) { var a = or(r, e), l = or(t, e), u = o.get(l); if (u) {
    ir(r, e, u);
    return;
} var c = i ? i(a, l, e + "", r, t, o) : void 0, f = c === void 0; if (f) {
    var h = ft(l), p = !h && St(l), m = !h && !p && Se(l);
    c = l, h || p || m ? ft(a) ? c = a : Ua(a) ? c = Dr(a) : p ? (f = !1, c = Kr(l, !0)) : m ? (f = !1, c = Yr(l, !0)) : c = [] : Do(l) || rr(l) ? (c = a, rr(a) ? c = Fa(a) : (!z(a) || Ae(a)) && (c = Jr(l))) : f = !1;
} f && (o.set(l, c), n(c, l, s, i, o), o.delete(l)), ir(r, e, c); }
var Ha = ag;
function za(r, t, e, s, n) { r !== t && Pa(t, function (i, o) { if (n || (n = new Vt), z(i))
    Ha(r, t, o, e, za, s, n);
else {
    var a = s ? s(or(r, o), i, o + "", r, t, n) : void 0;
    a === void 0 && (a = i), ir(r, o, a);
} }, vt); }
var $a = za;
function lg(r, t) { return Da(r, t); }
var le = lg;
var ug = io(function (r, t, e) { $a(r, t, e); }), tt = ug;
var ur = {};
jc(ur, { Attributor: () => W, AttributorStore: () => ar, BlockBlot: () => ue, ClassAttributor: () => D, ContainerBlot: () => Ue, EmbedBlot: () => q, InlineBlot: () => ns, LeafBlot: () => j, ParentBlot: () => et, Registry: () => Xt, Scope: () => b, ScrollBlot: () => lr, StyleAttributor: () => rt, TextBlot: () => Fe });
var b = (r => (r[r.TYPE = 3] = "TYPE", r[r.LEVEL = 12] = "LEVEL", r[r.ATTRIBUTE = 13] = "ATTRIBUTE", r[r.BLOT = 14] = "BLOT", r[r.INLINE = 7] = "INLINE", r[r.BLOCK = 11] = "BLOCK", r[r.BLOCK_BLOT = 10] = "BLOCK_BLOT", r[r.INLINE_BLOT = 6] = "INLINE_BLOT", r[r.BLOCK_ATTRIBUTE = 9] = "BLOCK_ATTRIBUTE", r[r.INLINE_ATTRIBUTE = 5] = "INLINE_ATTRIBUTE", r[r.ANY = 15] = "ANY", r))(b || {}), W = class {
    constructor(t, e, s = {}) { this.attrName = t, this.keyName = e; let n = b.TYPE & b.ATTRIBUTE; this.scope = s.scope != null ? s.scope & b.LEVEL | n : b.ATTRIBUTE, s.whitelist != null && (this.whitelist = s.whitelist); }
    static keys(t) { return Array.from(t.attributes).map(e => e.name); }
    add(t, e) { return this.canAdd(t, e) ? (t.setAttribute(this.keyName, e), !0) : !1; }
    canAdd(t, e) { return this.whitelist == null ? !0 : typeof e == "string" ? this.whitelist.indexOf(e.replace(/["']/g, "")) > -1 : this.whitelist.indexOf(e) > -1; }
    remove(t) { t.removeAttribute(this.keyName); }
    value(t) { let e = t.getAttribute(this.keyName); return this.canAdd(t, e) && e ? e : ""; }
}, Zt = class extends Error {
    constructor(t) { t = "[Parchment] " + t, super(t), this.message = t, this.name = this.constructor.name; }
}, cg = (() => { let r = class rn {
    constructor() { this.attributes = {}, this.classes = {}, this.tags = {}, this.types = {}; }
    static find(e, s = !1) { if (e == null)
        return null; if (this.blots.has(e))
        return this.blots.get(e) || null; if (s) {
        let n = null;
        try {
            n = e.parentNode;
        }
        catch {
            return null;
        }
        return this.find(n, s);
    } return null; }
    create(e, s, n) { let i = this.query(s); if (i == null)
        throw new Zt(`Unable to create ${s} blot`); let o = i, a = s instanceof Node || s.nodeType === Node.TEXT_NODE ? s : o.create(n), l = new o(e, a, n); return rn.blots.set(l.domNode, l), l; }
    find(e, s = !1) { return rn.find(e, s); }
    query(e, s = b.ANY) { let n; return typeof e == "string" ? n = this.types[e] || this.attributes[e] : e instanceof Text || e.nodeType === Node.TEXT_NODE ? n = this.types.text : typeof e == "number" ? e & b.LEVEL & b.BLOCK ? n = this.types.block : e & b.LEVEL & b.INLINE && (n = this.types.inline) : e instanceof Element && ((e.getAttribute("class") || "").split(/\s+/).some(i => (n = this.classes[i], !!n)), n = n || this.tags[e.tagName]), n == null ? null : "scope" in n && s & b.LEVEL & n.scope && s & b.TYPE & n.scope ? n : null; }
    register(...e) { return e.map(s => { let n = "blotName" in s, i = "attrName" in s; if (!n && !i)
        throw new Zt("Invalid definition"); if (n && s.blotName === "abstract")
        throw new Zt("Cannot register abstract class"); let o = n ? s.blotName : i ? s.attrName : void 0; return this.types[o] = s, i ? typeof s.keyName == "string" && (this.attributes[s.keyName] = s) : n && (s.className && (this.classes[s.className] = s), s.tagName && (Array.isArray(s.tagName) ? s.tagName = s.tagName.map(a => a.toUpperCase()) : s.tagName = s.tagName.toUpperCase(), (Array.isArray(s.tagName) ? s.tagName : [s.tagName]).forEach(a => { (this.tags[a] == null || s.className == null) && (this.tags[a] = s); }))), s; }); }
}; return r.blots = new WeakMap, r; })(), Xt = cg;
function Ka(r, t) { return (r.getAttribute("class") || "").split(/\s+/).filter(e => e.indexOf(`${t}-`) === 0); }
var sn = class extends W {
    static keys(t) { return (t.getAttribute("class") || "").split(/\s+/).map(e => e.split("-").slice(0, -1).join("-")); }
    add(t, e) { return this.canAdd(t, e) ? (this.remove(t), t.classList.add(`${this.keyName}-${e}`), !0) : !1; }
    remove(t) { Ka(t, this.keyName).forEach(e => { t.classList.remove(e); }), t.classList.length === 0 && t.removeAttribute("class"); }
    value(t) { let e = (Ka(t, this.keyName)[0] || "").slice(this.keyName.length + 1); return this.canAdd(t, e) ? e : ""; }
}, D = sn;
function en(r) { let t = r.split("-"), e = t.slice(1).map(s => s[0].toUpperCase() + s.slice(1)).join(""); return t[0] + e; }
var nn = class extends W {
    static keys(t) { return (t.getAttribute("style") || "").split(";").map(e => e.split(":")[0].trim()); }
    add(t, e) { return this.canAdd(t, e) ? (t.style[en(this.keyName)] = e, !0) : !1; }
    remove(t) { t.style[en(this.keyName)] = "", t.getAttribute("style") || t.removeAttribute("style"); }
    value(t) { let e = t.style[en(this.keyName)]; return this.canAdd(t, e) ? e : ""; }
}, rt = nn, on = class {
    constructor(t) { this.attributes = {}, this.domNode = t, this.build(); }
    attribute(t, e) { e ? t.add(this.domNode, e) && (t.value(this.domNode) != null ? this.attributes[t.attrName] = t : delete this.attributes[t.attrName]) : (t.remove(this.domNode), delete this.attributes[t.attrName]); }
    build() { this.attributes = {}; let t = Xt.find(this.domNode); if (t == null)
        return; let e = W.keys(this.domNode), s = D.keys(this.domNode), n = rt.keys(this.domNode); e.concat(s).concat(n).forEach(i => { let o = t.scroll.query(i, b.ATTRIBUTE); o instanceof W && (this.attributes[o.attrName] = o); }); }
    copy(t) { Object.keys(this.attributes).forEach(e => { let s = this.attributes[e].value(this.domNode); t.format(e, s); }); }
    move(t) { this.copy(t), Object.keys(this.attributes).forEach(e => { this.attributes[e].remove(this.domNode); }), this.attributes = {}; }
    values() { return Object.keys(this.attributes).reduce((t, e) => (t[e] = this.attributes[e].value(this.domNode), t), {}); }
}, ar = on, Va = class {
    constructor(t, e) { this.scroll = t, this.domNode = e, Xt.blots.set(e, this), this.prev = null, this.next = null; }
    static create(t) { if (this.tagName == null)
        throw new Zt("Blot definition missing tagName"); let e, s; return Array.isArray(this.tagName) ? (typeof t == "string" ? (s = t.toUpperCase(), parseInt(s, 10).toString() === s && (s = parseInt(s, 10))) : typeof t == "number" && (s = t), typeof s == "number" ? e = document.createElement(this.tagName[s - 1]) : s && this.tagName.indexOf(s) > -1 ? e = document.createElement(s) : e = document.createElement(this.tagName[0])) : e = document.createElement(this.tagName), this.className && e.classList.add(this.className), e; }
    get statics() { return this.constructor; }
    attach() { }
    clone() { let t = this.domNode.cloneNode(!1); return this.scroll.create(t); }
    detach() { this.parent != null && this.parent.removeChild(this), Xt.blots.delete(this.domNode); }
    deleteAt(t, e) { this.isolate(t, e).remove(); }
    formatAt(t, e, s, n) { let i = this.isolate(t, e); if (this.scroll.query(s, b.BLOT) != null && n)
        i.wrap(s, n);
    else if (this.scroll.query(s, b.ATTRIBUTE) != null) {
        let o = this.scroll.create(this.statics.scope);
        i.wrap(o), o.format(s, n);
    } }
    insertAt(t, e, s) { let n = s == null ? this.scroll.create("text", e) : this.scroll.create(e, s), i = this.split(t); this.parent.insertBefore(n, i || void 0); }
    isolate(t, e) { let s = this.split(t); if (s == null)
        throw new Error("Attempt to isolate at end"); return s.split(e), s; }
    length() { return 1; }
    offset(t = this.parent) { return this.parent == null || this === t ? 0 : this.parent.children.offset(this) + this.parent.offset(t); }
    optimize(t) { this.statics.requiredContainer && !(this.parent instanceof this.statics.requiredContainer) && this.wrap(this.statics.requiredContainer.blotName); }
    remove() { this.domNode.parentNode != null && this.domNode.parentNode.removeChild(this.domNode), this.detach(); }
    replaceWith(t, e) { let s = typeof t == "string" ? this.scroll.create(t, e) : t; return this.parent != null && (this.parent.insertBefore(s, this.next || void 0), this.remove()), s; }
    split(t, e) { return t === 0 ? this : this.next; }
    update(t, e) { }
    wrap(t, e) { let s = typeof t == "string" ? this.scroll.create(t, e) : t; if (this.parent != null && this.parent.insertBefore(s, this.next || void 0), typeof s.appendChild != "function")
        throw new Zt(`Cannot wrap ${t}`); return s.appendChild(this), s; }
};
Va.blotName = "abstract";
var Wa = Va, Za = class extends Wa {
    static value(t) { return !0; }
    index(t, e) { return this.domNode === t || this.domNode.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY ? Math.min(e, 1) : -1; }
    position(t, e) { let s = Array.from(this.parent.domNode.childNodes).indexOf(this.domNode); return t > 0 && (s += 1), [this.parent.domNode, s]; }
    value() { return { [this.statics.blotName]: this.statics.value(this.domNode) || !0 }; }
};
Za.scope = b.INLINE_BLOT;
var fg = Za, j = fg, an = class {
    constructor() { this.head = null, this.tail = null, this.length = 0; }
    append(...t) { if (this.insertBefore(t[0], null), t.length > 1) {
        let e = t.slice(1);
        this.append(...e);
    } }
    at(t) { let e = this.iterator(), s = e(); for (; s && t > 0;)
        t -= 1, s = e(); return s; }
    contains(t) { let e = this.iterator(), s = e(); for (; s;) {
        if (s === t)
            return !0;
        s = e();
    } return !1; }
    indexOf(t) { let e = this.iterator(), s = e(), n = 0; for (; s;) {
        if (s === t)
            return n;
        n += 1, s = e();
    } return -1; }
    insertBefore(t, e) { t != null && (this.remove(t), t.next = e, e != null ? (t.prev = e.prev, e.prev != null && (e.prev.next = t), e.prev = t, e === this.head && (this.head = t)) : this.tail != null ? (this.tail.next = t, t.prev = this.tail, this.tail = t) : (t.prev = null, this.head = this.tail = t), this.length += 1); }
    offset(t) { let e = 0, s = this.head; for (; s != null;) {
        if (s === t)
            return e;
        e += s.length(), s = s.next;
    } return -1; }
    remove(t) { this.contains(t) && (t.prev != null && (t.prev.next = t.next), t.next != null && (t.next.prev = t.prev), t === this.head && (this.head = t.next), t === this.tail && (this.tail = t.prev), this.length -= 1); }
    iterator(t = this.head) { return () => { let e = t; return t != null && (t = t.next), e; }; }
    find(t, e = !1) { let s = this.iterator(), n = s(); for (; n;) {
        let i = n.length();
        if (t < i || e && t === i && (n.next == null || n.next.length() !== 0))
            return [n, t];
        t -= i, n = s();
    } return [null, 0]; }
    forEach(t) { let e = this.iterator(), s = e(); for (; s;)
        t(s), s = e(); }
    forEachAt(t, e, s) { if (e <= 0)
        return; let [n, i] = this.find(t), o = t - i, a = this.iterator(n), l = a(); for (; l && o < t + e;) {
        let u = l.length();
        t > o ? s(l, t - o, Math.min(e, o + u - t)) : s(l, 0, Math.min(u, t + e - o)), o += u, l = a();
    } }
    map(t) { return this.reduce((e, s) => (e.push(t(s)), e), []); }
    reduce(t, e) { let s = this.iterator(), n = s(); for (; n;)
        e = t(e, n), n = s(); return e; }
};
function Ga(r, t) { let e = t.find(r); if (e)
    return e; try {
    return t.create(r);
}
catch {
    let s = t.create(b.INLINE);
    return Array.from(r.childNodes).forEach(n => { s.domNode.appendChild(n); }), r.parentNode && r.parentNode.replaceChild(s.domNode, r), s.attach(), s;
} }
var hg = (() => { let r = class Wt extends Wa {
    constructor(e, s) { super(e, s), this.uiNode = null, this.build(); }
    appendChild(e) { this.insertBefore(e); }
    attach() { super.attach(), this.children.forEach(e => { e.attach(); }); }
    attachUI(e) { this.uiNode != null && this.uiNode.remove(), this.uiNode = e, Wt.uiClass && this.uiNode.classList.add(Wt.uiClass), this.uiNode.setAttribute("contenteditable", "false"), this.domNode.insertBefore(this.uiNode, this.domNode.firstChild); }
    build() { this.children = new an, Array.from(this.domNode.childNodes).filter(e => e !== this.uiNode).reverse().forEach(e => { try {
        let s = Ga(e, this.scroll);
        this.insertBefore(s, this.children.head || void 0);
    }
    catch (s) {
        if (s instanceof Zt)
            return;
        throw s;
    } }); }
    deleteAt(e, s) { if (e === 0 && s === this.length())
        return this.remove(); this.children.forEachAt(e, s, (n, i, o) => { n.deleteAt(i, o); }); }
    descendant(e, s = 0) { let [n, i] = this.children.find(s); return e.blotName == null && e(n) || e.blotName != null && n instanceof e ? [n, i] : n instanceof Wt ? n.descendant(e, i) : [null, -1]; }
    descendants(e, s = 0, n = Number.MAX_VALUE) { let i = [], o = n; return this.children.forEachAt(s, n, (a, l, u) => { (e.blotName == null && e(a) || e.blotName != null && a instanceof e) && i.push(a), a instanceof Wt && (i = i.concat(a.descendants(e, l, o))), o -= u; }), i; }
    detach() { this.children.forEach(e => { e.detach(); }), super.detach(); }
    enforceAllowedChildren() { let e = !1; this.children.forEach(s => { e || this.statics.allowedChildren.some(n => s instanceof n) || (s.statics.scope === b.BLOCK_BLOT ? (s.next != null && this.splitAfter(s), s.prev != null && this.splitAfter(s.prev), s.parent.unwrap(), e = !0) : s instanceof Wt ? s.unwrap() : s.remove()); }); }
    formatAt(e, s, n, i) { this.children.forEachAt(e, s, (o, a, l) => { o.formatAt(a, l, n, i); }); }
    insertAt(e, s, n) { let [i, o] = this.children.find(e); if (i)
        i.insertAt(o, s, n);
    else {
        let a = n == null ? this.scroll.create("text", s) : this.scroll.create(s, n);
        this.appendChild(a);
    } }
    insertBefore(e, s) { e.parent != null && e.parent.children.remove(e); let n = null; this.children.insertBefore(e, s || null), e.parent = this, s != null && (n = s.domNode), (this.domNode.parentNode !== e.domNode || this.domNode.nextSibling !== n) && this.domNode.insertBefore(e.domNode, n), e.attach(); }
    length() { return this.children.reduce((e, s) => e + s.length(), 0); }
    moveChildren(e, s) { this.children.forEach(n => { e.insertBefore(n, s); }); }
    optimize(e) { if (super.optimize(e), this.enforceAllowedChildren(), this.uiNode != null && this.uiNode !== this.domNode.firstChild && this.domNode.insertBefore(this.uiNode, this.domNode.firstChild), this.children.length === 0)
        if (this.statics.defaultChild != null) {
            let s = this.scroll.create(this.statics.defaultChild.blotName);
            this.appendChild(s);
        }
        else
            this.remove(); }
    path(e, s = !1) { let [n, i] = this.children.find(e, s), o = [[this, e]]; return n instanceof Wt ? o.concat(n.path(i, s)) : (n != null && o.push([n, i]), o); }
    removeChild(e) { this.children.remove(e); }
    replaceWith(e, s) { let n = typeof e == "string" ? this.scroll.create(e, s) : e; return n instanceof Wt && this.moveChildren(n), super.replaceWith(n); }
    split(e, s = !1) { if (!s) {
        if (e === 0)
            return this;
        if (e === this.length())
            return this.next;
    } let n = this.clone(); return this.parent && this.parent.insertBefore(n, this.next || void 0), this.children.forEachAt(e, this.length(), (i, o, a) => { let l = i.split(o, s); l != null && n.appendChild(l); }), n; }
    splitAfter(e) { let s = this.clone(); for (; e.next != null;)
        s.appendChild(e.next); return this.parent && this.parent.insertBefore(s, this.next || void 0), s; }
    unwrap() { this.parent && this.moveChildren(this.parent, this.next || void 0), this.remove(); }
    update(e, s) { let n = [], i = []; e.forEach(o => { o.target === this.domNode && o.type === "childList" && (n.push(...o.addedNodes), i.push(...o.removedNodes)); }), i.forEach(o => { if (o.parentNode != null && o.tagName !== "IFRAME" && document.body.compareDocumentPosition(o) & Node.DOCUMENT_POSITION_CONTAINED_BY)
        return; let a = this.scroll.find(o); a != null && (a.domNode.parentNode == null || a.domNode.parentNode === this.domNode) && a.detach(); }), n.filter(o => o.parentNode === this.domNode && o !== this.uiNode).sort((o, a) => o === a ? 0 : o.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_FOLLOWING ? 1 : -1).forEach(o => { let a = null; o.nextSibling != null && (a = this.scroll.find(o.nextSibling)); let l = Ga(o, this.scroll); (l.next !== a || l.next == null) && (l.parent != null && l.parent.removeChild(this), this.insertBefore(l, a || void 0)); }), this.enforceAllowedChildren(); }
}; return r.uiClass = "", r; })(), dg = hg, et = dg;
function pg(r, t) { if (Object.keys(r).length !== Object.keys(t).length)
    return !1; for (let e in r)
    if (r[e] !== t[e])
        return !1; return !0; }
var Me = class De extends et {
    static create(t) { return super.create(t); }
    static formats(t, e) { let s = e.query(De.blotName); if (!(s != null && t.tagName === s.tagName)) {
        if (typeof this.tagName == "string")
            return !0;
        if (Array.isArray(this.tagName))
            return t.tagName.toLowerCase();
    } }
    constructor(t, e) { super(t, e), this.attributes = new ar(this.domNode); }
    format(t, e) { if (t === this.statics.blotName && !e)
        this.children.forEach(s => { s instanceof De || (s = s.wrap(De.blotName, !0)), this.attributes.copy(s); }), this.unwrap();
    else {
        let s = this.scroll.query(t, b.INLINE);
        if (s == null)
            return;
        s instanceof W ? this.attributes.attribute(s, e) : e && (t !== this.statics.blotName || this.formats()[t] !== e) && this.replaceWith(t, e);
    } }
    formats() { let t = this.attributes.values(), e = this.statics.formats(this.domNode, this.scroll); return e != null && (t[this.statics.blotName] = e), t; }
    formatAt(t, e, s, n) { this.formats()[s] != null || this.scroll.query(s, b.ATTRIBUTE) ? this.isolate(t, e).format(s, n) : super.formatAt(t, e, s, n); }
    optimize(t) { super.optimize(t); let e = this.formats(); if (Object.keys(e).length === 0)
        return this.unwrap(); let s = this.next; s instanceof De && s.prev === this && pg(e, s.formats()) && (s.moveChildren(this), s.remove()); }
    replaceWith(t, e) { let s = super.replaceWith(t, e); return this.attributes.copy(s), s; }
    update(t, e) { super.update(t, e), t.some(s => s.target === this.domNode && s.type === "attributes") && this.attributes.build(); }
    wrap(t, e) { let s = super.wrap(t, e); return s instanceof De && this.attributes.move(s), s; }
};
Me.allowedChildren = [Me, j], Me.blotName = "inline", Me.scope = b.INLINE_BLOT, Me.tagName = "SPAN";
var mg = Me, ns = mg, je = class ln extends et {
    static create(t) { return super.create(t); }
    static formats(t, e) { let s = e.query(ln.blotName); if (!(s != null && t.tagName === s.tagName)) {
        if (typeof this.tagName == "string")
            return !0;
        if (Array.isArray(this.tagName))
            return t.tagName.toLowerCase();
    } }
    constructor(t, e) { super(t, e), this.attributes = new ar(this.domNode); }
    format(t, e) { let s = this.scroll.query(t, b.BLOCK); s != null && (s instanceof W ? this.attributes.attribute(s, e) : t === this.statics.blotName && !e ? this.replaceWith(ln.blotName) : e && (t !== this.statics.blotName || this.formats()[t] !== e) && this.replaceWith(t, e)); }
    formats() { let t = this.attributes.values(), e = this.statics.formats(this.domNode, this.scroll); return e != null && (t[this.statics.blotName] = e), t; }
    formatAt(t, e, s, n) { this.scroll.query(s, b.BLOCK) != null ? this.format(s, n) : super.formatAt(t, e, s, n); }
    insertAt(t, e, s) { if (s == null || this.scroll.query(e, b.INLINE) != null)
        super.insertAt(t, e, s);
    else {
        let n = this.split(t);
        if (n != null) {
            let i = this.scroll.create(e, s);
            n.parent.insertBefore(i, n);
        }
        else
            throw new Error("Attempt to insertAt after block boundaries");
    } }
    replaceWith(t, e) { let s = super.replaceWith(t, e); return this.attributes.copy(s), s; }
    update(t, e) { super.update(t, e), t.some(s => s.target === this.domNode && s.type === "attributes") && this.attributes.build(); }
};
je.blotName = "block", je.scope = b.BLOCK_BLOT, je.tagName = "P", je.allowedChildren = [ns, je, j];
var gg = je, ue = gg, un = class extends et {
    checkMerge() { return this.next !== null && this.next.statics.blotName === this.statics.blotName; }
    deleteAt(t, e) { super.deleteAt(t, e), this.enforceAllowedChildren(); }
    formatAt(t, e, s, n) { super.formatAt(t, e, s, n), this.enforceAllowedChildren(); }
    insertAt(t, e, s) { super.insertAt(t, e, s), this.enforceAllowedChildren(); }
    optimize(t) { super.optimize(t), this.children.length > 0 && this.next != null && this.checkMerge() && (this.next.moveChildren(this), this.next.remove()); }
};
un.blotName = "container", un.scope = b.BLOCK_BLOT;
var bg = un, Ue = bg, cn = class extends j {
    static formats(t, e) { }
    format(t, e) { super.formatAt(0, this.length(), t, e); }
    formatAt(t, e, s, n) { t === 0 && e === this.length() ? this.format(s, n) : super.formatAt(t, e, s, n); }
    formats() { return this.statics.formats(this.domNode, this.scroll); }
}, q = cn, yg = { attributes: !0, characterData: !0, characterDataOldValue: !0, childList: !0, subtree: !0 }, xg = 100, Pe = class extends et {
    constructor(t, e) { super(null, e), this.registry = t, this.scroll = this, this.build(), this.observer = new MutationObserver(s => { this.update(s); }), this.observer.observe(this.domNode, yg), this.attach(); }
    create(t, e) { return this.registry.create(this, t, e); }
    find(t, e = !1) { let s = this.registry.find(t, e); return s ? s.scroll === this ? s : e ? this.find(s.scroll.domNode.parentNode, !0) : null : null; }
    query(t, e = b.ANY) { return this.registry.query(t, e); }
    register(...t) { return this.registry.register(...t); }
    build() { this.scroll != null && super.build(); }
    detach() { super.detach(), this.observer.disconnect(); }
    deleteAt(t, e) { this.update(), t === 0 && e === this.length() ? this.children.forEach(s => { s.remove(); }) : super.deleteAt(t, e); }
    formatAt(t, e, s, n) { this.update(), super.formatAt(t, e, s, n); }
    insertAt(t, e, s) { this.update(), super.insertAt(t, e, s); }
    optimize(t = [], e = {}) { super.optimize(e); let s = e.mutationsMap || new WeakMap, n = Array.from(this.observer.takeRecords()); for (; n.length > 0;)
        t.push(n.pop()); let i = (l, u = !0) => { l == null || l === this || l.domNode.parentNode != null && (s.has(l.domNode) || s.set(l.domNode, []), u && i(l.parent)); }, o = l => { s.has(l.domNode) && (l instanceof et && l.children.forEach(o), s.delete(l.domNode), l.optimize(e)); }, a = t; for (let l = 0; a.length > 0; l += 1) {
        if (l >= xg)
            throw new Error("[Parchment] Maximum optimize iterations reached");
        for (a.forEach(u => { let c = this.find(u.target, !0); c != null && (c.domNode === u.target && (u.type === "childList" ? (i(this.find(u.previousSibling, !1)), Array.from(u.addedNodes).forEach(f => { let h = this.find(f, !1); i(h, !1), h instanceof et && h.children.forEach(p => { i(p, !1); }); })) : u.type === "attributes" && i(c.prev)), i(c)); }), this.children.forEach(o), a = Array.from(this.observer.takeRecords()), n = a.slice(); n.length > 0;)
            t.push(n.pop());
    } }
    update(t, e = {}) { t = t || this.observer.takeRecords(); let s = new WeakMap; t.map(n => { let i = this.find(n.target, !0); return i == null ? null : s.has(i.domNode) ? (s.get(i.domNode).push(n), null) : (s.set(i.domNode, [n]), i); }).forEach(n => { n != null && n !== this && s.has(n.domNode) && n.update(s.get(n.domNode) || [], e); }), e.mutationsMap = s, s.has(this.domNode) && super.update(s.get(this.domNode), e), this.optimize(t, e); }
};
Pe.blotName = "scroll", Pe.defaultChild = ue, Pe.allowedChildren = [ue, Ue], Pe.scope = b.BLOCK_BLOT, Pe.tagName = "DIV";
var vg = Pe, lr = vg, fn = class Xa extends j {
    static create(t) { return document.createTextNode(t); }
    static value(t) { return t.data; }
    constructor(t, e) { super(t, e), this.text = this.statics.value(this.domNode); }
    deleteAt(t, e) { this.domNode.data = this.text = this.text.slice(0, t) + this.text.slice(t + e); }
    index(t, e) { return this.domNode === t ? e : -1; }
    insertAt(t, e, s) { s == null ? (this.text = this.text.slice(0, t) + e + this.text.slice(t), this.domNode.data = this.text) : super.insertAt(t, e, s); }
    length() { return this.text.length; }
    optimize(t) { super.optimize(t), this.text = this.statics.value(this.domNode), this.text.length === 0 ? this.remove() : this.next instanceof Xa && this.next.prev === this && (this.insertAt(this.length(), this.next.value()), this.next.remove()); }
    position(t, e = !1) { return [this.domNode, t]; }
    split(t, e = !1) { if (!e) {
        if (t === 0)
            return this;
        if (t === this.length())
            return this.next;
    } let s = this.scroll.create(this.domNode.splitText(t)); return this.parent.insertBefore(s, this.next || void 0), this.text = this.statics.value(this.domNode), s; }
    update(t, e) { t.some(s => s.type === "characterData" && s.target === this.domNode) && (this.text = this.statics.value(this.domNode)); }
    value() { return this.text; }
};
fn.blotName = "text", fn.scope = b.INLINE_BLOT;
var Ag = fn, Fe = Ag;
var ee = ot(lt(), 1);
var I = ot(lt(), 1);
var Xn = ot(lt(), 1);
var jb = (() => { class r extends q {
    static value() { }
    optimize() { (this.prev || this.next) && this.remove(); }
    length() { return 0; }
    value() { return ""; }
} return r.blotName = "break", r.tagName = "BR", r; })(), $ = jb;
var R = class extends Fe {
}, Pb = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
function ye(r) { return r.replace(/[&<>"']/g, t => Pb[t]); }
var Ub = (() => { class r extends ns {
    static allowedChildren = [r, $, q, R];
    static order = ["cursor", "inline", "link", "underline", "strike", "italic", "bold", "script", "code"];
    static compare(e, s) { let n = r.order.indexOf(e), i = r.order.indexOf(s); return n >= 0 || i >= 0 ? n - i : e === s ? 0 : e < s ? -1 : 1; }
    formatAt(e, s, n, i) { if (r.compare(this.statics.blotName, n) < 0 && this.scroll.query(n, b.BLOT)) {
        let o = this.isolate(e, s);
        i && o.wrap(n, i);
    }
    else
        super.formatAt(e, s, n, i); }
    optimize(e) { if (super.optimize(e), this.parent instanceof r && r.compare(this.statics.blotName, this.parent.statics.blotName) > 0) {
        let s = this.parent.isolate(this.offset(), this.length());
        this.moveChildren(s), s.wrap(this);
    } }
} return r; })(), K = Ub;
var ku = 1, B = (() => {
    class r extends ue {
        cache = {};
        delta() { return this.cache.delta == null && (this.cache.delta = Qn(this)), this.cache.delta; }
        deleteAt(e, s) { super.deleteAt(e, s), this.cache = {}; }
        formatAt(e, s, n, i) { s <= 0 || (this.scroll.query(n, b.BLOCK) ? e + s === this.length() && this.format(n, i) : super.formatAt(e, Math.min(s, this.length() - e - 1), n, i), this.cache = {}); }
        insertAt(e, s, n) {
            if (n != null) {
                super.insertAt(e, s, n), this.cache = {};
                return;
            }
            if (s.length === 0)
                return;
            let i = s.split(`
`), o = i.shift();
            o.length > 0 && (e < this.length() - 1 || this.children.tail == null ? super.insertAt(Math.min(e, this.length() - 1), o) : this.children.tail.insertAt(this.children.tail.length(), o), this.cache = {});
            let a = this;
            i.reduce((l, u) => (a = a.split(l, !0), a.insertAt(0, u), u.length), e + o.length);
        }
        insertBefore(e, s) { let { head: n } = this.children; super.insertBefore(e, s), n instanceof $ && n.remove(), this.cache = {}; }
        length() { return this.cache.length == null && (this.cache.length = super.length() + ku), this.cache.length; }
        moveChildren(e, s) { super.moveChildren(e, s), this.cache = {}; }
        optimize(e) { super.optimize(e), this.cache = {}; }
        path(e) { return super.path(e, !0); }
        removeChild(e) { super.removeChild(e), this.cache = {}; }
        split(e) { let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1; if (s && (e === 0 || e >= this.length() - ku)) {
            let i = this.clone();
            return e === 0 ? (this.parent.insertBefore(i, this), this) : (this.parent.insertBefore(i, this.next), i);
        } let n = super.split(e, s); return this.cache = {}, n; }
    }
    return r.blotName = "block", r.tagName = "P", r.defaultChild = $, r.allowedChildren = [$, K, q, R], r;
})(), U = class extends q {
    attach() { super.attach(), this.attributes = new ar(this.domNode); }
    delta() { return new Xn.default().insert(this.value(), L(L({}, this.formats()), this.attributes.values())); }
    format(t, e) { let s = this.scroll.query(t, b.BLOCK_ATTRIBUTE); s != null && this.attributes.attribute(s, e); }
    formatAt(t, e, s, n) { this.format(s, n); }
    insertAt(t, e, s) {
        if (s != null) {
            super.insertAt(t, e, s);
            return;
        }
        let n = e.split(`
`), i = n.pop(), o = n.map(l => { let u = this.scroll.create(B.blotName); return u.insertAt(0, l), u; }), a = this.split(t);
        o.forEach(l => { this.parent.insertBefore(l, a); }), i && this.parent.insertBefore(this.scroll.create("text", i), a);
    }
};
U.scope = b.BLOCK_BLOT;
function Qn(r) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    return r.descendants(j).reduce((e, s) => s.length() === 0 ? e : e.insert(s.value(), st(s, {}, t)), new Xn.default).insert(`
`, st(r));
}
function st(r) { let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, e = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0; return r == null || ("formats" in r && typeof r.formats == "function" && (t = L(L({}, t), r.formats()), e && delete t["code-token"]), r.parent == null || r.parent.statics.blotName === "scroll" || r.parent.statics.scope !== r.statics.scope) ? t : st(r.parent, t, e); }
var Fb = (() => { class r extends q {
    static blotName = "cursor";
    static className = "ql-cursor";
    static tagName = "span";
    static CONTENTS = "\uFEFF";
    static value() { }
    constructor(e, s, n) { super(e, s), this.selection = n, this.textNode = document.createTextNode(r.CONTENTS), this.domNode.appendChild(this.textNode), this.savedLength = 0; }
    detach() { this.parent != null && this.parent.removeChild(this); }
    format(e, s) { if (this.savedLength !== 0) {
        super.format(e, s);
        return;
    } let n = this, i = 0; for (; n != null && n.statics.scope !== b.BLOCK_BLOT;)
        i += n.offset(n.parent), n = n.parent; n != null && (this.savedLength = r.CONTENTS.length, n.optimize(), n.formatAt(i, r.CONTENTS.length, e, s), this.savedLength = 0); }
    index(e, s) { return e === this.textNode ? 0 : super.index(e, s); }
    length() { return this.savedLength; }
    position() { return [this.textNode, this.textNode.data.length]; }
    remove() { super.remove(), this.parent = null; }
    restore() { if (this.selection.composing || this.parent == null)
        return null; let e = this.selection.getNativeRange(); for (; this.domNode.lastChild != null && this.domNode.lastChild !== this.textNode;)
        this.domNode.parentNode.insertBefore(this.domNode.lastChild, this.domNode); let s = this.prev instanceof R ? this.prev : null, n = s ? s.length() : 0, i = this.next instanceof R ? this.next : null, o = i ? i.text : "", { textNode: a } = this, l = a.data.split(r.CONTENTS).join(""); a.data = r.CONTENTS; let u; if (s)
        u = s, (l || i) && (s.insertAt(s.length(), l + o), i && i.remove());
    else if (i)
        u = i, i.insertAt(0, l);
    else {
        let c = document.createTextNode(l);
        u = this.scroll.create(c), this.parent.insertBefore(u, this);
    } if (this.remove(), e) {
        let c = (p, m) => s && p === s.domNode ? m : p === a ? n + m - 1 : i && p === i.domNode ? n + l.length + m : null, f = c(e.start.node, e.start.offset), h = c(e.end.node, e.end.offset);
        if (f !== null && h !== null)
            return { startNode: u.domNode, startOffset: f, endNode: u.domNode, endOffset: h };
    } return null; }
    update(e, s) { if (e.some(n => n.type === "characterData" && n.target === this.textNode)) {
        let n = this.restore();
        n && (s.range = n);
    } }
    optimize(e) { super.optimize(e); let { parent: s } = this; for (; s;) {
        if (s.domNode.tagName === "A") {
            this.savedLength = r.CONTENTS.length, s.isolate(this.offset(s), this.length()).unwrap(), this.savedLength = 0;
            break;
        }
        s = s.parent;
    } }
    value() { return ""; }
} return r; })(), te = Fb;
var Jn = ot(Bu(), 1);
var vr = new WeakMap;
var ti = ["error", "warn", "log", "info"], ei = "warn";
function Mu(r) { if (ei && ti.indexOf(r) <= ti.indexOf(ei)) {
    for (var t = arguments.length, e = new Array(t > 1 ? t - 1 : 0), s = 1; s < t; s++)
        e[s - 1] = arguments[s];
    console[r](...e);
} }
function ri(r) { return ti.reduce((t, e) => (t[e] = Mu.bind(console, e, r), t), {}); }
ri.level = r => { ei = r; };
Mu.level = ri.level;
var ut = ri;
var si = ut("quill:events"), $b = ["selectionchange", "mousedown", "mouseup", "click"];
$b.forEach(r => { document.addEventListener(r, function () { for (var t = arguments.length, e = new Array(t), s = 0; s < t; s++)
    e[s] = arguments[s]; Array.from(document.querySelectorAll(".ql-container")).forEach(n => { let i = vr.get(n); i && i.emitter && i.emitter.handleDOM(...e); }); }); });
var Kb = (() => { class r extends Jn.default {
    static events = { EDITOR_CHANGE: "editor-change", SCROLL_BEFORE_UPDATE: "scroll-before-update", SCROLL_BLOT_MOUNT: "scroll-blot-mount", SCROLL_BLOT_UNMOUNT: "scroll-blot-unmount", SCROLL_OPTIMIZE: "scroll-optimize", SCROLL_UPDATE: "scroll-update", SCROLL_EMBED_UPDATE: "scroll-embed-update", SELECTION_CHANGE: "selection-change", TEXT_CHANGE: "text-change", COMPOSITION_BEFORE_START: "composition-before-start", COMPOSITION_START: "composition-start", COMPOSITION_BEFORE_END: "composition-before-end", COMPOSITION_END: "composition-end" };
    static sources = { API: "api", SILENT: "silent", USER: "user" };
    constructor() { super(), this.domListeners = {}, this.on("error", si.error); }
    emit() { for (var e = arguments.length, s = new Array(e), n = 0; n < e; n++)
        s[n] = arguments[n]; return si.log.call(si, ...s), super.emit(...s); }
    handleDOM(e) { for (var s = arguments.length, n = new Array(s > 1 ? s - 1 : 0), i = 1; i < s; i++)
        n[i - 1] = arguments[i]; (this.domListeners[e.type] || []).forEach(o => { let { node: a, handler: l } = o; (e.target === a || a.contains(e.target)) && l(e, ...n); }); }
    listenDOM(e, s, n) { this.domListeners[e] || (this.domListeners[e] = []), this.domListeners[e].push({ node: s, handler: n }); }
} return r; })(), x = Kb;
var ni = ut("quill:selection"), Q = class {
    constructor(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0; this.index = t, this.length = e; }
}, oi = class {
    constructor(t, e) { this.emitter = e, this.scroll = t, this.composing = !1, this.mouseDown = !1, this.root = this.scroll.domNode, this.cursor = this.scroll.create("cursor", this), this.savedRange = new Q(0, 0), this.lastRange = this.savedRange, this.lastNative = null, this.handleComposition(), this.handleDragging(), this.emitter.listenDOM("selectionchange", document, () => { !this.mouseDown && !this.composing && setTimeout(this.update.bind(this, x.sources.USER), 1); }), this.emitter.on(x.events.SCROLL_BEFORE_UPDATE, () => { if (!this.hasFocus())
        return; let s = this.getNativeRange(); s != null && s.start.node !== this.cursor.textNode && this.emitter.once(x.events.SCROLL_UPDATE, (n, i) => { try {
        this.root.contains(s.start.node) && this.root.contains(s.end.node) && this.setNativeRange(s.start.node, s.start.offset, s.end.node, s.end.offset);
        let o = i.some(a => a.type === "characterData" || a.type === "childList" || a.type === "attributes" && a.target === this.root);
        this.update(o ? x.sources.SILENT : n);
    }
    catch { } }); }), this.emitter.on(x.events.SCROLL_OPTIMIZE, (s, n) => { if (n.range) {
        let { startNode: i, startOffset: o, endNode: a, endOffset: l } = n.range;
        this.setNativeRange(i, o, a, l), this.update(x.sources.SILENT);
    } }), this.update(x.sources.SILENT); }
    handleComposition() { this.emitter.on(x.events.COMPOSITION_BEFORE_START, () => { this.composing = !0; }), this.emitter.on(x.events.COMPOSITION_END, () => { if (this.composing = !1, this.cursor.parent) {
        let t = this.cursor.restore();
        if (!t)
            return;
        setTimeout(() => { this.setNativeRange(t.startNode, t.startOffset, t.endNode, t.endOffset); }, 1);
    } }); }
    handleDragging() { this.emitter.listenDOM("mousedown", document.body, () => { this.mouseDown = !0; }), this.emitter.listenDOM("mouseup", document.body, () => { this.mouseDown = !1, this.update(x.sources.USER); }); }
    focus() { this.hasFocus() || (this.root.focus({ preventScroll: !0 }), this.setRange(this.savedRange)); }
    format(t, e) { this.scroll.update(); let s = this.getNativeRange(); if (!(s == null || !s.native.collapsed || this.scroll.query(t, b.BLOCK))) {
        if (s.start.node !== this.cursor.textNode) {
            let n = this.scroll.find(s.start.node, !1);
            if (n == null)
                return;
            if (n instanceof j) {
                let i = n.split(s.start.offset);
                n.parent.insertBefore(this.cursor, i);
            }
            else
                n.insertBefore(this.cursor, s.start.node);
            this.cursor.attach();
        }
        this.cursor.format(t, e), this.scroll.optimize(), this.setNativeRange(this.cursor.textNode, this.cursor.textNode.data.length), this.update();
    } }
    getBounds(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, s = this.scroll.length(); t = Math.min(t, s - 1), e = Math.min(t + e, s - 1) - t; let n, [i, o] = this.scroll.leaf(t); if (i == null)
        return null; if (e > 0 && o === i.length()) {
        let [c] = this.scroll.leaf(t + 1);
        if (c) {
            let [f] = this.scroll.line(t), [h] = this.scroll.line(t + 1);
            f === h && (i = c, o = 0);
        }
    } [n, o] = i.position(o, !0); let a = document.createRange(); if (e > 0)
        return a.setStart(n, o), [i, o] = this.scroll.leaf(t + e), i == null ? null : ([n, o] = i.position(o, !0), a.setEnd(n, o), a.getBoundingClientRect()); let l = "left", u; if (n instanceof Text) {
        if (!n.data.length)
            return null;
        o < n.data.length ? (a.setStart(n, o), a.setEnd(n, o + 1)) : (a.setStart(n, o - 1), a.setEnd(n, o), l = "right"), u = a.getBoundingClientRect();
    }
    else {
        if (!(i.domNode instanceof Element))
            return null;
        u = i.domNode.getBoundingClientRect(), o > 0 && (l = "right");
    } return { bottom: u.top + u.height, height: u.height, left: u[l], right: u[l], top: u.top, width: 0 }; }
    getNativeRange() { let t = document.getSelection(); if (t == null || t.rangeCount <= 0)
        return null; let e = t.getRangeAt(0); if (e == null)
        return null; let s = this.normalizeNative(e); return ni.info("getNativeRange", s), s; }
    getRange() { let t = this.scroll.domNode; if ("isConnected" in t && !t.isConnected)
        return [null, null]; let e = this.getNativeRange(); return e == null ? [null, null] : [this.normalizedToRange(e), e]; }
    hasFocus() { return document.activeElement === this.root || document.activeElement != null && ii(this.root, document.activeElement); }
    normalizedToRange(t) { let e = [[t.start.node, t.start.offset]]; t.native.collapsed || e.push([t.end.node, t.end.offset]); let s = e.map(o => { let [a, l] = o, u = this.scroll.find(a, !0), c = u.offset(this.scroll); return l === 0 ? c : u instanceof j ? c + u.index(a, l) : c + u.length(); }), n = Math.min(Math.max(...s), this.scroll.length() - 1), i = Math.min(n, ...s); return new Q(i, n - i); }
    normalizeNative(t) { if (!ii(this.root, t.startContainer) || !t.collapsed && !ii(this.root, t.endContainer))
        return null; let e = { start: { node: t.startContainer, offset: t.startOffset }, end: { node: t.endContainer, offset: t.endOffset }, native: t }; return [e.start, e.end].forEach(s => { let { node: n, offset: i } = s; for (; !(n instanceof Text) && n.childNodes.length > 0;)
        if (n.childNodes.length > i)
            n = n.childNodes[i], i = 0;
        else if (n.childNodes.length === i)
            n = n.lastChild, n instanceof Text ? i = n.data.length : n.childNodes.length > 0 ? i = n.childNodes.length : i = n.childNodes.length + 1;
        else
            break; s.node = n, s.offset = i; }), e; }
    rangeToNative(t) { let e = this.scroll.length(), s = (n, i) => { n = Math.min(e - 1, n); let [o, a] = this.scroll.leaf(n); return o ? o.position(a, i) : [null, -1]; }; return [...s(t.index, !1), ...s(t.index + t.length, !0)]; }
    setNativeRange(t, e) { let s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : t, n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : e, i = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1; if (ni.info("setNativeRange", t, e, s, n), t != null && (this.root.parentNode == null || t.parentNode == null || s.parentNode == null))
        return; let o = document.getSelection(); if (o != null)
        if (t != null) {
            this.hasFocus() || this.root.focus({ preventScroll: !0 });
            let { native: a } = this.getNativeRange() || {};
            if (a == null || i || t !== a.startContainer || e !== a.startOffset || s !== a.endContainer || n !== a.endOffset) {
                t instanceof Element && t.tagName === "BR" && (e = Array.from(t.parentNode.childNodes).indexOf(t), t = t.parentNode), s instanceof Element && s.tagName === "BR" && (n = Array.from(s.parentNode.childNodes).indexOf(s), s = s.parentNode);
                let l = document.createRange();
                l.setStart(t, e), l.setEnd(s, n), o.removeAllRanges(), o.addRange(l);
            }
        }
        else
            o.removeAllRanges(), this.root.blur(); }
    setRange(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : x.sources.API; if (typeof e == "string" && (s = e, e = !1), ni.info("setRange", t), t != null) {
        let n = this.rangeToNative(t);
        this.setNativeRange(...n, e);
    }
    else
        this.setNativeRange(null); this.update(s); }
    update() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : x.sources.USER, e = this.lastRange, [s, n] = this.getRange(); if (this.lastRange = s, this.lastNative = n, this.lastRange != null && (this.savedRange = this.lastRange), !le(e, this.lastRange)) {
        if (!this.composing && n != null && n.native.collapsed && n.start.node !== this.cursor.textNode) {
            let o = this.cursor.restore();
            o && this.setNativeRange(o.startNode, o.startOffset, o.endNode, o.endOffset);
        }
        let i = [x.events.SELECTION_CHANGE, At(this.lastRange), At(e), t];
        this.emitter.emit(x.events.EDITOR_CHANGE, ...i), t !== x.sources.SILENT && this.emitter.emit(...i);
    } }
};
function ii(r, t) { try {
    t.parentNode;
}
catch {
    return !1;
} return r.contains(t); }
var Du = oi;
var Gb = /^[ -~]*$/, li = class {
    constructor(t) { this.scroll = t, this.delta = this.getDelta(); }
    applyDelta(t) {
        this.scroll.update();
        let e = this.scroll.length();
        this.scroll.batchStart();
        let s = ju(t), n = new I.default;
        return Wb(s.ops.slice()).reduce((o, a) => {
            let l = I.Op.length(a), u = a.attributes || {}, c = !1, f = !1;
            if (a.insert != null) {
                if (n.retain(l), typeof a.insert == "string") {
                    let m = a.insert;
                    f = !m.endsWith(`
`) && (e <= o || !!this.scroll.descendant(U, o)[0]), this.scroll.insertAt(o, m);
                    let [y, v] = this.scroll.line(o), g = tt({}, st(y));
                    if (y instanceof B) {
                        let [A] = y.descendant(j, v);
                        A && (g = tt(g, st(A)));
                    }
                    u = I.AttributeMap.diff(g, u) || {};
                }
                else if (typeof a.insert == "object") {
                    let m = Object.keys(a.insert)[0];
                    if (m == null)
                        return o;
                    let y = this.scroll.query(m, b.INLINE) != null;
                    if (y)
                        (e <= o || this.scroll.descendant(U, o)[0]) && (f = !0);
                    else if (o > 0) {
                        let [v, g] = this.scroll.descendant(j, o - 1);
                        v instanceof R ? v.value()[g] !== `
` && (c = !0) : v instanceof q && v.statics.scope === b.INLINE_BLOT && (c = !0);
                    }
                    if (this.scroll.insertAt(o, m, a.insert[m]), y) {
                        let [v] = this.scroll.descendant(j, o);
                        if (v) {
                            let g = tt({}, st(v));
                            u = I.AttributeMap.diff(g, u) || {};
                        }
                    }
                }
                e += l;
            }
            else if (n.push(a), a.retain !== null && typeof a.retain == "object") {
                let m = Object.keys(a.retain)[0];
                if (m == null)
                    return o;
                this.scroll.updateEmbedAt(o, m, a.retain[m]);
            }
            Object.keys(u).forEach(m => { this.scroll.formatAt(o, l, m, u[m]); });
            let h = c ? 1 : 0, p = f ? 1 : 0;
            return e += h + p, n.retain(h), n.delete(p), o + l + h + p;
        }, 0), n.reduce((o, a) => typeof a.delete == "number" ? (this.scroll.deleteAt(o, a.delete), o) : o + I.Op.length(a), 0), this.scroll.batchEnd(), this.scroll.optimize(), this.update(s);
    }
    deleteText(t, e) { return this.scroll.deleteAt(t, e), this.update(new I.default().retain(t).delete(e)); }
    formatLine(t, e) { let s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}; this.scroll.update(), Object.keys(s).forEach(i => { this.scroll.lines(t, Math.max(e, 1)).forEach(o => { o.format(i, s[i]); }); }), this.scroll.optimize(); let n = new I.default().retain(t).retain(e, At(s)); return this.update(n); }
    formatText(t, e) { let s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}; Object.keys(s).forEach(i => { this.scroll.formatAt(t, e, i, s[i]); }); let n = new I.default().retain(t).retain(e, At(s)); return this.update(n); }
    getContents(t, e) { return this.delta.slice(t, t + e); }
    getDelta() { return this.scroll.lines().reduce((t, e) => t.concat(e.delta()), new I.default); }
    getFormat(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, s = [], n = []; e === 0 ? this.scroll.path(t).forEach(a => { let [l] = a; l instanceof B ? s.push(l) : l instanceof j && n.push(l); }) : (s = this.scroll.lines(t, e), n = this.scroll.descendants(j, t, e)); let [i, o] = [s, n].map(a => { let l = a.shift(); if (l == null)
        return {}; let u = st(l); for (; Object.keys(u).length > 0;) {
        let c = a.shift();
        if (c == null)
            return u;
        u = Vb(st(c), u);
    } return u; }); return L(L({}, i), o); }
    getHTML(t, e) { let [s, n] = this.scroll.line(t); if (s) {
        let i = s.length();
        return s.length() >= n + e && !(n === 0 && e === i) ? Ar(s, n, e, !0) : Ar(this.scroll, t, e, !0);
    } return ""; }
    getText(t, e) { return this.getContents(t, e).filter(s => typeof s.insert == "string").map(s => s.insert).join(""); }
    insertContents(t, e) { let s = ju(e), n = new I.default().retain(t).concat(s); return this.scroll.insertContents(t, s), this.update(n); }
    insertEmbed(t, e, s) { return this.scroll.insertAt(t, e, s), this.update(new I.default().retain(t).insert({ [e]: s })); }
    insertText(t, e) {
        let s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
        return e = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`), this.scroll.insertAt(t, e), Object.keys(s).forEach(n => { this.scroll.formatAt(t, e.length, n, s[n]); }), this.update(new I.default().retain(t).insert(e, At(s)));
    }
    isBlank() { if (this.scroll.children.length === 0)
        return !0; if (this.scroll.children.length > 1)
        return !1; let t = this.scroll.children.head; if (t?.statics.blotName !== B.blotName)
        return !1; let e = t; return e.children.length > 1 ? !1 : e.children.head instanceof $; }
    removeFormat(t, e) {
        let s = this.getText(t, e), [n, i] = this.scroll.line(t + e), o = 0, a = new I.default;
        n != null && (o = n.length() - i, a = n.delta().slice(i, i + o - 1).insert(`
`));
        let u = this.getContents(t, e + o).diff(new I.default().insert(s).concat(a)), c = new I.default().retain(t).concat(u);
        return this.applyDelta(c);
    }
    update(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [], s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0, n = this.delta; if (e.length === 1 && e[0].type === "characterData" && e[0].target.data.match(Gb) && this.scroll.find(e[0].target)) {
        let i = this.scroll.find(e[0].target), o = st(i), a = i.offset(this.scroll), l = e[0].oldValue.replace(te.CONTENTS, ""), u = new I.default().insert(l), c = new I.default().insert(i.value()), f = s && { oldRange: Pu(s.oldRange, -a), newRange: Pu(s.newRange, -a) };
        t = new I.default().retain(a).concat(u.diff(c, f)).reduce((p, m) => m.insert ? p.insert(m.insert, o) : p.push(m), new I.default), this.delta = n.compose(t);
    }
    else
        this.delta = this.getDelta(), (!t || !le(n.compose(t), this.delta)) && (t = n.diff(this.delta, s)); return t; }
};
function Ze(r, t, e) { if (r.length === 0) {
    let [p] = ai(e.pop());
    return t <= 0 ? `</li></${p}>` : `</li></${p}>${Ze([], t - 1, e)}`;
} let [{ child: s, offset: n, length: i, indent: o, type: a }, ...l] = r, [u, c] = ai(a); if (o > t)
    return e.push(a), o === t + 1 ? `<${u}><li${c}>${Ar(s, n, i)}${Ze(l, o, e)}` : `<${u}><li>${Ze(r, t + 1, e)}`; let f = e[e.length - 1]; if (o === t && a === f)
    return `</li><li${c}>${Ar(s, n, i)}${Ze(l, o, e)}`; let [h] = ai(e.pop()); return `</li></${h}>${Ze(r, t - 1, e)}`; }
function Ar(r, t, e) { let s = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1; if ("html" in r && typeof r.html == "function")
    return r.html(t, e); if (r instanceof R)
    return ye(r.value().slice(t, t + e)).replaceAll(" ", "&nbsp;"); if (r instanceof et) {
    if (r.statics.blotName === "list-container") {
        let u = [];
        return r.children.forEachAt(t, e, (c, f, h) => { let p = "formats" in c && typeof c.formats == "function" ? c.formats() : {}; u.push({ child: c, offset: f, length: h, indent: p.indent || 0, type: p.list }); }), Ze(u, -1, []);
    }
    let n = [];
    if (r.children.forEachAt(t, e, (u, c, f) => { n.push(Ar(u, c, f)); }), s || r.statics.blotName === "list")
        return n.join("");
    let { outerHTML: i, innerHTML: o } = r.domNode, [a, l] = i.split(`>${o}<`);
    return a === "<table" ? `<table style="border: 1px solid #000;">${n.join("")}<${l}` : `${a}>${n.join("")}<${l}`;
} return r.domNode instanceof Element ? r.domNode.outerHTML : ""; }
function Vb(r, t) { return Object.keys(t).reduce((e, s) => { if (r[s] == null)
    return e; let n = t[s]; return n === r[s] ? e[s] = n : Array.isArray(n) ? n.indexOf(r[s]) < 0 ? e[s] = n.concat([r[s]]) : e[s] = n : e[s] = [n, r[s]], e; }, {}); }
function ai(r) { let t = r === "ordered" ? "ol" : "ul"; switch (r) {
    case "checked": return [t, ' data-list="checked"'];
    case "unchecked": return [t, ' data-list="unchecked"'];
    default: return [t, ""];
} }
function ju(r) {
    return r.reduce((t, e) => {
        if (typeof e.insert == "string") {
            let s = e.insert.replace(/\r\n/g, `
`).replace(/\r/g, `
`);
            return t.insert(s, e.attributes);
        }
        return t.push(e);
    }, new I.default);
}
function Pu(r, t) { let { index: e, length: s } = r; return new Q(e + t, s); }
function Wb(r) {
    let t = [];
    return r.forEach(e => {
        typeof e.insert == "string" ? e.insert.split(`
`).forEach((n, i) => {
            i && t.push({ insert: `
`, attributes: e.attributes }), n && t.push({ insert: n, attributes: e.attributes });
        }) : t.push(e);
    }), t;
}
var Uu = li;
var Zb = (() => { class r {
    static DEFAULTS = {};
    constructor(e) { let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}; this.quill = e, this.options = s; }
} return r; })(), k = Zb;
var Cs = "\uFEFF", ui = class extends q {
    constructor(t, e) { super(t, e), this.contentNode = document.createElement("span"), this.contentNode.setAttribute("contenteditable", "false"), Array.from(this.domNode.childNodes).forEach(s => { this.contentNode.appendChild(s); }), this.leftGuard = document.createTextNode(Cs), this.rightGuard = document.createTextNode(Cs), this.domNode.appendChild(this.leftGuard), this.domNode.appendChild(this.contentNode), this.domNode.appendChild(this.rightGuard); }
    index(t, e) { return t === this.leftGuard ? 0 : t === this.rightGuard ? 1 : super.index(t, e); }
    restore(t) { let e = null, s, n = t.data.split(Cs).join(""); if (t === this.leftGuard)
        if (this.prev instanceof R) {
            let i = this.prev.length();
            this.prev.insertAt(i, n), e = { startNode: this.prev.domNode, startOffset: i + n.length };
        }
        else
            s = document.createTextNode(n), this.parent.insertBefore(this.scroll.create(s), this), e = { startNode: s, startOffset: n.length };
    else
        t === this.rightGuard && (this.next instanceof R ? (this.next.insertAt(0, n), e = { startNode: this.next.domNode, startOffset: n.length }) : (s = document.createTextNode(n), this.parent.insertBefore(this.scroll.create(s), this.next), e = { startNode: s, startOffset: n.length })); return t.data = Cs, e; }
    update(t, e) { t.forEach(s => { if (s.type === "characterData" && (s.target === this.leftGuard || s.target === this.rightGuard)) {
        let n = this.restore(s.target);
        n && (e.range = n);
    } }); }
}, Xe = ui;
var ci = class {
    isComposing = !1;
    constructor(t, e) { this.scroll = t, this.emitter = e, this.setupListeners(); }
    setupListeners() { this.scroll.domNode.addEventListener("compositionstart", t => { this.isComposing || this.handleCompositionStart(t); }), this.scroll.domNode.addEventListener("compositionend", t => { this.isComposing && queueMicrotask(() => { this.handleCompositionEnd(t); }); }); }
    handleCompositionStart(t) { let e = t.target instanceof Node ? this.scroll.find(t.target, !0) : null; e && !(e instanceof Xe) && (this.emitter.emit(x.events.COMPOSITION_BEFORE_START, t), this.scroll.batchStart(), this.emitter.emit(x.events.COMPOSITION_START, t), this.isComposing = !0); }
    handleCompositionEnd(t) { this.emitter.emit(x.events.COMPOSITION_BEFORE_END, t), this.scroll.batchEnd(), this.emitter.emit(x.events.COMPOSITION_END, t), this.isComposing = !1; }
}, Fu = ci;
var Xb = (() => { class r {
    static DEFAULTS = { modules: {} };
    static themes = { default: r };
    modules = {};
    constructor(e, s) { this.quill = e, this.options = s; }
    init() { Object.keys(this.options.modules).forEach(e => { this.modules[e] == null && this.addModule(e); }); }
    addModule(e) { let s = this.quill.constructor.import(`modules/${e}`); return this.modules[e] = new s(this.quill, this.options.modules[e] || {}), this.modules[e]; }
} return r; })(), Qe = Xb;
var Qb = r => r.parentElement || r.getRootNode().host || null, Yb = r => { let t = r.getBoundingClientRect(), e = "offsetWidth" in r && Math.abs(t.width) / r.offsetWidth || 1, s = "offsetHeight" in r && Math.abs(t.height) / r.offsetHeight || 1; return { top: t.top, right: t.left + r.clientWidth * e, bottom: t.top + r.clientHeight * s, left: t.left }; }, _s = r => { let t = parseInt(r, 10); return Number.isNaN(t) ? 0 : t; }, Hu = (r, t, e, s, n, i) => r < e && t > s ? 0 : r < e ? -(e - r + n) : t > s ? t - r > s - e ? r + n - e : t - s + i : 0, Jb = (r, t) => { let e = r.ownerDocument, s = t, n = r; for (; n;) {
    let i = n === e.body, o = i ? { top: 0, right: window.visualViewport?.width ?? e.documentElement.clientWidth, bottom: window.visualViewport?.height ?? e.documentElement.clientHeight, left: 0 } : Yb(n), a = getComputedStyle(n), l = Hu(s.left, s.right, o.left, o.right, _s(a.scrollPaddingLeft), _s(a.scrollPaddingRight)), u = Hu(s.top, s.bottom, o.top, o.bottom, _s(a.scrollPaddingTop), _s(a.scrollPaddingBottom));
    if (l || u)
        if (i)
            e.defaultView?.scrollBy(l, u);
        else {
            let { scrollLeft: c, scrollTop: f } = n;
            u && (n.scrollTop += u), l && (n.scrollLeft += l);
            let h = n.scrollLeft - c, p = n.scrollTop - f;
            s = { left: s.left - h, top: s.top - p, right: s.right - h, bottom: s.bottom - p };
        }
    n = i || a.position === "fixed" ? null : Qb(n);
} }, zu = Jb;
var ty = 100, ey = ["block", "break", "cursor", "inline", "scroll", "text"], ry = (r, t, e) => { let s = new Xt; return ey.forEach(n => { let i = t.query(n); i && s.register(i); }), r.forEach(n => { let i = t.query(n); i || e.error(`Cannot register "${n}" specified in "formats" config. Are you sure it was registered?`); let o = 0; for (; i;)
    if (s.register(i), i = "blotName" in i ? i.requiredContainer ?? null : null, o += 1, o > ty) {
        e.error(`Cycle detected in registering blot requiredContainer: "${n}"`);
        break;
    } }), s; }, $u = ry;
var Ye = ut("quill"), qs = new Xt;
et.uiClass = "ql-ui";
var d = class r {
    static DEFAULTS = { bounds: null, modules: { clipboard: !0, keyboard: !0, history: !0, uploader: !0 }, placeholder: "", readOnly: !1, registry: qs, theme: "default" };
    static events = x.events;
    static sources = x.sources;
    static version = "2.0.3";
    static imports = { delta: ee.default, parchment: ur, "core/module": k, "core/theme": Qe };
    static debug(t) { t === !0 && (t = "log"), ut.level(t); }
    static find(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1; return vr.get(t) || qs.find(t, e); }
    static import(t) { return this.imports[t] == null && Ye.error(`Cannot import ${t}. Are you sure it was registered?`), this.imports[t]; }
    static register() { if (typeof (arguments.length <= 0 ? void 0 : arguments[0]) != "string") {
        let t = arguments.length <= 0 ? void 0 : arguments[0], e = !!(!(arguments.length <= 1) && arguments[1]), s = "attrName" in t ? t.attrName : t.blotName;
        typeof s == "string" ? this.register(`formats/${s}`, t, e) : Object.keys(t).forEach(n => { this.register(n, t[n], e); });
    }
    else {
        let t = arguments.length <= 0 ? void 0 : arguments[0], e = arguments.length <= 1 ? void 0 : arguments[1], s = !!(!(arguments.length <= 2) && arguments[2]);
        this.imports[t] != null && !s && Ye.warn(`Overwriting ${t} with`, e), this.imports[t] = e, (t.startsWith("blots/") || t.startsWith("formats/")) && e && typeof e != "boolean" && e.blotName !== "abstract" && qs.register(e), typeof e.register == "function" && e.register(qs);
    } }
    constructor(t) {
        let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        if (this.options = sy(t, e), this.container = this.options.container, this.container == null) {
            Ye.error("Invalid Quill container", t);
            return;
        }
        this.options.debug && r.debug(this.options.debug);
        let s = this.container.innerHTML.trim();
        this.container.classList.add("ql-container"), this.container.innerHTML = "", vr.set(this.container, this), this.root = this.addContainer("ql-editor"), this.root.classList.add("ql-blank"), this.emitter = new x;
        let n = lr.blotName, i = this.options.registry.query(n);
        if (!i || !("blotName" in i))
            throw new Error(`Cannot initialize Quill without "${n}" blot`);
        if (this.scroll = new i(this.options.registry, this.root, { emitter: this.emitter }), this.editor = new Uu(this.scroll), this.selection = new Du(this.scroll, this.emitter), this.composition = new Fu(this.scroll, this.emitter), this.theme = new this.options.theme(this, this.options), this.keyboard = this.theme.addModule("keyboard"), this.clipboard = this.theme.addModule("clipboard"), this.history = this.theme.addModule("history"), this.uploader = this.theme.addModule("uploader"), this.theme.addModule("input"), this.theme.addModule("uiNode"), this.theme.init(), this.emitter.on(x.events.EDITOR_CHANGE, o => { o === x.events.TEXT_CHANGE && this.root.classList.toggle("ql-blank", this.editor.isBlank()); }), this.emitter.on(x.events.SCROLL_UPDATE, (o, a) => { let l = this.selection.lastRange, [u] = this.selection.getRange(), c = l && u ? { oldRange: l, newRange: u } : void 0; bt.call(this, () => this.editor.update(null, a, c), o); }), this.emitter.on(x.events.SCROLL_EMBED_UPDATE, (o, a) => { let l = this.selection.lastRange, [u] = this.selection.getRange(), c = l && u ? { oldRange: l, newRange: u } : void 0; bt.call(this, () => { let f = new ee.default().retain(o.offset(this)).retain({ [o.statics.blotName]: a }); return this.editor.update(f, [], c); }, r.sources.USER); }), s) {
            let o = this.clipboard.convert({ html: `${s}<p><br></p>`, text: `
` });
            this.setContents(o);
        }
        this.history.clear(), this.options.placeholder && this.root.setAttribute("data-placeholder", this.options.placeholder), this.options.readOnly && this.disable(), this.allowReadOnlyEdits = !1;
    }
    addContainer(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null; if (typeof t == "string") {
        let s = t;
        t = document.createElement("div"), t.classList.add(s);
    } return this.container.insertBefore(t, e), t; }
    blur() { this.selection.setRange(null); }
    deleteText(t, e, s) { return [t, e, , s] = Dt(t, e, s), bt.call(this, () => this.editor.deleteText(t, e), s, t, -1 * e); }
    disable() { this.enable(!1); }
    editReadOnly(t) { this.allowReadOnlyEdits = !0; let e = t(); return this.allowReadOnlyEdits = !1, e; }
    enable() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0; this.scroll.enable(t), this.container.classList.toggle("ql-disabled", !t); }
    focus() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}; this.selection.focus(), t.preventScroll || this.scrollSelectionIntoView(); }
    format(t, e) { let s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : x.sources.API; return bt.call(this, () => { let n = this.getSelection(!0), i = new ee.default; if (n == null)
        return i; if (this.scroll.query(t, b.BLOCK))
        i = this.editor.formatLine(n.index, n.length, { [t]: e });
    else {
        if (n.length === 0)
            return this.selection.format(t, e), i;
        i = this.editor.formatText(n.index, n.length, { [t]: e });
    } return this.setSelection(n, x.sources.SILENT), i; }, s); }
    formatLine(t, e, s, n, i) { let o; return [t, e, o, i] = Dt(t, e, s, n, i), bt.call(this, () => this.editor.formatLine(t, e, o), i, t, 0); }
    formatText(t, e, s, n, i) { let o; return [t, e, o, i] = Dt(t, e, s, n, i), bt.call(this, () => this.editor.formatText(t, e, o), i, t, 0); }
    getBounds(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, s = null; if (typeof t == "number" ? s = this.selection.getBounds(t, e) : s = this.selection.getBounds(t.index, t.length), !s)
        return null; let n = this.container.getBoundingClientRect(); return { bottom: s.bottom - n.top, height: s.height, left: s.left - n.left, right: s.right - n.left, top: s.top - n.top, width: s.width }; }
    getContents() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0, e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.getLength() - t; return [t, e] = Dt(t, e), this.editor.getContents(t, e); }
    getFormat() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.getSelection(!0), e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0; return typeof t == "number" ? this.editor.getFormat(t, e) : this.editor.getFormat(t.index, t.length); }
    getIndex(t) { return t.offset(this.scroll); }
    getLength() { return this.scroll.length(); }
    getLeaf(t) { return this.scroll.leaf(t); }
    getLine(t) { return this.scroll.line(t); }
    getLines() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0, e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : Number.MAX_VALUE; return typeof t != "number" ? this.scroll.lines(t.index, t.length) : this.scroll.lines(t, e); }
    getModule(t) { return this.theme.modules[t]; }
    getSelection() { return (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1) && this.focus(), this.update(), this.selection.getRange()[0]; }
    getSemanticHTML() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0, e = arguments.length > 1 ? arguments[1] : void 0; return typeof t == "number" && (e = e ?? this.getLength() - t), [t, e] = Dt(t, e), this.editor.getHTML(t, e); }
    getText() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0, e = arguments.length > 1 ? arguments[1] : void 0; return typeof t == "number" && (e = e ?? this.getLength() - t), [t, e] = Dt(t, e), this.editor.getText(t, e); }
    hasFocus() { return this.selection.hasFocus(); }
    insertEmbed(t, e, s) { let n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : r.sources.API; return bt.call(this, () => this.editor.insertEmbed(t, e, s), n, t); }
    insertText(t, e, s, n, i) { let o; return [t, , o, i] = Dt(t, 0, s, n, i), bt.call(this, () => this.editor.insertText(t, e, o), i, t, e.length); }
    isEnabled() { return this.scroll.isEnabled(); }
    off() { return this.emitter.off(...arguments); }
    on() { return this.emitter.on(...arguments); }
    once() { return this.emitter.once(...arguments); }
    removeFormat(t, e, s) { return [t, e, , s] = Dt(t, e, s), bt.call(this, () => this.editor.removeFormat(t, e), s, t); }
    scrollRectIntoView(t) { zu(this.root, t); }
    scrollIntoView() { console.warn("Quill#scrollIntoView() has been deprecated and will be removed in the near future. Please use Quill#scrollSelectionIntoView() instead."), this.scrollSelectionIntoView(); }
    scrollSelectionIntoView() { let t = this.selection.lastRange, e = t && this.selection.getBounds(t.index, t.length); e && this.scrollRectIntoView(e); }
    setContents(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : x.sources.API; return bt.call(this, () => { t = new ee.default(t); let s = this.getLength(), n = this.editor.deleteText(0, s), i = this.editor.insertContents(0, t), o = this.editor.deleteText(this.getLength() - 1, 1); return n.compose(i).compose(o); }, e); }
    setSelection(t, e, s) { t == null ? this.selection.setRange(null, e || r.sources.API) : ([t, e, , s] = Dt(t, e, s), this.selection.setRange(new Q(Math.max(0, t), e), s), s !== x.sources.SILENT && this.scrollSelectionIntoView()); }
    setText(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : x.sources.API, s = new ee.default().insert(t); return this.setContents(s, e); }
    update() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : x.sources.USER, e = this.scroll.update(t); return this.selection.update(t), e; }
    updateContents(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : x.sources.API; return bt.call(this, () => (t = new ee.default(t), this.editor.applyDelta(t)), e, !0); }
};
function Ku(r) { return typeof r == "string" ? document.querySelector(r) : r; }
function fi(r) { return Object.entries(r ?? {}).reduce((t, e) => { let [s, n] = e; return Ut(L({}, t), { [s]: n === !0 ? {} : n }); }, {}); }
function Gu(r) { return Object.fromEntries(Object.entries(r).filter(t => t[1] !== void 0)); }
function sy(r, t) { let e = Ku(r); if (!e)
    throw new Error("Invalid Quill container"); let n = !t.theme || t.theme === d.DEFAULTS.theme ? Qe : d.import(`themes/${t.theme}`); if (!n)
    throw new Error(`Invalid theme ${t.theme}. Did you register it?`); let p = d.DEFAULTS, { modules: i } = p, o = Xs(p, ["modules"]), m = n.DEFAULTS, { modules: a } = m, l = Xs(m, ["modules"]), u = fi(t.modules); u != null && u.toolbar && u.toolbar.constructor !== Object && (u = Ut(L({}, u), { toolbar: { container: u.toolbar } })); let c = tt({}, fi(i), fi(a), u), f = L(L(L({}, o), Gu(l)), Gu(t)), h = t.registry; return h ? t.formats && Ye.warn('Ignoring "formats" option because "registry" is specified') : h = t.formats ? $u(t.formats, f.registry, Ye) : f.registry, Ut(L({}, f), { registry: h, container: e, theme: n, modules: Object.entries(c).reduce((y, v) => { let [g, A] = v; if (!A)
        return y; let E = d.import(`modules/${g}`); return E == null ? (Ye.error(`Cannot load ${g} module. Are you sure you registered it?`), y) : Ut(L({}, y), { [g]: tt({}, E.DEFAULTS || {}, A) }); }, {}), bounds: Ku(f.bounds) }); }
function bt(r, t, e, s) { if (!this.isEnabled() && t === x.sources.USER && !this.allowReadOnlyEdits)
    return new ee.default; let n = e == null ? null : this.getSelection(), i = this.editor.delta, o = r(); if (n != null && (e === !0 && (e = n.index), s == null ? n = Vu(n, o, t) : s !== 0 && (n = Vu(n, e, s, t)), this.setSelection(n, x.sources.SILENT)), o.length() > 0) {
    let a = [x.events.TEXT_CHANGE, o, i, t];
    this.emitter.emit(x.events.EDITOR_CHANGE, ...a), t !== x.sources.SILENT && this.emitter.emit(...a);
} return o; }
function Dt(r, t, e, s, n) { let i = {}; return typeof r.index == "number" && typeof r.length == "number" ? typeof t != "number" ? (n = s, s = e, e = t, t = r.length, r = r.index) : (t = r.length, r = r.index) : typeof t != "number" && (n = s, s = e, e = t, t = 0), typeof e == "object" ? (i = e, n = s) : typeof e == "string" && (s != null ? i[e] = s : n = e), n = n || x.sources.API, [r, t, i, n]; }
function Vu(r, t, e, s) { let n = typeof e == "number" ? e : 0; if (r == null)
    return null; let i, o; return t && typeof t.transformPosition == "function" ? [i, o] = [r.index, r.index + r.length].map(a => t.transformPosition(a, s !== x.sources.USER)) : [i, o] = [r.index, r.index + r.length].map(a => a < t || a === t && s === x.sources.USER ? a : n >= 0 ? a + n : Math.max(t, a + n)), new Q(i, o - i); }
var hi = class extends Ue {
}, dt = hi;
var pt = ot(lt(), 1);
function Wu(r) { return r instanceof B || r instanceof U; }
function Zu(r) { return typeof r.updateContent == "function"; }
var ny = (() => {
    class r extends lr {
        static blotName = "scroll";
        static className = "ql-editor";
        static tagName = "DIV";
        static defaultChild = B;
        static allowedChildren = [B, U, dt];
        constructor(e, s, n) { let { emitter: i } = n; super(e, s), this.emitter = i, this.batch = !1, this.optimize(), this.enable(), this.domNode.addEventListener("dragstart", o => this.handleDragStart(o)); }
        batchStart() { Array.isArray(this.batch) || (this.batch = []); }
        batchEnd() { if (!this.batch)
            return; let e = this.batch; this.batch = !1, this.update(e); }
        emitMount(e) { this.emitter.emit(x.events.SCROLL_BLOT_MOUNT, e); }
        emitUnmount(e) { this.emitter.emit(x.events.SCROLL_BLOT_UNMOUNT, e); }
        emitEmbedUpdate(e, s) { this.emitter.emit(x.events.SCROLL_EMBED_UPDATE, e, s); }
        deleteAt(e, s) { let [n, i] = this.line(e), [o] = this.line(e + s); if (super.deleteAt(e, s), o != null && n !== o && i > 0) {
            if (n instanceof U || o instanceof U) {
                this.optimize();
                return;
            }
            let a = o.children.head instanceof $ ? null : o.children.head;
            n.moveChildren(o, a), n.remove();
        } this.optimize(); }
        enable() { let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0; this.domNode.setAttribute("contenteditable", e ? "true" : "false"); }
        formatAt(e, s, n, i) { super.formatAt(e, s, n, i), this.optimize(); }
        insertAt(e, s, n) {
            if (e >= this.length())
                if (n == null || this.scroll.query(s, b.BLOCK) == null) {
                    let i = this.scroll.create(this.statics.defaultChild.blotName);
                    this.appendChild(i), n == null && s.endsWith(`
`) ? i.insertAt(0, s.slice(0, -1), n) : i.insertAt(0, s, n);
                }
                else {
                    let i = this.scroll.create(s, n);
                    this.appendChild(i);
                }
            else
                super.insertAt(e, s, n);
            this.optimize();
        }
        insertBefore(e, s) { if (e.statics.scope === b.INLINE_BLOT) {
            let n = this.scroll.create(this.statics.defaultChild.blotName);
            n.appendChild(e), super.insertBefore(n, s);
        }
        else
            super.insertBefore(e, s); }
        insertContents(e, s) {
            let n = this.deltaToRenderBlocks(s.concat(new pt.default().insert(`
`))), i = n.pop();
            if (i == null)
                return;
            this.batchStart();
            let o = n.shift();
            if (o) {
                let u = o.type === "block" && (o.delta.length() === 0 || !this.descendant(U, e)[0] && e < this.length()), c = o.type === "block" ? o.delta : new pt.default().insert({ [o.key]: o.value });
                di(this, e, c);
                let f = o.type === "block" ? 1 : 0, h = e + c.length() + f;
                u && this.insertAt(h - 1, `
`);
                let p = st(this.line(e)[0]), m = pt.AttributeMap.diff(p, o.attributes) || {};
                Object.keys(m).forEach(y => { this.formatAt(h - 1, 1, y, m[y]); }), e = h;
            }
            let [a, l] = this.children.find(e);
            if (n.length && (a && (a = a.split(l), l = 0), n.forEach(u => { if (u.type === "block") {
                let c = this.createBlock(u.attributes, a || void 0);
                di(c, 0, u.delta);
            }
            else {
                let c = this.create(u.key, u.value);
                this.insertBefore(c, a || void 0), Object.keys(u.attributes).forEach(f => { c.format(f, u.attributes[f]); });
            } })), i.type === "block" && i.delta.length()) {
                let u = a ? a.offset(a.scroll) + l : this.length();
                di(this, u, i.delta);
            }
            this.batchEnd(), this.optimize();
        }
        isEnabled() { return this.domNode.getAttribute("contenteditable") === "true"; }
        leaf(e) { let s = this.path(e).pop(); if (!s)
            return [null, -1]; let [n, i] = s; return n instanceof j ? [n, i] : [null, -1]; }
        line(e) { return e === this.length() ? this.line(e - 1) : this.descendant(Wu, e); }
        lines() { let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0, s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : Number.MAX_VALUE, n = (i, o, a) => { let l = [], u = a; return i.children.forEachAt(o, a, (c, f, h) => { Wu(c) ? l.push(c) : c instanceof Ue && (l = l.concat(n(c, f, u))), u -= h; }), l; }; return n(this, e, s); }
        optimize() { let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}; this.batch || (super.optimize(e, s), e.length > 0 && this.emitter.emit(x.events.SCROLL_OPTIMIZE, e, s)); }
        path(e) { return super.path(e).slice(1); }
        remove() { }
        update(e) { if (this.batch) {
            Array.isArray(e) && (this.batch = this.batch.concat(e));
            return;
        } let s = x.sources.USER; typeof e == "string" && (s = e), Array.isArray(e) || (e = this.observer.takeRecords()), e = e.filter(n => { let { target: i } = n, o = this.find(i, !0); return o && !Zu(o); }), e.length > 0 && this.emitter.emit(x.events.SCROLL_BEFORE_UPDATE, s, e), super.update(e.concat([])), e.length > 0 && this.emitter.emit(x.events.SCROLL_UPDATE, s, e); }
        updateEmbedAt(e, s, n) { let [i] = this.descendant(o => o instanceof U, e); i && i.statics.blotName === s && Zu(i) && i.updateContent(n); }
        handleDragStart(e) { e.preventDefault(); }
        deltaToRenderBlocks(e) {
            let s = [], n = new pt.default;
            return e.forEach(i => {
                let o = i?.insert;
                if (o)
                    if (typeof o == "string") {
                        let a = o.split(`
`);
                        a.slice(0, -1).forEach(u => { n.insert(u, i.attributes), s.push({ type: "block", delta: n, attributes: i.attributes ?? {} }), n = new pt.default; });
                        let l = a[a.length - 1];
                        l && n.insert(l, i.attributes);
                    }
                    else {
                        let a = Object.keys(o)[0];
                        if (!a)
                            return;
                        this.query(a, b.INLINE) ? n.push(i) : (n.length() && s.push({ type: "block", delta: n, attributes: {} }), n = new pt.default, s.push({ type: "blockEmbed", key: a, value: o[a], attributes: i.attributes ?? {} }));
                    }
            }), n.length() && s.push({ type: "block", delta: n, attributes: {} }), s;
        }
        createBlock(e, s) { let n, i = {}; Object.entries(e).forEach(l => { let [u, c] = l; this.query(u, b.BLOCK & b.BLOT) != null ? n = u : i[u] = c; }); let o = this.create(n || this.statics.defaultChild.blotName, n ? e[n] : void 0); this.insertBefore(o, s || void 0); let a = o.length(); return Object.entries(i).forEach(l => { let [u, c] = l; o.formatAt(0, a, u, c); }), o; }
    }
    return r;
})();
function di(r, t, e) { e.reduce((s, n) => { let i = pt.Op.length(n), o = n.attributes || {}; if (n.insert != null) {
    if (typeof n.insert == "string") {
        let a = n.insert;
        r.insertAt(s, a);
        let [l] = r.descendant(j, s), u = st(l);
        o = pt.AttributeMap.diff(u, o) || {};
    }
    else if (typeof n.insert == "object") {
        let a = Object.keys(n.insert)[0];
        if (a == null)
            return s;
        if (r.insertAt(s, a, n.insert[a]), r.scroll.query(a, b.INLINE) != null) {
            let [u] = r.descendant(j, s), c = st(u);
            o = pt.AttributeMap.diff(c, o) || {};
        }
    }
} return Object.keys(o).forEach(a => { r.formatAt(s, i, a, o[a]); }), s + i; }, t); }
var Xu = ny;
var nt = ot(lt(), 1);
var pi = { scope: b.BLOCK, whitelist: ["right", "center", "justify"] }, Qu = new W("align", "align", pi), mi = new D("align", "ql-align", pi), Is = new rt("align", "text-align", pi);
var Er = class extends rt {
    value(t) { let e = super.value(t); return e.startsWith("rgb(") ? (e = e.replace(/^[^\d]+/, "").replace(/[^\d]+$/, ""), `#${e.split(",").map(n => `00${parseInt(n, 10).toString(16)}`.slice(-2)).join("")}`) : e; }
}, Yu = new D("color", "ql-color", { scope: b.INLINE }), Tr = new Er("color", "color", { scope: b.INLINE });
var Ju = new D("background", "ql-bg", { scope: b.INLINE }), Nr = new Er("background", "background-color", { scope: b.INLINE });
var Tt = class extends dt {
    static create(t) { let e = super.create(t); return e.setAttribute("spellcheck", "false"), e; }
    code(t, e) {
        return this.children.map(s => s.length() <= 1 ? "" : s.domNode.innerText).join(`
`).slice(t, t + e);
    }
    html(t, e) {
        return `<pre>
${ye(this.code(t, e))}
</pre>`;
    }
}, F = (() => { class r extends B {
    static TAB = "  ";
    static register() { d.register(Tt); }
} return r; })(), tc = (() => { class r extends K {
} return r.blotName = "code", r.tagName = "CODE", r; })();
F.blotName = "code-block";
F.className = "ql-code-block";
F.tagName = "DIV";
Tt.blotName = "code-block-container";
Tt.className = "ql-code-block-container";
Tt.tagName = "DIV";
Tt.allowedChildren = [F];
F.allowedChildren = [R, $, te];
F.requiredContainer = Tt;
var gi = { scope: b.BLOCK, whitelist: ["rtl"] }, ks = new W("direction", "dir", gi), bi = new D("direction", "ql-direction", gi), Rs = new rt("direction", "direction", gi);
var ec = { scope: b.INLINE, whitelist: ["serif", "monospace"] }, xi = new D("font", "ql-font", ec), yi = class extends rt {
    value(t) { return super.value(t).replace(/["']/g, ""); }
}, Bs = new yi("font", "font-family", ec);
var vi = new D("size", "ql-size", { scope: b.INLINE, whitelist: ["small", "large", "huge"] }), Ms = new rt("size", "font-size", { scope: b.INLINE, whitelist: ["10px", "18px", "32px"] });
var V = ot(lt(), 1);
var iy = ut("quill:keyboard"), oy = /Mac/i.test(navigator.platform) ? "metaKey" : "ctrlKey", wr = class r extends k {
    static match(t, e) { return ["altKey", "ctrlKey", "metaKey", "shiftKey"].some(s => !!e[s] !== t[s] && e[s] !== null) ? !1 : e.key === t.key || e.key === t.which; }
    constructor(t, e) { super(t, e), this.bindings = {}, Object.keys(this.options.bindings).forEach(s => { this.options.bindings[s] && this.addBinding(this.options.bindings[s]); }), this.addBinding({ key: "Enter", shiftKey: null }, this.handleEnter), this.addBinding({ key: "Enter", metaKey: null, ctrlKey: null, altKey: null }, () => { }), /Firefox/i.test(navigator.userAgent) ? (this.addBinding({ key: "Backspace" }, { collapsed: !0 }, this.handleBackspace), this.addBinding({ key: "Delete" }, { collapsed: !0 }, this.handleDelete)) : (this.addBinding({ key: "Backspace" }, { collapsed: !0, prefix: /^.?$/ }, this.handleBackspace), this.addBinding({ key: "Delete" }, { collapsed: !0, suffix: /^.?$/ }, this.handleDelete)), this.addBinding({ key: "Backspace" }, { collapsed: !1 }, this.handleDeleteRange), this.addBinding({ key: "Delete" }, { collapsed: !1 }, this.handleDeleteRange), this.addBinding({ key: "Backspace", altKey: null, ctrlKey: null, metaKey: null, shiftKey: null }, { collapsed: !0, offset: 0 }, this.handleBackspace), this.listen(); }
    addBinding(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, n = ly(t); if (n == null) {
        iy.warn("Attempted to add invalid keyboard binding", n);
        return;
    } typeof e == "function" && (e = { handler: e }), typeof s == "function" && (s = { handler: s }), (Array.isArray(n.key) ? n.key : [n.key]).forEach(o => { let a = L(L(Ut(L({}, n), { key: o }), e), s); this.bindings[a.key] = this.bindings[a.key] || [], this.bindings[a.key].push(a); }); }
    listen() { this.quill.root.addEventListener("keydown", t => { if (t.defaultPrevented || t.isComposing || t.keyCode === 229 && (t.key === "Enter" || t.key === "Backspace"))
        return; let n = (this.bindings[t.key] || []).concat(this.bindings[t.which] || []).filter(g => r.match(t, g)); if (n.length === 0)
        return; let i = d.find(t.target, !0); if (i && i.scroll !== this.quill.scroll)
        return; let o = this.quill.getSelection(); if (o == null || !this.quill.hasFocus())
        return; let [a, l] = this.quill.getLine(o.index), [u, c] = this.quill.getLeaf(o.index), [f, h] = o.length === 0 ? [u, c] : this.quill.getLeaf(o.index + o.length), p = u instanceof Fe ? u.value().slice(0, c) : "", m = f instanceof Fe ? f.value().slice(h) : "", y = { collapsed: o.length === 0, empty: o.length === 0 && a.length() <= 1, format: this.quill.getFormat(o), line: a, offset: l, prefix: p, suffix: m, event: t }; n.some(g => { if (g.collapsed != null && g.collapsed !== y.collapsed || g.empty != null && g.empty !== y.empty || g.offset != null && g.offset !== y.offset)
        return !1; if (Array.isArray(g.format)) {
        if (g.format.every(A => y.format[A] == null))
            return !1;
    }
    else if (typeof g.format == "object" && !Object.keys(g.format).every(A => g.format[A] === !0 ? y.format[A] != null : g.format[A] === !1 ? y.format[A] == null : le(g.format[A], y.format[A])))
        return !1; return g.prefix != null && !g.prefix.test(y.prefix) || g.suffix != null && !g.suffix.test(y.suffix) ? !1 : g.handler.call(this, o, y, g) !== !0; }) && t.preventDefault(); }); }
    handleBackspace(t, e) { let s = /[\uD800-\uDBFF][\uDC00-\uDFFF]$/.test(e.prefix) ? 2 : 1; if (t.index === 0 || this.quill.getLength() <= 1)
        return; let n = {}, [i] = this.quill.getLine(t.index), o = new V.default().retain(t.index - s).delete(s); if (e.offset === 0) {
        let [a] = this.quill.getLine(t.index - 1);
        if (a && !(a.statics.blotName === "block" && a.length() <= 1)) {
            let u = i.formats(), c = this.quill.getFormat(t.index - 1, 1);
            if (n = V.AttributeMap.diff(u, c) || {}, Object.keys(n).length > 0) {
                let f = new V.default().retain(t.index + i.length() - 2).retain(1, n);
                o = o.compose(f);
            }
        }
    } this.quill.updateContents(o, d.sources.USER), this.quill.focus(); }
    handleDelete(t, e) { let s = /^[\uD800-\uDBFF][\uDC00-\uDFFF]/.test(e.suffix) ? 2 : 1; if (t.index >= this.quill.getLength() - s)
        return; let n = {}, [i] = this.quill.getLine(t.index), o = new V.default().retain(t.index).delete(s); if (e.offset >= i.length() - 1) {
        let [a] = this.quill.getLine(t.index + 1);
        if (a) {
            let l = i.formats(), u = this.quill.getFormat(t.index, 1);
            n = V.AttributeMap.diff(l, u) || {}, Object.keys(n).length > 0 && (o = o.retain(a.length() - 1).retain(1, n));
        }
    } this.quill.updateContents(o, d.sources.USER), this.quill.focus(); }
    handleDeleteRange(t) { Sr({ range: t, quill: this.quill }), this.quill.focus(); }
    handleEnter(t, e) {
        let s = Object.keys(e.format).reduce((i, o) => (this.quill.scroll.query(o, b.BLOCK) && !Array.isArray(e.format[o]) && (i[o] = e.format[o]), i), {}), n = new V.default().retain(t.index).delete(t.length).insert(`
`, s);
        this.quill.updateContents(n, d.sources.USER), this.quill.setSelection(t.index + 1, d.sources.SILENT), this.quill.focus();
    }
}, ay = { bindings: { bold: Ai("bold"), italic: Ai("italic"), underline: Ai("underline"), indent: { key: "Tab", format: ["blockquote", "indent", "list"], handler(r, t) { return t.collapsed && t.offset !== 0 ? !0 : (this.quill.format("indent", "+1", d.sources.USER), !1); } }, outdent: { key: "Tab", shiftKey: !0, format: ["blockquote", "indent", "list"], handler(r, t) { return t.collapsed && t.offset !== 0 ? !0 : (this.quill.format("indent", "-1", d.sources.USER), !1); } }, "outdent backspace": { key: "Backspace", collapsed: !0, shiftKey: null, metaKey: null, ctrlKey: null, altKey: null, format: ["indent", "list"], offset: 0, handler(r, t) { t.format.indent != null ? this.quill.format("indent", "-1", d.sources.USER) : t.format.list != null && this.quill.format("list", !1, d.sources.USER); } }, "indent code-block": rc(!0), "outdent code-block": rc(!1), "remove tab": { key: "Tab", shiftKey: !0, collapsed: !0, prefix: /\t$/, handler(r) { this.quill.deleteText(r.index - 1, 1, d.sources.USER); } }, tab: { key: "Tab", handler(r, t) { if (t.format.table)
                return !0; this.quill.history.cutoff(); let e = new V.default().retain(r.index).delete(r.length).insert("	"); return this.quill.updateContents(e, d.sources.USER), this.quill.history.cutoff(), this.quill.setSelection(r.index + 1, d.sources.SILENT), !1; } }, "blockquote empty enter": { key: "Enter", collapsed: !0, format: ["blockquote"], empty: !0, handler() { this.quill.format("blockquote", !1, d.sources.USER); } }, "list empty enter": { key: "Enter", collapsed: !0, format: ["list"], empty: !0, handler(r, t) { let e = { list: !1 }; t.format.indent && (e.indent = !1), this.quill.formatLine(r.index, r.length, e, d.sources.USER); } }, "checklist enter": { key: "Enter", collapsed: !0, format: { list: "checked" }, handler(r) {
                let [t, e] = this.quill.getLine(r.index), s = Ut(L({}, t.formats()), { list: "checked" }), n = new V.default().retain(r.index).insert(`
`, s).retain(t.length() - e - 1).retain(1, { list: "unchecked" });
                this.quill.updateContents(n, d.sources.USER), this.quill.setSelection(r.index + 1, d.sources.SILENT), this.quill.scrollSelectionIntoView();
            } }, "header enter": { key: "Enter", collapsed: !0, format: ["header"], suffix: /^$/, handler(r, t) {
                let [e, s] = this.quill.getLine(r.index), n = new V.default().retain(r.index).insert(`
`, t.format).retain(e.length() - s - 1).retain(1, { header: null });
                this.quill.updateContents(n, d.sources.USER), this.quill.setSelection(r.index + 1, d.sources.SILENT), this.quill.scrollSelectionIntoView();
            } }, "table backspace": { key: "Backspace", format: ["table"], collapsed: !0, offset: 0, handler() { } }, "table delete": { key: "Delete", format: ["table"], collapsed: !0, suffix: /^$/, handler() { } }, "table enter": { key: "Enter", shiftKey: null, format: ["table"], handler(r) {
                let t = this.quill.getModule("table");
                if (t) {
                    let [e, s, n, i] = t.getTable(r), o = uy(e, s, n, i);
                    if (o == null)
                        return;
                    let a = e.offset();
                    if (o < 0) {
                        let l = new V.default().retain(a).insert(`
`);
                        this.quill.updateContents(l, d.sources.USER), this.quill.setSelection(r.index + 1, r.length, d.sources.SILENT);
                    }
                    else if (o > 0) {
                        a += e.length();
                        let l = new V.default().retain(a).insert(`
`);
                        this.quill.updateContents(l, d.sources.USER), this.quill.setSelection(a, d.sources.USER);
                    }
                }
            } }, "table tab": { key: "Tab", shiftKey: null, format: ["table"], handler(r, t) { let { event: e, line: s } = t, n = s.offset(this.quill.scroll); e.shiftKey ? this.quill.setSelection(n - 1, d.sources.USER) : this.quill.setSelection(n + s.length(), d.sources.USER); } }, "list autofill": { key: " ", shiftKey: null, collapsed: !0, format: { "code-block": !1, blockquote: !1, table: !1 }, prefix: /^\s*?(\d+\.|-|\*|\[ ?\]|\[x\])$/, handler(r, t) { if (this.quill.scroll.query("list") == null)
                return !0; let { length: e } = t.prefix, [s, n] = this.quill.getLine(r.index); if (n > e)
                return !0; let i; switch (t.prefix.trim()) {
                case "[]":
                case "[ ]":
                    i = "unchecked";
                    break;
                case "[x]":
                    i = "checked";
                    break;
                case "-":
                case "*":
                    i = "bullet";
                    break;
                default: i = "ordered";
            } this.quill.insertText(r.index, " ", d.sources.USER), this.quill.history.cutoff(); let o = new V.default().retain(r.index - n).delete(e + 1).retain(s.length() - 2 - n).retain(1, { list: i }); return this.quill.updateContents(o, d.sources.USER), this.quill.history.cutoff(), this.quill.setSelection(r.index - e, d.sources.SILENT), !1; } }, "code exit": { key: "Enter", collapsed: !0, format: ["code-block"], prefix: /^$/, suffix: /^\s*$/, handler(r) { let [t, e] = this.quill.getLine(r.index), s = 2, n = t; for (; n != null && n.length() <= 1 && n.formats()["code-block"];)
                if (n = n.prev, s -= 1, s <= 0) {
                    let i = new V.default().retain(r.index + t.length() - e - 2).retain(1, { "code-block": null }).delete(1);
                    return this.quill.updateContents(i, d.sources.USER), this.quill.setSelection(r.index - 1, d.sources.SILENT), !1;
                } return !0; } }, "embed left": Ds("ArrowLeft", !1), "embed left shift": Ds("ArrowLeft", !0), "embed right": Ds("ArrowRight", !1), "embed right shift": Ds("ArrowRight", !0), "table down": sc(!1), "table up": sc(!0) } };
wr.DEFAULTS = ay;
function rc(r) { return { key: "Tab", shiftKey: !r, format: { "code-block": !0 }, handler(t, e) { let { event: s } = e, n = this.quill.scroll.query("code-block"), { TAB: i } = n; if (t.length === 0 && !s.shiftKey) {
        this.quill.insertText(t.index, i, d.sources.USER), this.quill.setSelection(t.index + i.length, d.sources.SILENT);
        return;
    } let o = t.length === 0 ? this.quill.getLines(t.index, 1) : this.quill.getLines(t), { index: a, length: l } = t; o.forEach((u, c) => { r ? (u.insertAt(0, i), c === 0 ? a += i.length : l += i.length) : u.domNode.textContent.startsWith(i) && (u.deleteAt(0, i.length), c === 0 ? a -= i.length : l -= i.length); }), this.quill.update(d.sources.USER), this.quill.setSelection(a, l, d.sources.SILENT); } }; }
function Ds(r, t) { return { key: r, shiftKey: t, altKey: null, [r === "ArrowLeft" ? "prefix" : "suffix"]: /^$/, handler(s) { let { index: n } = s; r === "ArrowRight" && (n += s.length + 1); let [i] = this.quill.getLeaf(n); return i instanceof q ? (r === "ArrowLeft" ? t ? this.quill.setSelection(s.index - 1, s.length + 1, d.sources.USER) : this.quill.setSelection(s.index - 1, d.sources.USER) : t ? this.quill.setSelection(s.index, s.length + 1, d.sources.USER) : this.quill.setSelection(s.index + s.length + 1, d.sources.USER), !1) : !0; } }; }
function Ai(r) { return { key: r[0], shortKey: !0, handler(t, e) { this.quill.format(r, !e.format[r], d.sources.USER); } }; }
function sc(r) { return { key: r ? "ArrowUp" : "ArrowDown", collapsed: !0, format: ["table"], handler(t, e) { let s = r ? "prev" : "next", n = e.line, i = n.parent[s]; if (i != null) {
        if (i.statics.blotName === "table-row") {
            let o = i.children.head, a = n;
            for (; a.prev != null;)
                a = a.prev, o = o.next;
            let l = o.offset(this.quill.scroll) + Math.min(e.offset, o.length() - 1);
            this.quill.setSelection(l, 0, d.sources.USER);
        }
    }
    else {
        let o = n.table()[s];
        o != null && (r ? this.quill.setSelection(o.offset(this.quill.scroll) + o.length() - 1, 0, d.sources.USER) : this.quill.setSelection(o.offset(this.quill.scroll), 0, d.sources.USER));
    } return !1; } }; }
function ly(r) { if (typeof r == "string" || typeof r == "number")
    r = { key: r };
else if (typeof r == "object")
    r = At(r);
else
    return null; return r.shortKey && (r[oy] = r.shortKey, delete r.shortKey), r; }
function Sr(r) { let { quill: t, range: e } = r, s = t.getLines(e), n = {}; if (s.length > 1) {
    let i = s[0].formats(), o = s[s.length - 1].formats();
    n = V.AttributeMap.diff(o, i) || {};
} t.deleteText(e, d.sources.USER), Object.keys(n).length > 0 && t.formatLine(e.index, 1, n, d.sources.USER), t.setSelection(e.index, d.sources.SILENT); }
function uy(r, t, e, s) { return t.prev == null && t.next == null ? e.prev == null && e.next == null ? s === 0 ? -1 : 1 : e.prev == null ? -1 : 1 : t.prev == null ? -1 : t.next == null ? 1 : null; }
var cy = /font-weight:\s*normal/, fy = ["P", "OL", "UL"], nc = r => r && fy.includes(r.tagName), hy = r => { Array.from(r.querySelectorAll("br")).filter(t => nc(t.previousElementSibling) && nc(t.nextElementSibling)).forEach(t => { t.parentNode?.removeChild(t); }); }, dy = r => { Array.from(r.querySelectorAll('b[style*="font-weight"]')).filter(t => t.getAttribute("style")?.match(cy)).forEach(t => { let e = r.createDocumentFragment(); e.append(...t.childNodes), t.parentNode?.replaceChild(e, t); }); };
function Ei(r) { r.querySelector('[id^="docs-internal-guid-"]') && (dy(r), hy(r)); }
var py = /\bmso-list:[^;]*ignore/i, my = /\bmso-list:[^;]*\bl(\d+)/i, gy = /\bmso-list:[^;]*\blevel(\d+)/i, by = (r, t) => { let e = r.getAttribute("style"), s = e?.match(my); if (!s)
    return null; let n = Number(s[1]), i = e?.match(gy), o = i ? Number(i[1]) : 1, a = new RegExp(`@list l${n}:level${o}\\s*\\{[^\\}]*mso-level-number-format:\\s*([\\w-]+)`, "i"), l = t.match(a), u = l && l[1] === "bullet" ? "bullet" : "ordered"; return { id: n, indent: o, type: u, element: r }; }, yy = r => { let t = Array.from(r.querySelectorAll("[style*=mso-list]")), e = [], s = []; t.forEach(o => { (o.getAttribute("style") || "").match(py) ? e.push(o) : s.push(o); }), e.forEach(o => o.parentNode?.removeChild(o)); let n = r.documentElement.innerHTML, i = s.map(o => by(o, n)).filter(o => o); for (; i.length;) {
    let o = [], a = i.shift();
    for (; a;)
        o.push(a), a = i.length && i[0]?.element === a.element.nextElementSibling && i[0].id === a.id ? i.shift() : null;
    let l = document.createElement("ul");
    o.forEach(f => { let h = document.createElement("li"); h.setAttribute("data-list", f.type), f.indent > 1 && h.setAttribute("class", `ql-indent-${f.indent - 1}`), h.innerHTML = f.element.innerHTML, l.appendChild(h); });
    let u = o[0]?.element, { parentNode: c } = u ?? {};
    u && c?.replaceChild(l, u), o.slice(1).forEach(f => { let { element: h } = f; c?.removeChild(h); });
} };
function Ti(r) { r.documentElement.getAttribute("xmlns:w") === "urn:schemas-microsoft-com:office:word" && yy(r); }
var xy = [Ti, Ei], vy = r => { r.documentElement && xy.forEach(t => { t(r); }); }, ic = vy;
var Ay = ut("quill:clipboard"), Ey = [[Node.TEXT_NODE, Ry], [Node.TEXT_NODE, ac], ["br", Ly], [Node.ELEMENT_NODE, ac], [Node.ELEMENT_NODE, Sy], [Node.ELEMENT_NODE, wy], [Node.ELEMENT_NODE, Iy], ["li", _y], ["ol, ul", qy], ["pre", Oy], ["tr", ky], ["b", Ni("bold")], ["i", Ni("italic")], ["strike", Ni("strike")], ["style", Cy]], Ty = [Qu, ks].reduce((r, t) => (r[t.keyName] = t, r), {}), oc = [Is, Nr, Tr, Rs, Bs, Ms].reduce((r, t) => (r[t.keyName] = t, r), {}), lc = (() => {
    class r extends k {
        static DEFAULTS = { matchers: [] };
        constructor(e, s) { super(e, s), this.quill.root.addEventListener("copy", n => this.onCaptureCopy(n, !1)), this.quill.root.addEventListener("cut", n => this.onCaptureCopy(n, !0)), this.quill.root.addEventListener("paste", this.onCapturePaste.bind(this)), this.matchers = [], Ey.concat(this.options.matchers ?? []).forEach(n => { let [i, o] = n; this.addMatcher(i, o); }); }
        addMatcher(e, s) { this.matchers.push([e, s]); }
        convert(e) {
            let { html: s, text: n } = e, i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
            if (i[F.blotName])
                return new nt.default().insert(n || "", { [F.blotName]: i[F.blotName] });
            if (!s)
                return new nt.default().insert(n || "", i);
            let o = this.convertHTML(s);
            return Lr(o, `
`) && (o.ops[o.ops.length - 1].attributes == null || i.table) ? o.compose(new nt.default().retain(o.length() - 1).delete(1)) : o;
        }
        normalizeHTML(e) { ic(e); }
        convertHTML(e) { let s = new DOMParser().parseFromString(e, "text/html"); this.normalizeHTML(s); let n = s.body, i = new WeakMap, [o, a] = this.prepareMatching(n, i); return Ps(this.quill.scroll, n, o, a, i); }
        dangerouslyPasteHTML(e, s) { let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : d.sources.API; if (typeof e == "string") {
            let i = this.convert({ html: e, text: "" });
            this.quill.setContents(i, s), this.quill.setSelection(0, d.sources.SILENT);
        }
        else {
            let i = this.convert({ html: s, text: "" });
            this.quill.updateContents(new nt.default().retain(e).concat(i), n), this.quill.setSelection(e + i.length(), d.sources.SILENT);
        } }
        onCaptureCopy(e) { let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1; if (e.defaultPrevented)
            return; e.preventDefault(); let [n] = this.quill.selection.getRange(); if (n == null)
            return; let { html: i, text: o } = this.onCopy(n, s); e.clipboardData?.setData("text/plain", o), e.clipboardData?.setData("text/html", i), s && Sr({ range: n, quill: this.quill }); }
        normalizeURIList(e) {
            return e.split(/\r?\n/).filter(s => s[0] !== "#").join(`
`);
        }
        onCapturePaste(e) { if (e.defaultPrevented || !this.quill.isEnabled())
            return; e.preventDefault(); let s = this.quill.getSelection(!0); if (s == null)
            return; let n = e.clipboardData?.getData("text/html"), i = e.clipboardData?.getData("text/plain"); if (!n && !i) {
            let a = e.clipboardData?.getData("text/uri-list");
            a && (i = this.normalizeURIList(a));
        } let o = Array.from(e.clipboardData?.files || []); if (!n && o.length > 0) {
            this.quill.uploader.upload(s, o);
            return;
        } if (n && o.length > 0) {
            let a = new DOMParser().parseFromString(n, "text/html");
            if (a.body.childElementCount === 1 && a.body.firstElementChild?.tagName === "IMG") {
                this.quill.uploader.upload(s, o);
                return;
            }
        } this.onPaste(s, { html: n, text: i }); }
        onCopy(e) { let s = this.quill.getText(e); return { html: this.quill.getSemanticHTML(e), text: s }; }
        onPaste(e, s) { let { text: n, html: i } = s, o = this.quill.getFormat(e.index), a = this.convert({ text: n, html: i }, o); Ay.log("onPaste", a, { text: n, html: i }); let l = new nt.default().retain(e.index).delete(e.length).concat(a); this.quill.updateContents(l, d.sources.USER), this.quill.setSelection(l.length() - e.length, d.sources.SILENT), this.quill.scrollSelectionIntoView(); }
        prepareMatching(e, s) { let n = [], i = []; return this.matchers.forEach(o => { let [a, l] = o; switch (a) {
            case Node.TEXT_NODE:
                i.push(l);
                break;
            case Node.ELEMENT_NODE:
                n.push(l);
                break;
            default:
                Array.from(e.querySelectorAll(a)).forEach(u => { s.has(u) ? s.get(u)?.push(l) : s.set(u, [l]); });
                break;
        } }), [n, i]; }
    }
    return r;
})();
function xe(r, t, e, s) { return s.query(t) ? r.reduce((n, i) => { if (!i.insert)
    return n; if (i.attributes && i.attributes[t])
    return n.push(i); let o = e ? { [t]: e } : {}; return n.insert(i.insert, L(L({}, o), i.attributes)); }, new nt.default) : r; }
function Lr(r, t) { let e = ""; for (let s = r.ops.length - 1; s >= 0 && e.length < t.length; --s) {
    let n = r.ops[s];
    if (typeof n.insert != "string")
        break;
    e = n.insert + e;
} return e.slice(-1 * t.length) === t; }
function re(r, t) { if (!(r instanceof Element))
    return !1; let e = t.query(r); return e && e.prototype instanceof q ? !1 : ["address", "article", "blockquote", "canvas", "dd", "div", "dl", "dt", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "iframe", "li", "main", "nav", "ol", "output", "p", "pre", "section", "table", "td", "tr", "ul", "video"].includes(r.tagName.toLowerCase()); }
function Ny(r, t) { return r.previousElementSibling && r.nextElementSibling && !re(r.previousElementSibling, t) && !re(r.nextElementSibling, t); }
var js = new WeakMap;
function uc(r) { return r == null ? !1 : (js.has(r) || (r.tagName === "PRE" ? js.set(r, !0) : js.set(r, uc(r.parentNode))), js.get(r)); }
function Ps(r, t, e, s, n) { return t.nodeType === t.TEXT_NODE ? s.reduce((i, o) => o(t, i, r), new nt.default) : t.nodeType === t.ELEMENT_NODE ? Array.from(t.childNodes || []).reduce((i, o) => { let a = Ps(r, o, e, s, n); return o.nodeType === t.ELEMENT_NODE && (a = e.reduce((l, u) => u(o, l, r), a), a = (n.get(o) || []).reduce((l, u) => u(o, l, r), a)), i.concat(a); }, new nt.default) : new nt.default; }
function Ni(r) { return (t, e, s) => xe(e, r, !0, s); }
function wy(r, t, e) { let s = W.keys(r), n = D.keys(r), i = rt.keys(r), o = {}; return s.concat(n).concat(i).forEach(a => { let l = e.query(a, b.ATTRIBUTE); l != null && (o[l.attrName] = l.value(r), o[l.attrName]) || (l = Ty[a], l != null && (l.attrName === a || l.keyName === a) && (o[l.attrName] = l.value(r) || void 0), l = oc[a], l != null && (l.attrName === a || l.keyName === a) && (l = oc[a], o[l.attrName] = l.value(r) || void 0)); }), Object.entries(o).reduce((a, l) => { let [u, c] = l; return xe(a, u, c, e); }, t); }
function Sy(r, t, e) {
    let s = e.query(r);
    if (s == null)
        return t;
    if (s.prototype instanceof q) {
        let n = {}, i = s.value(r);
        if (i != null)
            return n[s.blotName] = i, new nt.default().insert(n, s.formats(r, e));
    }
    else if (s.prototype instanceof ue && !Lr(t, `
`) && t.insert(`
`), "blotName" in s && "formats" in s && typeof s.formats == "function")
        return xe(t, s.blotName, s.formats(r, e), e);
    return t;
}
function Ly(r, t) {
    return Lr(t, `
`) || t.insert(`
`), t;
}
function Oy(r, t, e) { let s = e.query("code-block"), n = s && "formats" in s && typeof s.formats == "function" ? s.formats(r, e) : !0; return xe(t, "code-block", n, e); }
function Cy() { return new nt.default; }
function _y(r, t, e) {
    let s = e.query(r);
    if (s == null || s.blotName !== "list" || !Lr(t, `
`))
        return t;
    let n = -1, i = r.parentNode;
    for (; i != null;)
        ["OL", "UL"].includes(i.tagName) && (n += 1), i = i.parentNode;
    return n <= 0 ? t : t.reduce((o, a) => a.insert ? a.attributes && typeof a.attributes.indent == "number" ? o.push(a) : o.insert(a.insert, L({ indent: n }, a.attributes || {})) : o, new nt.default);
}
function qy(r, t, e) { let s = r, n = s.tagName === "OL" ? "ordered" : "bullet", i = s.getAttribute("data-checked"); return i && (n = i === "true" ? "checked" : "unchecked"), xe(t, "list", n, e); }
function ac(r, t, e) {
    if (!Lr(t, `
`)) {
        if (re(r, e) && (r.childNodes.length > 0 || r instanceof HTMLParagraphElement))
            return t.insert(`
`);
        if (t.length() > 0 && r.nextSibling) {
            let s = r.nextSibling;
            for (; s != null;) {
                if (re(s, e))
                    return t.insert(`
`);
                let n = e.query(s);
                if (n && n.prototype instanceof U)
                    return t.insert(`
`);
                s = s.firstChild;
            }
        }
    }
    return t;
}
function Iy(r, t, e) { let s = {}, n = r.style || {}; return n.fontStyle === "italic" && (s.italic = !0), n.textDecoration === "underline" && (s.underline = !0), n.textDecoration === "line-through" && (s.strike = !0), (n.fontWeight?.startsWith("bold") || parseInt(n.fontWeight, 10) >= 700) && (s.bold = !0), t = Object.entries(s).reduce((i, o) => { let [a, l] = o; return xe(i, a, l, e); }, t), parseFloat(n.textIndent || 0) > 0 ? new nt.default().insert("	").concat(t) : t; }
function ky(r, t, e) { let s = r.parentElement?.tagName === "TABLE" ? r.parentElement : r.parentElement?.parentElement; if (s != null) {
    let i = Array.from(s.querySelectorAll("tr")).indexOf(r) + 1;
    return xe(t, "table", i, e);
} return t; }
function Ry(r, t, e) {
    let s = r.data;
    if (r.parentElement?.tagName === "O:P")
        return t.insert(s.trim());
    if (!uc(r)) {
        if (s.trim().length === 0 && s.includes(`
`) && !Ny(r, e))
            return t;
        s = s.replace(/[^\S\u00a0]/g, " "), s = s.replace(/ {2,}/g, " "), (r.previousSibling == null && r.parentElement != null && re(r.parentElement, e) || r.previousSibling instanceof Element && re(r.previousSibling, e)) && (s = s.replace(/^ /, "")), (r.nextSibling == null && r.parentElement != null && re(r.parentElement, e) || r.nextSibling instanceof Element && re(r.nextSibling, e)) && (s = s.replace(/ $/, "")), s = s.replaceAll("\xA0", " ");
    }
    return t.insert(s);
}
var fc = (() => { class r extends k {
    static DEFAULTS = { delay: 1e3, maxStack: 100, userOnly: !1 };
    lastRecorded = 0;
    ignoreChange = !1;
    stack = { undo: [], redo: [] };
    currentRange = null;
    constructor(e, s) { super(e, s), this.quill.on(d.events.EDITOR_CHANGE, (n, i, o, a) => { n === d.events.SELECTION_CHANGE ? i && a !== d.sources.SILENT && (this.currentRange = i) : n === d.events.TEXT_CHANGE && (this.ignoreChange || (!this.options.userOnly || a === d.sources.USER ? this.record(i, o) : this.transform(i)), this.currentRange = wi(this.currentRange, i)); }), this.quill.keyboard.addBinding({ key: "z", shortKey: !0 }, this.undo.bind(this)), this.quill.keyboard.addBinding({ key: ["z", "Z"], shortKey: !0, shiftKey: !0 }, this.redo.bind(this)), /Win/i.test(navigator.platform) && this.quill.keyboard.addBinding({ key: "y", shortKey: !0 }, this.redo.bind(this)), this.quill.root.addEventListener("beforeinput", n => { n.inputType === "historyUndo" ? (this.undo(), n.preventDefault()) : n.inputType === "historyRedo" && (this.redo(), n.preventDefault()); }); }
    change(e, s) { if (this.stack[e].length === 0)
        return; let n = this.stack[e].pop(); if (!n)
        return; let i = this.quill.getContents(), o = n.delta.invert(i); this.stack[s].push({ delta: o, range: wi(n.range, o) }), this.lastRecorded = 0, this.ignoreChange = !0, this.quill.updateContents(n.delta, d.sources.USER), this.ignoreChange = !1, this.restoreSelection(n); }
    clear() { this.stack = { undo: [], redo: [] }; }
    cutoff() { this.lastRecorded = 0; }
    record(e, s) { if (e.ops.length === 0)
        return; this.stack.redo = []; let n = e.invert(s), i = this.currentRange, o = Date.now(); if (this.lastRecorded + this.options.delay > o && this.stack.undo.length > 0) {
        let a = this.stack.undo.pop();
        a && (n = n.compose(a.delta), i = a.range);
    }
    else
        this.lastRecorded = o; n.length() !== 0 && (this.stack.undo.push({ delta: n, range: i }), this.stack.undo.length > this.options.maxStack && this.stack.undo.shift()); }
    redo() { this.change("redo", "undo"); }
    transform(e) { cc(this.stack.undo, e), cc(this.stack.redo, e); }
    undo() { this.change("undo", "redo"); }
    restoreSelection(e) { if (e.range)
        this.quill.setSelection(e.range, d.sources.USER);
    else {
        let s = My(this.quill.scroll, e.delta);
        this.quill.setSelection(s, d.sources.USER);
    } }
} return r; })();
function cc(r, t) { let e = t; for (let s = r.length - 1; s >= 0; s -= 1) {
    let n = r[s];
    r[s] = { delta: e.transform(n.delta, !0), range: n.range && wi(n.range, e) }, e = n.delta.transform(e), r[s].delta.length() === 0 && r.splice(s, 1);
} }
function By(r, t) {
    let e = t.ops[t.ops.length - 1];
    return e == null ? !1 : e.insert != null ? typeof e.insert == "string" && e.insert.endsWith(`
`) : e.attributes != null ? Object.keys(e.attributes).some(s => r.query(s, b.BLOCK) != null) : !1;
}
function My(r, t) { let e = t.reduce((n, i) => n + (i.delete || 0), 0), s = t.length() - e; return By(r, t) && (s -= 1), s; }
function wi(r, t) { if (!r)
    return r; let e = t.transformPosition(r.index), s = t.transformPosition(r.index + r.length); return { index: e, length: s - e }; }
var hc = ot(lt(), 1);
var Dy = (() => { class r extends k {
    constructor(e, s) { super(e, s), e.root.addEventListener("drop", n => { n.preventDefault(); let i = null; if (document.caretRangeFromPoint)
        i = document.caretRangeFromPoint(n.clientX, n.clientY);
    else if (document.caretPositionFromPoint) {
        let a = document.caretPositionFromPoint(n.clientX, n.clientY);
        i = document.createRange(), i.setStart(a.offsetNode, a.offset), i.setEnd(a.offsetNode, a.offset);
    } let o = i && e.selection.normalizeNative(i); if (o) {
        let a = e.selection.normalizedToRange(o);
        n.dataTransfer?.files && this.upload(a, n.dataTransfer.files);
    } }); }
    upload(e, s) { let n = []; Array.from(s).forEach(i => { i && this.options.mimetypes?.includes(i.type) && n.push(i); }), n.length > 0 && this.options.handler.call(this, e, n); }
} return r.DEFAULTS = { mimetypes: ["image/png", "image/jpeg"], handler(t, e) { if (!this.quill.scroll.query("image"))
        return; let s = e.map(n => new Promise(i => { let o = new FileReader; o.onload = () => { i(o.result); }, o.readAsDataURL(n); })); Promise.all(s).then(n => { let i = n.reduce((o, a) => o.insert({ image: a }), new hc.default().retain(t.index).delete(t.length)); this.quill.updateContents(i, x.sources.USER), this.quill.setSelection(t.index + n.length, x.sources.SILENT); }); } }, r; })(), dc = Dy;
var se = ot(lt(), 1);
var pc = ot(lt(), 1);
var jy = ["insertText", "insertReplacementText"], Si = class extends k {
    constructor(t, e) { super(t, e), t.root.addEventListener("beforeinput", s => { this.handleBeforeInput(s); }), /Android/i.test(navigator.userAgent) || t.on(d.events.COMPOSITION_BEFORE_START, () => { this.handleCompositionStart(); }); }
    deleteRange(t) { Sr({ range: t, quill: this.quill }); }
    replaceText(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ""; if (t.length === 0)
        return !1; if (e) {
        let s = this.quill.getFormat(t.index, 1);
        this.deleteRange(t), this.quill.updateContents(new pc.default().retain(t.index).insert(e, s), d.sources.USER);
    }
    else
        this.deleteRange(t); return this.quill.setSelection(t.index + e.length, 0, d.sources.SILENT), !0; }
    handleBeforeInput(t) { if (this.quill.composition.isComposing || t.defaultPrevented || !jy.includes(t.inputType))
        return; let e = t.getTargetRanges ? t.getTargetRanges()[0] : null; if (!e || e.collapsed === !0)
        return; let s = Py(t); if (s == null)
        return; let n = this.quill.selection.normalizeNative(e), i = n ? this.quill.selection.normalizedToRange(n) : null; i && this.replaceText(i, s) && t.preventDefault(); }
    handleCompositionStart() { let t = this.quill.getSelection(); t && this.replaceText(t); }
};
function Py(r) { return typeof r.data == "string" ? r.data : r.dataTransfer?.types.includes("text/plain") ? r.dataTransfer.getData("text/plain") : null; }
var mc = Si;
var Uy = /Mac/i.test(navigator.platform), Fy = 100, Hy = r => !!(r.key === "ArrowLeft" || r.key === "ArrowRight" || r.key === "ArrowUp" || r.key === "ArrowDown" || r.key === "Home" || Uy && r.key === "a" && r.ctrlKey === !0), Li = class extends k {
    isListening = !1;
    selectionChangeDeadline = 0;
    constructor(t, e) { super(t, e), this.handleArrowKeys(), this.handleNavigationShortcuts(); }
    handleArrowKeys() { this.quill.keyboard.addBinding({ key: ["ArrowLeft", "ArrowRight"], offset: 0, shiftKey: null, handler(t, e) { let { line: s, event: n } = e; if (!(s instanceof et) || !s.uiNode)
            return !0; let i = getComputedStyle(s.domNode).direction === "rtl"; return i && n.key !== "ArrowRight" || !i && n.key !== "ArrowLeft" ? !0 : (this.quill.setSelection(t.index - 1, t.length + (n.shiftKey ? 1 : 0), d.sources.USER), !1); } }); }
    handleNavigationShortcuts() { this.quill.root.addEventListener("keydown", t => { !t.defaultPrevented && Hy(t) && this.ensureListeningToSelectionChange(); }); }
    ensureListeningToSelectionChange() { if (this.selectionChangeDeadline = Date.now() + Fy, this.isListening)
        return; this.isListening = !0; let t = () => { this.isListening = !1, Date.now() <= this.selectionChangeDeadline && this.handleSelectionChange(); }; document.addEventListener("selectionchange", t, { once: !0 }); }
    handleSelectionChange() { let t = document.getSelection(); if (!t)
        return; let e = t.getRangeAt(0); if (e.collapsed !== !0 || e.startOffset !== 0)
        return; let s = this.quill.scroll.find(e.startContainer); if (!(s instanceof et) || !s.uiNode)
        return; let n = document.createRange(); n.setStartAfter(s.uiNode), n.setEndAfter(s.uiNode), t.removeAllRanges(), t.addRange(n); }
}, gc = Li;
d.register({ "blots/block": B, "blots/block/embed": U, "blots/break": $, "blots/container": dt, "blots/cursor": te, "blots/embed": Xe, "blots/inline": K, "blots/scroll": Xu, "blots/text": R, "modules/clipboard": lc, "modules/history": fc, "modules/keyboard": wr, "modules/uploader": dc, "modules/input": mc, "modules/uiNode": gc });
var Us = d;
var Oi = class extends D {
    add(t, e) { let s = 0; if (e === "+1" || e === "-1") {
        let n = this.value(t) || 0;
        s = e === "+1" ? n + 1 : n - 1;
    }
    else
        typeof e == "number" && (s = e); return s === 0 ? (this.remove(t), !0) : super.add(t, s.toString()); }
    canAdd(t, e) { return super.canAdd(t, e) || super.canAdd(t, parseInt(e, 10)); }
    value(t) { return parseInt(super.value(t), 10) || void 0; }
}, zy = new Oi("indent", "ql-indent", { scope: b.BLOCK, whitelist: [1, 2, 3, 4, 5, 6, 7, 8] }), bc = zy;
var $y = (() => { class r extends B {
    static blotName = "blockquote";
    static tagName = "blockquote";
} return r; })(), yc = $y;
var Ky = (() => { class r extends B {
    static blotName = "header";
    static tagName = ["H1", "H2", "H3", "H4", "H5", "H6"];
    static formats(e) { return this.tagName.indexOf(e.tagName) + 1; }
} return r; })(), xc = Ky;
var Ci = (() => { class r extends dt {
} return r.blotName = "list-container", r.tagName = "OL", r; })(), Fs = (() => { class r extends B {
    static create(e) { let s = super.create(); return s.setAttribute("data-list", e), s; }
    static formats(e) { return e.getAttribute("data-list") || void 0; }
    static register() { d.register(Ci); }
    constructor(e, s) { super(e, s); let n = s.ownerDocument.createElement("span"), i = o => { if (!e.isEnabled())
        return; let a = this.statics.formats(s, e); a === "checked" ? (this.format("list", "unchecked"), o.preventDefault()) : a === "unchecked" && (this.format("list", "checked"), o.preventDefault()); }; n.addEventListener("mousedown", i), n.addEventListener("touchstart", i), this.attachUI(n); }
    format(e, s) { e === this.statics.blotName && s ? this.domNode.setAttribute("data-list", s) : super.format(e, s); }
} return r.blotName = "list", r.tagName = "LI", r; })();
Ci.allowedChildren = [Fs];
Fs.requiredContainer = Ci;
var Gy = (() => { class r extends K {
    static blotName = "bold";
    static tagName = ["STRONG", "B"];
    static create() { return super.create(); }
    static formats() { return !0; }
    optimize(e) { super.optimize(e), this.domNode.tagName !== this.statics.tagName[0] && this.replaceWith(this.statics.blotName); }
} return r; })(), Je = Gy;
var Vy = (() => { class r extends Je {
    static blotName = "italic";
    static tagName = ["EM", "I"];
} return r; })(), vc = Vy;
var ve = (() => { class r extends K {
    static blotName = "link";
    static tagName = "A";
    static SANITIZED_URL = "about:blank";
    static PROTOCOL_WHITELIST = ["http", "https", "mailto", "tel", "sms"];
    static create(e) { let s = super.create(e); return s.setAttribute("href", this.sanitize(e)), s.setAttribute("rel", "noopener noreferrer"), s.setAttribute("target", "_blank"), s; }
    static formats(e) { return e.getAttribute("href"); }
    static sanitize(e) { return _i(e, this.PROTOCOL_WHITELIST) ? e : this.SANITIZED_URL; }
    format(e, s) { e !== this.statics.blotName || !s ? super.format(e, s) : this.domNode.setAttribute("href", this.constructor.sanitize(s)); }
} return r; })();
function _i(r, t) { let e = document.createElement("a"); e.href = r; let s = e.href.slice(0, e.href.indexOf(":")); return t.indexOf(s) > -1; }
var Wy = (() => { class r extends K {
    static blotName = "script";
    static tagName = ["SUB", "SUP"];
    static create(e) { return e === "super" ? document.createElement("sup") : e === "sub" ? document.createElement("sub") : super.create(e); }
    static formats(e) { if (e.tagName === "SUB")
        return "sub"; if (e.tagName === "SUP")
        return "super"; }
} return r; })(), Ac = Wy;
var Zy = (() => { class r extends Je {
    static blotName = "strike";
    static tagName = ["S", "STRIKE"];
} return r; })(), Ec = Zy;
var Xy = (() => { class r extends K {
    static blotName = "underline";
    static tagName = "U";
} return r; })(), Tc = Xy;
var Qy = (() => { class r extends Xe {
    static blotName = "formula";
    static className = "ql-formula";
    static tagName = "SPAN";
    static create(e) { if (window.katex == null)
        throw new Error("Formula module requires KaTeX."); let s = super.create(e); return typeof e == "string" && (window.katex.render(e, s, { throwOnError: !1, errorColor: "#f00" }), s.setAttribute("data-value", e)), s; }
    static value(e) { return e.getAttribute("data-value"); }
    html() { let { formula: e } = this.value(); return `<span>${e}</span>`; }
} return r; })(), Nc = Qy;
var wc = ["alt", "height", "width"], Yy = (() => { class r extends q {
    static blotName = "image";
    static tagName = "IMG";
    static create(e) { let s = super.create(e); return typeof e == "string" && s.setAttribute("src", this.sanitize(e)), s; }
    static formats(e) { return wc.reduce((s, n) => (e.hasAttribute(n) && (s[n] = e.getAttribute(n)), s), {}); }
    static match(e) { return /\.(jpe?g|gif|png)$/.test(e) || /^data:image\/.+;base64/.test(e); }
    static sanitize(e) { return _i(e, ["http", "https", "data"]) ? e : "//:0"; }
    static value(e) { return e.getAttribute("src"); }
    format(e, s) { wc.indexOf(e) > -1 ? s ? this.domNode.setAttribute(e, s) : this.domNode.removeAttribute(e) : super.format(e, s); }
} return r; })(), Sc = Yy;
var Lc = ["height", "width"], Jy = (() => { class r extends U {
    static blotName = "video";
    static className = "ql-video";
    static tagName = "IFRAME";
    static create(e) { let s = super.create(e); return s.setAttribute("frameborder", "0"), s.setAttribute("allowfullscreen", "true"), s.setAttribute("src", this.sanitize(e)), s; }
    static formats(e) { return Lc.reduce((s, n) => (e.hasAttribute(n) && (s[n] = e.getAttribute(n)), s), {}); }
    static sanitize(e) { return ve.sanitize(e); }
    static value(e) { return e.getAttribute("src"); }
    format(e, s) { Lc.indexOf(e) > -1 ? s ? this.domNode.setAttribute(e, s) : this.domNode.removeAttribute(e) : super.format(e, s); }
    html() { let { video: e } = this.value(); return `<a href="${e}">${e}</a>`; }
} return r; })(), Oc = Jy;
var zs = ot(lt(), 1);
var Or = new D("code-token", "hljs", { scope: b.INLINE }), Cr = (() => { class r extends K {
    static formats(e, s) { for (; e != null && e !== s.domNode;) {
        if (e.classList && e.classList.contains(F.className))
            return super.formats(e, s);
        e = e.parentNode;
    } }
    constructor(e, s, n) { super(e, s, n), Or.add(this.domNode, n); }
    format(e, s) { e !== r.blotName ? super.format(e, s) : s ? Or.add(this.domNode, s) : (Or.remove(this.domNode), this.domNode.classList.remove(this.statics.className)); }
    optimize() { super.optimize(...arguments), Or.value(this.domNode) || this.unwrap(); }
} return r.blotName = "code-token", r.className = "ql-token", r; })(), it = class extends F {
    static create(t) { let e = super.create(t); return typeof t == "string" && e.setAttribute("data-language", t), e; }
    static formats(t) { return t.getAttribute("data-language") || "plain"; }
    static register() { }
    format(t, e) { t === this.statics.blotName && e ? this.domNode.setAttribute("data-language", e) : super.format(t, e); }
    replaceWith(t, e) { return this.formatAt(0, this.length(), Cr.blotName, !1), super.replaceWith(t, e); }
}, Hs = (() => {
    class r extends Tt {
        attach() { super.attach(), this.forceNext = !1, this.scroll.emitMount(this); }
        format(e, s) { e === it.blotName && (this.forceNext = !0, this.children.forEach(n => { n.format(e, s); })); }
        formatAt(e, s, n, i) { n === it.blotName && (this.forceNext = !0), super.formatAt(e, s, n, i); }
        highlight(e) {
            let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
            if (this.children.head == null)
                return;
            let i = `${Array.from(this.domNode.childNodes).filter(a => a !== this.uiNode).map(a => a.textContent).join(`
`)}
`, o = it.formats(this.children.head.domNode);
            if (s || this.forceNext || this.cachedText !== i) {
                if (i.trim().length > 0 || this.cachedText == null) {
                    let a = this.children.reduce((u, c) => u.concat(Qn(c, !1)), new zs.default), l = e(i, o);
                    a.diff(l).reduce((u, c) => { let { retain: f, attributes: h } = c; return f ? (h && Object.keys(h).forEach(p => { [it.blotName, Cr.blotName].includes(p) && this.formatAt(u, f, p, h[p]); }), u + f) : u; }, 0);
                }
                this.cachedText = i, this.forceNext = !1;
            }
        }
        html(e, s) {
            let [n] = this.children.find(e);
            return `<pre data-language="${n ? it.formats(n.domNode) : "plain"}">
${ye(this.code(e, s))}
</pre>`;
        }
        optimize(e) { if (super.optimize(e), this.parent != null && this.children.head != null && this.uiNode != null) {
            let s = it.formats(this.children.head.domNode);
            s !== this.uiNode.value && (this.uiNode.value = s);
        } }
    }
    return r.allowedChildren = [it], r;
})();
it.requiredContainer = Hs;
it.allowedChildren = [Cr, te, R, $];
var tx = (r, t, e) => { if (typeof r.versionString == "string") {
    let s = r.versionString.split(".")[0];
    if (parseInt(s, 10) >= 11)
        return r.highlight(e, { language: t }).value;
} return r.highlight(t, e).value; }, _r = class extends k {
    static register() { d.register(Cr, !0), d.register(it, !0), d.register(Hs, !0); }
    constructor(t, e) { if (super(t, e), this.options.hljs == null)
        throw new Error("Syntax module requires highlight.js. Please include the library on the page before Quill."); this.languages = this.options.languages.reduce((s, n) => { let { key: i } = n; return s[i] = !0, s; }, {}), this.highlightBlot = this.highlightBlot.bind(this), this.initListener(), this.initTimer(); }
    initListener() { this.quill.on(d.events.SCROLL_BLOT_MOUNT, t => { if (!(t instanceof Hs))
        return; let e = this.quill.root.ownerDocument.createElement("select"); this.options.languages.forEach(s => { let { key: n, label: i } = s, o = e.ownerDocument.createElement("option"); o.textContent = i, o.setAttribute("value", n), e.appendChild(o); }), e.addEventListener("change", () => { t.format(it.blotName, e.value), this.quill.root.focus(), this.highlight(t, !0); }), t.uiNode == null && (t.attachUI(e), t.children.head && (e.value = it.formats(t.children.head.domNode))); }); }
    initTimer() { let t = null; this.quill.on(d.events.SCROLL_OPTIMIZE, () => { t && clearTimeout(t), t = setTimeout(() => { this.highlight(), t = null; }, this.options.interval); }); }
    highlight() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null, e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1; if (this.quill.selection.composing)
        return; this.quill.update(d.sources.USER); let s = this.quill.getSelection(); (t == null ? this.quill.scroll.descendants(Hs) : [t]).forEach(i => { i.highlight(this.highlightBlot, e); }), this.quill.update(d.sources.SILENT), s != null && this.quill.setSelection(s, d.sources.SILENT); }
    highlightBlot(t) {
        let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "plain";
        if (e = this.languages[e] ? e : "plain", e === "plain")
            return ye(t).split(`
`).reduce((n, i, o) => (o !== 0 && n.insert(`
`, { [F.blotName]: e }), n.insert(i)), new zs.default);
        let s = this.quill.root.ownerDocument.createElement("div");
        return s.classList.add(F.className), s.innerHTML = tx(this.options.hljs, e, t), Ps(this.quill.scroll, s, [(n, i) => { let o = Or.value(n); return o ? i.compose(new zs.default().retain(i.length(), { [Cr.blotName]: o })) : i; }], [(n, i) => n.data.split(`
`).reduce((o, a, l) => (l !== 0 && o.insert(`
`, { [F.blotName]: e }), o.insert(a)), i)], new WeakMap);
    }
};
_r.DEFAULTS = { hljs: window.hljs, interval: 1e3, languages: [{ key: "plain", label: "Plain" }, { key: "bash", label: "Bash" }, { key: "cpp", label: "C++" }, { key: "cs", label: "C#" }, { key: "css", label: "CSS" }, { key: "diff", label: "Diff" }, { key: "xml", label: "HTML/XML" }, { key: "java", label: "Java" }, { key: "javascript", label: "JavaScript" }, { key: "markdown", label: "Markdown" }, { key: "php", label: "PHP" }, { key: "python", label: "Python" }, { key: "ruby", label: "Ruby" }, { key: "sql", label: "SQL" }] };
var Cc = ot(lt(), 1);
var Nt = (() => { class r extends B {
    static blotName = "table";
    static tagName = "TD";
    static create(e) { let s = super.create(); return e ? s.setAttribute("data-row", e) : s.setAttribute("data-row", Ks()), s; }
    static formats(e) { if (e.hasAttribute("data-row"))
        return e.getAttribute("data-row"); }
    cellOffset() { return this.parent ? this.parent.children.indexOf(this) : -1; }
    format(e, s) { e === r.blotName && s ? this.domNode.setAttribute("data-row", s) : super.format(e, s); }
    row() { return this.parent; }
    rowOffset() { return this.row() ? this.row().rowOffset() : -1; }
    table() { return this.row() && this.row().table(); }
} return r; })(), ne = (() => { class r extends dt {
    static blotName = "table-row";
    static tagName = "TR";
    checkMerge() { if (super.checkMerge() && this.next.children.head != null) {
        let e = this.children.head.formats(), s = this.children.tail.formats(), n = this.next.children.head.formats(), i = this.next.children.tail.formats();
        return e.table === s.table && e.table === n.table && e.table === i.table;
    } return !1; }
    optimize(e) { super.optimize(e), this.children.forEach(s => { if (s.next == null)
        return; let n = s.formats(), i = s.next.formats(); if (n.table !== i.table) {
        let o = this.splitAfter(s);
        o && o.optimize(), this.prev && this.prev.optimize();
    } }); }
    rowOffset() { return this.parent ? this.parent.children.indexOf(this) : -1; }
    table() { return this.parent && this.parent.parent; }
} return r; })(), jt = (() => { class r extends dt {
    static blotName = "table-body";
    static tagName = "TBODY";
} return r; })(), $s = (() => { class r extends dt {
    static blotName = "table-container";
    static tagName = "TABLE";
    balanceCells() { let e = this.descendants(ne), s = e.reduce((n, i) => Math.max(i.children.length, n), 0); e.forEach(n => { new Array(s - n.children.length).fill(0).forEach(() => { let i; n.children.head != null && (i = Nt.formats(n.children.head.domNode)); let o = this.scroll.create(Nt.blotName, i); n.appendChild(o), o.optimize(); }); }); }
    cells(e) { return this.rows().map(s => s.children.at(e)); }
    deleteColumn(e) { let [s] = this.descendant(jt); s == null || s.children.head == null || s.children.forEach(n => { let i = n.children.at(e); i?.remove(); }); }
    insertColumn(e) { let [s] = this.descendant(jt); s == null || s.children.head == null || s.children.forEach(n => { let i = n.children.at(e), o = Nt.formats(n.children.head.domNode), a = this.scroll.create(Nt.blotName, o); n.insertBefore(a, i); }); }
    insertRow(e) { let [s] = this.descendant(jt); if (s == null || s.children.head == null)
        return; let n = Ks(), i = this.scroll.create(ne.blotName); s.children.head.children.forEach(() => { let a = this.scroll.create(Nt.blotName, n); i.appendChild(a); }); let o = s.children.at(e); s.insertBefore(i, o); }
    rows() { let e = this.children.head; return e == null ? [] : e.children.map(s => s); }
} return r.allowedChildren = [jt], r; })();
jt.requiredContainer = $s;
jt.allowedChildren = [ne];
ne.requiredContainer = jt;
ne.allowedChildren = [Nt];
Nt.requiredContainer = ne;
function Ks() { return `row-${Math.random().toString(36).slice(2, 6)}`; }
var qi = class extends k {
    static register() { d.register(Nt), d.register(ne), d.register(jt), d.register($s); }
    constructor() { super(...arguments), this.listenBalanceCells(); }
    balanceTables() { this.quill.scroll.descendants($s).forEach(t => { t.balanceCells(); }); }
    deleteColumn() { let [t, , e] = this.getTable(); e != null && (t.deleteColumn(e.cellOffset()), this.quill.update(d.sources.USER)); }
    deleteRow() { let [, t] = this.getTable(); t != null && (t.remove(), this.quill.update(d.sources.USER)); }
    deleteTable() { let [t] = this.getTable(); if (t == null)
        return; let e = t.offset(); t.remove(), this.quill.update(d.sources.USER), this.quill.setSelection(e, d.sources.SILENT); }
    getTable() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.quill.getSelection(); if (t == null)
        return [null, null, null, -1]; let [e, s] = this.quill.getLine(t.index); if (e == null || e.statics.blotName !== Nt.blotName)
        return [null, null, null, -1]; let n = e.parent; return [n.parent.parent, n, e, s]; }
    insertColumn(t) { let e = this.quill.getSelection(); if (!e)
        return; let [s, n, i] = this.getTable(e); if (i == null)
        return; let o = i.cellOffset(); s.insertColumn(o + t), this.quill.update(d.sources.USER); let a = n.rowOffset(); t === 0 && (a += 1), this.quill.setSelection(e.index + a, e.length, d.sources.SILENT); }
    insertColumnLeft() { this.insertColumn(0); }
    insertColumnRight() { this.insertColumn(1); }
    insertRow(t) { let e = this.quill.getSelection(); if (!e)
        return; let [s, n, i] = this.getTable(e); if (i == null)
        return; let o = n.rowOffset(); s.insertRow(o + t), this.quill.update(d.sources.USER), t > 0 ? this.quill.setSelection(e, d.sources.SILENT) : this.quill.setSelection(e.index + n.children.length, e.length, d.sources.SILENT); }
    insertRowAbove() { this.insertRow(0); }
    insertRowBelow() { this.insertRow(1); }
    insertTable(t, e) {
        let s = this.quill.getSelection();
        if (s == null)
            return;
        let n = new Array(t).fill(0).reduce(i => {
            let o = new Array(e).fill(`
`).join("");
            return i.insert(o, { table: Ks() });
        }, new Cc.default().retain(s.index));
        this.quill.updateContents(n, d.sources.USER), this.quill.setSelection(s.index, d.sources.SILENT), this.balanceTables();
    }
    listenBalanceCells() { this.quill.on(d.events.SCROLL_OPTIMIZE, t => { t.some(e => ["TD", "TR", "TBODY", "TABLE"].includes(e.target.tagName) ? (this.quill.once(d.events.TEXT_CHANGE, (s, n, i) => { i === d.sources.USER && this.balanceTables(); }), !0) : !1); }); }
}, _c = qi;
var kc = ot(lt(), 1);
var qc = ut("quill:toolbar"), Ii = (() => { class r extends k {
    constructor(e, s) { if (super(e, s), Array.isArray(this.options.container)) {
        let n = document.createElement("div");
        n.setAttribute("role", "toolbar"), ex(n, this.options.container), e.container?.parentNode?.insertBefore(n, e.container), this.container = n;
    }
    else
        typeof this.options.container == "string" ? this.container = document.querySelector(this.options.container) : this.container = this.options.container; if (!(this.container instanceof HTMLElement)) {
        qc.error("Container required for toolbar", this.options);
        return;
    } this.container.classList.add("ql-toolbar"), this.controls = [], this.handlers = {}, this.options.handlers && Object.keys(this.options.handlers).forEach(n => { let i = this.options.handlers?.[n]; i && this.addHandler(n, i); }), Array.from(this.container.querySelectorAll("button, select")).forEach(n => { this.attach(n); }), this.quill.on(d.events.EDITOR_CHANGE, () => { let [n] = this.quill.selection.getRange(); this.update(n); }); }
    addHandler(e, s) { this.handlers[e] = s; }
    attach(e) { let s = Array.from(e.classList).find(i => i.indexOf("ql-") === 0); if (!s)
        return; if (s = s.slice(3), e.tagName === "BUTTON" && e.setAttribute("type", "button"), this.handlers[s] == null && this.quill.scroll.query(s) == null) {
        qc.warn("ignoring attaching to nonexistent format", s, e);
        return;
    } let n = e.tagName === "SELECT" ? "change" : "click"; e.addEventListener(n, i => { let o; if (e.tagName === "SELECT") {
        if (e.selectedIndex < 0)
            return;
        let l = e.options[e.selectedIndex];
        l.hasAttribute("selected") ? o = !1 : o = l.value || !1;
    }
    else
        e.classList.contains("ql-active") ? o = !1 : o = e.value || !e.hasAttribute("value"), i.preventDefault(); this.quill.focus(); let [a] = this.quill.selection.getRange(); if (this.handlers[s] != null)
        this.handlers[s].call(this, o);
    else if (this.quill.scroll.query(s).prototype instanceof q) {
        if (o = prompt(`Enter ${s}`), !o)
            return;
        this.quill.updateContents(new kc.default().retain(a.index).delete(a.length).insert({ [s]: o }), d.sources.USER);
    }
    else
        this.quill.format(s, o, d.sources.USER); this.update(a); }), this.controls.push([s, e]); }
    update(e) { let s = e == null ? {} : this.quill.getFormat(e); this.controls.forEach(n => { let [i, o] = n; if (o.tagName === "SELECT") {
        let a = null;
        if (e == null)
            a = null;
        else if (s[i] == null)
            a = o.querySelector("option[selected]");
        else if (!Array.isArray(s[i])) {
            let l = s[i];
            typeof l == "string" && (l = l.replace(/"/g, '\\"')), a = o.querySelector(`option[value="${l}"]`);
        }
        a == null ? (o.value = "", o.selectedIndex = -1) : a.selected = !0;
    }
    else if (e == null)
        o.classList.remove("ql-active"), o.setAttribute("aria-pressed", "false");
    else if (o.hasAttribute("value")) {
        let a = s[i], l = a === o.getAttribute("value") || a != null && a.toString() === o.getAttribute("value") || a == null && !o.getAttribute("value");
        o.classList.toggle("ql-active", l), o.setAttribute("aria-pressed", l.toString());
    }
    else {
        let a = s[i] != null;
        o.classList.toggle("ql-active", a), o.setAttribute("aria-pressed", a.toString());
    } }); }
} return r.DEFAULTS = {}, r; })();
function Ic(r, t, e) { let s = document.createElement("button"); s.setAttribute("type", "button"), s.classList.add(`ql-${t}`), s.setAttribute("aria-pressed", "false"), e != null ? (s.value = e, s.setAttribute("aria-label", `${t}: ${e}`)) : s.setAttribute("aria-label", t), r.appendChild(s); }
function ex(r, t) { Array.isArray(t[0]) || (t = [t]), t.forEach(e => { let s = document.createElement("span"); s.classList.add("ql-formats"), e.forEach(n => { if (typeof n == "string")
    Ic(s, n);
else {
    let i = Object.keys(n)[0], o = n[i];
    Array.isArray(o) ? rx(s, i, o) : Ic(s, i, o);
} }), r.appendChild(s); }); }
function rx(r, t, e) { let s = document.createElement("select"); s.classList.add(`ql-${t}`), e.forEach(n => { let i = document.createElement("option"); n !== !1 ? i.setAttribute("value", String(n)) : i.setAttribute("selected", "selected"), s.appendChild(i); }), r.appendChild(s); }
Ii.DEFAULTS = { container: null, handlers: { clean() { let r = this.quill.getSelection(); if (r != null)
            if (r.length === 0) {
                let t = this.quill.getFormat();
                Object.keys(t).forEach(e => { this.quill.scroll.query(e, b.INLINE) != null && this.quill.format(e, !1, d.sources.USER); });
            }
            else
                this.quill.removeFormat(r.index, r.length, d.sources.USER); }, direction(r) { let { align: t } = this.quill.getFormat(); r === "rtl" && t == null ? this.quill.format("align", "right", d.sources.USER) : !r && t === "right" && this.quill.format("align", !1, d.sources.USER), this.quill.format("direction", r, d.sources.USER); }, indent(r) { let t = this.quill.getSelection(), e = this.quill.getFormat(t), s = parseInt(e.indent || 0, 10); if (r === "+1" || r === "-1") {
            let n = r === "+1" ? 1 : -1;
            e.direction === "rtl" && (n *= -1), this.quill.format("indent", s + n, d.sources.USER);
        } }, link(r) { r === !0 && (r = prompt("Enter link URL:")), this.quill.format("link", r, d.sources.USER); }, list(r) { let t = this.quill.getSelection(), e = this.quill.getFormat(t); r === "check" ? e.list === "checked" || e.list === "unchecked" ? this.quill.format("list", !1, d.sources.USER) : this.quill.format("list", "unchecked", d.sources.USER) : this.quill.format("list", r, d.sources.USER); } } };
var sx = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="3" x2="15" y1="9" y2="9"/><line class="ql-stroke" x1="3" x2="13" y1="14" y2="14"/><line class="ql-stroke" x1="3" x2="9" y1="4" y2="4"/></svg>', nx = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="15" x2="3" y1="9" y2="9"/><line class="ql-stroke" x1="14" x2="4" y1="14" y2="14"/><line class="ql-stroke" x1="12" x2="6" y1="4" y2="4"/></svg>', ix = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="15" x2="3" y1="9" y2="9"/><line class="ql-stroke" x1="15" x2="5" y1="14" y2="14"/><line class="ql-stroke" x1="15" x2="9" y1="4" y2="4"/></svg>', ox = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="15" x2="3" y1="9" y2="9"/><line class="ql-stroke" x1="15" x2="3" y1="14" y2="14"/><line class="ql-stroke" x1="15" x2="3" y1="4" y2="4"/></svg>', ax = '<svg viewbox="0 0 18 18"><g class="ql-fill ql-color-label"><polygon points="6 6.868 6 6 5 6 5 7 5.942 7 6 6.868"/><rect height="1" width="1" x="4" y="4"/><polygon points="6.817 5 6 5 6 6 6.38 6 6.817 5"/><rect height="1" width="1" x="2" y="6"/><rect height="1" width="1" x="3" y="5"/><rect height="1" width="1" x="4" y="7"/><polygon points="4 11.439 4 11 3 11 3 12 3.755 12 4 11.439"/><rect height="1" width="1" x="2" y="12"/><rect height="1" width="1" x="2" y="9"/><rect height="1" width="1" x="2" y="15"/><polygon points="4.63 10 4 10 4 11 4.192 11 4.63 10"/><rect height="1" width="1" x="3" y="8"/><path d="M10.832,4.2L11,4.582V4H10.708A1.948,1.948,0,0,1,10.832,4.2Z"/><path d="M7,4.582L7.168,4.2A1.929,1.929,0,0,1,7.292,4H7V4.582Z"/><path d="M8,13H7.683l-0.351.8a1.933,1.933,0,0,1-.124.2H8V13Z"/><rect height="1" width="1" x="12" y="2"/><rect height="1" width="1" x="11" y="3"/><path d="M9,3H8V3.282A1.985,1.985,0,0,1,9,3Z"/><rect height="1" width="1" x="2" y="3"/><rect height="1" width="1" x="6" y="2"/><rect height="1" width="1" x="3" y="2"/><rect height="1" width="1" x="5" y="3"/><rect height="1" width="1" x="9" y="2"/><rect height="1" width="1" x="15" y="14"/><polygon points="13.447 10.174 13.469 10.225 13.472 10.232 13.808 11 14 11 14 10 13.37 10 13.447 10.174"/><rect height="1" width="1" x="13" y="7"/><rect height="1" width="1" x="15" y="5"/><rect height="1" width="1" x="14" y="6"/><rect height="1" width="1" x="15" y="8"/><rect height="1" width="1" x="14" y="9"/><path d="M3.775,14H3v1H4V14.314A1.97,1.97,0,0,1,3.775,14Z"/><rect height="1" width="1" x="14" y="3"/><polygon points="12 6.868 12 6 11.62 6 12 6.868"/><rect height="1" width="1" x="15" y="2"/><rect height="1" width="1" x="12" y="5"/><rect height="1" width="1" x="13" y="4"/><polygon points="12.933 9 13 9 13 8 12.495 8 12.933 9"/><rect height="1" width="1" x="9" y="14"/><rect height="1" width="1" x="8" y="15"/><path d="M6,14.926V15H7V14.316A1.993,1.993,0,0,1,6,14.926Z"/><rect height="1" width="1" x="5" y="15"/><path d="M10.668,13.8L10.317,13H10v1h0.792A1.947,1.947,0,0,1,10.668,13.8Z"/><rect height="1" width="1" x="11" y="15"/><path d="M14.332,12.2a1.99,1.99,0,0,1,.166.8H15V12H14.245Z"/><rect height="1" width="1" x="14" y="15"/><rect height="1" width="1" x="15" y="11"/></g><polyline class="ql-stroke" points="5.5 13 9 5 12.5 13"/><line class="ql-stroke" x1="11.63" x2="6.38" y1="11" y2="11"/></svg>', lx = '<svg viewbox="0 0 18 18"><rect class="ql-fill ql-stroke" height="3" width="3" x="4" y="5"/><rect class="ql-fill ql-stroke" height="3" width="3" x="11" y="5"/><path class="ql-even ql-fill ql-stroke" d="M7,8c0,4.031-3,5-3,5"/><path class="ql-even ql-fill ql-stroke" d="M14,8c0,4.031-3,5-3,5"/></svg>', ux = '<svg viewbox="0 0 18 18"><path class="ql-stroke" d="M5,4H9.5A2.5,2.5,0,0,1,12,6.5v0A2.5,2.5,0,0,1,9.5,9H5A0,0,0,0,1,5,9V4A0,0,0,0,1,5,4Z"/><path class="ql-stroke" d="M5,9h5.5A2.5,2.5,0,0,1,13,11.5v0A2.5,2.5,0,0,1,10.5,14H5a0,0,0,0,1,0,0V9A0,0,0,0,1,5,9Z"/></svg>', cx = '<svg class="" viewbox="0 0 18 18"><line class="ql-stroke" x1="5" x2="13" y1="3" y2="3"/><line class="ql-stroke" x1="6" x2="9.35" y1="12" y2="3"/><line class="ql-stroke" x1="11" x2="15" y1="11" y2="15"/><line class="ql-stroke" x1="15" x2="11" y1="11" y2="15"/><rect class="ql-fill" height="1" rx="0.5" ry="0.5" width="7" x="2" y="14"/></svg>', Rc = '<svg viewbox="0 0 18 18"><polyline class="ql-even ql-stroke" points="5 7 3 9 5 11"/><polyline class="ql-even ql-stroke" points="13 7 15 9 13 11"/><line class="ql-stroke" x1="10" x2="8" y1="5" y2="13"/></svg>', fx = '<svg viewbox="0 0 18 18"><line class="ql-color-label ql-stroke ql-transparent" x1="3" x2="15" y1="15" y2="15"/><polyline class="ql-stroke" points="5.5 11 9 3 12.5 11"/><line class="ql-stroke" x1="11.63" x2="6.38" y1="9" y2="9"/></svg>', hx = '<svg viewbox="0 0 18 18"><polygon class="ql-stroke ql-fill" points="3 11 5 9 3 7 3 11"/><line class="ql-stroke ql-fill" x1="15" x2="11" y1="4" y2="4"/><path class="ql-fill" d="M11,3a3,3,0,0,0,0,6h1V3H11Z"/><rect class="ql-fill" height="11" width="1" x="11" y="4"/><rect class="ql-fill" height="11" width="1" x="13" y="4"/></svg>', dx = '<svg viewbox="0 0 18 18"><polygon class="ql-stroke ql-fill" points="15 12 13 10 15 8 15 12"/><line class="ql-stroke ql-fill" x1="9" x2="5" y1="4" y2="4"/><path class="ql-fill" d="M5,3A3,3,0,0,0,5,9H6V3H5Z"/><rect class="ql-fill" height="11" width="1" x="5" y="4"/><rect class="ql-fill" height="11" width="1" x="7" y="4"/></svg>', px = '<svg viewbox="0 0 18 18"><path class="ql-fill" d="M11.759,2.482a2.561,2.561,0,0,0-3.53.607A7.656,7.656,0,0,0,6.8,6.2C6.109,9.188,5.275,14.677,4.15,14.927a1.545,1.545,0,0,0-1.3-.933A0.922,0.922,0,0,0,2,15.036S1.954,16,4.119,16s3.091-2.691,3.7-5.553c0.177-.826.36-1.726,0.554-2.6L8.775,6.2c0.381-1.421.807-2.521,1.306-2.676a1.014,1.014,0,0,0,1.02.56A0.966,0.966,0,0,0,11.759,2.482Z"/><rect class="ql-fill" height="1.6" rx="0.8" ry="0.8" width="5" x="5.15" y="6.2"/><path class="ql-fill" d="M13.663,12.027a1.662,1.662,0,0,1,.266-0.276q0.193,0.069.456,0.138a2.1,2.1,0,0,0,.535.069,1.075,1.075,0,0,0,.767-0.3,1.044,1.044,0,0,0,.314-0.8,0.84,0.84,0,0,0-.238-0.619,0.8,0.8,0,0,0-.594-0.239,1.154,1.154,0,0,0-.781.3,4.607,4.607,0,0,0-.781,1q-0.091.15-.218,0.346l-0.246.38c-0.068-.288-0.137-0.582-0.212-0.885-0.459-1.847-2.494-.984-2.941-0.8-0.482.2-.353,0.647-0.094,0.529a0.869,0.869,0,0,1,1.281.585c0.217,0.751.377,1.436,0.527,2.038a5.688,5.688,0,0,1-.362.467,2.69,2.69,0,0,1-.264.271q-0.221-.08-0.471-0.147a2.029,2.029,0,0,0-.522-0.066,1.079,1.079,0,0,0-.768.3A1.058,1.058,0,0,0,9,15.131a0.82,0.82,0,0,0,.832.852,1.134,1.134,0,0,0,.787-0.3,5.11,5.11,0,0,0,.776-0.993q0.141-.219.215-0.34c0.046-.076.122-0.194,0.223-0.346a2.786,2.786,0,0,0,.918,1.726,2.582,2.582,0,0,0,2.376-.185c0.317-.181.212-0.565,0-0.494A0.807,0.807,0,0,1,14.176,15a5.159,5.159,0,0,1-.913-2.446l0,0Q13.487,12.24,13.663,12.027Z"/></svg>', mx = '<svg viewBox="0 0 18 18"><path class="ql-fill" d="M10,4V14a1,1,0,0,1-2,0V10H3v4a1,1,0,0,1-2,0V4A1,1,0,0,1,3,4V8H8V4a1,1,0,0,1,2,0Zm6.06787,9.209H14.98975V7.59863a.54085.54085,0,0,0-.605-.60547h-.62744a1.01119,1.01119,0,0,0-.748.29688L11.645,8.56641a.5435.5435,0,0,0-.022.8584l.28613.30762a.53861.53861,0,0,0,.84717.0332l.09912-.08789a1.2137,1.2137,0,0,0,.2417-.35254h.02246s-.01123.30859-.01123.60547V13.209H12.041a.54085.54085,0,0,0-.605.60547v.43945a.54085.54085,0,0,0,.605.60547h4.02686a.54085.54085,0,0,0,.605-.60547v-.43945A.54085.54085,0,0,0,16.06787,13.209Z"/></svg>', gx = '<svg viewBox="0 0 18 18"><path class="ql-fill" d="M16.73975,13.81445v.43945a.54085.54085,0,0,1-.605.60547H11.855a.58392.58392,0,0,1-.64893-.60547V14.0127c0-2.90527,3.39941-3.42187,3.39941-4.55469a.77675.77675,0,0,0-.84717-.78125,1.17684,1.17684,0,0,0-.83594.38477c-.2749.26367-.561.374-.85791.13184l-.4292-.34082c-.30811-.24219-.38525-.51758-.1543-.81445a2.97155,2.97155,0,0,1,2.45361-1.17676,2.45393,2.45393,0,0,1,2.68408,2.40918c0,2.45312-3.1792,2.92676-3.27832,3.93848h2.79443A.54085.54085,0,0,1,16.73975,13.81445ZM9,3A.99974.99974,0,0,0,8,4V8H3V4A1,1,0,0,0,1,4V14a1,1,0,0,0,2,0V10H8v4a1,1,0,0,0,2,0V4A.99974.99974,0,0,0,9,3Z"/></svg>', bx = '<svg viewBox="0 0 18 18"><path class="ql-fill" d="M16.65186,12.30664a2.6742,2.6742,0,0,1-2.915,2.68457,3.96592,3.96592,0,0,1-2.25537-.6709.56007.56007,0,0,1-.13232-.83594L11.64648,13c.209-.34082.48389-.36328.82471-.1543a2.32654,2.32654,0,0,0,1.12256.33008c.71484,0,1.12207-.35156,1.12207-.78125,0-.61523-.61621-.86816-1.46338-.86816H13.2085a.65159.65159,0,0,1-.68213-.41895l-.05518-.10937a.67114.67114,0,0,1,.14307-.78125l.71533-.86914a8.55289,8.55289,0,0,1,.68213-.7373V8.58887a3.93913,3.93913,0,0,1-.748.05469H11.9873a.54085.54085,0,0,1-.605-.60547V7.59863a.54085.54085,0,0,1,.605-.60547h3.75146a.53773.53773,0,0,1,.60547.59375v.17676a1.03723,1.03723,0,0,1-.27539.748L14.74854,10.0293A2.31132,2.31132,0,0,1,16.65186,12.30664ZM9,3A.99974.99974,0,0,0,8,4V8H3V4A1,1,0,0,0,1,4V14a1,1,0,0,0,2,0V10H8v4a1,1,0,0,0,2,0V4A.99974.99974,0,0,0,9,3Z"/></svg>', yx = '<svg viewBox="0 0 18 18"><path class="ql-fill" d="M10,4V14a1,1,0,0,1-2,0V10H3v4a1,1,0,0,1-2,0V4A1,1,0,0,1,3,4V8H8V4a1,1,0,0,1,2,0Zm7.05371,7.96582v.38477c0,.39648-.165.60547-.46191.60547h-.47314v1.29785a.54085.54085,0,0,1-.605.60547h-.69336a.54085.54085,0,0,1-.605-.60547V12.95605H11.333a.5412.5412,0,0,1-.60547-.60547v-.15332a1.199,1.199,0,0,1,.22021-.748l2.56348-4.05957a.7819.7819,0,0,1,.72607-.39648h1.27637a.54085.54085,0,0,1,.605.60547v3.7627h.33008A.54055.54055,0,0,1,17.05371,11.96582ZM14.28125,8.7207h-.022a4.18969,4.18969,0,0,1-.38525.81348l-1.188,1.80469v.02246h1.5293V9.60059A7.04058,7.04058,0,0,1,14.28125,8.7207Z"/></svg>', xx = '<svg viewBox="0 0 18 18"><path class="ql-fill" d="M16.74023,12.18555a2.75131,2.75131,0,0,1-2.91553,2.80566,3.908,3.908,0,0,1-2.25537-.68164.54809.54809,0,0,1-.13184-.8252L11.73438,13c.209-.34082.48389-.36328.8252-.1543a2.23757,2.23757,0,0,0,1.1001.33008,1.01827,1.01827,0,0,0,1.1001-.96777c0-.61621-.53906-.97949-1.25439-.97949a2.15554,2.15554,0,0,0-.64893.09961,1.15209,1.15209,0,0,1-.814.01074l-.12109-.04395a.64116.64116,0,0,1-.45117-.71484l.231-3.00391a.56666.56666,0,0,1,.62744-.583H15.541a.54085.54085,0,0,1,.605.60547v.43945a.54085.54085,0,0,1-.605.60547H13.41748l-.04395.72559a1.29306,1.29306,0,0,1-.04395.30859h.022a2.39776,2.39776,0,0,1,.57227-.07715A2.53266,2.53266,0,0,1,16.74023,12.18555ZM9,3A.99974.99974,0,0,0,8,4V8H3V4A1,1,0,0,0,1,4V14a1,1,0,0,0,2,0V10H8v4a1,1,0,0,0,2,0V4A.99974.99974,0,0,0,9,3Z"/></svg>', vx = '<svg viewBox="0 0 18 18"><path class="ql-fill" d="M14.51758,9.64453a1.85627,1.85627,0,0,0-1.24316.38477H13.252a1.73532,1.73532,0,0,1,1.72754-1.4082,2.66491,2.66491,0,0,1,.5498.06641c.35254.05469.57227.01074.70508-.40723l.16406-.5166a.53393.53393,0,0,0-.373-.75977,4.83723,4.83723,0,0,0-1.17773-.14258c-2.43164,0-3.7627,2.17773-3.7627,4.43359,0,2.47559,1.60645,3.69629,3.19043,3.69629A2.70585,2.70585,0,0,0,16.96,12.19727,2.43861,2.43861,0,0,0,14.51758,9.64453Zm-.23047,3.58691c-.67187,0-1.22168-.81445-1.22168-1.45215,0-.47363.30762-.583.72559-.583.96875,0,1.27734.59375,1.27734,1.12207A.82182.82182,0,0,1,14.28711,13.23145ZM10,4V14a1,1,0,0,1-2,0V10H3v4a1,1,0,0,1-2,0V4A1,1,0,0,1,3,4V8H8V4a1,1,0,0,1,2,0Z"/></svg>', Ax = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="7" x2="13" y1="4" y2="4"/><line class="ql-stroke" x1="5" x2="11" y1="14" y2="14"/><line class="ql-stroke" x1="8" x2="10" y1="14" y2="4"/></svg>', Ex = '<svg viewbox="0 0 18 18"><rect class="ql-stroke" height="10" width="12" x="3" y="4"/><circle class="ql-fill" cx="6" cy="7" r="1"/><polyline class="ql-even ql-fill" points="5 12 5 11 7 9 8 10 11 7 13 9 13 12 5 12"/></svg>', Tx = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="3" x2="15" y1="14" y2="14"/><line class="ql-stroke" x1="3" x2="15" y1="4" y2="4"/><line class="ql-stroke" x1="9" x2="15" y1="9" y2="9"/><polyline class="ql-fill ql-stroke" points="3 7 3 11 5 9 3 7"/></svg>', Nx = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="3" x2="15" y1="14" y2="14"/><line class="ql-stroke" x1="3" x2="15" y1="4" y2="4"/><line class="ql-stroke" x1="9" x2="15" y1="9" y2="9"/><polyline class="ql-stroke" points="5 7 5 11 3 9 5 7"/></svg>', wx = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="7" x2="11" y1="7" y2="11"/><path class="ql-even ql-stroke" d="M8.9,4.577a3.476,3.476,0,0,1,.36,4.679A3.476,3.476,0,0,1,4.577,8.9C3.185,7.5,2.035,6.4,4.217,4.217S7.5,3.185,8.9,4.577Z"/><path class="ql-even ql-stroke" d="M13.423,9.1a3.476,3.476,0,0,0-4.679-.36,3.476,3.476,0,0,0,.36,4.679c1.392,1.392,2.5,2.542,4.679.36S14.815,10.5,13.423,9.1Z"/></svg>', Sx = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="6" x2="15" y1="4" y2="4"/><line class="ql-stroke" x1="6" x2="15" y1="9" y2="9"/><line class="ql-stroke" x1="6" x2="15" y1="14" y2="14"/><line class="ql-stroke" x1="3" x2="3" y1="4" y2="4"/><line class="ql-stroke" x1="3" x2="3" y1="9" y2="9"/><line class="ql-stroke" x1="3" x2="3" y1="14" y2="14"/></svg>', Lx = '<svg class="" viewbox="0 0 18 18"><line class="ql-stroke" x1="9" x2="15" y1="4" y2="4"/><polyline class="ql-stroke" points="3 4 4 5 6 3"/><line class="ql-stroke" x1="9" x2="15" y1="14" y2="14"/><polyline class="ql-stroke" points="3 14 4 15 6 13"/><line class="ql-stroke" x1="9" x2="15" y1="9" y2="9"/><polyline class="ql-stroke" points="3 9 4 10 6 8"/></svg>', Ox = '<svg viewbox="0 0 18 18"><line class="ql-stroke" x1="7" x2="15" y1="4" y2="4"/><line class="ql-stroke" x1="7" x2="15" y1="9" y2="9"/><line class="ql-stroke" x1="7" x2="15" y1="14" y2="14"/><line class="ql-stroke ql-thin" x1="2.5" x2="4.5" y1="5.5" y2="5.5"/><path class="ql-fill" d="M3.5,6A0.5,0.5,0,0,1,3,5.5V3.085l-0.276.138A0.5,0.5,0,0,1,2.053,3c-0.124-.247-0.023-0.324.224-0.447l1-.5A0.5,0.5,0,0,1,4,2.5v3A0.5,0.5,0,0,1,3.5,6Z"/><path class="ql-stroke ql-thin" d="M4.5,10.5h-2c0-.234,1.85-1.076,1.85-2.234A0.959,0.959,0,0,0,2.5,8.156"/><path class="ql-stroke ql-thin" d="M2.5,14.846a0.959,0.959,0,0,0,1.85-.109A0.7,0.7,0,0,0,3.75,14a0.688,0.688,0,0,0,.6-0.736,0.959,0.959,0,0,0-1.85-.109"/></svg>', Cx = '<svg viewbox="0 0 18 18"><path class="ql-fill" d="M15.5,15H13.861a3.858,3.858,0,0,0,1.914-2.975,1.8,1.8,0,0,0-1.6-1.751A1.921,1.921,0,0,0,12.021,11.7a0.50013,0.50013,0,1,0,.957.291h0a0.914,0.914,0,0,1,1.053-.725,0.81,0.81,0,0,1,.744.762c0,1.076-1.16971,1.86982-1.93971,2.43082A1.45639,1.45639,0,0,0,12,15.5a0.5,0.5,0,0,0,.5.5h3A0.5,0.5,0,0,0,15.5,15Z"/><path class="ql-fill" d="M9.65,5.241a1,1,0,0,0-1.409.108L6,7.964,3.759,5.349A1,1,0,0,0,2.192,6.59178Q2.21541,6.6213,2.241,6.649L4.684,9.5,2.241,12.35A1,1,0,0,0,3.71,13.70722q0.02557-.02768.049-0.05722L6,11.036,8.241,13.65a1,1,0,1,0,1.567-1.24277Q9.78459,12.3777,9.759,12.35L7.316,9.5,9.759,6.651A1,1,0,0,0,9.65,5.241Z"/></svg>', _x = '<svg viewbox="0 0 18 18"><path class="ql-fill" d="M15.5,7H13.861a4.015,4.015,0,0,0,1.914-2.975,1.8,1.8,0,0,0-1.6-1.751A1.922,1.922,0,0,0,12.021,3.7a0.5,0.5,0,1,0,.957.291,0.917,0.917,0,0,1,1.053-.725,0.81,0.81,0,0,1,.744.762c0,1.077-1.164,1.925-1.934,2.486A1.423,1.423,0,0,0,12,7.5a0.5,0.5,0,0,0,.5.5h3A0.5,0.5,0,0,0,15.5,7Z"/><path class="ql-fill" d="M9.651,5.241a1,1,0,0,0-1.41.108L6,7.964,3.759,5.349a1,1,0,1,0-1.519,1.3L4.683,9.5,2.241,12.35a1,1,0,1,0,1.519,1.3L6,11.036,8.241,13.65a1,1,0,0,0,1.519-1.3L7.317,9.5,9.759,6.651A1,1,0,0,0,9.651,5.241Z"/></svg>', qx = '<svg viewbox="0 0 18 18"><line class="ql-stroke ql-thin" x1="15.5" x2="2.5" y1="8.5" y2="9.5"/><path class="ql-fill" d="M9.007,8C6.542,7.791,6,7.519,6,6.5,6,5.792,7.283,5,9,5c1.571,0,2.765.679,2.969,1.309a1,1,0,0,0,1.9-.617C13.356,4.106,11.354,3,9,3,6.2,3,4,4.538,4,6.5a3.2,3.2,0,0,0,.5,1.843Z"/><path class="ql-fill" d="M8.984,10C11.457,10.208,12,10.479,12,11.5c0,0.708-1.283,1.5-3,1.5-1.571,0-2.765-.679-2.969-1.309a1,1,0,1,0-1.9.617C4.644,13.894,6.646,15,9,15c2.8,0,5-1.538,5-3.5a3.2,3.2,0,0,0-.5-1.843Z"/></svg>', Ix = '<svg viewbox="0 0 18 18"><rect class="ql-stroke" height="12" width="12" x="3" y="3"/><rect class="ql-fill" height="2" width="3" x="5" y="5"/><rect class="ql-fill" height="2" width="4" x="9" y="5"/><g class="ql-fill ql-transparent"><rect height="2" width="3" x="5" y="8"/><rect height="2" width="4" x="9" y="8"/><rect height="2" width="3" x="5" y="11"/><rect height="2" width="4" x="9" y="11"/></g></svg>', kx = '<svg viewbox="0 0 18 18"><path class="ql-stroke" d="M5,3V9a4.012,4.012,0,0,0,4,4H9a4.012,4.012,0,0,0,4-4V3"/><rect class="ql-fill" height="1" rx="0.5" ry="0.5" width="12" x="3" y="15"/></svg>', Rx = '<svg viewbox="0 0 18 18"><rect class="ql-stroke" height="12" width="12" x="3" y="3"/><rect class="ql-fill" height="12" width="1" x="5" y="3"/><rect class="ql-fill" height="12" width="1" x="12" y="3"/><rect class="ql-fill" height="2" width="8" x="5" y="8"/><rect class="ql-fill" height="1" width="3" x="3" y="5"/><rect class="ql-fill" height="1" width="3" x="3" y="7"/><rect class="ql-fill" height="1" width="3" x="3" y="10"/><rect class="ql-fill" height="1" width="3" x="3" y="12"/><rect class="ql-fill" height="1" width="3" x="12" y="5"/><rect class="ql-fill" height="1" width="3" x="12" y="7"/><rect class="ql-fill" height="1" width="3" x="12" y="10"/><rect class="ql-fill" height="1" width="3" x="12" y="12"/></svg>', ie = { align: { "": sx, center: nx, right: ix, justify: ox }, background: ax, blockquote: lx, bold: ux, clean: cx, code: Rc, "code-block": Rc, color: fx, direction: { "": hx, rtl: dx }, formula: px, header: { 1: mx, 2: gx, 3: bx, 4: yx, 5: xx, 6: vx }, italic: Ax, image: Ex, indent: { "+1": Tx, "-1": Nx }, link: wx, list: { bullet: Sx, check: Lx, ordered: Ox }, script: { sub: Cx, super: _x }, strike: qx, table: Ix, underline: kx, video: Rx };
var Bx = '<svg viewbox="0 0 18 18"><polygon class="ql-stroke" points="7 11 9 13 11 11 7 11"/><polygon class="ql-stroke" points="7 7 9 5 11 7 7 7"/></svg>', Bc = 0;
function Mc(r, t) { r.setAttribute(t, `${r.getAttribute(t) !== "true"}`); }
var ki = class {
    constructor(t) { this.select = t, this.container = document.createElement("span"), this.buildPicker(), this.select.style.display = "none", this.select.parentNode.insertBefore(this.container, this.select), this.label.addEventListener("mousedown", () => { this.togglePicker(); }), this.label.addEventListener("keydown", e => { switch (e.key) {
        case "Enter":
            this.togglePicker();
            break;
        case "Escape":
            this.escape(), e.preventDefault();
            break;
        default:
    } }), this.select.addEventListener("change", this.update.bind(this)); }
    togglePicker() { this.container.classList.toggle("ql-expanded"), Mc(this.label, "aria-expanded"), Mc(this.options, "aria-hidden"); }
    buildItem(t) { let e = document.createElement("span"); e.tabIndex = "0", e.setAttribute("role", "button"), e.classList.add("ql-picker-item"); let s = t.getAttribute("value"); return s && e.setAttribute("data-value", s), t.textContent && e.setAttribute("data-label", t.textContent), e.addEventListener("click", () => { this.selectItem(e, !0); }), e.addEventListener("keydown", n => { switch (n.key) {
        case "Enter":
            this.selectItem(e, !0), n.preventDefault();
            break;
        case "Escape":
            this.escape(), n.preventDefault();
            break;
        default:
    } }), e; }
    buildLabel() { let t = document.createElement("span"); return t.classList.add("ql-picker-label"), t.innerHTML = Bx, t.tabIndex = "0", t.setAttribute("role", "button"), t.setAttribute("aria-expanded", "false"), this.container.appendChild(t), t; }
    buildOptions() { let t = document.createElement("span"); t.classList.add("ql-picker-options"), t.setAttribute("aria-hidden", "true"), t.tabIndex = "-1", t.id = `ql-picker-options-${Bc}`, Bc += 1, this.label.setAttribute("aria-controls", t.id), this.options = t, Array.from(this.select.options).forEach(e => { let s = this.buildItem(e); t.appendChild(s), e.selected === !0 && this.selectItem(s); }), this.container.appendChild(t); }
    buildPicker() { Array.from(this.select.attributes).forEach(t => { this.container.setAttribute(t.name, t.value); }), this.container.classList.add("ql-picker"), this.label = this.buildLabel(), this.buildOptions(); }
    escape() { this.close(), setTimeout(() => this.label.focus(), 1); }
    close() { this.container.classList.remove("ql-expanded"), this.label.setAttribute("aria-expanded", "false"), this.options.setAttribute("aria-hidden", "true"); }
    selectItem(t) { let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, s = this.container.querySelector(".ql-selected"); t !== s && (s?.classList.remove("ql-selected"), t != null && (t.classList.add("ql-selected"), this.select.selectedIndex = Array.from(t.parentNode.children).indexOf(t), t.hasAttribute("data-value") ? this.label.setAttribute("data-value", t.getAttribute("data-value")) : this.label.removeAttribute("data-value"), t.hasAttribute("data-label") ? this.label.setAttribute("data-label", t.getAttribute("data-label")) : this.label.removeAttribute("data-label"), e && (this.select.dispatchEvent(new Event("change")), this.close()))); }
    update() { let t; if (this.select.selectedIndex > -1) {
        let s = this.container.querySelector(".ql-picker-options").children[this.select.selectedIndex];
        t = this.select.options[this.select.selectedIndex], this.selectItem(s);
    }
    else
        this.selectItem(null); let e = t != null && t !== this.select.querySelector("option[selected]"); this.label.classList.toggle("ql-active", e); }
}, oe = ki;
var Ri = class extends oe {
    constructor(t, e) { super(t), this.label.innerHTML = e, this.container.classList.add("ql-color-picker"), Array.from(this.container.querySelectorAll(".ql-picker-item")).slice(0, 7).forEach(s => { s.classList.add("ql-primary"); }); }
    buildItem(t) { let e = super.buildItem(t); return e.style.backgroundColor = t.getAttribute("value") || "", e; }
    selectItem(t, e) { super.selectItem(t, e); let s = this.label.querySelector(".ql-color-label"), n = t && t.getAttribute("data-value") || ""; s && (s.tagName === "line" ? s.style.stroke = n : s.style.fill = n); }
}, Gs = Ri;
var Bi = class extends oe {
    constructor(t, e) { super(t), this.container.classList.add("ql-icon-picker"), Array.from(this.container.querySelectorAll(".ql-picker-item")).forEach(s => { s.innerHTML = e[s.getAttribute("data-value") || ""]; }), this.defaultItem = this.container.querySelector(".ql-selected"), this.selectItem(this.defaultItem); }
    selectItem(t, e) { super.selectItem(t, e); let s = t || this.defaultItem; if (s != null) {
        if (this.label.innerHTML === s.innerHTML)
            return;
        this.label.innerHTML = s.innerHTML;
    } }
}, Vs = Bi;
var Mx = r => { let { overflowY: t } = getComputedStyle(r, null); return t !== "visible" && t !== "clip"; }, Mi = class {
    constructor(t, e) { this.quill = t, this.boundsContainer = e || document.body, this.root = t.addContainer("ql-tooltip"), this.root.innerHTML = this.constructor.TEMPLATE, Mx(this.quill.root) && this.quill.root.addEventListener("scroll", () => { this.root.style.marginTop = `${-1 * this.quill.root.scrollTop}px`; }), this.hide(); }
    hide() { this.root.classList.add("ql-hidden"); }
    position(t) { let e = t.left + t.width / 2 - this.root.offsetWidth / 2, s = t.bottom + this.quill.root.scrollTop; this.root.style.left = `${e}px`, this.root.style.top = `${s}px`, this.root.classList.remove("ql-flip"); let n = this.boundsContainer.getBoundingClientRect(), i = this.root.getBoundingClientRect(), o = 0; if (i.right > n.right && (o = n.right - i.right, this.root.style.left = `${e + o}px`), i.left < n.left && (o = n.left - i.left, this.root.style.left = `${e + o}px`), i.bottom > n.bottom) {
        let a = i.bottom - i.top, l = t.bottom - t.top + a;
        this.root.style.top = `${s - l}px`, this.root.classList.add("ql-flip");
    } return o; }
    show() { this.root.classList.remove("ql-editing"), this.root.classList.remove("ql-hidden"); }
}, Ws = Mi;
var Dx = [!1, "center", "right", "justify"], jx = ["#000000", "#e60000", "#ff9900", "#ffff00", "#008a00", "#0066cc", "#9933ff", "#ffffff", "#facccc", "#ffebcc", "#ffffcc", "#cce8cc", "#cce0f5", "#ebd6ff", "#bbbbbb", "#f06666", "#ffc266", "#ffff66", "#66b966", "#66a3e0", "#c285ff", "#888888", "#a10000", "#b26b00", "#b2b200", "#006100", "#0047b2", "#6b24b2", "#444444", "#5c0000", "#663d00", "#666600", "#003700", "#002966", "#3d1466"], Px = [!1, "serif", "monospace"], Ux = ["1", "2", "3", !1], Fx = ["small", !1, "large", "huge"], Pt = class extends Qe {
    constructor(t, e) { super(t, e); let s = n => { if (!document.body.contains(t.root)) {
        document.body.removeEventListener("click", s);
        return;
    } this.tooltip != null && !this.tooltip.root.contains(n.target) && document.activeElement !== this.tooltip.textbox && !this.quill.hasFocus() && this.tooltip.hide(), this.pickers != null && this.pickers.forEach(i => { i.container.contains(n.target) || i.close(); }); }; t.emitter.listenDOM("click", document.body, s); }
    addModule(t) { let e = super.addModule(t); return t === "toolbar" && this.extendToolbar(e), e; }
    buildButtons(t, e) { Array.from(t).forEach(s => { (s.getAttribute("class") || "").split(/\s+/).forEach(i => { if (i.startsWith("ql-") && (i = i.slice(3), e[i] != null))
        if (i === "direction")
            s.innerHTML = e[i][""] + e[i].rtl;
        else if (typeof e[i] == "string")
            s.innerHTML = e[i];
        else {
            let o = s.value || "";
            o != null && e[i][o] && (s.innerHTML = e[i][o]);
        } }); }); }
    buildPickers(t, e) { this.pickers = Array.from(t).map(n => { if (n.classList.contains("ql-align") && (n.querySelector("option") == null && qr(n, Dx), typeof e.align == "object"))
        return new Vs(n, e.align); if (n.classList.contains("ql-background") || n.classList.contains("ql-color")) {
        let i = n.classList.contains("ql-background") ? "background" : "color";
        return n.querySelector("option") == null && qr(n, jx, i === "background" ? "#ffffff" : "#000000"), new Gs(n, e[i]);
    } return n.querySelector("option") == null && (n.classList.contains("ql-font") ? qr(n, Px) : n.classList.contains("ql-header") ? qr(n, Ux) : n.classList.contains("ql-size") && qr(n, Fx)), new oe(n); }); let s = () => { this.pickers.forEach(n => { n.update(); }); }; this.quill.on(x.events.EDITOR_CHANGE, s); }
};
Pt.DEFAULTS = tt({}, Qe.DEFAULTS, { modules: { toolbar: { handlers: { formula() { this.quill.theme.tooltip.edit("formula"); }, image() { let r = this.container.querySelector("input.ql-image[type=file]"); r == null && (r = document.createElement("input"), r.setAttribute("type", "file"), r.setAttribute("accept", this.quill.uploader.options.mimetypes.join(", ")), r.classList.add("ql-image"), r.addEventListener("change", () => { let t = this.quill.getSelection(!0); this.quill.uploader.upload(t, r.files), r.value = ""; }), this.container.appendChild(r)), r.click(); }, video() { this.quill.theme.tooltip.edit("video"); } } } } });
var tr = class extends Ws {
    constructor(t, e) { super(t, e), this.textbox = this.root.querySelector('input[type="text"]'), this.listen(); }
    listen() { this.textbox.addEventListener("keydown", t => { t.key === "Enter" ? (this.save(), t.preventDefault()) : t.key === "Escape" && (this.cancel(), t.preventDefault()); }); }
    cancel() { this.hide(), this.restoreFocus(); }
    edit() { let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "link", e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null; if (this.root.classList.remove("ql-hidden"), this.root.classList.add("ql-editing"), this.textbox == null)
        return; e != null ? this.textbox.value = e : t !== this.root.getAttribute("data-mode") && (this.textbox.value = ""); let s = this.quill.getBounds(this.quill.selection.savedRange); s != null && this.position(s), this.textbox.select(), this.textbox.setAttribute("placeholder", this.textbox.getAttribute(`data-${t}`) || ""), this.root.setAttribute("data-mode", t); }
    restoreFocus() { this.quill.focus({ preventScroll: !0 }); }
    save() { let { value: t } = this.textbox; switch (this.root.getAttribute("data-mode")) {
        case "link": {
            let { scrollTop: e } = this.quill.root;
            this.linkRange ? (this.quill.formatText(this.linkRange, "link", t, x.sources.USER), delete this.linkRange) : (this.restoreFocus(), this.quill.format("link", t, x.sources.USER)), this.quill.root.scrollTop = e;
            break;
        }
        case "video": t = Hx(t);
        case "formula": {
            if (!t)
                break;
            let e = this.quill.getSelection(!0);
            if (e != null) {
                let s = e.index + e.length;
                this.quill.insertEmbed(s, this.root.getAttribute("data-mode"), t, x.sources.USER), this.root.getAttribute("data-mode") === "formula" && this.quill.insertText(s + 1, " ", x.sources.USER), this.quill.setSelection(s + 2, x.sources.USER);
            }
            break;
        }
        default:
    } this.textbox.value = "", this.hide(); }
};
function Hx(r) { let t = r.match(/^(?:(https?):\/\/)?(?:(?:www|m)\.)?youtube\.com\/watch.*v=([a-zA-Z0-9_-]+)/) || r.match(/^(?:(https?):\/\/)?(?:(?:www|m)\.)?youtu\.be\/([a-zA-Z0-9_-]+)/); return t ? `${t[1] || "https"}://www.youtube.com/embed/${t[2]}?showinfo=0` : (t = r.match(/^(?:(https?):\/\/)?(?:www\.)?vimeo\.com\/(\d+)/)) ? `${t[1] || "https"}://player.vimeo.com/video/${t[2]}/` : r; }
function qr(r, t) { let e = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1; t.forEach(s => { let n = document.createElement("option"); s === e ? n.setAttribute("selected", "selected") : n.setAttribute("value", String(s)), r.appendChild(n); }); }
var zx = [["bold", "italic", "link"], [{ header: 1 }, { header: 2 }, "blockquote"]], Di = class extends tr {
    static TEMPLATE = ['<span class="ql-tooltip-arrow"></span>', '<div class="ql-tooltip-editor">', '<input type="text" data-formula="e=mc^2" data-link="https://quilljs.com" data-video="Embed URL">', '<a class="ql-close"></a>', "</div>"].join("");
    constructor(t, e) { super(t, e), this.quill.on(x.events.EDITOR_CHANGE, (s, n, i, o) => { if (s === x.events.SELECTION_CHANGE)
        if (n != null && n.length > 0 && o === x.sources.USER) {
            this.show(), this.root.style.left = "0px", this.root.style.width = "", this.root.style.width = `${this.root.offsetWidth}px`;
            let a = this.quill.getLines(n.index, n.length);
            if (a.length === 1) {
                let l = this.quill.getBounds(n);
                l != null && this.position(l);
            }
            else {
                let l = a[a.length - 1], u = this.quill.getIndex(l), c = Math.min(l.length() - 1, n.index + n.length - u), f = this.quill.getBounds(new Q(u, c));
                f != null && this.position(f);
            }
        }
        else
            document.activeElement !== this.textbox && this.quill.hasFocus() && this.hide(); }); }
    listen() { super.listen(), this.root.querySelector(".ql-close").addEventListener("click", () => { this.root.classList.remove("ql-editing"); }), this.quill.on(x.events.SCROLL_OPTIMIZE, () => { setTimeout(() => { if (this.root.classList.contains("ql-hidden"))
        return; let t = this.quill.getSelection(); if (t != null) {
        let e = this.quill.getBounds(t);
        e != null && this.position(e);
    } }, 1); }); }
    cancel() { this.show(); }
    position(t) { let e = super.position(t), s = this.root.querySelector(".ql-tooltip-arrow"); return s.style.marginLeft = "", e !== 0 && (s.style.marginLeft = `${-1 * e - s.offsetWidth / 2}px`), e; }
}, Ir = class extends Pt {
    constructor(t, e) { e.modules.toolbar != null && e.modules.toolbar.container == null && (e.modules.toolbar.container = zx), super(t, e), this.quill.container.classList.add("ql-bubble"); }
    extendToolbar(t) { this.tooltip = new Di(this.quill, this.options.bounds), t.container != null && (this.tooltip.root.appendChild(t.container), this.buildButtons(t.container.querySelectorAll("button"), ie), this.buildPickers(t.container.querySelectorAll("select"), ie)); }
};
Ir.DEFAULTS = tt({}, Pt.DEFAULTS, { modules: { toolbar: { handlers: { link(r) { r ? this.quill.theme.tooltip.edit() : this.quill.format("link", !1, d.sources.USER); } } } } });
var $x = [[{ header: ["1", "2", "3", !1] }], ["bold", "italic", "underline", "link"], [{ list: "ordered" }, { list: "bullet" }], ["clean"]], ji = class extends tr {
    static TEMPLATE = ['<a class="ql-preview" rel="noopener noreferrer" target="_blank" href="about:blank"></a>', '<input type="text" data-formula="e=mc^2" data-link="https://quilljs.com" data-video="Embed URL">', '<a class="ql-action"></a>', '<a class="ql-remove"></a>'].join("");
    preview = this.root.querySelector("a.ql-preview");
    listen() { super.listen(), this.root.querySelector("a.ql-action").addEventListener("click", t => { this.root.classList.contains("ql-editing") ? this.save() : this.edit("link", this.preview.textContent), t.preventDefault(); }), this.root.querySelector("a.ql-remove").addEventListener("click", t => { if (this.linkRange != null) {
        let e = this.linkRange;
        this.restoreFocus(), this.quill.formatText(e, "link", !1, x.sources.USER), delete this.linkRange;
    } t.preventDefault(), this.hide(); }), this.quill.on(x.events.SELECTION_CHANGE, (t, e, s) => { if (t != null) {
        if (t.length === 0 && s === x.sources.USER) {
            let [n, i] = this.quill.scroll.descendant(ve, t.index);
            if (n != null) {
                this.linkRange = new Q(t.index - i, n.length());
                let o = ve.formats(n.domNode);
                this.preview.textContent = o, this.preview.setAttribute("href", o), this.show();
                let a = this.quill.getBounds(this.linkRange);
                a != null && this.position(a);
                return;
            }
        }
        else
            delete this.linkRange;
        this.hide();
    } }); }
    show() { super.show(), this.root.removeAttribute("data-mode"); }
}, Zs = class extends Pt {
    constructor(t, e) { e.modules.toolbar != null && e.modules.toolbar.container == null && (e.modules.toolbar.container = $x), super(t, e), this.quill.container.classList.add("ql-snow"); }
    extendToolbar(t) { t.container != null && (t.container.classList.add("ql-snow"), this.buildButtons(t.container.querySelectorAll("button"), ie), this.buildPickers(t.container.querySelectorAll("select"), ie), this.tooltip = new ji(this.quill, this.options.bounds), t.container.querySelector(".ql-link") && this.quill.keyboard.addBinding({ key: "k", shortKey: !0 }, (e, s) => { t.handlers.link.call(t, !s.format.link); })); }
};
Zs.DEFAULTS = tt({}, Pt.DEFAULTS, { modules: { toolbar: { handlers: { link(r) { if (r) {
                    let t = this.quill.getSelection();
                    if (t == null || t.length === 0)
                        return;
                    let e = this.quill.getText(t);
                    /^\S+@\S+\.\S+$/.test(e) && e.indexOf("mailto:") !== 0 && (e = `mailto:${e}`);
                    let { tooltip: s } = this.quill.theme;
                    s.edit("link", e);
                }
                else
                    this.quill.format("link", !1, d.sources.USER); } } } } });
var Dc = Zs;
Us.register({ "attributors/attribute/direction": ks, "attributors/class/align": mi, "attributors/class/background": Ju, "attributors/class/color": Yu, "attributors/class/direction": bi, "attributors/class/font": xi, "attributors/class/size": vi, "attributors/style/align": Is, "attributors/style/background": Nr, "attributors/style/color": Tr, "attributors/style/direction": Rs, "attributors/style/font": Bs, "attributors/style/size": Ms }, !0);
Us.register({ "formats/align": mi, "formats/direction": bi, "formats/indent": bc, "formats/background": Nr, "formats/color": Tr, "formats/font": xi, "formats/size": vi, "formats/blockquote": yc, "formats/code-block": F, "formats/header": xc, "formats/list": Fs, "formats/bold": Je, "formats/code": tc, "formats/italic": vc, "formats/link": ve, "formats/script": Ac, "formats/strike": Ec, "formats/underline": Tc, "formats/formula": Nc, "formats/image": Sc, "formats/video": Oc, "modules/syntax": _r, "modules/table": _c, "modules/toolbar": Ii, "themes/bubble": Ir, "themes/snow": Dc, "ui/icons": ie, "ui/picker": oe, "ui/icon-picker": Vs, "ui/color-picker": Gs, "ui/tooltip": Ws }, !0);
var A4 = Us;
var export_AttributeMap = se.AttributeMap;
var export_Delta = se.default;
var export_Op = se.Op;
var export_OpIterator = se.OpIterator;
export { export_AttributeMap as AttributeMap, export_Delta as Delta, k as Module, export_Op as Op, export_OpIterator as OpIterator, ur as Parchment, Q as Range, A4 as default };
/*! Bundled license information:

lodash-es/lodash.js:
  (**
   * @license
   * Lodash (Custom Build) <https://lodash.com/>
   * Build: `lodash modularize exports="es" -o ./`
   * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
   * Released under MIT license <https://lodash.com/license>
   * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
   * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
   *)
*/
