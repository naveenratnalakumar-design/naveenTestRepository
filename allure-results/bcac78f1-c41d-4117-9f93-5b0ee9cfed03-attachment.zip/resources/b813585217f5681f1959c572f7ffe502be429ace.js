import { ConnectableObservable as t } from "rxjs";
var o = class {
};
function e(n) { return n && typeof n.connect == "function" && !(n instanceof t); }
export { o as a, e as b };
