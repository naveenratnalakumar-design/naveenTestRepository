import * as e from "@angular/core";
import "@angular/core";
var d = (() => {
    class t {
        static \u0275fac = function (o) { return new (o || t); };
        static \u0275cmp = e.\u0275\u0275defineComponent({ type: t, selectors: [["structural-styles"]], decls: 0, vars: 0, template: function (o, a) { }, styles: [`.mat-focus-indicator{position:relative}.mat-focus-indicator::before{top:0;left:0;right:0;bottom:0;position:absolute;box-sizing:border-box;pointer-events:none;display:var(--mat-focus-indicator-display, none);border-width:var(--mat-focus-indicator-border-width, 3px);border-style:var(--mat-focus-indicator-border-style, solid);border-color:var(--mat-focus-indicator-border-color, transparent);border-radius:var(--mat-focus-indicator-border-radius, 4px)}.mat-focus-indicator:focus::before{content:""}@media(forced-colors: active){html{--mat-focus-indicator-display: block}}
`], encapsulation: 2, changeDetection: 0 });
    }
    return t;
})();
export { d as a };
