import { a as Sc } from "@nf-internal/chunk-WG3LFJXC";
import { a as p, b as I, d as yt, f as Ie, h as Fn, i as d } from "@nf-internal/chunk-66YHNWRR";
var Xa = {};
Ie(Xa, { blockAPICallsBeforeInitialize: () => U, blockAcquireTokenInPopups: () => Ja, blockNonBrowserEnvironment: () => D, blockRedirectInIframe: () => ja, blockReloadInHiddenIframes: () => Wa, clearHash: () => ea, createGuid: () => oa, getCurrentUri: () => Ae, getHomepage: () => ra, invoke: () => fe, invokeAsync: () => f, isInIframe: () => kn, isInPopup: () => Ya, preconnect: () => bn, preflightCheck: () => _n, redirectPreflightCheck: () => Ei, replaceHash: () => ta });
var u = { LIBRARY_NAME: "MSAL.JS", SKU: "msal.js.common", CACHE_PREFIX: "msal", DEFAULT_AUTHORITY: "https://login.microsoftonline.com/common/", DEFAULT_AUTHORITY_HOST: "login.microsoftonline.com", DEFAULT_COMMON_TENANT: "common", ADFS: "adfs", DSTS: "dstsv2", AAD_INSTANCE_DISCOVERY_ENDPT: "https://login.microsoftonline.com/common/discovery/instance?api-version=1.1&authorization_endpoint=", CIAM_AUTH_URL: ".ciamlogin.com", AAD_TENANT_DOMAIN_SUFFIX: ".onmicrosoft.com", RESOURCE_DELIM: "|", NO_ACCOUNT: "NO_ACCOUNT", CLAIMS: "claims", CONSUMER_UTID: "9188040d-6c67-4c5b-b112-36a304b66dad", OPENID_SCOPE: "openid", PROFILE_SCOPE: "profile", OFFLINE_ACCESS_SCOPE: "offline_access", EMAIL_SCOPE: "email", CODE_RESPONSE_TYPE: "code", CODE_GRANT_TYPE: "authorization_code", RT_GRANT_TYPE: "refresh_token", FRAGMENT_RESPONSE_MODE: "fragment", S256_CODE_CHALLENGE_METHOD: "S256", URL_FORM_CONTENT_TYPE: "application/x-www-form-urlencoded;charset=utf-8", AUTHORIZATION_PENDING: "authorization_pending", NOT_DEFINED: "not_defined", EMPTY_STRING: "", NOT_APPLICABLE: "N/A", NOT_AVAILABLE: "Not Available", FORWARD_SLASH: "/", IMDS_ENDPOINT: "http://169.254.169.254/metadata/instance/compute/location", IMDS_VERSION: "2020-06-01", IMDS_TIMEOUT: 2e3, AZURE_REGION_AUTO_DISCOVER_FLAG: "TryAutoDetect", REGIONAL_AUTH_PUBLIC_CLOUD_SUFFIX: "login.microsoft.com", KNOWN_PUBLIC_CLOUDS: ["login.microsoftonline.com", "login.windows.net", "login.microsoft.com", "sts.windows.net"], TOKEN_RESPONSE_TYPE: "token", ID_TOKEN_RESPONSE_TYPE: "id_token", SHR_NONCE_VALIDITY: 240, INVALID_INSTANCE: "invalid_instance" }, lo = { SUCCESS: 200, SUCCESS_RANGE_START: 200, SUCCESS_RANGE_END: 299, REDIRECT: 302, CLIENT_ERROR: 400, CLIENT_ERROR_RANGE_START: 400, BAD_REQUEST: 400, UNAUTHORIZED: 401, NOT_FOUND: 404, REQUEST_TIMEOUT: 408, TOO_MANY_REQUESTS: 429, CLIENT_ERROR_RANGE_END: 499, SERVER_ERROR: 500, SERVER_ERROR_RANGE_START: 500, SERVICE_UNAVAILABLE: 503, GATEWAY_TIMEOUT: 504, SERVER_ERROR_RANGE_END: 599, MULTI_SIDED_ERROR: 600 }, ce = [u.OPENID_SCOPE, u.PROFILE_SCOPE, u.OFFLINE_ACCESS_SCOPE], $i = [...ce, u.EMAIL_SCOPE], V = { CONTENT_TYPE: "Content-Type", CONTENT_LENGTH: "Content-Length", RETRY_AFTER: "Retry-After", CCS_HEADER: "X-AnchorMailbox", WWWAuthenticate: "WWW-Authenticate", AuthenticationInfo: "Authentication-Info", X_MS_REQUEST_ID: "x-ms-request-id", X_MS_HTTP_VERSION: "x-ms-httpver" }, X = { ID_TOKEN: "idtoken", CLIENT_INFO: "client.info", ADAL_ID_TOKEN: "adal.idtoken", ERROR: "error", ERROR_DESC: "error.description", ACTIVE_ACCOUNT: "active-account", ACTIVE_ACCOUNT_FILTERS: "active-account-filters" }, Me = { COMMON: "common", ORGANIZATIONS: "organizations", CONSUMERS: "consumers" }, ho = { ACCESS_TOKEN: "access_token", XMS_CC: "xms_cc" }, G = { LOGIN: "login", SELECT_ACCOUNT: "select_account", CONSENT: "consent", NONE: "none", CREATE: "create", NO_SESSION: "no_session" }, Kn = { PLAIN: "plain", S256: "S256" }, Ue = { QUERY: "query", FRAGMENT: "fragment" }, Vi = I(p({}, Ue), { FORM_POST: "form_post" }), Po = { IMPLICIT_GRANT: "implicit", AUTHORIZATION_CODE_GRANT: "authorization_code", CLIENT_CREDENTIALS_GRANT: "client_credentials", RESOURCE_OWNER_PASSWORD_GRANT: "password", REFRESH_TOKEN_GRANT: "refresh_token", DEVICE_CODE_GRANT: "device_code", JWT_BEARER: "urn:ietf:params:oauth:grant-type:jwt-bearer" }, uo = { MSSTS_ACCOUNT_TYPE: "MSSTS", ADFS_ACCOUNT_TYPE: "ADFS", MSAV1_ACCOUNT_TYPE: "MSA", GENERIC_ACCOUNT_TYPE: "Generic" }, J = { CACHE_KEY_SEPARATOR: "-", CLIENT_INFO_SEPARATOR: "." }, S = { ID_TOKEN: "IdToken", ACCESS_TOKEN: "AccessToken", ACCESS_TOKEN_WITH_AUTH_SCHEME: "AccessToken_With_AuthScheme", REFRESH_TOKEN: "RefreshToken" };
var No = "appmetadata", da = "client_info", It = "1", mo = { CACHE_KEY: "authority-metadata", REFRESH_TIME_SECONDS: 3600 * 24 }, me = { CONFIG: "config", CACHE: "cache", NETWORK: "network", HARDCODED_VALUES: "hardcoded_values" }, te = { SCHEMA_VERSION: 5, MAX_CUR_HEADER_BYTES: 80, MAX_LAST_HEADER_BYTES: 330, MAX_CACHED_ERRORS: 50, CACHE_KEY: "server-telemetry", CATEGORY_SEPARATOR: "|", VALUE_SEPARATOR: ",", OVERFLOW_TRUE: "1", OVERFLOW_FALSE: "0", UNKNOWN_ERROR: "unknown_error" }, b = { BEARER: "Bearer", POP: "pop", SSH: "ssh-cert" }, tt = { DEFAULT_THROTTLE_TIME_SECONDS: 60, DEFAULT_MAX_THROTTLE_TIME_SECONDS: 3600, THROTTLING_PREFIX: "throttling", X_MS_LIB_CAPABILITY_VALUE: "retry-after, h429" }, qn = { INVALID_GRANT_ERROR: "invalid_grant", CLIENT_MISMATCH_ERROR: "client_mismatch" }, Gn = { username: "username", password: "password" }, Oo = { httpSuccess: 200, httpBadRequest: 400 }, Yt = { FAILED_AUTO_DETECTION: "1", INTERNAL_CACHE: "2", ENVIRONMENT_VARIABLE: "3", IMDS: "4" }, zn = { CONFIGURED_MATCHES_DETECTED: "1", CONFIGURED_NO_AUTO_DETECTION: "2", CONFIGURED_NOT_DETECTED: "3", AUTO_DETECTION_REQUESTED_SUCCESSFUL: "4", AUTO_DETECTION_REQUESTED_FAILED: "5" }, Le = { NOT_APPLICABLE: "0", FORCE_REFRESH_OR_CLAIMS: "1", NO_CACHED_ACCESS_TOKEN: "2", CACHED_ACCESS_TOKEN_EXPIRED: "3", PROACTIVELY_REFRESHED: "4" }, $n = { Jwt: "JWT", Jwk: "JWK", Pop: "pop" };
var Qi = 300;
var Wt = {};
Ie(Wt, { postRequestFailed: () => Uo, unexpectedError: () => Mo });
var Mo = "unexpected_error", Uo = "post_request_failed";
var Vn = { [Mo]: "Unexpected error in authentication.", [Uo]: "Post request failed from the network, could be a 4xx/5xx or a network unavailability. Please check the exact error code for details." }, ha = { unexpectedError: { code: Mo, desc: Vn[Mo] }, postRequestFailed: { code: Uo, desc: Vn[Uo] } }, w = class n extends Error {
    constructor(e, t, r) { let o = t ? `${e}: ${t}` : e; super(o), Object.setPrototypeOf(this, n.prototype), this.errorCode = e || u.EMPTY_STRING, this.errorMessage = t || u.EMPTY_STRING, this.subError = r || u.EMPTY_STRING, this.name = "AuthError"; }
    setCorrelationId(e) { this.correlationId = e; }
};
function Lo(n, e) { return new w(n, e ? `${Vn[n]} ${e}` : Vn[n]); }
var F = {};
Ie(F, { authTimeNotFound: () => rt, authorizationCodeMissingFromServerResponse: () => dr, bindingKeyNotRemoved: () => hr, cannotAppendScopeSet: () => ar, cannotRemoveEmptyScope: () => sr, clientInfoDecodingError: () => St, clientInfoEmptyError: () => jt, deviceCodeExpired: () => Bo, deviceCodePollingCancelled: () => Ho, deviceCodeUnknownError: () => Fo, emptyInputScopeSet: () => Rt, endSessionEndpointNotSupported: () => ur, endpointResolutionError: () => ge, hashNotDeserialized: () => er, invalidAssertion: () => Go, invalidCacheEnvironment: () => nt, invalidCacheRecord: () => cr, invalidClientCredential: () => zo, invalidState: () => De, keyIdMissing: () => mr, maxAgeTranspired: () => or, methodNotImplemented: () => k, missingTenantIdError: () => Yo, multipleMatchingAccounts: () => xo, multipleMatchingAppMetadata: () => nr, multipleMatchingTokens: () => Do, nestedAppAuthBridgeDisabled: () => Wo, networkError: () => Xt, noAccountFound: () => Ko, noAccountInSilentRequest: () => ot, noCryptoObject: () => kt, noNetworkConnectivity: () => Vo, nonceMismatch: () => rr, nullOrEmptyToken: () => Jt, openIdConfigError: () => Zt, requestCannotBeMade: () => ir, stateMismatch: () => tr, stateNotFound: () => wt, tokenClaimsCnfRequiredForSignedJwt: () => lr, tokenParsingError: () => vt, tokenRefreshRequired: () => Ve, unexpectedCredentialType: () => qo, userCanceled: () => Qo, userTimeoutReached: () => $o });
var St = "client_info_decoding_error", jt = "client_info_empty_error", vt = "token_parsing_error", Jt = "null_or_empty_token", ge = "endpoints_resolution_error", Xt = "network_error", Zt = "openid_config_error", er = "hash_not_deserialized", De = "invalid_state", tr = "state_mismatch", wt = "state_not_found", rr = "nonce_mismatch", rt = "auth_time_not_found", or = "max_age_transpired", Do = "multiple_matching_tokens", xo = "multiple_matching_accounts", nr = "multiple_matching_appMetadata", ir = "request_cannot_be_made", sr = "cannot_remove_empty_scope", ar = "cannot_append_scopeset", Rt = "empty_input_scopeset", Ho = "device_code_polling_cancelled", Bo = "device_code_expired", Fo = "device_code_unknown_error", ot = "no_account_in_silent_request", cr = "invalid_cache_record", nt = "invalid_cache_environment", Ko = "no_account_found", kt = "no_crypto_object", qo = "unexpected_credential_type", Go = "invalid_assertion", zo = "invalid_client_credential", Ve = "token_refresh_required", $o = "user_timeout_reached", lr = "token_claims_cnf_required_for_signedjwt", dr = "authorization_code_missing_from_server_response", hr = "binding_key_not_removed", ur = "end_session_endpoint_not_supported", mr = "key_id_missing", Vo = "no_network_connectivity", Qo = "user_canceled", Yo = "missing_tenant_id_error", k = "method_not_implemented", Wo = "nested_app_auth_bridge_disabled";
var _ = { [St]: "The client info could not be parsed/decoded correctly", [jt]: "The client info was empty", [vt]: "Token cannot be parsed", [Jt]: "The token is null or empty", [ge]: "Endpoints cannot be resolved", [Xt]: "Network request failed", [Zt]: "Could not retrieve endpoints. Check your authority and verify the .well-known/openid-configuration endpoint returns the required endpoints.", [er]: "The hash parameters could not be deserialized", [De]: "State was not the expected format", [tr]: "State mismatch error", [wt]: "State not found", [rr]: "Nonce mismatch error", [rt]: "Max Age was requested and the ID token is missing the auth_time variable. auth_time is an optional claim and is not enabled by default - it must be enabled. See https://aka.ms/msaljs/optional-claims for more information.", [or]: "Max Age is set to 0, or too much time has elapsed since the last end-user authentication.", [Do]: "The cache contains multiple tokens satisfying the requirements. Call AcquireToken again providing more requirements such as authority or account.", [xo]: "The cache contains multiple accounts satisfying the given parameters. Please pass more info to obtain the correct account", [nr]: "The cache contains multiple appMetadata satisfying the given parameters. Please pass more info to obtain the correct appMetadata", [ir]: "Token request cannot be made without authorization code or refresh token.", [sr]: "Cannot remove null or empty scope from ScopeSet", [ar]: "Cannot append ScopeSet", [Rt]: "Empty input ScopeSet cannot be processed", [Ho]: "Caller has cancelled token endpoint polling during device code flow by setting DeviceCodeRequest.cancel = true.", [Bo]: "Device code is expired.", [Fo]: "Device code stopped polling for unknown reasons.", [ot]: "Please pass an account object, silent flow is not supported without account information", [cr]: "Cache record object was null or undefined.", [nt]: "Invalid environment when attempting to create cache entry", [Ko]: "No account found in cache for given key.", [kt]: "No crypto object detected.", [qo]: "Unexpected credential type.", [Go]: "Client assertion must meet requirements described in https://tools.ietf.org/html/rfc7515", [zo]: "Client credential (secret, certificate, or assertion) must not be empty when creating a confidential client. An application should at most have one credential", [Ve]: "Cannot return token from cache because it must be refreshed. This may be due to one of the following reasons: forceRefresh parameter is set to true, claims have been requested, there is no cached access token or it is expired.", [$o]: "User defined timeout for device code polling reached", [lr]: "Cannot generate a POP jwt if the token_claims are not populated", [dr]: "Server response does not contain an authorization code to proceed", [hr]: "Could not remove the credential's binding key from storage.", [ur]: "The provided authority does not support logout", [mr]: "A keyId value is missing from the requested bound token's cache record and is required to match the token to it's stored binding key.", [Vo]: "No network connectivity. Check your internet connection.", [Qo]: "User cancelled the flow.", [Yo]: "A tenant id - not common, organizations, or consumers - must be specified when using the client_credentials flow.", [k]: "This method has not been implemented", [Wo]: "The nested app auth bridge is disabled" }, ua = { clientInfoDecodingError: { code: St, desc: _[St] }, clientInfoEmptyError: { code: jt, desc: _[jt] }, tokenParsingError: { code: vt, desc: _[vt] }, nullOrEmptyToken: { code: Jt, desc: _[Jt] }, endpointResolutionError: { code: ge, desc: _[ge] }, networkError: { code: Xt, desc: _[Xt] }, unableToGetOpenidConfigError: { code: Zt, desc: _[Zt] }, hashNotDeserialized: { code: er, desc: _[er] }, invalidStateError: { code: De, desc: _[De] }, stateMismatchError: { code: tr, desc: _[tr] }, stateNotFoundError: { code: wt, desc: _[wt] }, nonceMismatchError: { code: rr, desc: _[rr] }, authTimeNotFoundError: { code: rt, desc: _[rt] }, maxAgeTranspired: { code: or, desc: _[or] }, multipleMatchingTokens: { code: Do, desc: _[Do] }, multipleMatchingAccounts: { code: xo, desc: _[xo] }, multipleMatchingAppMetadata: { code: nr, desc: _[nr] }, tokenRequestCannotBeMade: { code: ir, desc: _[ir] }, removeEmptyScopeError: { code: sr, desc: _[sr] }, appendScopeSetError: { code: ar, desc: _[ar] }, emptyInputScopeSetError: { code: Rt, desc: _[Rt] }, DeviceCodePollingCancelled: { code: Ho, desc: _[Ho] }, DeviceCodeExpired: { code: Bo, desc: _[Bo] }, DeviceCodeUnknownError: { code: Fo, desc: _[Fo] }, NoAccountInSilentRequest: { code: ot, desc: _[ot] }, invalidCacheRecord: { code: cr, desc: _[cr] }, invalidCacheEnvironment: { code: nt, desc: _[nt] }, noAccountFound: { code: Ko, desc: _[Ko] }, noCryptoObj: { code: kt, desc: _[kt] }, unexpectedCredentialType: { code: qo, desc: _[qo] }, invalidAssertion: { code: Go, desc: _[Go] }, invalidClientCredential: { code: zo, desc: _[zo] }, tokenRefreshRequired: { code: Ve, desc: _[Ve] }, userTimeoutReached: { code: $o, desc: _[$o] }, tokenClaimsRequired: { code: lr, desc: _[lr] }, noAuthorizationCodeFromServer: { code: dr, desc: _[dr] }, bindingKeyNotRemovedError: { code: hr, desc: _[hr] }, logoutNotSupported: { code: ur, desc: _[ur] }, keyIdMissing: { code: mr, desc: _[mr] }, noNetworkConnectivity: { code: Vo, desc: _[Vo] }, userCanceledError: { code: Qo, desc: _[Qo] }, missingTenantIdError: { code: Yo, desc: _[Yo] }, nestedAppAuthBridgeDisabled: { code: Wo, desc: _[Wo] } }, Se = class n extends w {
    constructor(e, t) { super(e, t ? `${_[e]}: ${t}` : _[e]), this.name = "ClientAuthError", Object.setPrototypeOf(this, n.prototype); }
};
function m(n, e) { return new Se(n, e); }
var _e = { createNewGuid: () => { throw m(k); }, base64Decode: () => { throw m(k); }, base64Encode: () => { throw m(k); }, base64UrlEncode: () => { throw m(k); }, encodeKid: () => { throw m(k); }, getPublicKeyThumbprint() { return d(this, null, function* () { throw m(k); }); }, removeTokenBindingKey() { return d(this, null, function* () { throw m(k); }); }, clearKeystore() { return d(this, null, function* () { throw m(k); }); }, signJwt() { return d(this, null, function* () { throw m(k); }); }, hashString() { return d(this, null, function* () { throw m(k); }); } };
var H = (function (n) { return n[n.Error = 0] = "Error", n[n.Warning = 1] = "Warning", n[n.Info = 2] = "Info", n[n.Verbose = 3] = "Verbose", n[n.Trace = 4] = "Trace", n; })(H || {}), ae = class n {
    constructor(e, t, r) { this.level = H.Info; let o = () => { }, i = e || n.createDefaultLoggerOptions(); this.localCallback = i.loggerCallback || o, this.piiLoggingEnabled = i.piiLoggingEnabled || !1, this.level = typeof i.logLevel == "number" ? i.logLevel : H.Info, this.correlationId = i.correlationId || u.EMPTY_STRING, this.packageName = t || u.EMPTY_STRING, this.packageVersion = r || u.EMPTY_STRING; }
    static createDefaultLoggerOptions() { return { loggerCallback: () => { }, piiLoggingEnabled: !1, logLevel: H.Info }; }
    clone(e, t, r) { return new n({ loggerCallback: this.localCallback, piiLoggingEnabled: this.piiLoggingEnabled, logLevel: this.level, correlationId: r || this.correlationId }, e, t); }
    logMessage(e, t) { if (t.logLevel > this.level || !this.piiLoggingEnabled && t.containsPii)
        return; let i = `${`[${new Date().toUTCString()}] : [${t.correlationId || this.correlationId || ""}]`} : ${this.packageName}@${this.packageVersion} : ${H[t.logLevel]} - ${e}`; this.executeCallback(t.logLevel, i, t.containsPii || !1); }
    executeCallback(e, t, r) { this.localCallback && this.localCallback(e, t, r); }
    error(e, t) { this.logMessage(e, { logLevel: H.Error, containsPii: !1, correlationId: t || u.EMPTY_STRING }); }
    errorPii(e, t) { this.logMessage(e, { logLevel: H.Error, containsPii: !0, correlationId: t || u.EMPTY_STRING }); }
    warning(e, t) { this.logMessage(e, { logLevel: H.Warning, containsPii: !1, correlationId: t || u.EMPTY_STRING }); }
    warningPii(e, t) { this.logMessage(e, { logLevel: H.Warning, containsPii: !0, correlationId: t || u.EMPTY_STRING }); }
    info(e, t) { this.logMessage(e, { logLevel: H.Info, containsPii: !1, correlationId: t || u.EMPTY_STRING }); }
    infoPii(e, t) { this.logMessage(e, { logLevel: H.Info, containsPii: !0, correlationId: t || u.EMPTY_STRING }); }
    verbose(e, t) { this.logMessage(e, { logLevel: H.Verbose, containsPii: !1, correlationId: t || u.EMPTY_STRING }); }
    verbosePii(e, t) { this.logMessage(e, { logLevel: H.Verbose, containsPii: !0, correlationId: t || u.EMPTY_STRING }); }
    trace(e, t) { this.logMessage(e, { logLevel: H.Trace, containsPii: !1, correlationId: t || u.EMPTY_STRING }); }
    tracePii(e, t) { this.logMessage(e, { logLevel: H.Trace, containsPii: !0, correlationId: t || u.EMPTY_STRING }); }
    isPiiLoggingEnabled() { return this.piiLoggingEnabled || !1; }
};
var Qn = "@azure/msal-common", go = "14.16.0";
var _t = { None: "none", AzurePublic: "https://login.microsoftonline.com", AzurePpe: "https://login.windows-ppe.net", AzureChina: "https://login.chinacloudapi.cn", AzureGermany: "https://login.microsoftonline.de", AzureUsGovernment: "https://login.microsoftonline.us" };
var K = {};
Ie(K, { createAccessTokenEntity: () => ji, createIdTokenEntity: () => Wi, createRefreshTokenEntity: () => Ji, generateAppMetadataKey: () => Lc, generateAuthorityMetadataExpiresAt: () => Wn, generateCredentialKey: () => Jo, isAccessTokenEntity: () => wc, isAppMetadataEntity: () => Dc, isAuthorityMetadataEntity: () => xc, isAuthorityMetadataExpired: () => jn, isCredentialEntity: () => Yn, isIdTokenEntity: () => Rc, isRefreshTokenEntity: () => kc, isServerTelemetryEntity: () => Mc, isThrottlingEntity: () => Uc, updateAuthorityEndpointMetadata: () => fo, updateCloudDiscoveryMetadata: () => Xo });
var xe = {};
Ie(xe, { checkMaxAge: () => jo, extractTokenClaims: () => it, getJWSPayload: () => ma });
function it(n, e) { let t = ma(n); try {
    let r = e(t);
    return JSON.parse(r);
}
catch {
    throw m(vt);
} }
function ma(n) { if (!n)
    throw m(Jt); let t = /^([^\.\s]*)\.([^\.\s]+)\.([^\.\s]*)$/.exec(n); if (!t || t.length < 4)
    throw m(vt); return t[2]; }
function jo(n, e) { if (e === 0 || Date.now() - 3e5 > n + e)
    throw m(or); }
var Qe = {};
Ie(Qe, { delay: () => vc, isTokenExpired: () => po, nowSeconds: () => ve, wasClockTurnedBack: () => Yi });
function ve() { return Math.round(new Date().getTime() / 1e3); }
function po(n, e) { let t = Number(n) || 0; return ve() + e > t; }
function Yi(n) { return Number(n) > ve(); }
function vc(n, e) { return new Promise(t => setTimeout(() => t(e), n)); }
function Jo(n) { return [_c(n), bc(n), Pc(n), Nc(n), Oc(n)].join(J.CACHE_KEY_SEPARATOR).toLowerCase(); }
function Wi(n, e, t, r, o) { return { credentialType: S.ID_TOKEN, homeAccountId: n, environment: e, clientId: r, secret: t, realm: o }; }
function ji(n, e, t, r, o, i, s, a, l, h, g, T, y, v, L) { let x = { homeAccountId: n, credentialType: S.ACCESS_TOKEN, secret: t, cachedAt: ve().toString(), expiresOn: s.toString(), extendedExpiresOn: a.toString(), environment: e, clientId: r, realm: o, target: i, tokenType: g || b.BEARER }; if (T && (x.userAssertionHash = T), h && (x.refreshOn = h.toString()), v && (x.requestedClaims = v, x.requestedClaimsHash = L), x.tokenType?.toLowerCase() !== b.BEARER.toLowerCase())
    switch (x.credentialType = S.ACCESS_TOKEN_WITH_AUTH_SCHEME, x.tokenType) {
        case b.POP:
            let de = it(t, l);
            if (!de?.cnf?.kid)
                throw m(lr);
            x.keyId = de.cnf.kid;
            break;
        case b.SSH: x.keyId = y;
    } return x; }
function Ji(n, e, t, r, o, i, s) { let a = { credentialType: S.REFRESH_TOKEN, homeAccountId: n, environment: e, clientId: r, secret: t }; return i && (a.userAssertionHash = i), o && (a.familyId = o), s && (a.expiresOn = s.toString()), a; }
function Yn(n) { return n.hasOwnProperty("homeAccountId") && n.hasOwnProperty("environment") && n.hasOwnProperty("credentialType") && n.hasOwnProperty("clientId") && n.hasOwnProperty("secret"); }
function wc(n) { return n ? Yn(n) && n.hasOwnProperty("realm") && n.hasOwnProperty("target") && (n.credentialType === S.ACCESS_TOKEN || n.credentialType === S.ACCESS_TOKEN_WITH_AUTH_SCHEME) : !1; }
function Rc(n) { return n ? Yn(n) && n.hasOwnProperty("realm") && n.credentialType === S.ID_TOKEN : !1; }
function kc(n) { return n ? Yn(n) && n.credentialType === S.REFRESH_TOKEN : !1; }
function _c(n) { return [n.homeAccountId, n.environment].join(J.CACHE_KEY_SEPARATOR).toLowerCase(); }
function bc(n) { let e = n.credentialType === S.REFRESH_TOKEN && n.familyId || n.clientId; return [n.credentialType, e, n.realm || ""].join(J.CACHE_KEY_SEPARATOR).toLowerCase(); }
function Pc(n) { return (n.target || "").toLowerCase(); }
function Nc(n) { return (n.requestedClaimsHash || "").toLowerCase(); }
function Oc(n) { return n.tokenType && n.tokenType.toLowerCase() !== b.BEARER.toLowerCase() ? n.tokenType.toLowerCase() : ""; }
function Mc(n, e) { let t = n.indexOf(te.CACHE_KEY) === 0, r = !0; return e && (r = e.hasOwnProperty("failedRequests") && e.hasOwnProperty("errors") && e.hasOwnProperty("cacheHits")), t && r; }
function Uc(n, e) { let t = !1; n && (t = n.indexOf(tt.THROTTLING_PREFIX) === 0); let r = !0; return e && (r = e.hasOwnProperty("throttleTime")), t && r; }
function Lc({ environment: n, clientId: e }) { return [No, n, e].join(J.CACHE_KEY_SEPARATOR).toLowerCase(); }
function Dc(n, e) { return e ? n.indexOf(No) === 0 && e.hasOwnProperty("clientId") && e.hasOwnProperty("environment") : !1; }
function xc(n, e) { return e ? n.indexOf(mo.CACHE_KEY) === 0 && e.hasOwnProperty("aliases") && e.hasOwnProperty("preferred_cache") && e.hasOwnProperty("preferred_network") && e.hasOwnProperty("canonical_authority") && e.hasOwnProperty("authorization_endpoint") && e.hasOwnProperty("token_endpoint") && e.hasOwnProperty("issuer") && e.hasOwnProperty("aliasesFromNetwork") && e.hasOwnProperty("endpointsFromNetwork") && e.hasOwnProperty("expiresAt") && e.hasOwnProperty("jwks_uri") : !1; }
function Wn() { return ve() + mo.REFRESH_TIME_SECONDS; }
function fo(n, e, t) { n.authorization_endpoint = e.authorization_endpoint, n.token_endpoint = e.token_endpoint, n.end_session_endpoint = e.end_session_endpoint, n.issuer = e.issuer, n.endpointsFromNetwork = t, n.jwks_uri = e.jwks_uri; }
function Xo(n, e, t) { n.aliases = e.aliases, n.preferred_cache = e.preferred_cache, n.preferred_network = e.preferred_network, n.aliasesFromNetwork = t; }
function jn(n) { return n.expiresAt <= ve(); }
var He = {};
Ie(He, { authorityMismatch: () => on, authorityUriInsecure: () => pr, cannotAllowNativeBroker: () => rn, cannotSetOIDCOptions: () => tn, claimsRequestParsingError: () => Zo, emptyInputScopesError: () => Cr, invalidAuthenticationHeader: () => Pt, invalidAuthorityMetadata: () => Ir, invalidClaims: () => st, invalidCloudDiscoveryMetadata: () => bt, invalidCodeChallengeMethod: () => yr, invalidPromptValue: () => Tr, logoutRequestEmpty: () => Er, missingNonceAuthenticationHeader: () => vr, missingSshJwk: () => ct, missingSshKid: () => en, pkceParamsMissing: () => at, redirectUriEmpty: () => gr, tokenRequestEmpty: () => Ar, untrustedAuthority: () => Sr, urlEmptyError: () => fr, urlParseError: () => Ye });
var gr = "redirect_uri_empty", Zo = "claims_request_parsing_error", pr = "authority_uri_insecure", Ye = "url_parse_error", fr = "empty_url_error", Cr = "empty_input_scopes_error", Tr = "invalid_prompt_value", st = "invalid_claims", Ar = "token_request_empty", Er = "logout_request_empty", yr = "invalid_code_challenge_method", at = "pkce_params_missing", bt = "invalid_cloud_discovery_metadata", Ir = "invalid_authority_metadata", Sr = "untrusted_authority", ct = "missing_ssh_jwk", en = "missing_ssh_kid", vr = "missing_nonce_authentication_header", Pt = "invalid_authentication_header", tn = "cannot_set_OIDCOptions", rn = "cannot_allow_native_broker", on = "authority_mismatch";
var Y = { [gr]: "A redirect URI is required for all calls, and none has been set.", [Zo]: "Could not parse the given claims request object.", [pr]: "Authority URIs must use https.  Please see here for valid authority configuration options: https://docs.microsoft.com/en-us/azure/active-directory/develop/msal-js-initializing-client-applications#configuration-options", [Ye]: "URL could not be parsed into appropriate segments.", [fr]: "URL was empty or null.", [Cr]: "Scopes cannot be passed as null, undefined or empty array because they are required to obtain an access token.", [Tr]: "Please see here for valid configuration options: https://azuread.github.io/microsoft-authentication-library-for-js/ref/modules/_azure_msal_common.html#commonauthorizationurlrequest", [st]: "Given claims parameter must be a stringified JSON object.", [Ar]: "Token request was empty and not found in cache.", [Er]: "The logout request was null or undefined.", [yr]: 'code_challenge_method passed is invalid. Valid values are "plain" and "S256".', [at]: "Both params: code_challenge and code_challenge_method are to be passed if to be sent in the request", [bt]: "Invalid cloudDiscoveryMetadata provided. Must be a stringified JSON object containing tenant_discovery_endpoint and metadata fields", [Ir]: "Invalid authorityMetadata provided. Must by a stringified JSON object containing authorization_endpoint, token_endpoint, issuer fields.", [Sr]: "The provided authority is not a trusted authority. Please include this authority in the knownAuthorities config parameter.", [ct]: "Missing sshJwk in SSH certificate request. A stringified JSON Web Key is required when using the SSH authentication scheme.", [en]: "Missing sshKid in SSH certificate request. A string that uniquely identifies the public SSH key is required when using the SSH authentication scheme.", [vr]: "Unable to find an authentication header containing server nonce. Either the Authentication-Info or WWW-Authenticate headers must be present in order to obtain a server nonce.", [Pt]: "Invalid authentication header provided", [tn]: "Cannot set OIDCOptions parameter. Please change the protocol mode to OIDC or use a non-Microsoft authority.", [rn]: "Cannot set allowNativeBroker parameter to true when not in AAD protocol mode.", [on]: "Authority mismatch error. Authority provided in login request or PublicClientApplication config does not match the environment of the provided account. Please use a matching account or make an interactive request to login to this authority." }, ga = { redirectUriNotSet: { code: gr, desc: Y[gr] }, claimsRequestParsingError: { code: Zo, desc: Y[Zo] }, authorityUriInsecure: { code: pr, desc: Y[pr] }, urlParseError: { code: Ye, desc: Y[Ye] }, urlEmptyError: { code: fr, desc: Y[fr] }, emptyScopesError: { code: Cr, desc: Y[Cr] }, invalidPrompt: { code: Tr, desc: Y[Tr] }, invalidClaimsRequest: { code: st, desc: Y[st] }, tokenRequestEmptyError: { code: Ar, desc: Y[Ar] }, logoutRequestEmptyError: { code: Er, desc: Y[Er] }, invalidCodeChallengeMethod: { code: yr, desc: Y[yr] }, invalidCodeChallengeParams: { code: at, desc: Y[at] }, invalidCloudDiscoveryMetadata: { code: bt, desc: Y[bt] }, invalidAuthorityMetadata: { code: Ir, desc: Y[Ir] }, untrustedAuthority: { code: Sr, desc: Y[Sr] }, missingSshJwk: { code: ct, desc: Y[ct] }, missingSshKid: { code: en, desc: Y[en] }, missingNonceAuthenticationHeader: { code: vr, desc: Y[vr] }, invalidAuthenticationHeader: { code: Pt, desc: Y[Pt] }, cannotSetOIDCOptions: { code: tn, desc: Y[tn] }, cannotAllowNativeBroker: { code: rn, desc: Y[rn] }, authorityMismatch: { code: on, desc: Y[on] } }, nn = class n extends w {
    constructor(e) { super(e, Y[e]), this.name = "ClientConfigurationError", Object.setPrototypeOf(this, n.prototype); }
};
function N(n) { return new nn(n); }
var Q = class {
    static isEmptyObj(e) { if (e)
        try {
            let t = JSON.parse(e);
            return Object.keys(t).length === 0;
        }
        catch { } return !0; }
    static startsWith(e, t) { return e.indexOf(t) === 0; }
    static endsWith(e, t) { return e.length >= t.length && e.lastIndexOf(t) === e.length - t.length; }
    static queryStringToObject(e) { let t = {}, r = e.split("&"), o = i => decodeURIComponent(i.replace(/\+/g, " ")); return r.forEach(i => { if (i.trim()) {
        let [s, a] = i.split(/=(.+)/g, 2);
        s && a && (t[o(s)] = o(a));
    } }), t; }
    static trimArrayEntries(e) { return e.map(t => t.trim()); }
    static removeEmptyStringsFromArray(e) { return e.filter(t => !!t); }
    static jsonParseHelper(e) { try {
        return JSON.parse(e);
    }
    catch {
        return null;
    } }
    static matchPattern(e, t) { return new RegExp(e.replace(/\\/g, "\\\\").replace(/\*/g, "[^ ]*").replace(/\?/g, "\\?")).test(t); }
};
var z = class n {
    constructor(e) { let t = e ? Q.trimArrayEntries([...e]) : [], r = t ? Q.removeEmptyStringsFromArray(t) : []; this.validateInputScopes(r), this.scopes = new Set, r.forEach(o => this.scopes.add(o)); }
    static fromString(e) { let r = (e || u.EMPTY_STRING).split(" "); return new n(r); }
    static createSearchScopes(e) { let t = new n(e); return t.containsOnlyOIDCScopes() ? t.removeScope(u.OFFLINE_ACCESS_SCOPE) : t.removeOIDCScopes(), t; }
    validateInputScopes(e) { if (!e || e.length < 1)
        throw N(Cr); }
    containsScope(e) { let t = this.printScopesLowerCase().split(" "), r = new n(t); return e ? r.scopes.has(e.toLowerCase()) : !1; }
    containsScopeSet(e) { return !e || e.scopes.size <= 0 ? !1 : this.scopes.size >= e.scopes.size && e.asArray().every(t => this.containsScope(t)); }
    containsOnlyOIDCScopes() { let e = 0; return $i.forEach(t => { this.containsScope(t) && (e += 1); }), this.scopes.size === e; }
    appendScope(e) { e && this.scopes.add(e.trim()); }
    appendScopes(e) { try {
        e.forEach(t => this.appendScope(t));
    }
    catch {
        throw m(ar);
    } }
    removeScope(e) { if (!e)
        throw m(sr); this.scopes.delete(e.trim()); }
    removeOIDCScopes() { $i.forEach(e => { this.scopes.delete(e); }); }
    unionScopeSets(e) { if (!e)
        throw m(Rt); let t = new Set; return e.scopes.forEach(r => t.add(r.toLowerCase())), this.scopes.forEach(r => t.add(r.toLowerCase())), t; }
    intersectingScopeSets(e) { if (!e)
        throw m(Rt); e.containsOnlyOIDCScopes() || e.removeOIDCScopes(); let t = this.unionScopeSets(e), r = e.getScopeCount(), o = this.getScopeCount(); return t.size < o + r; }
    getScopeCount() { return this.scopes.size; }
    asArray() { let e = []; return this.scopes.forEach(t => e.push(t)), e; }
    printScopes() { return this.scopes ? this.asArray().join(" ") : u.EMPTY_STRING; }
    printScopesLowerCase() { return this.printScopes().toLowerCase(); }
};
function Co(n, e) { if (!n)
    throw m(jt); try {
    let t = e(n);
    return JSON.parse(t);
}
catch {
    throw m(St);
} }
function lt(n) { if (!n)
    throw m(St); let e = n.split(J.CLIENT_INFO_SEPARATOR, 2); return { uid: e[0], utid: e.length < 2 ? u.EMPTY_STRING : e[1] }; }
function To(n, e) { return !!n && !!e && n === e.split(".")[1]; }
function Nt(n, e, t, r) { if (r) {
    let { oid: o, sub: i, tid: s, name: a, tfp: l, acr: h } = r, g = s || l || h || "";
    return { tenantId: g, localAccountId: o || i || "", name: a, isHomeTenant: To(g, n) };
}
else
    return { tenantId: t, localAccountId: e, isHomeTenant: To(t, n) }; }
function wr(n, e, t, r) { let o = n; if (e) {
    let i = e, { isHomeTenant: a } = i, l = yt(i, ["isHomeTenant"]);
    o = p(p({}, n), l);
} if (t) {
    let s = Nt(n.homeAccountId, n.localAccountId, n.tenantId, t), { isHomeTenant: a } = s, l = yt(s, ["isHomeTenant"]);
    return o = I(p(p({}, o), l), { idTokenClaims: t, idToken: r }), o;
} return o; }
var pe = { Default: 0, Adfs: 1, Dsts: 2, Ciam: 3 };
function Jn(n) { return n && (n.tid || n.tfp || n.acr) || null; }
var le = { AAD: "AAD", OIDC: "OIDC" };
var B = class n {
    generateAccountId() { return [this.homeAccountId, this.environment].join(J.CACHE_KEY_SEPARATOR).toLowerCase(); }
    generateAccountKey() { return n.generateAccountCacheKey({ homeAccountId: this.homeAccountId, environment: this.environment, tenantId: this.realm, username: this.username, localAccountId: this.localAccountId }); }
    getAccountInfo() { return { homeAccountId: this.homeAccountId, environment: this.environment, tenantId: this.realm, username: this.username, localAccountId: this.localAccountId, name: this.name, nativeAccountId: this.nativeAccountId, authorityType: this.authorityType, tenantProfiles: new Map((this.tenantProfiles || []).map(e => [e.tenantId, e])) }; }
    isSingleTenant() { return !this.tenantProfiles; }
    static generateAccountCacheKey(e) { let t = e.homeAccountId.split(".")[1]; return [e.homeAccountId, e.environment || "", t || e.tenantId || ""].join(J.CACHE_KEY_SEPARATOR).toLowerCase(); }
    static createAccount(e, t, r) { let o = new n; t.authorityType === pe.Adfs ? o.authorityType = uo.ADFS_ACCOUNT_TYPE : t.protocolMode === le.AAD ? o.authorityType = uo.MSSTS_ACCOUNT_TYPE : o.authorityType = uo.GENERIC_ACCOUNT_TYPE; let i; e.clientInfo && r && (i = Co(e.clientInfo, r)), o.clientInfo = e.clientInfo, o.homeAccountId = e.homeAccountId, o.nativeAccountId = e.nativeAccountId; let s = e.environment || t && t.getPreferredCache(); if (!s)
        throw m(nt); o.environment = s, o.realm = i?.utid || Jn(e.idTokenClaims) || "", o.localAccountId = i?.uid || e.idTokenClaims?.oid || e.idTokenClaims?.sub || ""; let a = e.idTokenClaims?.preferred_username || e.idTokenClaims?.upn, l = e.idTokenClaims?.emails ? e.idTokenClaims.emails[0] : null; if (o.username = a || l || "", o.name = e.idTokenClaims?.name || "", o.cloudGraphHostName = e.cloudGraphHostName, o.msGraphHost = e.msGraphHost, e.tenantProfiles)
        o.tenantProfiles = e.tenantProfiles;
    else {
        let h = Nt(e.homeAccountId, o.localAccountId, o.realm, e.idTokenClaims);
        o.tenantProfiles = [h];
    } return o; }
    static createFromAccountInfo(e, t, r) { let o = new n; return o.authorityType = e.authorityType || uo.GENERIC_ACCOUNT_TYPE, o.homeAccountId = e.homeAccountId, o.localAccountId = e.localAccountId, o.nativeAccountId = e.nativeAccountId, o.realm = e.tenantId, o.environment = e.environment, o.username = e.username, o.name = e.name, o.cloudGraphHostName = t, o.msGraphHost = r, o.tenantProfiles = Array.from(e.tenantProfiles?.values() || []), o; }
    static generateHomeAccountId(e, t, r, o, i) { if (!(t === pe.Adfs || t === pe.Dsts)) {
        if (e)
            try {
                let s = Co(e, o.base64Decode);
                if (s.uid && s.utid)
                    return `${s.uid}.${s.utid}`;
            }
            catch { }
        r.warning("No client info in response");
    } return i?.sub || ""; }
    static isAccountEntity(e) { return e ? e.hasOwnProperty("homeAccountId") && e.hasOwnProperty("environment") && e.hasOwnProperty("realm") && e.hasOwnProperty("localAccountId") && e.hasOwnProperty("username") && e.hasOwnProperty("authorityType") : !1; }
    static accountInfoIsEqual(e, t, r) { if (!e || !t)
        return !1; let o = !0; if (r) {
        let i = e.idTokenClaims || {}, s = t.idTokenClaims || {};
        o = i.iat === s.iat && i.nonce === s.nonce;
    } return e.homeAccountId === t.homeAccountId && e.localAccountId === t.localAccountId && e.username === t.username && e.tenantId === t.tenantId && e.environment === t.environment && e.nativeAccountId === t.nativeAccountId && o; }
};
var Ot = {};
Ie(Ot, { getDeserializedResponse: () => Xi, stripLeadingHashOrQuery: () => pa });
function pa(n) { return n.startsWith("#/") ? n.substring(2) : n.startsWith("#") || n.startsWith("?") ? n.substring(1) : n; }
function Xi(n) { if (!n || n.indexOf("=") < 0)
    return null; try {
    let e = pa(n), t = Object.fromEntries(new URLSearchParams(e));
    if (t.code || t.error || t.error_description || t.state)
        return t;
}
catch {
    throw m(er);
} return null; }
var P = class n {
    get urlString() { return this._urlString; }
    constructor(e) { if (this._urlString = e, !this._urlString)
        throw N(fr); e.includes("#") || (this._urlString = n.canonicalizeUri(e)); }
    static canonicalizeUri(e) { if (e) {
        let t = e.toLowerCase();
        return Q.endsWith(t, "?") ? t = t.slice(0, -1) : Q.endsWith(t, "?/") && (t = t.slice(0, -2)), Q.endsWith(t, "/") || (t += "/"), t;
    } return e; }
    validateAsUri() { let e; try {
        e = this.getUrlComponents();
    }
    catch {
        throw N(Ye);
    } if (!e.HostNameAndPort || !e.PathSegments)
        throw N(Ye); if (!e.Protocol || e.Protocol.toLowerCase() !== "https:")
        throw N(pr); }
    static appendQueryString(e, t) { return t ? e.indexOf("?") < 0 ? `${e}?${t}` : `${e}&${t}` : e; }
    static removeHashFromUrl(e) { return n.canonicalizeUri(e.split("#")[0]); }
    replaceTenantPath(e) { let t = this.getUrlComponents(), r = t.PathSegments; return e && r.length !== 0 && (r[0] === Me.COMMON || r[0] === Me.ORGANIZATIONS) && (r[0] = e), n.constructAuthorityUriFromObject(t); }
    getUrlComponents() { let e = RegExp("^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\\?([^#]*))?(#(.*))?"), t = this.urlString.match(e); if (!t)
        throw N(Ye); let r = { Protocol: t[1], HostNameAndPort: t[4], AbsolutePath: t[5], QueryString: t[7] }, o = r.AbsolutePath.split("/"); return o = o.filter(i => i && i.length > 0), r.PathSegments = o, r.QueryString && r.QueryString.endsWith("/") && (r.QueryString = r.QueryString.substring(0, r.QueryString.length - 1)), r; }
    static getDomainFromUrl(e) { let t = RegExp("^([^:/?#]+://)?([^/?#]*)"), r = e.match(t); if (!r)
        throw N(Ye); return r[2]; }
    static getAbsoluteUrl(e, t) { if (e[0] === u.FORWARD_SLASH) {
        let o = new n(t).getUrlComponents();
        return o.Protocol + "//" + o.HostNameAndPort + e;
    } return e; }
    static constructAuthorityUriFromObject(e) { return new n(e.Protocol + "//" + e.HostNameAndPort + "/" + e.PathSegments.join("/")); }
    static hashContainsKnownProperties(e) { return !!Xi(e); }
};
var Ca = { endpointMetadata: { "login.microsoftonline.com": { token_endpoint: "https://login.microsoftonline.com/{tenantid}/oauth2/v2.0/token", jwks_uri: "https://login.microsoftonline.com/{tenantid}/discovery/v2.0/keys", issuer: "https://login.microsoftonline.com/{tenantid}/v2.0", authorization_endpoint: "https://login.microsoftonline.com/{tenantid}/oauth2/v2.0/authorize", end_session_endpoint: "https://login.microsoftonline.com/{tenantid}/oauth2/v2.0/logout" }, "login.chinacloudapi.cn": { token_endpoint: "https://login.chinacloudapi.cn/{tenantid}/oauth2/v2.0/token", jwks_uri: "https://login.chinacloudapi.cn/{tenantid}/discovery/v2.0/keys", issuer: "https://login.partner.microsoftonline.cn/{tenantid}/v2.0", authorization_endpoint: "https://login.chinacloudapi.cn/{tenantid}/oauth2/v2.0/authorize", end_session_endpoint: "https://login.chinacloudapi.cn/{tenantid}/oauth2/v2.0/logout" }, "login.microsoftonline.us": { token_endpoint: "https://login.microsoftonline.us/{tenantid}/oauth2/v2.0/token", jwks_uri: "https://login.microsoftonline.us/{tenantid}/discovery/v2.0/keys", issuer: "https://login.microsoftonline.us/{tenantid}/v2.0", authorization_endpoint: "https://login.microsoftonline.us/{tenantid}/oauth2/v2.0/authorize", end_session_endpoint: "https://login.microsoftonline.us/{tenantid}/oauth2/v2.0/logout" } }, instanceDiscoveryMetadata: { tenant_discovery_endpoint: "https://{canonicalAuthority}/v2.0/.well-known/openid-configuration", metadata: [{ preferred_network: "login.microsoftonline.com", preferred_cache: "login.windows.net", aliases: ["login.microsoftonline.com", "login.windows.net", "login.microsoft.com", "sts.windows.net"] }, { preferred_network: "login.partner.microsoftonline.cn", preferred_cache: "login.partner.microsoftonline.cn", aliases: ["login.partner.microsoftonline.cn", "login.chinacloudapi.cn"] }, { preferred_network: "login.microsoftonline.de", preferred_cache: "login.microsoftonline.de", aliases: ["login.microsoftonline.de"] }, { preferred_network: "login.microsoftonline.us", preferred_cache: "login.microsoftonline.us", aliases: ["login.microsoftonline.us", "login.usgovcloudapi.net"] }, { preferred_network: "login-us.microsoftonline.com", preferred_cache: "login-us.microsoftonline.com", aliases: ["login-us.microsoftonline.com"] }] } }, Zi = Ca.endpointMetadata, es = Ca.instanceDiscoveryMetadata, ts = new Set;
es.metadata.forEach(n => { n.aliases.forEach(e => { ts.add(e); }); });
function Ta(n, e) { let t, r = n.canonicalAuthority; if (r) {
    let o = new P(r).getUrlComponents().HostNameAndPort;
    t = fa(o, n.cloudDiscoveryMetadata?.metadata, me.CONFIG, e) || fa(o, es.metadata, me.HARDCODED_VALUES, e) || n.knownAuthorities;
} return t || []; }
function fa(n, e, t, r) { if (r?.trace(`getAliasesFromMetadata called with source: ${t}`), n && e) {
    let o = sn(e, n);
    if (o)
        return r?.trace(`getAliasesFromMetadata: found cloud discovery metadata in ${t}, returning aliases`), o.aliases;
    r?.trace(`getAliasesFromMetadata: did not find cloud discovery metadata in ${t}`);
} return null; }
function Aa(n) { return sn(es.metadata, n); }
function sn(n, e) { for (let t = 0; t < n.length; t++) {
    let r = n[t];
    if (r.aliases.includes(e))
        return r;
} return null; }
var Xn = "cache_quota_exceeded", an = "cache_error_unknown";
var rs = { [Xn]: "Exceeded cache storage capacity.", [an]: "Unexpected error occurred when using cache storage." }, Be = class n extends Error {
    constructor(e, t) { let r = t || (rs[e] ? rs[e] : rs[an]); super(`${e}: ${r}`), Object.setPrototypeOf(this, n.prototype), this.name = "CacheError", this.errorCode = e, this.errorMessage = r; }
};
var dt = class n {
    constructor(e, t, r, o) { this.clientId = e, this.cryptoImpl = t, this.commonLogger = r.clone(Qn, go), this.staticAuthorityOptions = o; }
    getAllAccounts(e) { return this.buildTenantProfiles(this.getAccountsFilteredBy(e || {}), e); }
    getAccountInfoFilteredBy(e) { let t = this.getAllAccounts(e); return t.length > 1 ? t.sort(o => o.idTokenClaims ? -1 : 1)[0] : t.length === 1 ? t[0] : null; }
    getBaseAccountInfo(e) { let t = this.getAccountsFilteredBy(e); return t.length > 0 ? t[0].getAccountInfo() : null; }
    buildTenantProfiles(e, t) { return e.flatMap(r => this.getTenantProfilesFromAccountEntity(r, t?.tenantId, t)); }
    getTenantedAccountInfoByFilter(e, t, r, o) { let i = null, s; if (o && !this.tenantProfileMatchesFilter(r, o))
        return null; let a = this.getIdToken(e, t, r.tenantId); return a && (s = it(a.secret, this.cryptoImpl.base64Decode), !this.idTokenClaimsMatchTenantProfileFilter(s, o)) ? null : (i = wr(e, r, s, a?.secret), i); }
    getTenantProfilesFromAccountEntity(e, t, r) { let o = e.getAccountInfo(), i = o.tenantProfiles || new Map, s = this.getTokenKeys(); if (t) {
        let l = i.get(t);
        if (l)
            i = new Map([[t, l]]);
        else
            return [];
    } let a = []; return i.forEach(l => { let h = this.getTenantedAccountInfoByFilter(o, s, l, r); h && a.push(h); }), a; }
    tenantProfileMatchesFilter(e, t) { return !(t.localAccountId && !this.matchLocalAccountIdFromTenantProfile(e, t.localAccountId) || t.name && e.name !== t.name || t.isHomeTenant !== void 0 && e.isHomeTenant !== t.isHomeTenant); }
    idTokenClaimsMatchTenantProfileFilter(e, t) { return !(t && (t.localAccountId && !this.matchLocalAccountIdFromTokenClaims(e, t.localAccountId) || t.loginHint && !this.matchLoginHintFromTokenClaims(e, t.loginHint) || t.username && !this.matchUsername(e.preferred_username, t.username) || t.name && !this.matchName(e, t.name) || t.sid && !this.matchSid(e, t.sid))); }
    saveCacheRecord(e, t, r) { return d(this, null, function* () { if (!e)
        throw m(cr); try {
        e.account && this.setAccount(e.account), e.idToken && t?.idToken !== !1 && this.setIdTokenCredential(e.idToken), e.accessToken && t?.accessToken !== !1 && (yield this.saveAccessToken(e.accessToken)), e.refreshToken && t?.refreshToken !== !1 && this.setRefreshTokenCredential(e.refreshToken), e.appMetadata && this.setAppMetadata(e.appMetadata);
    }
    catch (o) {
        throw this.commonLogger?.error("CacheManager.saveCacheRecord: failed"), o instanceof Error ? (this.commonLogger?.errorPii(`CacheManager.saveCacheRecord: ${o.message}`, r), o.name === "QuotaExceededError" || o.name === "NS_ERROR_DOM_QUOTA_REACHED" || o.message.includes("exceeded the quota") ? (this.commonLogger?.error("CacheManager.saveCacheRecord: exceeded storage quota", r), new Be(Xn)) : new Be(o.name, o.message)) : (this.commonLogger?.errorPii(`CacheManager.saveCacheRecord: ${o}`, r), new Be(an));
    } }); }
    saveAccessToken(e) { return d(this, null, function* () { let t = { clientId: e.clientId, credentialType: e.credentialType, environment: e.environment, homeAccountId: e.homeAccountId, realm: e.realm, tokenType: e.tokenType, requestedClaimsHash: e.requestedClaimsHash }, r = this.getTokenKeys(), o = z.fromString(e.target), i = []; r.accessToken.forEach(s => { if (!this.accessTokenKeyMatchesFilter(s, t, !1))
        return; let a = this.getAccessTokenCredential(s); a && this.credentialMatchesFilter(a, t) && z.fromString(a.target).intersectingScopeSets(o) && i.push(this.removeAccessToken(s)); }), yield Promise.all(i), this.setAccessTokenCredential(e); }); }
    getAccountsFilteredBy(e) { let t = this.getAccountKeys(), r = []; return t.forEach(o => { if (!this.isAccountKey(o, e.homeAccountId))
        return; let i = this.getAccount(o, this.commonLogger); if (!i || e.homeAccountId && !this.matchHomeAccountId(i, e.homeAccountId) || e.username && !this.matchUsername(i.username, e.username) || e.environment && !this.matchEnvironment(i, e.environment) || e.realm && !this.matchRealm(i, e.realm) || e.nativeAccountId && !this.matchNativeAccountId(i, e.nativeAccountId) || e.authorityType && !this.matchAuthorityType(i, e.authorityType))
        return; let s = { localAccountId: e?.localAccountId, name: e?.name }, a = i.tenantProfiles?.filter(l => this.tenantProfileMatchesFilter(l, s)); a && a.length === 0 || r.push(i); }), r; }
    isAccountKey(e, t, r) { return !(e.split(J.CACHE_KEY_SEPARATOR).length < 3 || t && !e.toLowerCase().includes(t.toLowerCase()) || r && !e.toLowerCase().includes(r.toLowerCase())); }
    isCredentialKey(e) { if (e.split(J.CACHE_KEY_SEPARATOR).length < 6)
        return !1; let t = e.toLowerCase(); if (t.indexOf(S.ID_TOKEN.toLowerCase()) === -1 && t.indexOf(S.ACCESS_TOKEN.toLowerCase()) === -1 && t.indexOf(S.ACCESS_TOKEN_WITH_AUTH_SCHEME.toLowerCase()) === -1 && t.indexOf(S.REFRESH_TOKEN.toLowerCase()) === -1)
        return !1; if (t.indexOf(S.REFRESH_TOKEN.toLowerCase()) > -1) {
        let r = `${S.REFRESH_TOKEN}${J.CACHE_KEY_SEPARATOR}${this.clientId}${J.CACHE_KEY_SEPARATOR}`, o = `${S.REFRESH_TOKEN}${J.CACHE_KEY_SEPARATOR}${It}${J.CACHE_KEY_SEPARATOR}`;
        if (t.indexOf(r.toLowerCase()) === -1 && t.indexOf(o.toLowerCase()) === -1)
            return !1;
    }
    else if (t.indexOf(this.clientId.toLowerCase()) === -1)
        return !1; return !0; }
    credentialMatchesFilter(e, t) { return !(t.clientId && !this.matchClientId(e, t.clientId) || t.userAssertionHash && !this.matchUserAssertionHash(e, t.userAssertionHash) || typeof t.homeAccountId == "string" && !this.matchHomeAccountId(e, t.homeAccountId) || t.environment && !this.matchEnvironment(e, t.environment) || t.realm && !this.matchRealm(e, t.realm) || t.credentialType && !this.matchCredentialType(e, t.credentialType) || t.familyId && !this.matchFamilyId(e, t.familyId) || t.target && !this.matchTarget(e, t.target) || (t.requestedClaimsHash || e.requestedClaimsHash) && e.requestedClaimsHash !== t.requestedClaimsHash || e.credentialType === S.ACCESS_TOKEN_WITH_AUTH_SCHEME && (t.tokenType && !this.matchTokenType(e, t.tokenType) || t.tokenType === b.SSH && t.keyId && !this.matchKeyId(e, t.keyId))); }
    getAppMetadataFilteredBy(e) { let t = this.getKeys(), r = {}; return t.forEach(o => { if (!this.isAppMetadata(o))
        return; let i = this.getAppMetadata(o); i && (e.environment && !this.matchEnvironment(i, e.environment) || e.clientId && !this.matchClientId(i, e.clientId) || (r[o] = i)); }), r; }
    getAuthorityMetadataByAlias(e) { let t = this.getAuthorityMetadataKeys(), r = null; return t.forEach(o => { if (!this.isAuthorityMetadata(o) || o.indexOf(this.clientId) === -1)
        return; let i = this.getAuthorityMetadata(o); i && i.aliases.indexOf(e) !== -1 && (r = i); }), r; }
    removeAllAccounts() { return d(this, null, function* () { let e = this.getAccountKeys(), t = []; e.forEach(r => { t.push(this.removeAccount(r)); }), yield Promise.all(t); }); }
    removeAccount(e) { return d(this, null, function* () { let t = this.getAccount(e, this.commonLogger); t && (yield this.removeAccountContext(t), this.removeItem(e)); }); }
    removeAccountContext(e) { return d(this, null, function* () { let t = this.getTokenKeys(), r = e.generateAccountId(), o = []; t.idToken.forEach(i => { i.indexOf(r) === 0 && this.removeIdToken(i); }), t.accessToken.forEach(i => { i.indexOf(r) === 0 && o.push(this.removeAccessToken(i)); }), t.refreshToken.forEach(i => { i.indexOf(r) === 0 && this.removeRefreshToken(i); }), yield Promise.all(o); }); }
    updateOutdatedCachedAccount(e, t, r) { if (t && t.isSingleTenant()) {
        this.commonLogger?.verbose("updateOutdatedCachedAccount: Found a single-tenant (outdated) account entity in the cache, migrating to multi-tenant account entity");
        let o = this.getAccountKeys().filter(h => h.startsWith(t.homeAccountId)), i = [];
        o.forEach(h => { let g = this.getCachedAccountEntity(h); g && i.push(g); });
        let s = i.find(h => To(h.realm, h.homeAccountId)) || i[0];
        s.tenantProfiles = i.map(h => ({ tenantId: h.realm, localAccountId: h.localAccountId, name: h.name, isHomeTenant: To(h.realm, h.homeAccountId) }));
        let a = n.toObject(new B, p({}, s)), l = a.generateAccountKey();
        return o.forEach(h => { h !== l && this.removeOutdatedAccount(e); }), this.setAccount(a), r?.verbose("Updated an outdated account entity in the cache"), a;
    } return t; }
    removeAccessToken(e) { return d(this, null, function* () { let t = this.getAccessTokenCredential(e); if (t) {
        if (t.credentialType.toLowerCase() === S.ACCESS_TOKEN_WITH_AUTH_SCHEME.toLowerCase() && t.tokenType === b.POP) {
            let o = t.keyId;
            if (o)
                try {
                    yield this.cryptoImpl.removeTokenBindingKey(o);
                }
                catch {
                    throw m(hr);
                }
        }
        return this.removeItem(e);
    } }); }
    removeAppMetadata() { return this.getKeys().forEach(t => { this.isAppMetadata(t) && this.removeItem(t); }), !0; }
    readAccountFromCache(e) { let t = B.generateAccountCacheKey(e); return this.getAccount(t, this.commonLogger); }
    getIdToken(e, t, r, o, i) { this.commonLogger.trace("CacheManager - getIdToken called"); let s = { homeAccountId: e.homeAccountId, environment: e.environment, credentialType: S.ID_TOKEN, clientId: this.clientId, realm: r }, a = this.getIdTokensByFilter(s, t), l = a.size; if (l < 1)
        return this.commonLogger.info("CacheManager:getIdToken - No token found"), null; if (l > 1) {
        let h = a;
        if (!r) {
            let g = new Map;
            a.forEach((y, v) => { y.realm === e.tenantId && g.set(v, y); });
            let T = g.size;
            if (T < 1)
                return this.commonLogger.info("CacheManager:getIdToken - Multiple ID tokens found for account but none match account entity tenant id, returning first result"), a.values().next().value;
            if (T === 1)
                return this.commonLogger.info("CacheManager:getIdToken - Multiple ID tokens found for account, defaulting to home tenant profile"), g.values().next().value;
            h = g;
        }
        return this.commonLogger.info("CacheManager:getIdToken - Multiple matching ID tokens found, clearing them"), h.forEach((g, T) => { this.removeIdToken(T); }), o && i && o.addFields({ multiMatchedID: a.size }, i), null;
    } return this.commonLogger.info("CacheManager:getIdToken - Returning ID token"), a.values().next().value; }
    getIdTokensByFilter(e, t) { let r = t && t.idToken || this.getTokenKeys().idToken, o = new Map; return r.forEach(i => { if (!this.idTokenKeyMatchesFilter(i, p({ clientId: this.clientId }, e)))
        return; let s = this.getIdTokenCredential(i); s && this.credentialMatchesFilter(s, e) && o.set(i, s); }), o; }
    idTokenKeyMatchesFilter(e, t) { let r = e.toLowerCase(); return !(t.clientId && r.indexOf(t.clientId.toLowerCase()) === -1 || t.homeAccountId && r.indexOf(t.homeAccountId.toLowerCase()) === -1); }
    removeIdToken(e) { this.removeItem(e); }
    removeRefreshToken(e) { this.removeItem(e); }
    getAccessToken(e, t, r, o, i, s) { this.commonLogger.trace("CacheManager - getAccessToken called"); let a = z.createSearchScopes(t.scopes), l = t.authenticationScheme || b.BEARER, h = l && l.toLowerCase() !== b.BEARER.toLowerCase() ? S.ACCESS_TOKEN_WITH_AUTH_SCHEME : S.ACCESS_TOKEN, g = { homeAccountId: e.homeAccountId, environment: e.environment, credentialType: h, clientId: this.clientId, realm: o || e.tenantId, target: a, tokenType: l, keyId: t.sshKid, requestedClaimsHash: t.requestedClaimsHash }, T = r && r.accessToken || this.getTokenKeys().accessToken, y = []; T.forEach(L => { if (this.accessTokenKeyMatchesFilter(L, g, !0)) {
        let x = this.getAccessTokenCredential(L);
        x && this.credentialMatchesFilter(x, g) && y.push(x);
    } }); let v = y.length; return v < 1 ? (this.commonLogger.info("CacheManager:getAccessToken - No token found"), null) : v > 1 ? (this.commonLogger.info("CacheManager:getAccessToken - Multiple access tokens found, clearing them"), y.forEach(L => { this.removeAccessToken(Jo(L)); }), i && s && i.addFields({ multiMatchedAT: y.length }, s), null) : (this.commonLogger.info("CacheManager:getAccessToken - Returning access token"), y[0]); }
    accessTokenKeyMatchesFilter(e, t, r) { let o = e.toLowerCase(); if (t.clientId && o.indexOf(t.clientId.toLowerCase()) === -1 || t.homeAccountId && o.indexOf(t.homeAccountId.toLowerCase()) === -1 || t.realm && o.indexOf(t.realm.toLowerCase()) === -1 || t.requestedClaimsHash && o.indexOf(t.requestedClaimsHash.toLowerCase()) === -1)
        return !1; if (t.target) {
        let i = t.target.asArray();
        for (let s = 0; s < i.length; s++) {
            if (r && !o.includes(i[s].toLowerCase()))
                return !1;
            if (!r && o.includes(i[s].toLowerCase()))
                return !0;
        }
    } return !0; }
    getAccessTokensByFilter(e) { let t = this.getTokenKeys(), r = []; return t.accessToken.forEach(o => { if (!this.accessTokenKeyMatchesFilter(o, e, !0))
        return; let i = this.getAccessTokenCredential(o); i && this.credentialMatchesFilter(i, e) && r.push(i); }), r; }
    getRefreshToken(e, t, r, o, i) { this.commonLogger.trace("CacheManager - getRefreshToken called"); let s = t ? It : void 0, a = { homeAccountId: e.homeAccountId, environment: e.environment, credentialType: S.REFRESH_TOKEN, clientId: this.clientId, familyId: s }, l = r && r.refreshToken || this.getTokenKeys().refreshToken, h = []; l.forEach(T => { if (this.refreshTokenKeyMatchesFilter(T, a)) {
        let y = this.getRefreshTokenCredential(T);
        y && this.credentialMatchesFilter(y, a) && h.push(y);
    } }); let g = h.length; return g < 1 ? (this.commonLogger.info("CacheManager:getRefreshToken - No refresh token found."), null) : (g > 1 && o && i && o.addFields({ multiMatchedRT: g }, i), this.commonLogger.info("CacheManager:getRefreshToken - returning refresh token"), h[0]); }
    refreshTokenKeyMatchesFilter(e, t) { let r = e.toLowerCase(); return !(t.familyId && r.indexOf(t.familyId.toLowerCase()) === -1 || !t.familyId && t.clientId && r.indexOf(t.clientId.toLowerCase()) === -1 || t.homeAccountId && r.indexOf(t.homeAccountId.toLowerCase()) === -1); }
    readAppMetadataFromCache(e) { let t = { environment: e, clientId: this.clientId }, r = this.getAppMetadataFilteredBy(t), o = Object.keys(r).map(s => r[s]), i = o.length; if (i < 1)
        return null; if (i > 1)
        throw m(nr); return o[0]; }
    isAppMetadataFOCI(e) { let t = this.readAppMetadataFromCache(e); return !!(t && t.familyId === It); }
    matchHomeAccountId(e, t) { return typeof e.homeAccountId == "string" && t === e.homeAccountId; }
    matchLocalAccountIdFromTokenClaims(e, t) { let r = e.oid || e.sub; return t === r; }
    matchLocalAccountIdFromTenantProfile(e, t) { return e.localAccountId === t; }
    matchName(e, t) { return t.toLowerCase() === e.name?.toLowerCase(); }
    matchUsername(e, t) { return !!(e && typeof e == "string" && t?.toLowerCase() === e.toLowerCase()); }
    matchUserAssertionHash(e, t) { return !!(e.userAssertionHash && t === e.userAssertionHash); }
    matchEnvironment(e, t) { if (this.staticAuthorityOptions) {
        let o = Ta(this.staticAuthorityOptions, this.commonLogger);
        if (o.includes(t) && o.includes(e.environment))
            return !0;
    } let r = this.getAuthorityMetadataByAlias(t); return !!(r && r.aliases.indexOf(e.environment) > -1); }
    matchCredentialType(e, t) { return e.credentialType && t.toLowerCase() === e.credentialType.toLowerCase(); }
    matchClientId(e, t) { return !!(e.clientId && t === e.clientId); }
    matchFamilyId(e, t) { return !!(e.familyId && t === e.familyId); }
    matchRealm(e, t) { return e.realm?.toLowerCase() === t.toLowerCase(); }
    matchNativeAccountId(e, t) { return !!(e.nativeAccountId && t === e.nativeAccountId); }
    matchLoginHintFromTokenClaims(e, t) { return e.login_hint === t || e.preferred_username === t || e.upn === t; }
    matchSid(e, t) { return e.sid === t; }
    matchAuthorityType(e, t) { return !!(e.authorityType && t.toLowerCase() === e.authorityType.toLowerCase()); }
    matchTarget(e, t) { return e.credentialType !== S.ACCESS_TOKEN && e.credentialType !== S.ACCESS_TOKEN_WITH_AUTH_SCHEME || !e.target ? !1 : z.fromString(e.target).containsScopeSet(t); }
    matchTokenType(e, t) { return !!(e.tokenType && e.tokenType === t); }
    matchKeyId(e, t) { return !!(e.keyId && e.keyId === t); }
    isAppMetadata(e) { return e.indexOf(No) !== -1; }
    isAuthorityMetadata(e) { return e.indexOf(mo.CACHE_KEY) !== -1; }
    generateAuthorityMetadataCacheKey(e) { return `${mo.CACHE_KEY}-${this.clientId}-${e}`; }
    static toObject(e, t) { for (let r in t)
        e[r] = t[r]; return e; }
}, cn = class extends dt {
    setAccount() { throw m(k); }
    getAccount() { throw m(k); }
    getCachedAccountEntity() { throw m(k); }
    setIdTokenCredential() { throw m(k); }
    getIdTokenCredential() { throw m(k); }
    setAccessTokenCredential() { throw m(k); }
    getAccessTokenCredential() { throw m(k); }
    setRefreshTokenCredential() { throw m(k); }
    getRefreshTokenCredential() { throw m(k); }
    setAppMetadata() { throw m(k); }
    getAppMetadata() { throw m(k); }
    setServerTelemetry() { throw m(k); }
    getServerTelemetry() { throw m(k); }
    setAuthorityMetadata() { throw m(k); }
    getAuthorityMetadata() { throw m(k); }
    getAuthorityMetadataKeys() { throw m(k); }
    setThrottlingCache() { throw m(k); }
    getThrottlingCache() { throw m(k); }
    removeItem() { throw m(k); }
    getKeys() { throw m(k); }
    getAccountKeys() { throw m(k); }
    getTokenKeys() { throw m(k); }
    updateCredentialCacheKey() { throw m(k); }
    removeOutdatedAccount() { throw m(k); }
};
var Zn = { tokenRenewalOffsetSeconds: Qi, preventCorsPreflight: !1 }, Hc = { loggerCallback: () => { }, piiLoggingEnabled: !1, logLevel: H.Info, correlationId: u.EMPTY_STRING }, Bc = { claimsBasedCachingEnabled: !1 }, Fc = { sendGetRequestAsync() { return d(this, null, function* () { throw m(k); }); }, sendPostRequestAsync() { return d(this, null, function* () { throw m(k); }); } }, Kc = { sku: u.SKU, version: go, cpu: u.EMPTY_STRING, os: u.EMPTY_STRING }, qc = { clientSecret: u.EMPTY_STRING, clientAssertion: void 0 }, Gc = { azureCloudInstance: _t.None, tenant: `${u.DEFAULT_COMMON_TENANT}` }, zc = { application: { appName: "", appVersion: "" } };
function Ea({ authOptions: n, systemOptions: e, loggerOptions: t, cacheOptions: r, storageInterface: o, networkInterface: i, cryptoInterface: s, clientCredentials: a, libraryInfo: l, telemetry: h, serverTelemetryManager: g, persistencePlugin: T, serializableCache: y }) { let v = p(p({}, Hc), t); return { authOptions: $c(n), systemOptions: p(p({}, Zn), e), loggerOptions: v, cacheOptions: p(p({}, Bc), r), storageInterface: o || new cn(n.clientId, _e, new ae(v)), networkInterface: i || Fc, cryptoInterface: s || _e, clientCredentials: a || qc, libraryInfo: p(p({}, Kc), l), telemetry: p(p({}, zc), h), serverTelemetryManager: g || null, persistencePlugin: T || null, serializableCache: y || null }; }
function $c(n) { return p({ clientCapabilities: [], azureCloudOptions: Gc, skipAuthorityMetadataCache: !1, instanceAware: !1 }, n); }
function ln(n) { return n.authOptions.authority.options.protocolMode === le.OIDC; }
var re = { HOME_ACCOUNT_ID: "home_account_id", UPN: "UPN" };
var ut = {};
Ie(ut, { ACCESS_TOKEN: () => Yc, BROKER_CLIENT_ID: () => ii, BROKER_REDIRECT_URI: () => Hs, CCS_HEADER: () => rl, CLAIMS: () => is, CLIENT_ASSERTION: () => bs, CLIENT_ASSERTION_TYPE: () => Ps, CLIENT_ID: () => ht, CLIENT_INFO: () => Zc, CLIENT_REQUEST_ID: () => ps, CLIENT_SECRET: () => _s, CODE: () => hs, CODE_CHALLENGE: () => us, CODE_CHALLENGE_METHOD: () => ms, CODE_VERIFIER: () => gs, DEVICE_CODE: () => ks, DOMAIN_HINT: () => xs, ERROR: () => Vc, ERROR_DESCRIPTION: () => Qc, EXPIRES_IN: () => jc, FOCI: () => tl, GRANT_TYPE: () => ns, ID_TOKEN: () => Wc, ID_TOKEN_HINT: () => Rs, LOGIN_HINT: () => Ds, LOGOUT_HINT: () => Us, NATIVE_BROKER: () => Ms, NONCE: () => ls, OBO_ASSERTION: () => Ns, ON_BEHALF_OF: () => el, POST_LOGOUT_URI: () => ws, PROMPT: () => ds, REDIRECT_URI: () => ei, REFRESH_TOKEN: () => as, REFRESH_TOKEN_EXPIRES_IN: () => Jc, REQUESTED_TOKEN_USE: () => Os, REQ_CNF: () => oi, RESPONSE_MODE: () => os, RESPONSE_TYPE: () => ti, RETURN_SPA_CODE: () => ni, SCOPE: () => ss, SESSION_STATE: () => Xc, SID: () => Ls, STATE: () => cs, TOKEN_TYPE: () => ri, X_APP_NAME: () => Ss, X_APP_VER: () => vs, X_CLIENT_CPU: () => As, X_CLIENT_CURR_TELEM: () => Es, X_CLIENT_EXTRA_SKU: () => ol, X_CLIENT_LAST_TELEM: () => ys, X_CLIENT_OS: () => Ts, X_CLIENT_SKU: () => fs, X_CLIENT_VER: () => Cs, X_MS_LIB_CAPABILITY: () => Is });
var ht = "client_id", ei = "redirect_uri", ti = "response_type", os = "response_mode", ns = "grant_type", is = "claims", ss = "scope", Vc = "error", Qc = "error_description", Yc = "access_token", Wc = "id_token", as = "refresh_token", jc = "expires_in", Jc = "refresh_token_expires_in", cs = "state", ls = "nonce", ds = "prompt", Xc = "session_state", Zc = "client_info", hs = "code", us = "code_challenge", ms = "code_challenge_method", gs = "code_verifier", ps = "client-request-id", fs = "x-client-SKU", Cs = "x-client-VER", Ts = "x-client-OS", As = "x-client-CPU", Es = "x-client-current-telemetry", ys = "x-client-last-telemetry", Is = "x-ms-lib-capability", Ss = "x-app-name", vs = "x-app-ver", ws = "post_logout_redirect_uri", Rs = "id_token_hint", ks = "device_code", _s = "client_secret", bs = "client_assertion", Ps = "client_assertion_type", ri = "token_type", oi = "req_cnf", Ns = "assertion", Os = "requested_token_use", el = "on_behalf_of", tl = "foci", rl = "X-AnchorMailbox", ni = "return_spa_code", Ms = "nativebroker", Us = "logout_hint", Ls = "sid", Ds = "login_hint", xs = "domain_hint", ol = "x-client-xtra-sku", ii = "brk_client_id", Hs = "brk_redirect_uri";
var We = class {
    static validateRedirectUri(e) { if (!e)
        throw N(gr); }
    static validatePrompt(e) { let t = []; for (let r in G)
        t.push(G[r]); if (t.indexOf(e) < 0)
        throw N(Tr); }
    static validateClaims(e) { try {
        JSON.parse(e);
    }
    catch {
        throw N(st);
    } }
    static validateCodeChallengeParams(e, t) { if (!e || !t)
        throw N(at); this.validateCodeChallengeMethod(t); }
    static validateCodeChallengeMethod(e) { if ([Kn.PLAIN, Kn.S256].indexOf(e) < 0)
        throw N(yr); }
};
function nl(n, e, t) { if (!e)
    return; let r = n.get(ht); r && n.has(ii) && t?.addFields({ embeddedClientId: r, embeddedRedirectUri: n.get(ei) }, e); }
var we = class {
    constructor(e, t) { this.parameters = new Map, this.performanceClient = t, this.correlationId = e; }
    addResponseTypeCode() { this.parameters.set(ti, encodeURIComponent(u.CODE_RESPONSE_TYPE)); }
    addResponseTypeForTokenAndIdToken() { this.parameters.set(ti, encodeURIComponent(`${u.TOKEN_RESPONSE_TYPE} ${u.ID_TOKEN_RESPONSE_TYPE}`)); }
    addResponseMode(e) { this.parameters.set(os, encodeURIComponent(e || Vi.QUERY)); }
    addNativeBroker() { this.parameters.set(Ms, encodeURIComponent("1")); }
    addScopes(e, t = !0, r = ce) { t && !r.includes("openid") && !e.includes("openid") && r.push("openid"); let o = t ? [...e || [], ...r] : e || [], i = new z(o); this.parameters.set(ss, encodeURIComponent(i.printScopes())); }
    addClientId(e) { this.parameters.set(ht, encodeURIComponent(e)); }
    addRedirectUri(e) { We.validateRedirectUri(e), this.parameters.set(ei, encodeURIComponent(e)); }
    addPostLogoutRedirectUri(e) { We.validateRedirectUri(e), this.parameters.set(ws, encodeURIComponent(e)); }
    addIdTokenHint(e) { this.parameters.set(Rs, encodeURIComponent(e)); }
    addDomainHint(e) { this.parameters.set(xs, encodeURIComponent(e)); }
    addLoginHint(e) { this.parameters.set(Ds, encodeURIComponent(e)); }
    addCcsUpn(e) { this.parameters.set(V.CCS_HEADER, encodeURIComponent(`UPN:${e}`)); }
    addCcsOid(e) { this.parameters.set(V.CCS_HEADER, encodeURIComponent(`Oid:${e.uid}@${e.utid}`)); }
    addSid(e) { this.parameters.set("sid", encodeURIComponent(e)); }
    addClaims(e, t) { let r = this.addClientCapabilitiesToClaims(e, t); We.validateClaims(r), this.parameters.set(is, encodeURIComponent(r)); }
    addCorrelationId(e) { this.parameters.set(ps, encodeURIComponent(e)); }
    addLibraryInfo(e) { this.parameters.set(fs, e.sku), this.parameters.set(Cs, e.version), e.os && this.parameters.set(Ts, e.os), e.cpu && this.parameters.set(As, e.cpu); }
    addApplicationTelemetry(e) { e?.appName && this.parameters.set(Ss, e.appName), e?.appVersion && this.parameters.set(vs, e.appVersion); }
    addPrompt(e) { We.validatePrompt(e), this.parameters.set(`${ds}`, encodeURIComponent(e)); }
    addState(e) { e && this.parameters.set(cs, encodeURIComponent(e)); }
    addNonce(e) { this.parameters.set(ls, encodeURIComponent(e)); }
    addCodeChallengeParams(e, t) { if (We.validateCodeChallengeParams(e, t), e && t)
        this.parameters.set(us, encodeURIComponent(e)), this.parameters.set(ms, encodeURIComponent(t));
    else
        throw N(at); }
    addAuthorizationCode(e) { this.parameters.set(hs, encodeURIComponent(e)); }
    addDeviceCode(e) { this.parameters.set(ks, encodeURIComponent(e)); }
    addRefreshToken(e) { this.parameters.set(as, encodeURIComponent(e)); }
    addCodeVerifier(e) { this.parameters.set(gs, encodeURIComponent(e)); }
    addClientSecret(e) { this.parameters.set(_s, encodeURIComponent(e)); }
    addClientAssertion(e) { e && this.parameters.set(bs, encodeURIComponent(e)); }
    addClientAssertionType(e) { e && this.parameters.set(Ps, encodeURIComponent(e)); }
    addOboAssertion(e) { this.parameters.set(Ns, encodeURIComponent(e)); }
    addRequestTokenUse(e) { this.parameters.set(Os, encodeURIComponent(e)); }
    addGrantType(e) { this.parameters.set(ns, encodeURIComponent(e)); }
    addClientInfo() { this.parameters.set(da, "1"); }
    addExtraQueryParameters(e) { Object.entries(e).forEach(([t, r]) => { !this.parameters.has(t) && r && this.parameters.set(t, r); }); }
    addClientCapabilitiesToClaims(e, t) { let r; if (!e)
        r = {};
    else
        try {
            r = JSON.parse(e);
        }
        catch {
            throw N(st);
        } return t && t.length > 0 && (r.hasOwnProperty(ho.ACCESS_TOKEN) || (r[ho.ACCESS_TOKEN] = {}), r[ho.ACCESS_TOKEN][ho.XMS_CC] = { values: t }), JSON.stringify(r); }
    addUsername(e) { this.parameters.set(Gn.username, encodeURIComponent(e)); }
    addPassword(e) { this.parameters.set(Gn.password, encodeURIComponent(e)); }
    addPopToken(e) { e && (this.parameters.set(ri, b.POP), this.parameters.set(oi, encodeURIComponent(e))); }
    addSshJwk(e) { e && (this.parameters.set(ri, b.SSH), this.parameters.set(oi, encodeURIComponent(e))); }
    addServerTelemetry(e) { this.parameters.set(Es, e.generateCurrentRequestHeaderValue()), this.parameters.set(ys, e.generateLastRequestHeaderValue()); }
    addThrottling() { this.parameters.set(Is, tt.X_MS_LIB_CAPABILITY_VALUE); }
    addLogoutHint(e) { this.parameters.set(Us, encodeURIComponent(e)); }
    addBrokerParameters(e) { let t = {}; t[ii] = e.brokerClientId, t[Hs] = e.brokerRedirectUri, this.addExtraQueryParameters(t); }
    createQueryString() { let e = new Array; return this.parameters.forEach((t, r) => { e.push(`${r}=${t}`); }), nl(this.parameters, this.correlationId, this.performanceClient), e.join("&"); }
};
var ai = {};
Ie(ai, { createDiscoveredInstance: () => Fs });
function ya(n) { return n.hasOwnProperty("authorization_endpoint") && n.hasOwnProperty("token_endpoint") && n.hasOwnProperty("issuer") && n.hasOwnProperty("jwks_uri"); }
function Ia(n) { return n.hasOwnProperty("tenant_discovery_endpoint") && n.hasOwnProperty("metadata"); }
function Sa(n) { return n.hasOwnProperty("error") && n.hasOwnProperty("error_description"); }
var c = { AcquireTokenByCode: "acquireTokenByCode", AcquireTokenByRefreshToken: "acquireTokenByRefreshToken", AcquireTokenSilent: "acquireTokenSilent", AcquireTokenSilentAsync: "acquireTokenSilentAsync", AcquireTokenPopup: "acquireTokenPopup", AcquireTokenPreRedirect: "acquireTokenPreRedirect", AcquireTokenRedirect: "acquireTokenRedirect", CryptoOptsGetPublicKeyThumbprint: "cryptoOptsGetPublicKeyThumbprint", CryptoOptsSignJwt: "cryptoOptsSignJwt", SilentCacheClientAcquireToken: "silentCacheClientAcquireToken", SilentIframeClientAcquireToken: "silentIframeClientAcquireToken", AwaitConcurrentIframe: "awaitConcurrentIframe", SilentRefreshClientAcquireToken: "silentRefreshClientAcquireToken", SsoSilent: "ssoSilent", StandardInteractionClientGetDiscoveredAuthority: "standardInteractionClientGetDiscoveredAuthority", FetchAccountIdWithNativeBroker: "fetchAccountIdWithNativeBroker", NativeInteractionClientAcquireToken: "nativeInteractionClientAcquireToken", BaseClientCreateTokenRequestHeaders: "baseClientCreateTokenRequestHeaders", NetworkClientSendPostRequestAsync: "networkClientSendPostRequestAsync", RefreshTokenClientExecutePostToTokenEndpoint: "refreshTokenClientExecutePostToTokenEndpoint", AuthorizationCodeClientExecutePostToTokenEndpoint: "authorizationCodeClientExecutePostToTokenEndpoint", BrokerHandhshake: "brokerHandshake", AcquireTokenByRefreshTokenInBroker: "acquireTokenByRefreshTokenInBroker", AcquireTokenByBroker: "acquireTokenByBroker", RefreshTokenClientExecuteTokenRequest: "refreshTokenClientExecuteTokenRequest", RefreshTokenClientAcquireToken: "refreshTokenClientAcquireToken", RefreshTokenClientAcquireTokenWithCachedRefreshToken: "refreshTokenClientAcquireTokenWithCachedRefreshToken", RefreshTokenClientAcquireTokenByRefreshToken: "refreshTokenClientAcquireTokenByRefreshToken", RefreshTokenClientCreateTokenRequestBody: "refreshTokenClientCreateTokenRequestBody", AcquireTokenFromCache: "acquireTokenFromCache", SilentFlowClientAcquireCachedToken: "silentFlowClientAcquireCachedToken", SilentFlowClientGenerateResultFromCacheRecord: "silentFlowClientGenerateResultFromCacheRecord", AcquireTokenBySilentIframe: "acquireTokenBySilentIframe", InitializeBaseRequest: "initializeBaseRequest", InitializeSilentRequest: "initializeSilentRequest", InitializeClientApplication: "initializeClientApplication", SilentIframeClientTokenHelper: "silentIframeClientTokenHelper", SilentHandlerInitiateAuthRequest: "silentHandlerInitiateAuthRequest", SilentHandlerMonitorIframeForHash: "silentHandlerMonitorIframeForHash", SilentHandlerLoadFrame: "silentHandlerLoadFrame", SilentHandlerLoadFrameSync: "silentHandlerLoadFrameSync", StandardInteractionClientCreateAuthCodeClient: "standardInteractionClientCreateAuthCodeClient", StandardInteractionClientGetClientConfiguration: "standardInteractionClientGetClientConfiguration", StandardInteractionClientInitializeAuthorizationRequest: "standardInteractionClientInitializeAuthorizationRequest", StandardInteractionClientInitializeAuthorizationCodeRequest: "standardInteractionClientInitializeAuthorizationCodeRequest", GetAuthCodeUrl: "getAuthCodeUrl", HandleCodeResponseFromServer: "handleCodeResponseFromServer", HandleCodeResponse: "handleCodeResponse", UpdateTokenEndpointAuthority: "updateTokenEndpointAuthority", AuthClientAcquireToken: "authClientAcquireToken", AuthClientExecuteTokenRequest: "authClientExecuteTokenRequest", AuthClientCreateTokenRequestBody: "authClientCreateTokenRequestBody", AuthClientCreateQueryString: "authClientCreateQueryString", PopTokenGenerateCnf: "popTokenGenerateCnf", PopTokenGenerateKid: "popTokenGenerateKid", HandleServerTokenResponse: "handleServerTokenResponse", DeserializeResponse: "deserializeResponse", AuthorityFactoryCreateDiscoveredInstance: "authorityFactoryCreateDiscoveredInstance", AuthorityResolveEndpointsAsync: "authorityResolveEndpointsAsync", AuthorityResolveEndpointsFromLocalSources: "authorityResolveEndpointsFromLocalSources", AuthorityGetCloudDiscoveryMetadataFromNetwork: "authorityGetCloudDiscoveryMetadataFromNetwork", AuthorityUpdateCloudDiscoveryMetadata: "authorityUpdateCloudDiscoveryMetadata", AuthorityGetEndpointMetadataFromNetwork: "authorityGetEndpointMetadataFromNetwork", AuthorityUpdateEndpointMetadata: "authorityUpdateEndpointMetadata", AuthorityUpdateMetadataWithRegionalInformation: "authorityUpdateMetadataWithRegionalInformation", RegionDiscoveryDetectRegion: "regionDiscoveryDetectRegion", RegionDiscoveryGetRegionFromIMDS: "regionDiscoveryGetRegionFromIMDS", RegionDiscoveryGetCurrentVersion: "regionDiscoveryGetCurrentVersion", AcquireTokenByCodeAsync: "acquireTokenByCodeAsync", GetEndpointMetadataFromNetwork: "getEndpointMetadataFromNetwork", GetCloudDiscoveryMetadataFromNetworkMeasurement: "getCloudDiscoveryMetadataFromNetworkMeasurement", HandleRedirectPromiseMeasurement: "handleRedirectPromise", HandleNativeRedirectPromiseMeasurement: "handleNativeRedirectPromise", UpdateCloudDiscoveryMetadataMeasurement: "updateCloudDiscoveryMetadataMeasurement", UsernamePasswordClientAcquireToken: "usernamePasswordClientAcquireToken", NativeMessageHandlerHandshake: "nativeMessageHandlerHandshake", NativeGenerateAuthResult: "nativeGenerateAuthResult", RemoveHiddenIframe: "removeHiddenIframe", ClearTokensAndKeysWithClaims: "clearTokensAndKeysWithClaims", CacheManagerGetRefreshToken: "cacheManagerGetRefreshToken", GeneratePkceCodes: "generatePkceCodes", GenerateCodeVerifier: "generateCodeVerifier", GenerateCodeChallengeFromVerifier: "generateCodeChallengeFromVerifier", Sha256Digest: "sha256Digest", GetRandomValues: "getRandomValues" }, va = new Map([[c.AcquireTokenByCode, "ATByCode"], [c.AcquireTokenByRefreshToken, "ATByRT"], [c.AcquireTokenSilent, "ATS"], [c.AcquireTokenSilentAsync, "ATSAsync"], [c.AcquireTokenPopup, "ATPopup"], [c.AcquireTokenRedirect, "ATRedirect"], [c.CryptoOptsGetPublicKeyThumbprint, "CryptoGetPKThumb"], [c.CryptoOptsSignJwt, "CryptoSignJwt"], [c.SilentCacheClientAcquireToken, "SltCacheClientAT"], [c.SilentIframeClientAcquireToken, "SltIframeClientAT"], [c.SilentRefreshClientAcquireToken, "SltRClientAT"], [c.SsoSilent, "SsoSlt"], [c.StandardInteractionClientGetDiscoveredAuthority, "StdIntClientGetDiscAuth"], [c.FetchAccountIdWithNativeBroker, "FetchAccIdWithNtvBroker"], [c.NativeInteractionClientAcquireToken, "NtvIntClientAT"], [c.BaseClientCreateTokenRequestHeaders, "BaseClientCreateTReqHead"], [c.NetworkClientSendPostRequestAsync, "NetClientSendPost"], [c.RefreshTokenClientExecutePostToTokenEndpoint, "RTClientExecPost"], [c.AuthorizationCodeClientExecutePostToTokenEndpoint, "AuthCodeClientExecPost"], [c.BrokerHandhshake, "BrokerHandshake"], [c.AcquireTokenByRefreshTokenInBroker, "ATByRTInBroker"], [c.AcquireTokenByBroker, "ATByBroker"], [c.RefreshTokenClientExecuteTokenRequest, "RTClientExecTReq"], [c.RefreshTokenClientAcquireToken, "RTClientAT"], [c.RefreshTokenClientAcquireTokenWithCachedRefreshToken, "RTClientATWithCachedRT"], [c.RefreshTokenClientAcquireTokenByRefreshToken, "RTClientATByRT"], [c.RefreshTokenClientCreateTokenRequestBody, "RTClientCreateTReqBody"], [c.AcquireTokenFromCache, "ATFromCache"], [c.SilentFlowClientAcquireCachedToken, "SltFlowClientATCached"], [c.SilentFlowClientGenerateResultFromCacheRecord, "SltFlowClientGenResFromCache"], [c.AcquireTokenBySilentIframe, "ATBySltIframe"], [c.InitializeBaseRequest, "InitBaseReq"], [c.InitializeSilentRequest, "InitSltReq"], [c.InitializeClientApplication, "InitClientApplication"], [c.SilentIframeClientTokenHelper, "SIClientTHelper"], [c.SilentHandlerInitiateAuthRequest, "SHandlerInitAuthReq"], [c.SilentHandlerMonitorIframeForHash, "SltHandlerMonitorIframeForHash"], [c.SilentHandlerLoadFrame, "SHandlerLoadFrame"], [c.SilentHandlerLoadFrameSync, "SHandlerLoadFrameSync"], [c.StandardInteractionClientCreateAuthCodeClient, "StdIntClientCreateAuthCodeClient"], [c.StandardInteractionClientGetClientConfiguration, "StdIntClientGetClientConf"], [c.StandardInteractionClientInitializeAuthorizationRequest, "StdIntClientInitAuthReq"], [c.StandardInteractionClientInitializeAuthorizationCodeRequest, "StdIntClientInitAuthCodeReq"], [c.GetAuthCodeUrl, "GetAuthCodeUrl"], [c.HandleCodeResponseFromServer, "HandleCodeResFromServer"], [c.HandleCodeResponse, "HandleCodeResp"], [c.UpdateTokenEndpointAuthority, "UpdTEndpointAuth"], [c.AuthClientAcquireToken, "AuthClientAT"], [c.AuthClientExecuteTokenRequest, "AuthClientExecTReq"], [c.AuthClientCreateTokenRequestBody, "AuthClientCreateTReqBody"], [c.AuthClientCreateQueryString, "AuthClientCreateQueryStr"], [c.PopTokenGenerateCnf, "PopTGenCnf"], [c.PopTokenGenerateKid, "PopTGenKid"], [c.HandleServerTokenResponse, "HandleServerTRes"], [c.DeserializeResponse, "DeserializeRes"], [c.AuthorityFactoryCreateDiscoveredInstance, "AuthFactCreateDiscInst"], [c.AuthorityResolveEndpointsAsync, "AuthResolveEndpointsAsync"], [c.AuthorityResolveEndpointsFromLocalSources, "AuthResolveEndpointsFromLocal"], [c.AuthorityGetCloudDiscoveryMetadataFromNetwork, "AuthGetCDMetaFromNet"], [c.AuthorityUpdateCloudDiscoveryMetadata, "AuthUpdCDMeta"], [c.AuthorityGetEndpointMetadataFromNetwork, "AuthUpdCDMetaFromNet"], [c.AuthorityUpdateEndpointMetadata, "AuthUpdEndpointMeta"], [c.AuthorityUpdateMetadataWithRegionalInformation, "AuthUpdMetaWithRegInfo"], [c.RegionDiscoveryDetectRegion, "RegDiscDetectReg"], [c.RegionDiscoveryGetRegionFromIMDS, "RegDiscGetRegFromIMDS"], [c.RegionDiscoveryGetCurrentVersion, "RegDiscGetCurrentVer"], [c.AcquireTokenByCodeAsync, "ATByCodeAsync"], [c.GetEndpointMetadataFromNetwork, "GetEndpointMetaFromNet"], [c.GetCloudDiscoveryMetadataFromNetworkMeasurement, "GetCDMetaFromNet"], [c.HandleRedirectPromiseMeasurement, "HandleRedirectPromise"], [c.HandleNativeRedirectPromiseMeasurement, "HandleNtvRedirectPromise"], [c.UpdateCloudDiscoveryMetadataMeasurement, "UpdateCDMeta"], [c.UsernamePasswordClientAcquireToken, "UserPassClientAT"], [c.NativeMessageHandlerHandshake, "NtvMsgHandlerHandshake"], [c.NativeGenerateAuthResult, "NtvGenAuthRes"], [c.RemoveHiddenIframe, "RemoveHiddenIframe"], [c.ClearTokensAndKeysWithClaims, "ClearTAndKeysWithClaims"], [c.CacheManagerGetRefreshToken, "CacheManagerGetRT"], [c.GeneratePkceCodes, "GenPkceCodes"], [c.GenerateCodeVerifier, "GenCodeVerifier"], [c.GenerateCodeChallengeFromVerifier, "GenCodeChallengeFromVerifier"], [c.Sha256Digest, "Sha256Digest"], [c.GetRandomValues, "GetRandomValues"]]), Ao = { NotStarted: 0, InProgress: 1, Completed: 2 }, Bs = new Set(["accessTokenSize", "durationMs", "idTokenSize", "matsSilentStatus", "matsHttpStatus", "refreshTokenSize", "queuedTimeMs", "startTimeMs", "status", "multiMatchedAT", "multiMatchedID", "multiMatchedRT"]);
var fe = (n, e, t, r, o) => (...i) => { t.trace(`Executing function ${e}`); let s = r?.startMeasurement(e, o); if (o) {
    let a = e + "CallCount";
    r?.incrementFields({ [a]: 1 }, o);
} try {
    let a = n(...i);
    return s?.end({ success: !0 }), t.trace(`Returning result from ${e}`), a;
}
catch (a) {
    t.trace(`Error occurred in ${e}`);
    try {
        t.trace(JSON.stringify(a));
    }
    catch {
        t.trace("Unable to print error message.");
    }
    throw s?.end({ success: !1 }, a), a;
} }, f = (n, e, t, r, o) => (...i) => { t.trace(`Executing function ${e}`); let s = r?.startMeasurement(e, o); if (o) {
    let a = e + "CallCount";
    r?.incrementFields({ [a]: 1 }, o);
} return r?.setPreQueueTime(e, o), n(...i).then(a => (t.trace(`Returning result from ${e}`), s?.end({ success: !0 }), a)).catch(a => { t.trace(`Error occurred in ${e}`); try {
    t.trace(JSON.stringify(a));
}
catch {
    t.trace("Unable to print error message.");
} throw s?.end({ success: !1 }, a), a; }); };
var wa = (() => { class n {
    constructor(t, r, o, i) { this.networkInterface = t, this.logger = r, this.performanceClient = o, this.correlationId = i; }
    detectRegion(t, r) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.RegionDiscoveryDetectRegion, this.correlationId); let o = t; if (o)
        r.region_source = Yt.ENVIRONMENT_VARIABLE;
    else {
        let i = n.IMDS_OPTIONS;
        try {
            let s = yield f(this.getRegionFromIMDS.bind(this), c.RegionDiscoveryGetRegionFromIMDS, this.logger, this.performanceClient, this.correlationId)(u.IMDS_VERSION, i);
            if (s.status === Oo.httpSuccess && (o = s.body, r.region_source = Yt.IMDS), s.status === Oo.httpBadRequest) {
                let a = yield f(this.getCurrentVersion.bind(this), c.RegionDiscoveryGetCurrentVersion, this.logger, this.performanceClient, this.correlationId)(i);
                if (!a)
                    return r.region_source = Yt.FAILED_AUTO_DETECTION, null;
                let l = yield f(this.getRegionFromIMDS.bind(this), c.RegionDiscoveryGetRegionFromIMDS, this.logger, this.performanceClient, this.correlationId)(a, i);
                l.status === Oo.httpSuccess && (o = l.body, r.region_source = Yt.IMDS);
            }
        }
        catch {
            return r.region_source = Yt.FAILED_AUTO_DETECTION, null;
        }
    } return o || (r.region_source = Yt.FAILED_AUTO_DETECTION), o || null; }); }
    getRegionFromIMDS(t, r) { return d(this, null, function* () { return this.performanceClient?.addQueueMeasurement(c.RegionDiscoveryGetRegionFromIMDS, this.correlationId), this.networkInterface.sendGetRequestAsync(`${u.IMDS_ENDPOINT}?api-version=${t}&format=text`, r, u.IMDS_TIMEOUT); }); }
    getCurrentVersion(t) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.RegionDiscoveryGetCurrentVersion, this.correlationId); try {
        let r = yield this.networkInterface.sendGetRequestAsync(`${u.IMDS_ENDPOINT}?format=json`, t);
        return r.status === Oo.httpBadRequest && r.body && r.body["newest-versions"] && r.body["newest-versions"].length > 0 ? r.body["newest-versions"][0] : null;
    }
    catch {
        return null;
    } }); }
} return n.IMDS_OPTIONS = { headers: { Metadata: "true" } }, n; })();
var be = class n {
    constructor(e, t, r, o, i, s, a, l) { this.canonicalAuthority = e, this._canonicalAuthority.validateAsUri(), this.networkInterface = t, this.cacheManager = r, this.authorityOptions = o, this.regionDiscoveryMetadata = { region_used: void 0, region_source: void 0, region_outcome: void 0 }, this.logger = i, this.performanceClient = a, this.correlationId = s, this.managedIdentity = l || !1, this.regionDiscovery = new wa(t, this.logger, this.performanceClient, this.correlationId); }
    getAuthorityType(e) { if (e.HostNameAndPort.endsWith(u.CIAM_AUTH_URL))
        return pe.Ciam; let t = e.PathSegments; if (t.length)
        switch (t[0].toLowerCase()) {
            case u.ADFS: return pe.Adfs;
            case u.DSTS: return pe.Dsts;
        } return pe.Default; }
    get authorityType() { return this.getAuthorityType(this.canonicalAuthorityUrlComponents); }
    get protocolMode() { return this.authorityOptions.protocolMode; }
    get options() { return this.authorityOptions; }
    get canonicalAuthority() { return this._canonicalAuthority.urlString; }
    set canonicalAuthority(e) { this._canonicalAuthority = new P(e), this._canonicalAuthority.validateAsUri(), this._canonicalAuthorityUrlComponents = null; }
    get canonicalAuthorityUrlComponents() { return this._canonicalAuthorityUrlComponents || (this._canonicalAuthorityUrlComponents = this._canonicalAuthority.getUrlComponents()), this._canonicalAuthorityUrlComponents; }
    get hostnameAndPort() { return this.canonicalAuthorityUrlComponents.HostNameAndPort.toLowerCase(); }
    get tenant() { return this.canonicalAuthorityUrlComponents.PathSegments[0]; }
    get authorizationEndpoint() { if (this.discoveryComplete())
        return this.replacePath(this.metadata.authorization_endpoint); throw m(ge); }
    get tokenEndpoint() { if (this.discoveryComplete())
        return this.replacePath(this.metadata.token_endpoint); throw m(ge); }
    get deviceCodeEndpoint() { if (this.discoveryComplete())
        return this.replacePath(this.metadata.token_endpoint.replace("/token", "/devicecode")); throw m(ge); }
    get endSessionEndpoint() { if (this.discoveryComplete()) {
        if (!this.metadata.end_session_endpoint)
            throw m(ur);
        return this.replacePath(this.metadata.end_session_endpoint);
    }
    else
        throw m(ge); }
    get selfSignedJwtAudience() { if (this.discoveryComplete())
        return this.replacePath(this.metadata.issuer); throw m(ge); }
    get jwksUri() { if (this.discoveryComplete())
        return this.replacePath(this.metadata.jwks_uri); throw m(ge); }
    canReplaceTenant(e) { return e.PathSegments.length === 1 && !n.reservedTenantDomains.has(e.PathSegments[0]) && this.getAuthorityType(e) === pe.Default && this.protocolMode === le.AAD; }
    replaceTenant(e) { return e.replace(/{tenant}|{tenantid}/g, this.tenant); }
    replacePath(e) { let t = e, o = new P(this.metadata.canonical_authority).getUrlComponents(), i = o.PathSegments; return this.canonicalAuthorityUrlComponents.PathSegments.forEach((a, l) => { let h = i[l]; if (l === 0 && this.canReplaceTenant(o)) {
        let g = new P(this.metadata.authorization_endpoint).getUrlComponents().PathSegments[0];
        h !== g && (this.logger.verbose(`Replacing tenant domain name ${h} with id ${g}`), h = g);
    } a !== h && (t = t.replace(`/${h}/`, `/${a}/`)); }), this.replaceTenant(t); }
    get defaultOpenIdConfigurationEndpoint() { let e = this.hostnameAndPort; return this.canonicalAuthority.endsWith("v2.0/") || this.authorityType === pe.Adfs || this.protocolMode !== le.AAD && !this.isAliasOfKnownMicrosoftAuthority(e) ? `${this.canonicalAuthority}.well-known/openid-configuration` : `${this.canonicalAuthority}v2.0/.well-known/openid-configuration`; }
    discoveryComplete() { return !!this.metadata; }
    resolveEndpointsAsync() { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.AuthorityResolveEndpointsAsync, this.correlationId); let e = this.getCurrentMetadataEntity(), t = yield f(this.updateCloudDiscoveryMetadata.bind(this), c.AuthorityUpdateCloudDiscoveryMetadata, this.logger, this.performanceClient, this.correlationId)(e); this.canonicalAuthority = this.canonicalAuthority.replace(this.hostnameAndPort, e.preferred_network); let r = yield f(this.updateEndpointMetadata.bind(this), c.AuthorityUpdateEndpointMetadata, this.logger, this.performanceClient, this.correlationId)(e); this.updateCachedMetadata(e, t, { source: r }), this.performanceClient?.addFields({ cloudDiscoverySource: t, authorityEndpointSource: r }, this.correlationId); }); }
    getCurrentMetadataEntity() { let e = this.cacheManager.getAuthorityMetadataByAlias(this.hostnameAndPort); return e || (e = { aliases: [], preferred_cache: this.hostnameAndPort, preferred_network: this.hostnameAndPort, canonical_authority: this.canonicalAuthority, authorization_endpoint: "", token_endpoint: "", end_session_endpoint: "", issuer: "", aliasesFromNetwork: !1, endpointsFromNetwork: !1, expiresAt: Wn(), jwks_uri: "" }), e; }
    updateCachedMetadata(e, t, r) { t !== me.CACHE && r?.source !== me.CACHE && (e.expiresAt = Wn(), e.canonical_authority = this.canonicalAuthority); let o = this.cacheManager.generateAuthorityMetadataCacheKey(e.preferred_cache); this.cacheManager.setAuthorityMetadata(o, e), this.metadata = e; }
    updateEndpointMetadata(e) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.AuthorityUpdateEndpointMetadata, this.correlationId); let t = this.updateEndpointMetadataFromLocalSources(e); if (t) {
        if (t.source === me.HARDCODED_VALUES && this.authorityOptions.azureRegionConfiguration?.azureRegion && t.metadata) {
            let o = yield f(this.updateMetadataWithRegionalInformation.bind(this), c.AuthorityUpdateMetadataWithRegionalInformation, this.logger, this.performanceClient, this.correlationId)(t.metadata);
            fo(e, o, !1), e.canonical_authority = this.canonicalAuthority;
        }
        return t.source;
    } let r = yield f(this.getEndpointMetadataFromNetwork.bind(this), c.AuthorityGetEndpointMetadataFromNetwork, this.logger, this.performanceClient, this.correlationId)(); if (r)
        return this.authorityOptions.azureRegionConfiguration?.azureRegion && (r = yield f(this.updateMetadataWithRegionalInformation.bind(this), c.AuthorityUpdateMetadataWithRegionalInformation, this.logger, this.performanceClient, this.correlationId)(r)), fo(e, r, !0), me.NETWORK; throw m(Zt, this.defaultOpenIdConfigurationEndpoint); }); }
    updateEndpointMetadataFromLocalSources(e) { this.logger.verbose("Attempting to get endpoint metadata from authority configuration"); let t = this.getEndpointMetadataFromConfig(); if (t)
        return this.logger.verbose("Found endpoint metadata in authority configuration"), fo(e, t, !1), { source: me.CONFIG }; if (this.logger.verbose("Did not find endpoint metadata in the config... Attempting to get endpoint metadata from the hardcoded values."), this.authorityOptions.skipAuthorityMetadataCache)
        this.logger.verbose("Skipping hardcoded metadata cache since skipAuthorityMetadataCache is set to true. Attempting to get endpoint metadata from the network metadata cache.");
    else {
        let o = this.getEndpointMetadataFromHardcodedValues();
        if (o)
            return fo(e, o, !1), { source: me.HARDCODED_VALUES, metadata: o };
        this.logger.verbose("Did not find endpoint metadata in hardcoded values... Attempting to get endpoint metadata from the network metadata cache.");
    } let r = jn(e); return this.isAuthoritySameType(e) && e.endpointsFromNetwork && !r ? (this.logger.verbose("Found endpoint metadata in the cache."), { source: me.CACHE }) : (r && this.logger.verbose("The metadata entity is expired."), null); }
    isAuthoritySameType(e) { return new P(e.canonical_authority).getUrlComponents().PathSegments.length === this.canonicalAuthorityUrlComponents.PathSegments.length; }
    getEndpointMetadataFromConfig() { if (this.authorityOptions.authorityMetadata)
        try {
            return JSON.parse(this.authorityOptions.authorityMetadata);
        }
        catch {
            throw N(Ir);
        } return null; }
    getEndpointMetadataFromNetwork() { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.AuthorityGetEndpointMetadataFromNetwork, this.correlationId); let e = {}, t = this.defaultOpenIdConfigurationEndpoint; this.logger.verbose(`Authority.getEndpointMetadataFromNetwork: attempting to retrieve OAuth endpoints from ${t}`); try {
        let r = yield this.networkInterface.sendGetRequestAsync(t, e);
        return ya(r.body) ? r.body : (this.logger.verbose("Authority.getEndpointMetadataFromNetwork: could not parse response as OpenID configuration"), null);
    }
    catch (r) {
        return this.logger.verbose(`Authority.getEndpointMetadataFromNetwork: ${r}`), null;
    } }); }
    getEndpointMetadataFromHardcodedValues() { return this.hostnameAndPort in Zi ? Zi[this.hostnameAndPort] : null; }
    updateMetadataWithRegionalInformation(e) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.AuthorityUpdateMetadataWithRegionalInformation, this.correlationId); let t = this.authorityOptions.azureRegionConfiguration?.azureRegion; if (t) {
        if (t !== u.AZURE_REGION_AUTO_DISCOVER_FLAG)
            return this.regionDiscoveryMetadata.region_outcome = zn.CONFIGURED_NO_AUTO_DETECTION, this.regionDiscoveryMetadata.region_used = t, n.replaceWithRegionalInformation(e, t);
        let r = yield f(this.regionDiscovery.detectRegion.bind(this.regionDiscovery), c.RegionDiscoveryDetectRegion, this.logger, this.performanceClient, this.correlationId)(this.authorityOptions.azureRegionConfiguration?.environmentRegion, this.regionDiscoveryMetadata);
        if (r)
            return this.regionDiscoveryMetadata.region_outcome = zn.AUTO_DETECTION_REQUESTED_SUCCESSFUL, this.regionDiscoveryMetadata.region_used = r, n.replaceWithRegionalInformation(e, r);
        this.regionDiscoveryMetadata.region_outcome = zn.AUTO_DETECTION_REQUESTED_FAILED;
    } return e; }); }
    updateCloudDiscoveryMetadata(e) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.AuthorityUpdateCloudDiscoveryMetadata, this.correlationId); let t = this.updateCloudDiscoveryMetadataFromLocalSources(e); if (t)
        return t; let r = yield f(this.getCloudDiscoveryMetadataFromNetwork.bind(this), c.AuthorityGetCloudDiscoveryMetadataFromNetwork, this.logger, this.performanceClient, this.correlationId)(); if (r)
        return Xo(e, r, !0), me.NETWORK; throw N(Sr); }); }
    updateCloudDiscoveryMetadataFromLocalSources(e) { this.logger.verbose("Attempting to get cloud discovery metadata  from authority configuration"), this.logger.verbosePii(`Known Authorities: ${this.authorityOptions.knownAuthorities || u.NOT_APPLICABLE}`), this.logger.verbosePii(`Authority Metadata: ${this.authorityOptions.authorityMetadata || u.NOT_APPLICABLE}`), this.logger.verbosePii(`Canonical Authority: ${e.canonical_authority || u.NOT_APPLICABLE}`); let t = this.getCloudDiscoveryMetadataFromConfig(); if (t)
        return this.logger.verbose("Found cloud discovery metadata in authority configuration"), Xo(e, t, !1), me.CONFIG; if (this.logger.verbose("Did not find cloud discovery metadata in the config... Attempting to get cloud discovery metadata from the hardcoded values."), this.options.skipAuthorityMetadataCache)
        this.logger.verbose("Skipping hardcoded cloud discovery metadata cache since skipAuthorityMetadataCache is set to true. Attempting to get cloud discovery metadata from the network metadata cache.");
    else {
        let o = Aa(this.hostnameAndPort);
        if (o)
            return this.logger.verbose("Found cloud discovery metadata from hardcoded values."), Xo(e, o, !1), me.HARDCODED_VALUES;
        this.logger.verbose("Did not find cloud discovery metadata in hardcoded values... Attempting to get cloud discovery metadata from the network metadata cache.");
    } let r = jn(e); return this.isAuthoritySameType(e) && e.aliasesFromNetwork && !r ? (this.logger.verbose("Found cloud discovery metadata in the cache."), me.CACHE) : (r && this.logger.verbose("The metadata entity is expired."), null); }
    getCloudDiscoveryMetadataFromConfig() { if (this.authorityType === pe.Ciam)
        return this.logger.verbose("CIAM authorities do not support cloud discovery metadata, generate the aliases from authority host."), n.createCloudDiscoveryMetadataFromHost(this.hostnameAndPort); if (this.authorityOptions.cloudDiscoveryMetadata) {
        this.logger.verbose("The cloud discovery metadata has been provided as a network response, in the config.");
        try {
            this.logger.verbose("Attempting to parse the cloud discovery metadata.");
            let e = JSON.parse(this.authorityOptions.cloudDiscoveryMetadata), t = sn(e.metadata, this.hostnameAndPort);
            if (this.logger.verbose("Parsed the cloud discovery metadata."), t)
                return this.logger.verbose("There is returnable metadata attached to the parsed cloud discovery metadata."), t;
            this.logger.verbose("There is no metadata attached to the parsed cloud discovery metadata.");
        }
        catch {
            throw this.logger.verbose("Unable to parse the cloud discovery metadata. Throwing Invalid Cloud Discovery Metadata Error."), N(bt);
        }
    } return this.isInKnownAuthorities() ? (this.logger.verbose("The host is included in knownAuthorities. Creating new cloud discovery metadata from the host."), n.createCloudDiscoveryMetadataFromHost(this.hostnameAndPort)) : null; }
    getCloudDiscoveryMetadataFromNetwork() {
        return d(this, null, function* () {
            this.performanceClient?.addQueueMeasurement(c.AuthorityGetCloudDiscoveryMetadataFromNetwork, this.correlationId);
            let e = `${u.AAD_INSTANCE_DISCOVERY_ENDPT}${this.canonicalAuthority}oauth2/v2.0/authorize`, t = {}, r = null;
            try {
                let o = yield this.networkInterface.sendGetRequestAsync(e, t), i, s;
                if (Ia(o.body))
                    i = o.body, s = i.metadata, this.logger.verbosePii(`tenant_discovery_endpoint is: ${i.tenant_discovery_endpoint}`);
                else if (Sa(o.body)) {
                    if (this.logger.warning(`A CloudInstanceDiscoveryErrorResponse was returned. The cloud instance discovery network request's status code is: ${o.status}`), i = o.body, i.error === u.INVALID_INSTANCE)
                        return this.logger.error("The CloudInstanceDiscoveryErrorResponse error is invalid_instance."), null;
                    this.logger.warning(`The CloudInstanceDiscoveryErrorResponse error is ${i.error}`), this.logger.warning(`The CloudInstanceDiscoveryErrorResponse error description is ${i.error_description}`), this.logger.warning("Setting the value of the CloudInstanceDiscoveryMetadata (returned from the network) to []"), s = [];
                }
                else
                    return this.logger.error("AAD did not return a CloudInstanceDiscoveryResponse or CloudInstanceDiscoveryErrorResponse"), null;
                this.logger.verbose("Attempting to find a match between the developer's authority and the CloudInstanceDiscoveryMetadata returned from the network request."), r = sn(s, this.hostnameAndPort);
            }
            catch (o) {
                if (o instanceof w)
                    this.logger.error(`There was a network error while attempting to get the cloud discovery instance metadata.
Error: ${o.errorCode}
Error Description: ${o.errorMessage}`);
                else {
                    let i = o;
                    this.logger.error(`A non-MSALJS error was thrown while attempting to get the cloud instance discovery metadata.
Error: ${i.name}
Error Description: ${i.message}`);
                }
                return null;
            }
            return r || (this.logger.warning("The developer's authority was not found within the CloudInstanceDiscoveryMetadata returned from the network request."), this.logger.verbose("Creating custom Authority for custom domain scenario."), r = n.createCloudDiscoveryMetadataFromHost(this.hostnameAndPort)), r;
        });
    }
    isInKnownAuthorities() { return this.authorityOptions.knownAuthorities.filter(t => t && P.getDomainFromUrl(t).toLowerCase() === this.hostnameAndPort).length > 0; }
    static generateAuthority(e, t) { let r; if (t && t.azureCloudInstance !== _t.None) {
        let o = t.tenant ? t.tenant : u.DEFAULT_COMMON_TENANT;
        r = `${t.azureCloudInstance}/${o}/`;
    } return r || e; }
    static createCloudDiscoveryMetadataFromHost(e) { return { preferred_network: e, preferred_cache: e, aliases: [e] }; }
    getPreferredCache() { if (this.managedIdentity)
        return u.DEFAULT_AUTHORITY_HOST; if (this.discoveryComplete())
        return this.metadata.preferred_cache; throw m(ge); }
    isAlias(e) { return this.metadata.aliases.indexOf(e) > -1; }
    isAliasOfKnownMicrosoftAuthority(e) { return ts.has(e); }
    static isPublicCloudAuthority(e) { return u.KNOWN_PUBLIC_CLOUDS.indexOf(e) >= 0; }
    static buildRegionalAuthorityString(e, t, r) { let o = new P(e); o.validateAsUri(); let i = o.getUrlComponents(), s = `${t}.${i.HostNameAndPort}`; this.isPublicCloudAuthority(i.HostNameAndPort) && (s = `${t}.${u.REGIONAL_AUTH_PUBLIC_CLOUD_SUFFIX}`); let a = P.constructAuthorityUriFromObject(I(p({}, o.getUrlComponents()), { HostNameAndPort: s })).urlString; return r ? `${a}?${r}` : a; }
    static replaceWithRegionalInformation(e, t) { let r = p({}, e); return r.authorization_endpoint = n.buildRegionalAuthorityString(r.authorization_endpoint, t), r.token_endpoint = n.buildRegionalAuthorityString(r.token_endpoint, t), r.end_session_endpoint && (r.end_session_endpoint = n.buildRegionalAuthorityString(r.end_session_endpoint, t)), r; }
    static transformCIAMAuthority(e) { let t = e, o = new P(e).getUrlComponents(); if (o.PathSegments.length === 0 && o.HostNameAndPort.endsWith(u.CIAM_AUTH_URL)) {
        let i = o.HostNameAndPort.split(".")[0];
        t = `${t}${i}${u.AAD_TENANT_DOMAIN_SUFFIX}`;
    } return t; }
};
be.reservedTenantDomains = new Set(["{tenant}", "{tenantid}", Me.COMMON, Me.CONSUMERS, Me.ORGANIZATIONS]);
function Ra(n) { let r = new P(n).getUrlComponents().PathSegments.slice(-1)[0]?.toLowerCase(); switch (r) {
    case Me.COMMON:
    case Me.ORGANIZATIONS:
    case Me.CONSUMERS: return;
    default: return r;
} }
function si(n) { return n.endsWith(u.FORWARD_SLASH) ? n : `${n}${u.FORWARD_SLASH}`; }
function dn(n) { let e = n.cloudDiscoveryMetadata, t; if (e)
    try {
        t = JSON.parse(e);
    }
    catch {
        throw N(bt);
    } return { canonicalAuthority: n.authority ? si(n.authority) : void 0, knownAuthorities: n.knownAuthorities, cloudDiscoveryMetadata: t }; }
function Fs(n, e, t, r, o, i, s) { return d(this, null, function* () { s?.addQueueMeasurement(c.AuthorityFactoryCreateDiscoveredInstance, i); let a = be.transformCIAMAuthority(si(n)), l = new be(a, e, t, r, o, i, s); try {
    return yield f(l.resolveEndpointsAsync.bind(l), c.AuthorityResolveEndpointsAsync, o, s, i)(), l;
}
catch {
    throw m(ge);
} }); }
var oe = class n extends w {
    constructor(e, t, r, o, i) { super(e, t, r), this.name = "ServerError", this.errorNo = o, this.status = i, Object.setPrototypeOf(this, n.prototype); }
};
var je = class n {
    static generateThrottlingStorageKey(e) { return `${tt.THROTTLING_PREFIX}.${JSON.stringify(e)}`; }
    static preProcess(e, t) { let r = n.generateThrottlingStorageKey(t), o = e.getThrottlingCache(r); if (o) {
        if (o.throttleTime < Date.now()) {
            e.removeItem(r);
            return;
        }
        throw new oe(o.errorCodes?.join(" ") || u.EMPTY_STRING, o.errorMessage, o.subError);
    } }
    static postProcess(e, t, r) { if (n.checkResponseStatus(r) || n.checkResponseForRetryAfter(r)) {
        let o = { throttleTime: n.calculateThrottleTime(parseInt(r.headers[V.RETRY_AFTER])), error: r.body.error, errorCodes: r.body.error_codes, errorMessage: r.body.error_description, subError: r.body.suberror };
        e.setThrottlingCache(n.generateThrottlingStorageKey(t), o);
    } }
    static checkResponseStatus(e) { return e.status === 429 || e.status >= 500 && e.status < 600; }
    static checkResponseForRetryAfter(e) { return e.headers ? e.headers.hasOwnProperty(V.RETRY_AFTER) && (e.status < 200 || e.status >= 300) : !1; }
    static calculateThrottleTime(e) { let t = e <= 0 ? 0 : e, r = Date.now() / 1e3; return Math.floor(Math.min(r + (t || tt.DEFAULT_THROTTLE_TIME_SECONDS), r + tt.DEFAULT_MAX_THROTTLE_TIME_SECONDS) * 1e3); }
    static removeThrottle(e, t, r, o) { let i = { clientId: t, authority: r.authority, scopes: r.scopes, homeAccountIdentifier: o, claims: r.claims, authenticationScheme: r.authenticationScheme, resourceRequestMethod: r.resourceRequestMethod, resourceRequestUri: r.resourceRequestUri, shrClaims: r.shrClaims, sshKid: r.sshKid }, s = this.generateThrottlingStorageKey(i); e.removeItem(s); }
};
var Eo = class n extends w {
    constructor(e, t, r) { super(e.errorCode, e.errorMessage, e.subError), Object.setPrototypeOf(this, n.prototype), this.name = "NetworkError", this.error = e, this.httpStatus = t, this.responseHeaders = r; }
};
function ci(n, e, t) { return new Eo(n, e, t); }
var Mt = class {
    constructor(e, t) { this.config = Ea(e), this.logger = new ae(this.config.loggerOptions, Qn, go), this.cryptoUtils = this.config.cryptoInterface, this.cacheManager = this.config.storageInterface, this.networkClient = this.config.networkInterface, this.serverTelemetryManager = this.config.serverTelemetryManager, this.authority = this.config.authOptions.authority, this.performanceClient = t; }
    createTokenRequestHeaders(e) { let t = {}; if (t[V.CONTENT_TYPE] = u.URL_FORM_CONTENT_TYPE, !this.config.systemOptions.preventCorsPreflight && e)
        switch (e.type) {
            case re.HOME_ACCOUNT_ID:
                try {
                    let r = lt(e.credential);
                    t[V.CCS_HEADER] = `Oid:${r.uid}@${r.utid}`;
                }
                catch (r) {
                    this.logger.verbose("Could not parse home account ID for CCS Header: " + r);
                }
                break;
            case re.UPN:
                t[V.CCS_HEADER] = `UPN: ${e.credential}`;
                break;
        } return t; }
    executePostToTokenEndpoint(e, t, r, o, i, s) { return d(this, null, function* () { s && this.performanceClient?.addQueueMeasurement(s, i); let a = yield this.sendPostRequest(o, e, { body: t, headers: r }, i); return this.config.serverTelemetryManager && a.status < 500 && a.status !== 429 && this.config.serverTelemetryManager.clearTelemetryCache(), a; }); }
    sendPostRequest(e, t, r, o) { return d(this, null, function* () { je.preProcess(this.cacheManager, e); let i; try {
        i = yield f(this.networkClient.sendPostRequestAsync.bind(this.networkClient), c.NetworkClientSendPostRequestAsync, this.logger, this.performanceClient, o)(t, r);
        let s = i.headers || {};
        this.performanceClient?.addFields({ refreshTokenSize: i.body.refresh_token?.length || 0, httpVerToken: s[V.X_MS_HTTP_VERSION] || "", requestId: s[V.X_MS_REQUEST_ID] || "" }, o);
    }
    catch (s) {
        if (s instanceof Eo) {
            let a = s.responseHeaders;
            throw a && this.performanceClient?.addFields({ httpVerToken: a[V.X_MS_HTTP_VERSION] || "", requestId: a[V.X_MS_REQUEST_ID] || "", contentTypeHeader: a[V.CONTENT_TYPE] || void 0, contentLengthHeader: a[V.CONTENT_LENGTH] || void 0, httpStatus: s.httpStatus }, o), s.error;
        }
        throw s instanceof w ? s : m(Xt);
    } return je.postProcess(this.cacheManager, e, i), i; }); }
    updateAuthority(e, t) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.UpdateTokenEndpointAuthority, t); let r = `https://${e}/${this.authority.tenant}/`, o = yield Fs(r, this.networkClient, this.cacheManager, this.authority.options, this.logger, t, this.performanceClient); this.authority = o; }); }
    createTokenQueryParameters(e) { let t = new we(e.correlationId, this.performanceClient); return e.embeddedClientId && t.addBrokerParameters({ brokerClientId: this.config.authOptions.clientId, brokerRedirectUri: this.config.authOptions.redirectUri }), e.tokenQueryParameters && t.addExtraQueryParameters(e.tokenQueryParameters), t.addCorrelationId(e.correlationId), t.createQueryString(); }
};
var mt = {};
Ie(mt, { badToken: () => Lt, consentRequired: () => qs, interactionRequired: () => Ks, loginRequired: () => Gs, nativeAccountUnavailable: () => hn, noTokensFound: () => Ut, refreshTokenExpired: () => un });
var Ut = "no_tokens_found", hn = "native_account_unavailable", un = "refresh_token_expired", Ks = "interaction_required", qs = "consent_required", Gs = "login_required", Lt = "bad_token";
var ka = [Ks, qs, Gs, Lt], il = ["message_only", "additional_action", "basic_action", "user_password_expired", "consent_required", "bad_token"], li = { [Ut]: "No refresh token found in the cache. Please sign-in.", [hn]: "The requested account is not available in the native broker. It may have been deleted or logged out. Please sign-in again using an interactive API.", [un]: "Refresh token has expired.", [Lt]: "Identity provider returned bad_token due to an expired or invalid refresh token. Please invoke an interactive API to resolve." }, _a = { noTokensFoundError: { code: Ut, desc: li[Ut] }, native_account_unavailable: { code: hn, desc: li[hn] }, bad_token: { code: Lt, desc: li[Lt] } }, Z = class n extends w {
    constructor(e, t, r, o, i, s, a, l) { super(e, t, r), Object.setPrototypeOf(this, n.prototype), this.timestamp = o || u.EMPTY_STRING, this.traceId = i || u.EMPTY_STRING, this.correlationId = s || u.EMPTY_STRING, this.claims = a || u.EMPTY_STRING, this.name = "InteractionRequiredAuthError", this.errorNo = l; }
};
function zs(n, e, t) { let r = !!n && ka.indexOf(n) > -1, o = !!t && il.indexOf(t) > -1, i = !!e && ka.some(s => e.indexOf(s) > -1); return r || i || o; }
function yo(n) { return new Z(n, li[n]); }
var ne = class n {
    static setRequestState(e, t, r) { let o = n.generateLibraryState(e, r); return t ? `${o}${u.RESOURCE_DELIM}${t}` : o; }
    static generateLibraryState(e, t) { if (!e)
        throw m(kt); let r = { id: e.createNewGuid() }; t && (r.meta = t); let o = JSON.stringify(r); return e.base64Encode(o); }
    static parseRequestState(e, t) { if (!e)
        throw m(kt); if (!t)
        throw m(De); try {
        let r = t.split(u.RESOURCE_DELIM), o = r[0], i = r.length > 1 ? r.slice(1).join(u.RESOURCE_DELIM) : u.EMPTY_STRING, s = e.base64Decode(o), a = JSON.parse(s);
        return { userRequestState: i || u.EMPTY_STRING, libraryState: a };
    }
    catch {
        throw m(De);
    } }
};
var sl = { SW: "sw", UHW: "uhw" }, Ce = class {
    constructor(e, t) { this.cryptoUtils = e, this.performanceClient = t; }
    generateCnf(e, t) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.PopTokenGenerateCnf, e.correlationId); let r = yield f(this.generateKid.bind(this), c.PopTokenGenerateCnf, t, this.performanceClient, e.correlationId)(e), o = this.cryptoUtils.base64UrlEncode(JSON.stringify(r)); return { kid: r.kid, reqCnfString: o }; }); }
    generateKid(e) { return d(this, null, function* () { return this.performanceClient?.addQueueMeasurement(c.PopTokenGenerateKid, e.correlationId), { kid: yield this.cryptoUtils.getPublicKeyThumbprint(e), xms_ksl: sl.SW }; }); }
    signPopToken(e, t, r) { return d(this, null, function* () { return this.signPayload(e, t, r); }); }
    signPayload(e, t, r, o) { return d(this, null, function* () { let { resourceRequestMethod: i, resourceRequestUri: s, shrClaims: a, shrNonce: l, shrOptions: h } = r, T = (s ? new P(s) : void 0)?.getUrlComponents(); return this.cryptoUtils.signJwt(p({ at: e, ts: ve(), m: i?.toUpperCase(), u: T?.HostNameAndPort, nonce: l || this.cryptoUtils.createNewGuid(), p: T?.AbsolutePath, q: T?.QueryString ? [[], T.QueryString] : void 0, client_claims: a || void 0 }, o), t, h, r.correlationId); }); }
};
var di = class {
    constructor(e, t) { this.cache = e, this.hasChanged = t; }
    get cacheHasChanged() { return this.hasChanged; }
    get tokenCache() { return this.cache; }
};
function al(n) { let e = "code=", t = n.error_uri?.lastIndexOf(e); return t && t >= 0 ? n.error_uri?.substring(t + e.length) : void 0; }
var Je = class n {
    constructor(e, t, r, o, i, s, a) { this.clientId = e, this.cacheStorage = t, this.cryptoObj = r, this.logger = o, this.serializableCache = i, this.persistencePlugin = s, this.performanceClient = a; }
    validateServerAuthorizationCodeResponse(e, t) { if (!e.state || !t)
        throw e.state ? m(wt, "Cached State") : m(wt, "Server State"); let r, o; try {
        r = decodeURIComponent(e.state);
    }
    catch {
        throw m(De, e.state);
    } try {
        o = decodeURIComponent(t);
    }
    catch {
        throw m(De, e.state);
    } if (r !== o)
        throw m(tr); if (e.error || e.error_description || e.suberror) {
        let i = al(e);
        throw zs(e.error, e.error_description, e.suberror) ? new Z(e.error || "", e.error_description, e.suberror, e.timestamp || "", e.trace_id || "", e.correlation_id || "", e.claims || "", i) : new oe(e.error || "", e.error_description, e.suberror, i);
    } }
    validateTokenResponse(e, t) {
        if (e.error || e.error_description || e.suberror) {
            let r = `Error(s): ${e.error_codes || u.NOT_AVAILABLE} - Timestamp: ${e.timestamp || u.NOT_AVAILABLE} - Description: ${e.error_description || u.NOT_AVAILABLE} - Correlation ID: ${e.correlation_id || u.NOT_AVAILABLE} - Trace ID: ${e.trace_id || u.NOT_AVAILABLE}`, o = e.error_codes?.length ? e.error_codes[0] : void 0, i = new oe(e.error, r, e.suberror, o, e.status);
            if (t && e.status && e.status >= lo.SERVER_ERROR_RANGE_START && e.status <= lo.SERVER_ERROR_RANGE_END) {
                this.logger.warning(`executeTokenRequest:validateTokenResponse - AAD is currently unavailable and the access token is unable to be refreshed.
${i}`);
                return;
            }
            else if (t && e.status && e.status >= lo.CLIENT_ERROR_RANGE_START && e.status <= lo.CLIENT_ERROR_RANGE_END) {
                this.logger.warning(`executeTokenRequest:validateTokenResponse - AAD is currently available but is unable to refresh the access token.
${i}`);
                return;
            }
            throw zs(e.error, e.error_description, e.suberror) ? new Z(e.error, e.error_description, e.suberror, e.timestamp || u.EMPTY_STRING, e.trace_id || u.EMPTY_STRING, e.correlation_id || u.EMPTY_STRING, e.claims || u.EMPTY_STRING, o) : i;
        }
    }
    handleServerTokenResponse(e, t, r, o, i, s, a, l, h) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.HandleServerTokenResponse, e.correlation_id); let g; if (e.id_token) {
        if (g = it(e.id_token || u.EMPTY_STRING, this.cryptoObj.base64Decode), i && i.nonce && g.nonce !== i.nonce)
            throw m(rr);
        if (o.maxAge || o.maxAge === 0) {
            let L = g.auth_time;
            if (!L)
                throw m(rt);
            jo(L, o.maxAge);
        }
    } this.homeAccountIdentifier = B.generateHomeAccountId(e.client_info || u.EMPTY_STRING, t.authorityType, this.logger, this.cryptoObj, g); let T; i && i.state && (T = ne.parseRequestState(this.cryptoObj, i.state)), e.key_id = e.key_id || o.sshKid || void 0; let y = this.generateCacheRecord(e, t, r, o, g, s, i), v; try {
        if (this.persistencePlugin && this.serializableCache && (this.logger.verbose("Persistence enabled, calling beforeCacheAccess"), v = new di(this.serializableCache, !0), yield this.persistencePlugin.beforeCacheAccess(v)), a && !l && y.account) {
            let L = y.account.generateAccountKey();
            if (!this.cacheStorage.getAccount(L, this.logger))
                return this.logger.warning("Account used to refresh tokens not in persistence, refreshed tokens will not be stored in the cache"), yield n.generateAuthenticationResult(this.cryptoObj, t, y, !1, o, g, T, void 0, h);
        }
        yield this.cacheStorage.saveCacheRecord(y, o.storeInCache, o.correlationId);
    }
    finally {
        this.persistencePlugin && this.serializableCache && v && (this.logger.verbose("Persistence enabled, calling afterCacheAccess"), yield this.persistencePlugin.afterCacheAccess(v));
    } return n.generateAuthenticationResult(this.cryptoObj, t, y, !1, o, g, T, e, h); }); }
    generateCacheRecord(e, t, r, o, i, s, a) { let l = t.getPreferredCache(); if (!l)
        throw m(nt); let h = Jn(i), g, T; e.id_token && i && (g = Wi(this.homeAccountIdentifier, l, e.id_token, this.clientId, h || ""), T = Io(this.cacheStorage, t, this.homeAccountIdentifier, this.cryptoObj.base64Decode, i, e.client_info, l, h, a, void 0, this.logger)); let y = null; if (e.access_token) {
        let x = e.scope ? z.fromString(e.scope) : new z(o.scopes || []), de = (typeof e.expires_in == "string" ? parseInt(e.expires_in, 10) : e.expires_in) || 0, Oe = (typeof e.ext_expires_in == "string" ? parseInt(e.ext_expires_in, 10) : e.ext_expires_in) || 0, Qt = (typeof e.refresh_in == "string" ? parseInt(e.refresh_in, 10) : e.refresh_in) || void 0, co = r + de, zi = co + Oe, Bn = Qt && Qt > 0 ? r + Qt : void 0;
        y = ji(this.homeAccountIdentifier, l, e.access_token, this.clientId, h || t.tenant || "", x.printScopes(), co, zi, this.cryptoObj.base64Decode, Bn, e.token_type, s, e.key_id, o.claims, o.requestedClaimsHash);
    } let v = null; if (e.refresh_token) {
        let x;
        if (e.refresh_token_expires_in) {
            let de = typeof e.refresh_token_expires_in == "string" ? parseInt(e.refresh_token_expires_in, 10) : e.refresh_token_expires_in;
            x = r + de;
        }
        v = Ji(this.homeAccountIdentifier, l, e.refresh_token, this.clientId, e.foci, s, x);
    } let L = null; return e.foci && (L = { clientId: this.clientId, environment: l, familyId: e.foci }), { account: T, idToken: g, accessToken: y, refreshToken: v, appMetadata: L }; }
    static generateAuthenticationResult(e, t, r, o, i, s, a, l, h) { return d(this, null, function* () { let g = u.EMPTY_STRING, T = [], y = null, v, L, x = u.EMPTY_STRING; if (r.accessToken) {
        if (r.accessToken.tokenType === b.POP && !i.popKid) {
            let co = new Ce(e), { secret: zi, keyId: Bn } = r.accessToken;
            if (!Bn)
                throw m(mr);
            g = yield co.signPopToken(zi, Bn, i);
        }
        else
            g = r.accessToken.secret;
        T = z.fromString(r.accessToken.target).asArray(), y = new Date(Number(r.accessToken.expiresOn) * 1e3), v = new Date(Number(r.accessToken.extendedExpiresOn) * 1e3), r.accessToken.refreshOn && (L = new Date(Number(r.accessToken.refreshOn) * 1e3));
    } r.appMetadata && (x = r.appMetadata.familyId === It ? It : ""); let de = s?.oid || s?.sub || "", Oe = s?.tid || ""; l?.spa_accountid && r.account && (r.account.nativeAccountId = l?.spa_accountid); let Qt = r.account ? wr(r.account.getAccountInfo(), void 0, s, r.idToken?.secret) : null; return { authority: t.canonicalAuthority, uniqueId: de, tenantId: Oe, scopes: T, account: Qt, idToken: r?.idToken?.secret || "", idTokenClaims: s || {}, accessToken: g, fromCache: o, expiresOn: y, extExpiresOn: v, refreshOn: L, correlationId: i.correlationId, requestId: h || u.EMPTY_STRING, familyId: x, tokenType: r.accessToken?.tokenType || u.EMPTY_STRING, state: a ? a.userRequestState : u.EMPTY_STRING, cloudGraphHostName: r.account?.cloudGraphHostName || u.EMPTY_STRING, msGraphHost: r.account?.msGraphHost || u.EMPTY_STRING, code: l?.spa_code, fromNativeBroker: !1 }; }); }
};
function Io(n, e, t, r, o, i, s, a, l, h, g) { g?.verbose("setCachedAccount called"); let y = n.getAccountKeys().find(Oe => Oe.startsWith(t)), v = null; y && (v = n.getAccount(y, g)); let L = v || B.createAccount({ homeAccountId: t, idTokenClaims: o, clientInfo: i, environment: s, cloudGraphHostName: l?.cloud_graph_host_name, msGraphHost: l?.msgraph_host, nativeAccountId: h }, e, r), x = L.tenantProfiles || [], de = a || L.realm; if (de && !x.find(Oe => Oe.tenantId === de)) {
    let Oe = Nt(t, L.localAccountId, de, o);
    x.push(Oe);
} return L.tenantProfiles = x, L; }
function hi(n, e, t) { return d(this, null, function* () { return typeof n == "string" ? n : n({ clientId: e, tokenEndpoint: t }); }); }
var Rr = class extends Mt {
    constructor(e, t) { super(e, t), this.includeRedirectUri = !0, this.oidcDefaultScopes = this.config.authOptions.authority.options.OIDCOptions?.defaultScopes; }
    getAuthCodeUrl(e) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.GetAuthCodeUrl, e.correlationId); let t = yield f(this.createAuthCodeUrlQueryString.bind(this), c.AuthClientCreateQueryString, this.logger, this.performanceClient, e.correlationId)(e); return P.appendQueryString(this.authority.authorizationEndpoint, t); }); }
    acquireToken(e, t) { return d(this, null, function* () { if (this.performanceClient?.addQueueMeasurement(c.AuthClientAcquireToken, e.correlationId), !e.code)
        throw m(ir); let r = ve(), o = yield f(this.executeTokenRequest.bind(this), c.AuthClientExecuteTokenRequest, this.logger, this.performanceClient, e.correlationId)(this.authority, e), i = o.headers?.[V.X_MS_REQUEST_ID], s = new Je(this.config.authOptions.clientId, this.cacheManager, this.cryptoUtils, this.logger, this.config.serializableCache, this.config.persistencePlugin, this.performanceClient); return s.validateTokenResponse(o.body), f(s.handleServerTokenResponse.bind(s), c.HandleServerTokenResponse, this.logger, this.performanceClient, e.correlationId)(o.body, this.authority, r, e, t, void 0, void 0, void 0, i); }); }
    handleFragmentResponse(e, t) { if (new Je(this.config.authOptions.clientId, this.cacheManager, this.cryptoUtils, this.logger, null, null).validateServerAuthorizationCodeResponse(e, t), !e.code)
        throw m(dr); return e; }
    getLogoutUri(e) { if (!e)
        throw N(Er); let t = this.createLogoutUrlQueryString(e); return P.appendQueryString(this.authority.endSessionEndpoint, t); }
    executeTokenRequest(e, t) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.AuthClientExecuteTokenRequest, t.correlationId); let r = this.createTokenQueryParameters(t), o = P.appendQueryString(e.tokenEndpoint, r), i = yield f(this.createTokenRequestBody.bind(this), c.AuthClientCreateTokenRequestBody, this.logger, this.performanceClient, t.correlationId)(t), s; if (t.clientInfo)
        try {
            let h = Co(t.clientInfo, this.cryptoUtils.base64Decode);
            s = { credential: `${h.uid}${J.CLIENT_INFO_SEPARATOR}${h.utid}`, type: re.HOME_ACCOUNT_ID };
        }
        catch (h) {
            this.logger.verbose("Could not parse client info for CCS Header: " + h);
        } let a = this.createTokenRequestHeaders(s || t.ccsCredential), l = { clientId: t.tokenBodyParameters?.clientId || this.config.authOptions.clientId, authority: e.canonicalAuthority, scopes: t.scopes, claims: t.claims, authenticationScheme: t.authenticationScheme, resourceRequestMethod: t.resourceRequestMethod, resourceRequestUri: t.resourceRequestUri, shrClaims: t.shrClaims, sshKid: t.sshKid }; return f(this.executePostToTokenEndpoint.bind(this), c.AuthorizationCodeClientExecutePostToTokenEndpoint, this.logger, this.performanceClient, t.correlationId)(o, i, a, l, t.correlationId, c.AuthorizationCodeClientExecutePostToTokenEndpoint); }); }
    createTokenRequestBody(e) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.AuthClientCreateTokenRequestBody, e.correlationId); let t = new we(e.correlationId, this.performanceClient); if (t.addClientId(e.embeddedClientId || e.tokenBodyParameters?.[ht] || this.config.authOptions.clientId), this.includeRedirectUri ? t.addRedirectUri(e.redirectUri) : We.validateRedirectUri(e.redirectUri), t.addScopes(e.scopes, !0, this.oidcDefaultScopes), t.addAuthorizationCode(e.code), t.addLibraryInfo(this.config.libraryInfo), t.addApplicationTelemetry(this.config.telemetry.application), t.addThrottling(), this.serverTelemetryManager && !ln(this.config) && t.addServerTelemetry(this.serverTelemetryManager), e.codeVerifier && t.addCodeVerifier(e.codeVerifier), this.config.clientCredentials.clientSecret && t.addClientSecret(this.config.clientCredentials.clientSecret), this.config.clientCredentials.clientAssertion) {
        let o = this.config.clientCredentials.clientAssertion;
        t.addClientAssertion(yield hi(o.assertion, this.config.authOptions.clientId, e.resourceRequestUri)), t.addClientAssertionType(o.assertionType);
    } if (t.addGrantType(Po.AUTHORIZATION_CODE_GRANT), t.addClientInfo(), e.authenticationScheme === b.POP) {
        let o = new Ce(this.cryptoUtils, this.performanceClient), i;
        e.popKid ? i = this.cryptoUtils.encodeKid(e.popKid) : i = (yield f(o.generateCnf.bind(o), c.PopTokenGenerateCnf, this.logger, this.performanceClient, e.correlationId)(e, this.logger)).reqCnfString, t.addPopToken(i);
    }
    else if (e.authenticationScheme === b.SSH)
        if (e.sshJwk)
            t.addSshJwk(e.sshJwk);
        else
            throw N(ct); (!Q.isEmptyObj(e.claims) || this.config.authOptions.clientCapabilities && this.config.authOptions.clientCapabilities.length > 0) && t.addClaims(e.claims, this.config.authOptions.clientCapabilities); let r; if (e.clientInfo)
        try {
            let o = Co(e.clientInfo, this.cryptoUtils.base64Decode);
            r = { credential: `${o.uid}${J.CLIENT_INFO_SEPARATOR}${o.utid}`, type: re.HOME_ACCOUNT_ID };
        }
        catch (o) {
            this.logger.verbose("Could not parse client info for CCS Header: " + o);
        }
    else
        r = e.ccsCredential; if (this.config.systemOptions.preventCorsPreflight && r)
        switch (r.type) {
            case re.HOME_ACCOUNT_ID:
                try {
                    let o = lt(r.credential);
                    t.addCcsOid(o);
                }
                catch (o) {
                    this.logger.verbose("Could not parse home account ID for CCS Header: " + o);
                }
                break;
            case re.UPN:
                t.addCcsUpn(r.credential);
                break;
        } return e.embeddedClientId && t.addBrokerParameters({ brokerClientId: this.config.authOptions.clientId, brokerRedirectUri: this.config.authOptions.redirectUri }), e.tokenBodyParameters && t.addExtraQueryParameters(e.tokenBodyParameters), e.enableSpaAuthorizationCode && (!e.tokenBodyParameters || !e.tokenBodyParameters[ni]) && t.addExtraQueryParameters({ [ni]: "1" }), t.createQueryString(); }); }
    createAuthCodeUrlQueryString(e) { return d(this, null, function* () { let t = e.correlationId || this.config.cryptoInterface.createNewGuid(); this.performanceClient?.addQueueMeasurement(c.AuthClientCreateQueryString, t); let r = new we(t, this.performanceClient); r.addClientId(e.embeddedClientId || e.extraQueryParameters?.[ht] || this.config.authOptions.clientId); let o = [...e.scopes || [], ...e.extraScopesToConsent || []]; if (r.addScopes(o, !0, this.oidcDefaultScopes), r.addRedirectUri(e.redirectUri), r.addCorrelationId(t), r.addResponseMode(e.responseMode), r.addResponseTypeCode(), r.addLibraryInfo(this.config.libraryInfo), ln(this.config) || r.addApplicationTelemetry(this.config.telemetry.application), r.addClientInfo(), e.codeChallenge && e.codeChallengeMethod && r.addCodeChallengeParams(e.codeChallenge, e.codeChallengeMethod), e.prompt && r.addPrompt(e.prompt), e.domainHint && r.addDomainHint(e.domainHint), e.prompt !== G.SELECT_ACCOUNT)
        if (e.sid && e.prompt === G.NONE)
            this.logger.verbose("createAuthCodeUrlQueryString: Prompt is none, adding sid from request"), r.addSid(e.sid);
        else if (e.account) {
            let i = this.extractAccountSid(e.account), s = this.extractLoginHint(e.account);
            if (s && e.domainHint && (this.logger.warning('AuthorizationCodeClient.createAuthCodeUrlQueryString: "domainHint" param is set, skipping opaque "login_hint" claim. Please consider not passing domainHint'), s = null), s) {
                this.logger.verbose("createAuthCodeUrlQueryString: login_hint claim present on account"), r.addLoginHint(s);
                try {
                    let a = lt(e.account.homeAccountId);
                    r.addCcsOid(a);
                }
                catch {
                    this.logger.verbose("createAuthCodeUrlQueryString: Could not parse home account ID for CCS Header");
                }
            }
            else if (i && e.prompt === G.NONE) {
                this.logger.verbose("createAuthCodeUrlQueryString: Prompt is none, adding sid from account"), r.addSid(i);
                try {
                    let a = lt(e.account.homeAccountId);
                    r.addCcsOid(a);
                }
                catch {
                    this.logger.verbose("createAuthCodeUrlQueryString: Could not parse home account ID for CCS Header");
                }
            }
            else if (e.loginHint)
                this.logger.verbose("createAuthCodeUrlQueryString: Adding login_hint from request"), r.addLoginHint(e.loginHint), r.addCcsUpn(e.loginHint);
            else if (e.account.username) {
                this.logger.verbose("createAuthCodeUrlQueryString: Adding login_hint from account"), r.addLoginHint(e.account.username);
                try {
                    let a = lt(e.account.homeAccountId);
                    r.addCcsOid(a);
                }
                catch {
                    this.logger.verbose("createAuthCodeUrlQueryString: Could not parse home account ID for CCS Header");
                }
            }
        }
        else
            e.loginHint && (this.logger.verbose("createAuthCodeUrlQueryString: No account, adding login_hint from request"), r.addLoginHint(e.loginHint), r.addCcsUpn(e.loginHint));
    else
        this.logger.verbose("createAuthCodeUrlQueryString: Prompt is select_account, ignoring account hints"); if (e.nonce && r.addNonce(e.nonce), e.state && r.addState(e.state), (e.claims || this.config.authOptions.clientCapabilities && this.config.authOptions.clientCapabilities.length > 0) && r.addClaims(e.claims, this.config.authOptions.clientCapabilities), e.embeddedClientId && r.addBrokerParameters({ brokerClientId: this.config.authOptions.clientId, brokerRedirectUri: this.config.authOptions.redirectUri }), this.addExtraQueryParams(e, r), e.nativeBroker && (r.addNativeBroker(), e.authenticationScheme === b.POP)) {
        let i = new Ce(this.cryptoUtils), s;
        e.popKid ? s = this.cryptoUtils.encodeKid(e.popKid) : s = (yield f(i.generateCnf.bind(i), c.PopTokenGenerateCnf, this.logger, this.performanceClient, e.correlationId)(e, this.logger)).reqCnfString, r.addPopToken(s);
    } return r.createQueryString(); }); }
    createLogoutUrlQueryString(e) { let t = new we(e.correlationId, this.performanceClient); return e.postLogoutRedirectUri && t.addPostLogoutRedirectUri(e.postLogoutRedirectUri), e.correlationId && t.addCorrelationId(e.correlationId), e.idTokenHint && t.addIdTokenHint(e.idTokenHint), e.state && t.addState(e.state), e.logoutHint && t.addLogoutHint(e.logoutHint), this.addExtraQueryParams(e, t), t.createQueryString(); }
    addExtraQueryParams(e, t) { !(e.extraQueryParameters && e.extraQueryParameters.hasOwnProperty("instance_aware")) && this.config.authOptions.instanceAware && (e.extraQueryParameters = e.extraQueryParameters || {}, e.extraQueryParameters.instance_aware = "true"), e.extraQueryParameters && t.addExtraQueryParameters(e.extraQueryParameters); }
    extractAccountSid(e) { return e.idTokenClaims?.sid || null; }
    extractLoginHint(e) { return e.idTokenClaims?.login_hint || null; }
};
var cl = 300, Dt = class extends Mt {
    constructor(e, t) { super(e, t); }
    acquireToken(e) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.RefreshTokenClientAcquireToken, e.correlationId); let t = ve(), r = yield f(this.executeTokenRequest.bind(this), c.RefreshTokenClientExecuteTokenRequest, this.logger, this.performanceClient, e.correlationId)(e, this.authority), o = r.headers?.[V.X_MS_REQUEST_ID], i = new Je(this.config.authOptions.clientId, this.cacheManager, this.cryptoUtils, this.logger, this.config.serializableCache, this.config.persistencePlugin); return i.validateTokenResponse(r.body), f(i.handleServerTokenResponse.bind(i), c.HandleServerTokenResponse, this.logger, this.performanceClient, e.correlationId)(r.body, this.authority, t, e, void 0, void 0, !0, e.forceCache, o); }); }
    acquireTokenByRefreshToken(e) { return d(this, null, function* () { if (!e)
        throw N(Ar); if (this.performanceClient?.addQueueMeasurement(c.RefreshTokenClientAcquireTokenByRefreshToken, e.correlationId), !e.account)
        throw m(ot); if (this.cacheManager.isAppMetadataFOCI(e.account.environment))
        try {
            return yield f(this.acquireTokenWithCachedRefreshToken.bind(this), c.RefreshTokenClientAcquireTokenWithCachedRefreshToken, this.logger, this.performanceClient, e.correlationId)(e, !0);
        }
        catch (r) {
            let o = r instanceof Z && r.errorCode === Ut, i = r instanceof oe && r.errorCode === qn.INVALID_GRANT_ERROR && r.subError === qn.CLIENT_MISMATCH_ERROR;
            if (o || i)
                return f(this.acquireTokenWithCachedRefreshToken.bind(this), c.RefreshTokenClientAcquireTokenWithCachedRefreshToken, this.logger, this.performanceClient, e.correlationId)(e, !1);
            throw r;
        } return f(this.acquireTokenWithCachedRefreshToken.bind(this), c.RefreshTokenClientAcquireTokenWithCachedRefreshToken, this.logger, this.performanceClient, e.correlationId)(e, !1); }); }
    acquireTokenWithCachedRefreshToken(e, t) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.RefreshTokenClientAcquireTokenWithCachedRefreshToken, e.correlationId); let r = fe(this.cacheManager.getRefreshToken.bind(this.cacheManager), c.CacheManagerGetRefreshToken, this.logger, this.performanceClient, e.correlationId)(e.account, t, void 0, this.performanceClient, e.correlationId); if (!r)
        throw yo(Ut); if (r.expiresOn && po(r.expiresOn, e.refreshTokenExpirationOffsetSeconds || cl))
        throw yo(un); let o = I(p({}, e), { refreshToken: r.secret, authenticationScheme: e.authenticationScheme || b.BEARER, ccsCredential: { credential: e.account.homeAccountId, type: re.HOME_ACCOUNT_ID } }); try {
        return yield f(this.acquireToken.bind(this), c.RefreshTokenClientAcquireToken, this.logger, this.performanceClient, e.correlationId)(o);
    }
    catch (i) {
        if (i instanceof Z && i.subError === Lt) {
            this.logger.verbose("acquireTokenWithRefreshToken: bad refresh token, removing from cache");
            let s = Jo(r);
            this.cacheManager.removeRefreshToken(s);
        }
        throw i;
    } }); }
    executeTokenRequest(e, t) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.RefreshTokenClientExecuteTokenRequest, e.correlationId); let r = this.createTokenQueryParameters(e), o = P.appendQueryString(t.tokenEndpoint, r), i = yield f(this.createTokenRequestBody.bind(this), c.RefreshTokenClientCreateTokenRequestBody, this.logger, this.performanceClient, e.correlationId)(e), s = this.createTokenRequestHeaders(e.ccsCredential), a = { clientId: e.tokenBodyParameters?.clientId || this.config.authOptions.clientId, authority: t.canonicalAuthority, scopes: e.scopes, claims: e.claims, authenticationScheme: e.authenticationScheme, resourceRequestMethod: e.resourceRequestMethod, resourceRequestUri: e.resourceRequestUri, shrClaims: e.shrClaims, sshKid: e.sshKid }; return f(this.executePostToTokenEndpoint.bind(this), c.RefreshTokenClientExecutePostToTokenEndpoint, this.logger, this.performanceClient, e.correlationId)(o, i, s, a, e.correlationId, c.RefreshTokenClientExecutePostToTokenEndpoint); }); }
    createTokenRequestBody(e) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.RefreshTokenClientCreateTokenRequestBody, e.correlationId); let t = e.correlationId, r = new we(t, this.performanceClient); if (r.addClientId(e.embeddedClientId || e.tokenBodyParameters?.[ht] || this.config.authOptions.clientId), e.redirectUri && r.addRedirectUri(e.redirectUri), r.addScopes(e.scopes, !0, this.config.authOptions.authority.options.OIDCOptions?.defaultScopes), r.addGrantType(Po.REFRESH_TOKEN_GRANT), r.addClientInfo(), r.addLibraryInfo(this.config.libraryInfo), r.addApplicationTelemetry(this.config.telemetry.application), r.addThrottling(), this.serverTelemetryManager && !ln(this.config) && r.addServerTelemetry(this.serverTelemetryManager), r.addRefreshToken(e.refreshToken), this.config.clientCredentials.clientSecret && r.addClientSecret(this.config.clientCredentials.clientSecret), this.config.clientCredentials.clientAssertion) {
        let o = this.config.clientCredentials.clientAssertion;
        r.addClientAssertion(yield hi(o.assertion, this.config.authOptions.clientId, e.resourceRequestUri)), r.addClientAssertionType(o.assertionType);
    } if (e.authenticationScheme === b.POP) {
        let o = new Ce(this.cryptoUtils, this.performanceClient), i;
        e.popKid ? i = this.cryptoUtils.encodeKid(e.popKid) : i = (yield f(o.generateCnf.bind(o), c.PopTokenGenerateCnf, this.logger, this.performanceClient, e.correlationId)(e, this.logger)).reqCnfString, r.addPopToken(i);
    }
    else if (e.authenticationScheme === b.SSH)
        if (e.sshJwk)
            r.addSshJwk(e.sshJwk);
        else
            throw N(ct); if ((!Q.isEmptyObj(e.claims) || this.config.authOptions.clientCapabilities && this.config.authOptions.clientCapabilities.length > 0) && r.addClaims(e.claims, this.config.authOptions.clientCapabilities), this.config.systemOptions.preventCorsPreflight && e.ccsCredential)
        switch (e.ccsCredential.type) {
            case re.HOME_ACCOUNT_ID:
                try {
                    let o = lt(e.ccsCredential.credential);
                    r.addCcsOid(o);
                }
                catch (o) {
                    this.logger.verbose("Could not parse home account ID for CCS Header: " + o);
                }
                break;
            case re.UPN:
                r.addCcsUpn(e.ccsCredential.credential);
                break;
        } return e.embeddedClientId && r.addBrokerParameters({ brokerClientId: this.config.authOptions.clientId, brokerRedirectUri: this.config.authOptions.redirectUri }), e.tokenBodyParameters && r.addExtraQueryParameters(e.tokenBodyParameters), r.createQueryString(); }); }
};
var mn = class extends Mt {
    constructor(e, t) { super(e, t); }
    acquireToken(e) { return d(this, null, function* () { try {
        let [t, r] = yield this.acquireCachedToken(I(p({}, e), { scopes: e.scopes?.length ? e.scopes : [...ce] }));
        return r === Le.PROACTIVELY_REFRESHED && (this.logger.info("SilentFlowClient:acquireCachedToken - Cached access token's refreshOn property has been exceeded'. It's not expired, but must be refreshed."), new Dt(this.config, this.performanceClient).acquireTokenByRefreshToken(e).catch(() => { })), t;
    }
    catch (t) {
        if (t instanceof Se && t.errorCode === Ve)
            return new Dt(this.config, this.performanceClient).acquireTokenByRefreshToken(e);
        throw t;
    } }); }
    acquireCachedToken(e) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.SilentFlowClientAcquireCachedToken, e.correlationId); let t = Le.NOT_APPLICABLE; if (e.forceRefresh || !this.config.cacheOptions.claimsBasedCachingEnabled && !Q.isEmptyObj(e.claims))
        throw this.setCacheOutcome(Le.FORCE_REFRESH_OR_CLAIMS, e.correlationId), m(Ve); if (!e.account)
        throw m(ot); let r = e.account.tenantId || Ra(e.authority), o = this.cacheManager.getTokenKeys(), i = this.cacheManager.getAccessToken(e.account, e, o, r, this.performanceClient, e.correlationId); if (i) {
        if (Yi(i.cachedAt) || po(i.expiresOn, this.config.systemOptions.tokenRenewalOffsetSeconds))
            throw this.setCacheOutcome(Le.CACHED_ACCESS_TOKEN_EXPIRED, e.correlationId), m(Ve);
        i.refreshOn && po(i.refreshOn, 0) && (t = Le.PROACTIVELY_REFRESHED);
    }
    else
        throw this.setCacheOutcome(Le.NO_CACHED_ACCESS_TOKEN, e.correlationId), m(Ve); let s = e.authority || this.authority.getPreferredCache(), a = { account: this.cacheManager.readAccountFromCache(e.account), accessToken: i, idToken: this.cacheManager.getIdToken(e.account, o, r, this.performanceClient, e.correlationId), refreshToken: null, appMetadata: this.cacheManager.readAppMetadataFromCache(s) }; return this.setCacheOutcome(t, e.correlationId), this.config.serverTelemetryManager && this.config.serverTelemetryManager.incrementCacheHits(), [yield f(this.generateResultFromCacheRecord.bind(this), c.SilentFlowClientGenerateResultFromCacheRecord, this.logger, this.performanceClient, e.correlationId)(a, e), t]; }); }
    setCacheOutcome(e, t) { this.serverTelemetryManager?.setCacheOutcome(e), this.performanceClient?.addFields({ cacheOutcome: e }, t), e !== Le.NOT_APPLICABLE && this.logger.info(`Token refresh is required due to cache outcome: ${e}`); }
    generateResultFromCacheRecord(e, t) { return d(this, null, function* () { this.performanceClient?.addQueueMeasurement(c.SilentFlowClientGenerateResultFromCacheRecord, t.correlationId); let r; if (e.idToken && (r = it(e.idToken.secret, this.config.cryptoInterface.base64Decode)), t.maxAge || t.maxAge === 0) {
        let o = r?.auth_time;
        if (!o)
            throw m(rt);
        jo(o, t.maxAge);
    } return Je.generateAuthenticationResult(this.cryptoUtils, this.authority, e, !0, t, r); }); }
};
var $s = { sendGetRequestAsync: () => Promise.reject(m(k)), sendPostRequestAsync: () => Promise.reject(m(k)) };
var ui = class {
    constructor(e) { this.headers = e; }
    getShrNonce() { let e = this.headers[V.AuthenticationInfo]; if (e) {
        let r = this.parseChallenges(e);
        if (r.nextnonce)
            return r.nextnonce;
        throw N(Pt);
    } let t = this.headers[V.WWWAuthenticate]; if (t) {
        let r = this.parseChallenges(t);
        if (r.nonce)
            return r.nonce;
        throw N(Pt);
    } throw N(vr); }
    parseChallenges(e) { let t = e.indexOf(" "), r = e.substr(t + 1).split(","), o = {}; return r.forEach(i => { let [s, a] = i.split("="); o[s] = unescape(a.replace(/['"]+/g, u.EMPTY_STRING)); }), o; }
};
var ba = ",", Pa = "|";
function ll(n) { let { skus: e, libraryName: t, libraryVersion: r, extensionName: o, extensionVersion: i } = n, s = new Map([[0, [t, r]], [2, [o, i]]]), a = []; if (e?.length) {
    if (a = e.split(ba), a.length < 4)
        return e;
}
else
    a = Array.from({ length: 4 }, () => Pa); return s.forEach((l, h) => { l.length === 2 && l[0]?.length && l[1]?.length && dl({ skuArr: a, index: h, skuName: l[0], skuVersion: l[1] }); }), a.join(ba); }
function dl(n) { let { skuArr: e, index: t, skuName: r, skuVersion: o } = n; t >= e.length || (e[t] = [r, o].join(Pa)); }
var kr = class n {
    constructor(e, t) { this.cacheOutcome = Le.NOT_APPLICABLE, this.cacheManager = t, this.apiId = e.apiId, this.correlationId = e.correlationId, this.wrapperSKU = e.wrapperSKU || u.EMPTY_STRING, this.wrapperVer = e.wrapperVer || u.EMPTY_STRING, this.telemetryCacheKey = te.CACHE_KEY + J.CACHE_KEY_SEPARATOR + e.clientId; }
    generateCurrentRequestHeaderValue() { let e = `${this.apiId}${te.VALUE_SEPARATOR}${this.cacheOutcome}`, t = [this.wrapperSKU, this.wrapperVer], r = this.getNativeBrokerErrorCode(); r?.length && t.push(`broker_error=${r}`); let o = t.join(te.VALUE_SEPARATOR), i = this.getRegionDiscoveryFields(), s = [e, i].join(te.VALUE_SEPARATOR); return [te.SCHEMA_VERSION, s, o].join(te.CATEGORY_SEPARATOR); }
    generateLastRequestHeaderValue() { let e = this.getLastRequests(), t = n.maxErrorsToSend(e), r = e.failedRequests.slice(0, 2 * t).join(te.VALUE_SEPARATOR), o = e.errors.slice(0, t).join(te.VALUE_SEPARATOR), i = e.errors.length, s = t < i ? te.OVERFLOW_TRUE : te.OVERFLOW_FALSE, a = [i, s].join(te.VALUE_SEPARATOR); return [te.SCHEMA_VERSION, e.cacheHits, r, o, a].join(te.CATEGORY_SEPARATOR); }
    cacheFailedRequest(e) { let t = this.getLastRequests(); t.errors.length >= te.MAX_CACHED_ERRORS && (t.failedRequests.shift(), t.failedRequests.shift(), t.errors.shift()), t.failedRequests.push(this.apiId, this.correlationId), e instanceof Error && e && e.toString() ? e instanceof w ? e.subError ? t.errors.push(e.subError) : e.errorCode ? t.errors.push(e.errorCode) : t.errors.push(e.toString()) : t.errors.push(e.toString()) : t.errors.push(te.UNKNOWN_ERROR), this.cacheManager.setServerTelemetry(this.telemetryCacheKey, t); }
    incrementCacheHits() { let e = this.getLastRequests(); return e.cacheHits += 1, this.cacheManager.setServerTelemetry(this.telemetryCacheKey, e), e.cacheHits; }
    getLastRequests() { let e = { failedRequests: [], errors: [], cacheHits: 0 }; return this.cacheManager.getServerTelemetry(this.telemetryCacheKey) || e; }
    clearTelemetryCache() { let e = this.getLastRequests(), t = n.maxErrorsToSend(e), r = e.errors.length; if (t === r)
        this.cacheManager.removeItem(this.telemetryCacheKey);
    else {
        let o = { failedRequests: e.failedRequests.slice(t * 2), errors: e.errors.slice(t), cacheHits: 0 };
        this.cacheManager.setServerTelemetry(this.telemetryCacheKey, o);
    } }
    static maxErrorsToSend(e) { let t, r = 0, o = 0, i = e.errors.length; for (t = 0; t < i; t++) {
        let s = e.failedRequests[2 * t] || u.EMPTY_STRING, a = e.failedRequests[2 * t + 1] || u.EMPTY_STRING, l = e.errors[t] || u.EMPTY_STRING;
        if (o += s.toString().length + a.toString().length + l.length + 3, o < te.MAX_LAST_HEADER_BYTES)
            r += 1;
        else
            break;
    } return r; }
    getRegionDiscoveryFields() { let e = []; return e.push(this.regionUsed || u.EMPTY_STRING), e.push(this.regionSource || u.EMPTY_STRING), e.push(this.regionOutcome || u.EMPTY_STRING), e.join(","); }
    updateRegionDiscoveryMetadata(e) { this.regionUsed = e.region_used, this.regionSource = e.region_source, this.regionOutcome = e.region_outcome; }
    setCacheOutcome(e) { this.cacheOutcome = e; }
    setNativeBrokerErrorCode(e) { let t = this.getLastRequests(); t.nativeBrokerErrorCode = e, this.cacheManager.setServerTelemetry(this.telemetryCacheKey, t); }
    getNativeBrokerErrorCode() { return this.getLastRequests().nativeBrokerErrorCode; }
    clearNativeBrokerErrorCode() { let e = this.getLastRequests(); delete e.nativeBrokerErrorCode, this.cacheManager.setServerTelemetry(this.telemetryCacheKey, e); }
    static makeExtraSkuString(e) { return ll(e); }
};
var mi = "missing_kid_error", gi = "missing_alg_error";
var hl = { [mi]: "The JOSE Header for the requested JWT, JWS or JWK object requires a keyId to be configured as the 'kid' header claim. No 'kid' value was provided.", [gi]: "The JOSE Header for the requested JWT, JWS or JWK object requires an algorithm to be specified as the 'alg' header claim. No 'alg' value was provided." }, Vs = class n extends w {
    constructor(e, t) { super(e, t), this.name = "JoseHeaderError", Object.setPrototypeOf(this, n.prototype); }
};
function Qs(n) { return new Vs(n, hl[n]); }
var gn = class n {
    constructor(e) { this.typ = e.typ, this.alg = e.alg, this.kid = e.kid; }
    static getShrHeaderString(e) { if (!e.kid)
        throw Qs(mi); if (!e.alg)
        throw Qs(gi); let t = new n({ typ: e.typ || $n.Pop, kid: e.kid, alg: e.alg }); return JSON.stringify(t); }
};
var So = class {
    startMeasurement() { }
    endMeasurement() { }
    flushMeasurement() { return null; }
}, vo = class {
    generateId() { return "callback-id"; }
    startMeasurement(e, t) { return { end: () => null, discard: () => { }, add: () => { }, increment: () => { }, event: { eventId: this.generateId(), status: Ao.InProgress, authority: "", libraryName: "", libraryVersion: "", clientId: "", name: e, startTimeMs: Date.now(), correlationId: t || "" }, measurement: new So }; }
    startPerformanceMeasurement() { return new So; }
    calculateQueuedTime() { return 0; }
    addQueueMeasurement() { }
    setPreQueueTime() { }
    endMeasurement() { return null; }
    discardMeasurements() { }
    removePerformanceCallback() { return !0; }
    addPerformanceCallback() { return ""; }
    emitEvents() { }
    addFields() { }
    incrementFields() { }
    cacheEventByCorrelationId() { }
};
function ul(n, e, t) { t && t.push({ name: e.get(n.name) || n.name }); }
function ml(n, e, t, r) { if (!t?.length)
    return; let o = v => v.length ? v[v.length - 1] : void 0, i = e.get(n.name) || n.name; if (o(t)?.name !== i)
    return; let a = t?.pop(); if (!a)
    return; let l = r instanceof w ? r.errorCode : r instanceof Error ? r.name : void 0, h = r instanceof w ? r.subError : void 0; l && a.childErr !== l && (a.err = l, h && (a.subErr = h)), delete a.name, delete a.childErr; let g = I(p({}, a), { dur: n.durationMs }); n.success || (g.fail = 1); let T = o(t); if (!T)
    return { [i]: g }; l && (T.childErr = l); let y; if (!T[i])
    y = i;
else {
    let v = Object.keys(T).filter(L => L.startsWith(i)).length;
    y = `${i}_${v + 1}`;
} return T[y] = g, T; }
function gl(n, e, t, r = 5) { if (n instanceof Error) {
    if (n instanceof w) {
        t.errorCode = n.errorCode, t.subErrorCode = n.subError, (n instanceof oe || n instanceof Z) && (t.serverErrorNo = n.errorNo);
        return;
    }
    else if (n instanceof Be) {
        t.errorCode = n.errorCode;
        return;
    }
    else if (t.errorStack?.length) {
        e.trace("PerformanceClient.addErrorStack: Stack already exist", t.correlationId);
        return;
    }
    else if (!n.stack?.length) {
        e.trace("PerformanceClient.addErrorStack: Input stack is empty", t.correlationId);
        return;
    }
}
else {
    e.trace("PerformanceClient.addErrorStack: Input error is not instance of Error", t.correlationId);
    return;
} n.stack && (t.errorStack = pl(n.stack, r)), t.errorName = n.name; }
function pl(n, e) {
    if (e < 0)
        return [];
    let t = n.split(`
`) || [], r = [], o = t[0];
    o.startsWith("TypeError: Cannot read property") || o.startsWith("TypeError: Cannot read properties of") || o.startsWith("TypeError: Cannot set property") || o.startsWith("TypeError: Cannot set properties of") || o.endsWith("is not a function") ? r.push(Ys(o)) : (o.startsWith("SyntaxError") || o.startsWith("TypeError")) && r.push(Ys(o.replace(/['].*[']|["].*["]/g, "<redacted>")));
    for (let i = 1; i < t.length && !(r.length >= e); i++) {
        let s = t[i];
        r.push(Ys(s));
    }
    return r;
}
function Ys(n) { let e = n.lastIndexOf(" ") + 1; if (e < 1)
    return n; let t = n.substring(e), r = t.lastIndexOf("/"); return r = r < 0 ? t.lastIndexOf("\\") : r, r >= 0 ? (n.substring(0, e) + "(" + t.substring(r + 1) + (t.charAt(t.length - 1) === ")" ? "" : ")")).trimStart() : n.trimStart(); }
var pn = class {
    constructor(e, t, r, o, i, s, a, l) { this.authority = t, this.libraryName = o, this.libraryVersion = i, this.applicationTelemetry = s, this.clientId = e, this.logger = r, this.callbacks = new Map, this.eventsByCorrelationId = new Map, this.eventStack = new Map, this.queueMeasurements = new Map, this.preQueueTimeByCorrelationId = new Map, this.intFields = a || new Set; for (let h of Bs)
        this.intFields.add(h); this.abbreviations = l || new Map; for (let [h, g] of va)
        this.abbreviations.set(h, g); }
    startPerformanceMeasurement(e, t) { return {}; }
    getPreQueueTime(e, t) { let r = this.preQueueTimeByCorrelationId.get(t); if (r) {
        if (r.name !== e) {
            this.logger.trace(`PerformanceClient.getPreQueueTime: no pre-queue time found for ${e}, unable to add queue measurement`);
            return;
        }
    }
    else {
        this.logger.trace(`PerformanceClient.getPreQueueTime: no pre-queue times found for correlationId: ${t}, unable to add queue measurement`);
        return;
    } return r.time; }
    calculateQueuedTime(e, t) { return e < 1 ? (this.logger.trace(`PerformanceClient: preQueueTime should be a positive integer and not ${e}`), 0) : t < 1 ? (this.logger.trace(`PerformanceClient: currentTime should be a positive integer and not ${t}`), 0) : t < e ? (this.logger.trace("PerformanceClient: currentTime is less than preQueueTime, check how time is being retrieved"), 0) : t - e; }
    addQueueMeasurement(e, t, r, o) { if (!t) {
        this.logger.trace(`PerformanceClient.addQueueMeasurement: correlationId not provided for ${e}, cannot add queue measurement`);
        return;
    } if (r === 0)
        this.logger.trace(`PerformanceClient.addQueueMeasurement: queue time provided for ${e} is ${r}`);
    else if (!r) {
        this.logger.trace(`PerformanceClient.addQueueMeasurement: no queue time provided for ${e}`);
        return;
    } let i = { eventName: e, queueTime: o ? 0 : r, manuallyCompleted: o }, s = this.queueMeasurements.get(t); if (s)
        s.push(i), this.queueMeasurements.set(t, s);
    else {
        this.logger.trace(`PerformanceClient.addQueueMeasurement: adding correlationId ${t} to queue measurements`);
        let a = [i];
        this.queueMeasurements.set(t, a);
    } this.preQueueTimeByCorrelationId.delete(t); }
    startMeasurement(e, t) { let r = t || this.generateId(); t || this.logger.info(`PerformanceClient: No correlation id provided for ${e}, generating`, r), this.logger.trace(`PerformanceClient: Performance measurement started for ${e}`, r); let o = { eventId: this.generateId(), status: Ao.InProgress, authority: this.authority, libraryName: this.libraryName, libraryVersion: this.libraryVersion, clientId: this.clientId, name: e, startTimeMs: Date.now(), correlationId: r, appName: this.applicationTelemetry?.appName, appVersion: this.applicationTelemetry?.appVersion }; return this.cacheEventByCorrelationId(o), ul(o, this.abbreviations, this.eventStack.get(r)), { end: (i, s) => this.endMeasurement(p(p({}, o), i), s), discard: () => this.discardMeasurements(o.correlationId), add: i => this.addFields(i, o.correlationId), increment: i => this.incrementFields(i, o.correlationId), event: o, measurement: new So }; }
    endMeasurement(e, t) { let r = this.eventsByCorrelationId.get(e.correlationId); if (!r)
        return this.logger.trace(`PerformanceClient: Measurement not found for ${e.eventId}`, e.correlationId), null; let o = e.eventId === r.eventId, i = { totalQueueTime: 0, totalQueueCount: 0, manuallyCompletedCount: 0 }; e.durationMs = Math.round(e.durationMs || this.getDurationMs(e.startTimeMs)); let s = JSON.stringify(ml(e, this.abbreviations, this.eventStack.get(r.correlationId), t)); if (o ? (i = this.getQueueInfo(e.correlationId), this.discardMeasurements(r.correlationId)) : r.incompleteSubMeasurements?.delete(e.eventId), this.logger.trace(`PerformanceClient: Performance measurement ended for ${e.name}: ${e.durationMs} ms`, e.correlationId), t && gl(t, this.logger, r), !o)
        return r[e.name + "DurationMs"] = Math.floor(e.durationMs), p({}, r); o && !t && (r.errorCode || r.subErrorCode) && (this.logger.trace(`PerformanceClient: Remove error and sub-error codes for root event ${e.name} as intermediate error was successfully handled`, e.correlationId), r.errorCode = void 0, r.subErrorCode = void 0); let a = p(p({}, r), e), l = 0; return a.incompleteSubMeasurements?.forEach(h => { this.logger.trace(`PerformanceClient: Incomplete submeasurement ${h.name} found for ${e.name}`, a.correlationId), l++; }), a.incompleteSubMeasurements = void 0, a = I(p({}, a), { queuedTimeMs: i.totalQueueTime, queuedCount: i.totalQueueCount, queuedManuallyCompletedCount: i.manuallyCompletedCount, status: Ao.Completed, incompleteSubsCount: l, context: s }), this.truncateIntegralFields(a), this.emitEvents([a], e.correlationId), a; }
    addFields(e, t) { this.logger.trace("PerformanceClient: Updating static fields"); let r = this.eventsByCorrelationId.get(t); r ? this.eventsByCorrelationId.set(t, p(p({}, r), e)) : this.logger.trace("PerformanceClient: Event not found for", t); }
    incrementFields(e, t) { this.logger.trace("PerformanceClient: Updating counters"); let r = this.eventsByCorrelationId.get(t); if (r)
        for (let o in e) {
            if (!r.hasOwnProperty(o))
                r[o] = 0;
            else if (isNaN(Number(r[o])))
                return;
            r[o] += e[o];
        }
    else
        this.logger.trace("PerformanceClient: Event not found for", t); }
    cacheEventByCorrelationId(e) { let t = this.eventsByCorrelationId.get(e.correlationId); t ? (this.logger.trace(`PerformanceClient: Performance measurement for ${e.name} added/updated`, e.correlationId), t.incompleteSubMeasurements = t.incompleteSubMeasurements || new Map, t.incompleteSubMeasurements.set(e.eventId, { name: e.name, startTimeMs: e.startTimeMs })) : (this.logger.trace(`PerformanceClient: Performance measurement for ${e.name} started`, e.correlationId), this.eventsByCorrelationId.set(e.correlationId, p({}, e)), this.eventStack.set(e.correlationId, [])); }
    getQueueInfo(e) { let t = this.queueMeasurements.get(e); t || this.logger.trace(`PerformanceClient: no queue measurements found for for correlationId: ${e}`); let r = 0, o = 0, i = 0; return t?.forEach(s => { r += s.queueTime, o++, i += s.manuallyCompleted ? 1 : 0; }), { totalQueueTime: r, totalQueueCount: o, manuallyCompletedCount: i }; }
    discardMeasurements(e) { this.logger.trace("PerformanceClient: Performance measurements discarded", e), this.eventsByCorrelationId.delete(e), this.logger.trace("PerformanceClient: QueueMeasurements discarded", e), this.queueMeasurements.delete(e), this.logger.trace("PerformanceClient: Pre-queue times discarded", e), this.preQueueTimeByCorrelationId.delete(e), this.logger.trace("PerformanceClient: Event stack discarded", e), this.eventStack.delete(e); }
    addPerformanceCallback(e) { for (let [r, o] of this.callbacks)
        if (o.toString() === e.toString())
            return this.logger.warning(`PerformanceClient: Performance callback is already registered with id: ${r}`), r; let t = this.generateId(); return this.callbacks.set(t, e), this.logger.verbose(`PerformanceClient: Performance callback registered with id: ${t}`), t; }
    removePerformanceCallback(e) { let t = this.callbacks.delete(e); return t ? this.logger.verbose(`PerformanceClient: Performance callback ${e} removed.`) : this.logger.verbose(`PerformanceClient: Performance callback ${e} not removed.`), t; }
    emitEvents(e, t) { this.logger.verbose("PerformanceClient: Emitting performance events", t), this.callbacks.forEach((r, o) => { this.logger.trace(`PerformanceClient: Emitting event to callback ${o}`, t), r.apply(null, [e]); }); }
    truncateIntegralFields(e) { this.intFields.forEach(t => { t in e && typeof e[t] == "number" && (e[t] = Math.floor(e[t])); }); }
    getDurationMs(e) { let t = Date.now() - e; return t < 0 ? t : 0; }
};
var Na = {};
Ie(Na, { authCodeOrNativeAccountIdRequired: () => Vr, authCodeRequired: () => $r, authRequestNotSetError: () => An, blockIframeReload: () => xr, blockNestedPopups: () => Hr, cryptoKeyNotFound: () => ft, cryptoNonExistent: () => Ht, databaseNotOpen: () => Ge, databaseUnavailable: () => Ct, emptyNavigateUri: () => Fe, emptyWindowError: () => Ur, failedToBuildHeaders: () => yn, failedToParseHeaders: () => In, failedToParseResponse: () => Bt, getRequestFailed: () => Gr, hashDoesNotContainKnownProperties: () => br, hashEmptyError: () => _r, iframeClosedPrematurely: () => Cn, interactionInProgress: () => Or, invalidBase64String: () => Zr, invalidCacheType: () => En, invalidPopTokenRequest: () => eo, monitorPopupTimeout: () => fn, monitorWindowTimeout: () => Lr, nativeConnectionNotEstablished: () => Re, nativeExtensionNotInstalled: () => jr, nativeHandshakeTimeout: () => Wr, nativePromptNotSupported: () => Xr, noAccountError: () => Br, noCachedAuthorityError: () => pt, noNetworkConnectivity: () => Xe, noStateInHash: () => gt, noTokenRequestCacheError: () => Fr, nonBrowserEnvironment: () => qe, pkceNotCreated: () => xt, popupWindowError: () => Mr, postRequestFailed: () => qr, redirectInIframe: () => Dr, silentLogoutUnsupported: () => Ke, silentPromptValueError: () => Tn, spaCodeAndNativeAccountIdPresent: () => Qr, stateInteractionTypeMismatch: () => Nr, unableToAcquireTokenFromNativePlatform: () => Yr, unableToLoadToken: () => zr, unableToParseState: () => Pr, unableToParseTokenRequestCacheError: () => Kr, uninitializedPublicClientApplication: () => Jr, userCancelled: () => Te });
var xt = "pkce_not_created", Ht = "crypto_nonexistent", Fe = "empty_navigate_uri", _r = "hash_empty_error", gt = "no_state_in_hash", br = "hash_does_not_contain_known_properties", Pr = "unable_to_parse_state", Nr = "state_interaction_type_mismatch", Or = "interaction_in_progress", Mr = "popup_window_error", Ur = "empty_window_error", Te = "user_cancelled", fn = "monitor_popup_timeout", Lr = "monitor_window_timeout", Dr = "redirect_in_iframe", xr = "block_iframe_reload", Hr = "block_nested_popups", Cn = "iframe_closed_prematurely", Ke = "silent_logout_unsupported", Br = "no_account_error", Tn = "silent_prompt_value_error", Fr = "no_token_request_cache_error", Kr = "unable_to_parse_token_request_cache_error", pt = "no_cached_authority_error", An = "auth_request_not_set_error", En = "invalid_cache_type", qe = "non_browser_environment", Ge = "database_not_open", Xe = "no_network_connectivity", qr = "post_request_failed", Gr = "get_request_failed", Bt = "failed_to_parse_response", zr = "unable_to_load_token", ft = "crypto_key_not_found", $r = "auth_code_required", Vr = "auth_code_or_nativeAccountId_required", Qr = "spa_code_and_nativeAccountId_present", Ct = "database_unavailable", Yr = "unable_to_acquire_token_from_native_platform", Wr = "native_handshake_timeout", jr = "native_extension_not_installed", Re = "native_connection_not_established", Jr = "uninitialized_public_client_application", Xr = "native_prompt_not_supported", Zr = "invalid_base64_string", eo = "invalid_pop_token_request", yn = "failed_to_build_headers", In = "failed_to_parse_headers";
var Tt = "For more visit: aka.ms/msaljs/browser-errors", R = { [xt]: "The PKCE code challenge and verifier could not be generated.", [Ht]: "The crypto object or function is not available.", [Fe]: "Navigation URI is empty. Please check stack trace for more info.", [_r]: `Hash value cannot be processed because it is empty. Please verify that your redirectUri is not clearing the hash. ${Tt}`, [gt]: "Hash does not contain state. Please verify that the request originated from msal.", [br]: `Hash does not contain known properites. Please verify that your redirectUri is not changing the hash.  ${Tt}`, [Pr]: "Unable to parse state. Please verify that the request originated from msal.", [Nr]: "Hash contains state but the interaction type does not match the caller.", [Or]: `Interaction is currently in progress. Please ensure that this interaction has been completed before calling an interactive API.   ${Tt}`, [Mr]: "Error opening popup window. This can happen if you are using IE or if popups are blocked in the browser.", [Ur]: "window.open returned null or undefined window object.", [Te]: "User cancelled the flow.", [fn]: `Token acquisition in popup failed due to timeout.  ${Tt}`, [Lr]: `Token acquisition in iframe failed due to timeout.  ${Tt}`, [Dr]: "Redirects are not supported for iframed or brokered applications. Please ensure you are using MSAL.js in a top frame of the window if using the redirect APIs, or use the popup APIs.", [xr]: `Request was blocked inside an iframe because MSAL detected an authentication response.  ${Tt}`, [Hr]: "Request was blocked inside a popup because MSAL detected it was running in a popup.", [Cn]: "The iframe being monitored was closed prematurely.", [Ke]: "Silent logout not supported. Please call logoutRedirect or logoutPopup instead.", [Br]: "No account object provided to acquireTokenSilent and no active account has been set. Please call setActiveAccount or provide an account on the request.", [Tn]: "The value given for the prompt value is not valid for silent requests - must be set to 'none' or 'no_session'.", [Fr]: "No token request found in cache.", [Kr]: "The cached token request could not be parsed.", [pt]: "No cached authority found.", [An]: "Auth Request not set. Please ensure initiateAuthRequest was called from the InteractionHandler", [En]: "Invalid cache type", [qe]: "Login and token requests are not supported in non-browser environments.", [Ge]: "Database is not open!", [Xe]: "No network connectivity. Check your internet connection.", [qr]: "Network request failed: If the browser threw a CORS error, check that the redirectUri is registered in the Azure App Portal as type 'SPA'", [Gr]: "Network request failed. Please check the network trace to determine root cause.", [Bt]: "Failed to parse network response. Check network trace.", [zr]: "Error loading token to cache.", [ft]: "Cryptographic Key or Keypair not found in browser storage.", [$r]: "An authorization code must be provided (as the `code` property on the request) to this flow.", [Vr]: "An authorization code or nativeAccountId must be provided to this flow.", [Qr]: "Request cannot contain both spa code and native account id.", [Ct]: "IndexedDB, which is required for persistent cryptographic key storage, is unavailable. This may be caused by browser privacy features which block persistent storage in third-party contexts.", [Yr]: `Unable to acquire token from native platform.  ${Tt}`, [Wr]: "Timed out while attempting to establish connection to browser extension", [jr]: "Native extension is not installed. If you think this is a mistake call the initialize function.", [Re]: `Connection to native platform has not been established. Please install a compatible browser extension and run initialize().  ${Tt}`, [Jr]: `You must call and await the initialize function before attempting to call any other MSAL API.  ${Tt}`, [Xr]: "The provided prompt is not supported by the native platform. This request should be routed to the web based flow.", [Zr]: "Invalid base64 encoded string.", [eo]: "Invalid PoP token request. The request should not have both a popKid value and signPopToken set to true.", [yn]: "Failed to build request headers object.", [In]: "Failed to parse response headers" }, fl = { pkceNotGenerated: { code: xt, desc: R[xt] }, cryptoDoesNotExist: { code: Ht, desc: R[Ht] }, emptyNavigateUriError: { code: Fe, desc: R[Fe] }, hashEmptyError: { code: _r, desc: R[_r] }, hashDoesNotContainStateError: { code: gt, desc: R[gt] }, hashDoesNotContainKnownPropertiesError: { code: br, desc: R[br] }, unableToParseStateError: { code: Pr, desc: R[Pr] }, stateInteractionTypeMismatchError: { code: Nr, desc: R[Nr] }, interactionInProgress: { code: Or, desc: R[Or] }, popupWindowError: { code: Mr, desc: R[Mr] }, emptyWindowError: { code: Ur, desc: R[Ur] }, userCancelledError: { code: Te, desc: R[Te] }, monitorPopupTimeoutError: { code: fn, desc: R[fn] }, monitorIframeTimeoutError: { code: Lr, desc: R[Lr] }, redirectInIframeError: { code: Dr, desc: R[Dr] }, blockTokenRequestsInHiddenIframeError: { code: xr, desc: R[xr] }, blockAcquireTokenInPopupsError: { code: Hr, desc: R[Hr] }, iframeClosedPrematurelyError: { code: Cn, desc: R[Cn] }, silentLogoutUnsupportedError: { code: Ke, desc: R[Ke] }, noAccountError: { code: Br, desc: R[Br] }, silentPromptValueError: { code: Tn, desc: R[Tn] }, noTokenRequestCacheError: { code: Fr, desc: R[Fr] }, unableToParseTokenRequestCacheError: { code: Kr, desc: R[Kr] }, noCachedAuthorityError: { code: pt, desc: R[pt] }, authRequestNotSet: { code: An, desc: R[An] }, invalidCacheType: { code: En, desc: R[En] }, notInBrowserEnvironment: { code: qe, desc: R[qe] }, databaseNotOpen: { code: Ge, desc: R[Ge] }, noNetworkConnectivity: { code: Xe, desc: R[Xe] }, postRequestFailed: { code: qr, desc: R[qr] }, getRequestFailed: { code: Gr, desc: R[Gr] }, failedToParseNetworkResponse: { code: Bt, desc: R[Bt] }, unableToLoadTokenError: { code: zr, desc: R[zr] }, signingKeyNotFoundInStorage: { code: ft, desc: R[ft] }, authCodeRequired: { code: $r, desc: R[$r] }, authCodeOrNativeAccountRequired: { code: Vr, desc: R[Vr] }, spaCodeAndNativeAccountPresent: { code: Qr, desc: R[Qr] }, databaseUnavailable: { code: Ct, desc: R[Ct] }, unableToAcquireTokenFromNativePlatform: { code: Yr, desc: R[Yr] }, nativeHandshakeTimeout: { code: Wr, desc: R[Wr] }, nativeExtensionNotInstalled: { code: jr, desc: R[jr] }, nativeConnectionNotEstablished: { code: Re, desc: R[Re] }, uninitializedPublicClientApplication: { code: Jr, desc: R[Jr] }, nativePromptNotSupported: { code: Xr, desc: R[Xr] }, invalidBase64StringError: { code: Zr, desc: R[Zr] }, invalidPopTokenRequest: { code: eo, desc: R[eo] } }, Ft = class n extends w {
    constructor(e, t) { super(e, R[e], t), Object.setPrototypeOf(this, n.prototype), this.name = "BrowserAuthError"; }
};
function C(n, e) { return new Ft(n, e); }
var W = { INTERACTION_IN_PROGRESS_VALUE: "interaction_in_progress", INVALID_GRANT_ERROR: "invalid_grant", POPUP_WIDTH: 483, POPUP_HEIGHT: 600, POPUP_NAME_PREFIX: "msal", DEFAULT_POLL_INTERVAL_MS: 30, MSAL_SKU: "msal.js.browser" }, Kt = { CHANNEL_ID: "53ee284d-920a-4b59-9d30-a60315b26836", PREFERRED_EXTENSION_ID: "ppnbnpeolgkicgegkbkbjmhlideopiji", MATS_TELEMETRY: "MATS" }, At = { HandshakeRequest: "Handshake", HandshakeResponse: "HandshakeResponse", GetToken: "GetToken", Response: "Response" }, $ = { LocalStorage: "localStorage", SessionStorage: "sessionStorage", MemoryStorage: "memoryStorage" }, Ws = { GET: "GET", POST: "POST" }, O = { AUTHORITY: "authority", ACQUIRE_TOKEN_ACCOUNT: "acquireToken.account", SESSION_STATE: "session.state", REQUEST_STATE: "request.state", NONCE_IDTOKEN: "nonce.id_token", ORIGIN_URI: "request.origin", RENEW_STATUS: "token.renew.status", URL_HASH: "urlHash", REQUEST_PARAMS: "request.params", SCOPES: "scopes", INTERACTION_STATUS_KEY: "interaction.status", CCS_CREDENTIAL: "ccs.credential", CORRELATION_ID: "request.correlationId", NATIVE_REQUEST: "request.native", REDIRECT_CONTEXT: "request.redirect.context" }, Et = { ACCOUNT_KEYS: "msal.account.keys", TOKEN_KEYS: "msal.token.keys" }, Sn = { WRAPPER_SKU: "wrapper.sku", WRAPPER_VER: "wrapper.version" }, M = { acquireTokenRedirect: 861, acquireTokenPopup: 862, ssoSilent: 863, acquireTokenSilent_authCode: 864, handleRedirectPromise: 865, acquireTokenByCode: 866, acquireTokenSilent_silentFlow: 61, logout: 961, logoutPopup: 962 }, E = (function (n) { return n.Redirect = "redirect", n.Popup = "popup", n.Silent = "silent", n.None = "none", n; })(E || {}), he = { Startup: "startup", Login: "login", Logout: "logout", AcquireToken: "acquireToken", SsoSilent: "ssoSilent", HandleRedirect: "handleRedirect", None: "none" }, vn = { scopes: ce }, js = "jwk", Cl = { React: "@azure/msal-react", Angular: "@azure/msal-angular" }, pi = "msal.db", Oa = 1, Ma = `${pi}.keys`, ie = { Default: 0, AccessToken: 1, AccessTokenAndRefreshToken: 2, RefreshToken: 3, RefreshTokenAndNetwork: 4, Skip: 5 }, Ua = [ie.Default, ie.Skip, ie.RefreshTokenAndNetwork], La = "msal.browser.log.level", Da = "msal.browser.log.pii", xa = "msal.browser.performance.enabled";
function wn(n) { return encodeURIComponent(Rn(n).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_")); }
function to(n) { return Ha(n).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_"); }
function Rn(n) { return Ha(new TextEncoder().encode(n)); }
function Ha(n) { let e = Array.from(n, t => String.fromCodePoint(t)).join(""); return btoa(e); }
var Tl = "RSASSA-PKCS1-v1_5", Ka = "SHA-256", Al = 2048, El = new Uint8Array([1, 0, 1]), Ba = "0123456789abcdef", Fa = new Uint32Array(1), yl = "crypto_subtle_undefined", Xs = { name: Tl, hash: Ka, modulusLength: Al, publicExponent: El };
function qa(n) { if (!window)
    throw C(qe); if (!window.crypto)
    throw C(Ht); if (!n && !window.crypto.subtle)
    throw C(Ht, yl); }
function Zs(n, e, t) { return d(this, null, function* () { e?.addQueueMeasurement(c.Sha256Digest, t); let o = new TextEncoder().encode(n); return window.crypto.subtle.digest(Ka, o); }); }
function Ga(n) { return window.crypto.getRandomValues(n); }
function Js() { return window.crypto.getRandomValues(Fa), Fa[0]; }
function ee() { let n = Date.now(), e = Js() * 1024 + (Js() & 1023), t = new Uint8Array(16), r = Math.trunc(e / 2 ** 30), o = e & 2 ** 30 - 1, i = Js(); t[0] = n / 2 ** 40, t[1] = n / 2 ** 32, t[2] = n / 2 ** 24, t[3] = n / 2 ** 16, t[4] = n / 2 ** 8, t[5] = n, t[6] = 112 | r >>> 8, t[7] = r, t[8] = 128 | o >>> 24, t[9] = o >>> 16, t[10] = o >>> 8, t[11] = o, t[12] = i >>> 24, t[13] = i >>> 16, t[14] = i >>> 8, t[15] = i; let s = ""; for (let a = 0; a < t.length; a++)
    s += Ba.charAt(t[a] >>> 4), s += Ba.charAt(t[a] & 15), (a === 3 || a === 5 || a === 7 || a === 9) && (s += "-"); return s; }
function za(n, e) { return d(this, null, function* () { return window.crypto.subtle.generateKey(Xs, n, e); }); }
function fi(n) { return d(this, null, function* () { return window.crypto.subtle.exportKey(js, n); }); }
function $a(n, e, t) { return d(this, null, function* () { return window.crypto.subtle.importKey(js, n, Xs, e, t); }); }
function Va(n, e) { return d(this, null, function* () { return window.crypto.subtle.sign(Xs, n, e); }); }
function Ci(n) { return d(this, null, function* () { let e = yield Zs(n), t = new Uint8Array(e); return to(t); }); }
var Qa = {};
Ie(Qa, { inMemRedirectUnavailable: () => ro, storageNotSupported: () => ze, stubbedPublicClientApplicationCalled: () => j });
var ze = "storage_not_supported", j = "stubbed_public_client_application_called", ro = "in_mem_redirect_unavailable";
var Ti = { [ze]: "Given storage configuration option was not supported.", [j]: "Stub instance of Public Client Application was called. If using msal-react, please ensure context is not used without a provider. For more visit: aka.ms/msaljs/browser-errors", [ro]: "Redirect cannot be supported. In-memory storage was selected and storeAuthStateInCookie=false, which would cause the library to be unable to handle the incoming hash. If you would like to use the redirect API, please use session/localStorage or set storeAuthStateInCookie=true." }, Il = { storageNotSupportedError: { code: ze, desc: Ti[ze] }, stubPcaInstanceCalled: { code: j, desc: Ti[j] }, inMemRedirectUnavailable: { code: ro, desc: Ti[ro] } }, Ai = class n extends w {
    constructor(e, t) { super(e, t), this.name = "BrowserConfigurationAuthError", Object.setPrototypeOf(this, n.prototype); }
};
function q(n) { return new Ai(n, Ti[n]); }
function ea(n) { n.location.hash = "", typeof n.history.replaceState == "function" && n.history.replaceState(null, "", `${n.location.origin}${n.location.pathname}${n.location.search}`); }
function ta(n) { let e = n.split("#"); e.shift(), window.location.hash = e.length > 0 ? e.join("#") : ""; }
function kn() { return window.parent !== window; }
function Ya() { return typeof window < "u" && !!window.opener && window.opener !== window && typeof window.name == "string" && window.name.indexOf(`${W.POPUP_NAME_PREFIX}.`) === 0; }
function Ae() { return typeof window < "u" && window.location ? window.location.href.split("?")[0].split("#")[0] : ""; }
function ra() { let e = new P(window.location.href).getUrlComponents(); return `${e.Protocol}//${e.HostNameAndPort}/`; }
function Wa() { if (P.hashContainsKnownProperties(window.location.hash) && kn())
    throw C(xr); }
function ja(n) { if (kn() && !n)
    throw C(Dr); }
function Ja() { if (Ya())
    throw C(Hr); }
function D() { if (typeof window > "u")
    throw C(qe); }
function U(n) { if (!n)
    throw C(Jr); }
function _n(n) { D(), Wa(), Ja(), U(n); }
function Ei(n, e) { if (_n(n), ja(e.system.allowRedirectInIframe), e.cache.cacheLocation === $.MemoryStorage && !e.cache.storeAuthStateInCookie)
    throw q(ro); }
function bn(n) { let e = document.createElement("link"); e.rel = "preconnect", e.href = new URL(n).origin, e.crossOrigin = "anonymous", document.head.appendChild(e), window.setTimeout(() => { try {
    document.head.removeChild(e);
}
catch { } }, 1e4); }
function oa() { return ee(); }
var Pn = class n {
    navigateInternal(e, t) { return n.defaultNavigateWindow(e, t); }
    navigateExternal(e, t) { return n.defaultNavigateWindow(e, t); }
    static defaultNavigateWindow(e, t) { return t.noHistory ? window.location.replace(e) : window.location.assign(e), new Promise(r => { setTimeout(() => { r(!0); }, t.timeout); }); }
};
var yi = class {
    sendGetRequestAsync(e, t) { return d(this, null, function* () { let r, o = {}, i = 0, s = Za(t); try {
        r = yield fetch(e, { method: Ws.GET, headers: s });
    }
    catch {
        throw C(window.navigator.onLine ? Gr : Xe);
    } o = ec(r.headers); try {
        return i = r.status, { headers: o, body: yield r.json(), status: i };
    }
    catch {
        throw ci(C(Bt), i, o);
    } }); }
    sendPostRequestAsync(e, t) { return d(this, null, function* () { let r = t && t.body || "", o = Za(t), i, s = 0, a = {}; try {
        i = yield fetch(e, { method: Ws.POST, headers: o, body: r });
    }
    catch {
        throw C(window.navigator.onLine ? qr : Xe);
    } a = ec(i.headers); try {
        return s = i.status, { headers: a, body: yield i.json(), status: s };
    }
    catch {
        throw ci(C(Bt), s, a);
    } }); }
};
function Za(n) { try {
    let e = new Headers;
    if (!(n && n.headers))
        return e;
    let t = n.headers;
    return Object.entries(t).forEach(([r, o]) => { e.append(r, o); }), e;
}
catch {
    throw C(yn);
} }
function ec(n) { try {
    let e = {};
    return n.forEach((t, r) => { e[r] = t; }), e;
}
catch {
    throw C(In);
} }
var Sl = 6e4, Nn = 1e4, vl = 3e4, wl = 2e3;
function tc({ auth: n, cache: e, system: t, telemetry: r }, o) { let i = { clientId: u.EMPTY_STRING, authority: `${u.DEFAULT_AUTHORITY}`, knownAuthorities: [], cloudDiscoveryMetadata: u.EMPTY_STRING, authorityMetadata: u.EMPTY_STRING, redirectUri: typeof window < "u" ? Ae() : "", postLogoutRedirectUri: u.EMPTY_STRING, navigateToLoginRequestUrl: !0, clientCapabilities: [], protocolMode: le.AAD, OIDCOptions: { serverResponseType: Ue.FRAGMENT, defaultScopes: [u.OPENID_SCOPE, u.PROFILE_SCOPE, u.OFFLINE_ACCESS_SCOPE] }, azureCloudOptions: { azureCloudInstance: _t.None, tenant: u.EMPTY_STRING }, skipAuthorityMetadataCache: !1, supportsNestedAppAuth: !1, instanceAware: !1 }, s = { cacheLocation: $.SessionStorage, temporaryCacheLocation: $.SessionStorage, storeAuthStateInCookie: !1, secureCookies: !1, cacheMigrationEnabled: !!(e && e.cacheLocation === $.LocalStorage), claimsBasedCachingEnabled: !1 }, a = { loggerCallback: () => { }, logLevel: H.Info, piiLoggingEnabled: !1 }, l = I(p({}, Zn), { loggerOptions: a, networkClient: o ? new yi : $s, navigationClient: new Pn, loadFrameTimeout: 0, windowHashTimeout: t?.loadFrameTimeout || Sl, iframeHashTimeout: t?.loadFrameTimeout || Nn, navigateFrameWait: 0, redirectNavigationTimeout: vl, asyncPopups: !1, allowRedirectInIframe: !1, allowNativeBroker: !1, nativeBrokerHandshakeTimeout: t?.nativeBrokerHandshakeTimeout || wl, pollIntervalMilliseconds: W.DEFAULT_POLL_INTERVAL_MS }), h = I(p(p({}, l), t), { loggerOptions: t?.loggerOptions || a }), g = { application: { appName: u.EMPTY_STRING, appVersion: u.EMPTY_STRING }, client: new vo }; if (n?.protocolMode !== le.OIDC && n?.OIDCOptions && new ae(h.loggerOptions).warning(JSON.stringify(N(He.cannotSetOIDCOptions))), n?.protocolMode && n.protocolMode !== le.AAD && h?.allowNativeBroker)
    throw N(He.cannotAllowNativeBroker); return { auth: I(p(p({}, i), n), { OIDCOptions: p(p({}, i.OIDCOptions), n?.OIDCOptions) }), cache: p(p({}, s), e), system: h, telemetry: p(p({}, g), r) }; }
var oo = "@azure/msal-browser", ue = "3.28.1";
var qt = class n {
    static loggerCallback(e, t) { switch (e) {
        case H.Error:
            console.error(t);
            return;
        case H.Info:
            console.info(t);
            return;
        case H.Verbose:
            console.debug(t);
            return;
        case H.Warning:
            console.warn(t);
            return;
        default:
            console.log(t);
            return;
    } }
    constructor(e) { this.browserEnvironment = typeof window < "u", this.config = tc(e, this.browserEnvironment); let t; try {
        t = window[$.SessionStorage];
    }
    catch { } let r = t?.getItem(La), o = t?.getItem(Da)?.toLowerCase(), i = o === "true" ? !0 : o === "false" ? !1 : void 0, s = p({}, this.config.system.loggerOptions), a = r && Object.keys(H).includes(r) ? H[r] : void 0; a && (s.loggerCallback = n.loggerCallback, s.logLevel = a), i !== void 0 && (s.piiLoggingEnabled = i), this.logger = new ae(s, oo, ue), this.available = !1; }
    getConfig() { return this.config; }
    getLogger() { return this.logger; }
    isAvailable() { return this.available; }
    isBrowserEnvironment() { return this.browserEnvironment; }
};
var $e = { UserInteractionRequired: "USER_INTERACTION_REQUIRED", UserCancel: "USER_CANCEL", NoNetwork: "NO_NETWORK", TransientError: "TRANSIENT_ERROR", PersistentError: "PERSISTENT_ERROR", Disabled: "DISABLED", AccountUnavailable: "ACCOUNT_UNAVAILABLE", NestedAppAuthUnavailable: "NESTED_APP_AUTH_UNAVAILABLE" };
var rc = (() => { class n {
    static initializeNestedAppAuthBridge() { return d(this, null, function* () { if (window === void 0)
        throw new Error("window is undefined"); if (window.nestedAppAuthBridge === void 0)
        throw new Error("window.nestedAppAuthBridge is undefined"); try {
        window.nestedAppAuthBridge.addEventListener("message", r => { let o = typeof r == "string" ? r : r.data, i = JSON.parse(o), s = n.bridgeRequests.find(a => a.requestId === i.requestId); s !== void 0 && (n.bridgeRequests.splice(n.bridgeRequests.indexOf(s), 1), i.success ? s.resolve(i) : s.reject(i.error)); });
        let t = yield new Promise((r, o) => { let i = n.buildRequest("GetInitContext"), s = { requestId: i.requestId, method: i.method, resolve: r, reject: o }; n.bridgeRequests.push(s), window.nestedAppAuthBridge.postMessage(JSON.stringify(i)); });
        return n.validateBridgeResultOrThrow(t.initContext);
    }
    catch (t) {
        throw window.console.log(t), t;
    } }); }
    getTokenInteractive(t) { return this.getToken("GetTokenPopup", t); }
    getTokenSilent(t) { return this.getToken("GetToken", t); }
    getToken(t, r) { return d(this, null, function* () { let o = yield this.sendRequest(t, { tokenParams: r }); return { token: n.validateBridgeResultOrThrow(o.token), account: n.validateBridgeResultOrThrow(o.account) }; }); }
    getHostCapabilities() { return this.capabilities ?? null; }
    getAccountContext() { return this.accountContext ? this.accountContext : null; }
    static buildRequest(t, r) { return p({ messageType: "NestedAppAuthRequest", method: t, requestId: ee(), sendTime: Date.now(), clientLibrary: W.MSAL_SKU, clientLibraryVersion: ue }, r); }
    sendRequest(t, r) { let o = n.buildRequest(t, r); return new Promise((s, a) => { let l = { requestId: o.requestId, method: o.method, resolve: s, reject: a }; n.bridgeRequests.push(l), window.nestedAppAuthBridge.postMessage(JSON.stringify(o)); }); }
    static validateBridgeResultOrThrow(t) { if (t === void 0)
        throw { status: $e.NestedAppAuthUnavailable }; return t; }
    constructor(t, r, o, i) { this.sdkName = t, this.sdkVersion = r, this.accountContext = o, this.capabilities = i; }
    static create() { return d(this, null, function* () { let t = yield n.initializeNestedAppAuthBridge(); return new n(t.sdkName, t.sdkVersion, t.accountContext, t.capabilities); }); }
} return n.bridgeRequests = [], n; })();
var Ii = (() => { class n extends qt {
    constructor() { super(...arguments), this.bridgeProxy = void 0, this.accountContext = null; }
    getModuleName() { return n.MODULE_NAME; }
    getId() { return n.ID; }
    getBridgeProxy() { return this.bridgeProxy; }
    initialize() { return d(this, null, function* () { try {
        if (typeof window < "u") {
            typeof window.__initializeNestedAppAuth == "function" && (yield window.__initializeNestedAppAuth());
            let t = yield rc.create();
            this.accountContext = t.getAccountContext(), this.bridgeProxy = t, this.available = t !== void 0;
        }
    }
    catch (t) {
        this.logger.infoPii(`Could not initialize Nested App Auth bridge (${t})`);
    } return this.logger.info(`Nested App Auth Bridge available: ${this.available}`), this.available; }); }
} return n.MODULE_NAME = "", n.ID = "NestedAppOperatingContext", n; })();
var On = (() => { class n extends qt {
    getModuleName() { return n.MODULE_NAME; }
    getId() { return n.ID; }
    initialize() { return d(this, null, function* () { return this.available = typeof window < "u", this.available; }); }
} return n.MODULE_NAME = "", n.ID = "StandardOperatingContext", n; })();
function Ee(n) { return new TextDecoder().decode(Rl(n)); }
function Rl(n) { let e = n.replace(/-/g, "+").replace(/_/g, "/"); switch (e.length % 4) {
    case 0: break;
    case 2:
        e += "==";
        break;
    case 3:
        e += "=";
        break;
    default: throw C(Zr);
} let t = atob(e); return Uint8Array.from(t, r => r.codePointAt(0) || 0); }
var Si = class {
    constructor() { this.dbName = pi, this.version = Oa, this.tableName = Ma, this.dbOpen = !1; }
    open() { return d(this, null, function* () { return new Promise((e, t) => { let r = window.indexedDB.open(this.dbName, this.version); r.addEventListener("upgradeneeded", o => { o.target.result.createObjectStore(this.tableName); }), r.addEventListener("success", o => { let i = o; this.db = i.target.result, this.dbOpen = !0, e(); }), r.addEventListener("error", () => t(C(Ct))); }); }); }
    closeConnection() { let e = this.db; e && this.dbOpen && (e.close(), this.dbOpen = !1); }
    validateDbIsOpen() { return d(this, null, function* () { if (!this.dbOpen)
        return this.open(); }); }
    getItem(e) { return d(this, null, function* () { return yield this.validateDbIsOpen(), new Promise((t, r) => { if (!this.db)
        return r(C(Ge)); let s = this.db.transaction([this.tableName], "readonly").objectStore(this.tableName).get(e); s.addEventListener("success", a => { let l = a; this.closeConnection(), t(l.target.result); }), s.addEventListener("error", a => { this.closeConnection(), r(a); }); }); }); }
    setItem(e, t) { return d(this, null, function* () { return yield this.validateDbIsOpen(), new Promise((r, o) => { if (!this.db)
        return o(C(Ge)); let a = this.db.transaction([this.tableName], "readwrite").objectStore(this.tableName).put(t, e); a.addEventListener("success", () => { this.closeConnection(), r(); }), a.addEventListener("error", l => { this.closeConnection(), o(l); }); }); }); }
    removeItem(e) { return d(this, null, function* () { return yield this.validateDbIsOpen(), new Promise((t, r) => { if (!this.db)
        return r(C(Ge)); let s = this.db.transaction([this.tableName], "readwrite").objectStore(this.tableName).delete(e); s.addEventListener("success", () => { this.closeConnection(), t(); }), s.addEventListener("error", a => { this.closeConnection(), r(a); }); }); }); }
    getKeys() { return d(this, null, function* () { return yield this.validateDbIsOpen(), new Promise((e, t) => { if (!this.db)
        return t(C(Ge)); let i = this.db.transaction([this.tableName], "readonly").objectStore(this.tableName).getAllKeys(); i.addEventListener("success", s => { let a = s; this.closeConnection(), e(a.target.result); }), i.addEventListener("error", s => { this.closeConnection(), t(s); }); }); }); }
    containsKey(e) { return d(this, null, function* () { return yield this.validateDbIsOpen(), new Promise((t, r) => { if (!this.db)
        return r(C(Ge)); let s = this.db.transaction([this.tableName], "readonly").objectStore(this.tableName).count(e); s.addEventListener("success", a => { let l = a; this.closeConnection(), t(l.target.result === 1); }), s.addEventListener("error", a => { this.closeConnection(), r(a); }); }); }); }
    deleteDatabase() { return d(this, null, function* () { return this.db && this.dbOpen && this.closeConnection(), new Promise((e, t) => { let r = window.indexedDB.deleteDatabase(pi), o = setTimeout(() => t(!1), 200); r.addEventListener("success", () => (clearTimeout(o), e(!0))), r.addEventListener("blocked", () => (clearTimeout(o), e(!0))), r.addEventListener("error", () => (clearTimeout(o), t(!1))); }); }); }
};
var Gt = class {
    constructor() { this.cache = new Map; }
    getItem(e) { return this.cache.get(e) || null; }
    setItem(e, t) { this.cache.set(e, t); }
    removeItem(e) { this.cache.delete(e); }
    getKeys() { let e = []; return this.cache.forEach((t, r) => { e.push(r); }), e; }
    containsKey(e) { return this.cache.has(e); }
    clear() { this.cache.clear(); }
};
var vi = class {
    constructor(e) { this.inMemoryCache = new Gt, this.indexedDBCache = new Si, this.logger = e; }
    handleDatabaseAccessError(e) { if (e instanceof Ft && e.errorCode === Ct)
        this.logger.error("Could not access persistent storage. This may be caused by browser privacy features which block persistent storage in third-party contexts.");
    else
        throw e; }
    getItem(e) { return d(this, null, function* () { let t = this.inMemoryCache.getItem(e); if (!t)
        try {
            return this.logger.verbose("Queried item not found in in-memory cache, now querying persistent storage."), yield this.indexedDBCache.getItem(e);
        }
        catch (r) {
            this.handleDatabaseAccessError(r);
        } return t; }); }
    setItem(e, t) { return d(this, null, function* () { this.inMemoryCache.setItem(e, t); try {
        yield this.indexedDBCache.setItem(e, t);
    }
    catch (r) {
        this.handleDatabaseAccessError(r);
    } }); }
    removeItem(e) { return d(this, null, function* () { this.inMemoryCache.removeItem(e); try {
        yield this.indexedDBCache.removeItem(e);
    }
    catch (t) {
        this.handleDatabaseAccessError(t);
    } }); }
    getKeys() { return d(this, null, function* () { let e = this.inMemoryCache.getKeys(); if (e.length === 0)
        try {
            return this.logger.verbose("In-memory cache is empty, now querying persistent storage."), yield this.indexedDBCache.getKeys();
        }
        catch (t) {
            this.handleDatabaseAccessError(t);
        } return e; }); }
    containsKey(e) { return d(this, null, function* () { let t = this.inMemoryCache.containsKey(e); if (!t)
        try {
            return this.logger.verbose("Key not found in in-memory cache, now querying persistent storage."), yield this.indexedDBCache.containsKey(e);
        }
        catch (r) {
            this.handleDatabaseAccessError(r);
        } return t; }); }
    clearInMemory() { this.logger.verbose("Deleting in-memory keystore"), this.inMemoryCache.clear(), this.logger.verbose("In-memory keystore deleted"); }
    clearPersistent() { return d(this, null, function* () { try {
        this.logger.verbose("Deleting persistent keystore");
        let e = yield this.indexedDBCache.deleteDatabase();
        return e && this.logger.verbose("Persistent keystore deleted"), e;
    }
    catch (e) {
        return this.handleDatabaseAccessError(e), !1;
    } }); }
};
var zt = (() => { class n {
    constructor(t, r, o) { this.logger = t, qa(o ?? !1), this.cache = new vi(this.logger), this.performanceClient = r; }
    createNewGuid() { return ee(); }
    base64Encode(t) { return Rn(t); }
    base64Decode(t) { return Ee(t); }
    base64UrlEncode(t) { return wn(t); }
    encodeKid(t) { return this.base64UrlEncode(JSON.stringify({ kid: t })); }
    getPublicKeyThumbprint(t) { return d(this, null, function* () { let r = this.performanceClient?.startMeasurement(c.CryptoOptsGetPublicKeyThumbprint, t.correlationId), o = yield za(n.EXTRACTABLE, n.POP_KEY_USAGES), i = yield fi(o.publicKey), s = { e: i.e, kty: i.kty, n: i.n }, a = oc(s), l = yield this.hashString(a), h = yield fi(o.privateKey), g = yield $a(h, !1, ["sign"]); return yield this.cache.setItem(l, { privateKey: g, publicKey: o.publicKey, requestMethod: t.resourceRequestMethod, requestUri: t.resourceRequestUri }), r && r.end({ success: !0 }), l; }); }
    removeTokenBindingKey(t) { return d(this, null, function* () { return yield this.cache.removeItem(t), !(yield this.cache.containsKey(t)); }); }
    clearKeystore() { return d(this, null, function* () { this.cache.clearInMemory(); try {
        return yield this.cache.clearPersistent(), !0;
    }
    catch (t) {
        return t instanceof Error ? this.logger.error(`Clearing keystore failed with error: ${t.message}`) : this.logger.error("Clearing keystore failed with unknown error"), !1;
    } }); }
    signJwt(t, r, o, i) { return d(this, null, function* () { let s = this.performanceClient?.startMeasurement(c.CryptoOptsSignJwt, i), a = yield this.cache.getItem(r); if (!a)
        throw C(ft); let l = yield fi(a.publicKey), h = oc(l), g = wn(JSON.stringify({ kid: r })), T = gn.getShrHeaderString(I(p({}, o?.header), { alg: l.alg, kid: g })), y = wn(T); t.cnf = { jwk: JSON.parse(h) }; let v = wn(JSON.stringify(t)), L = `${y}.${v}`, de = new TextEncoder().encode(L), Oe = yield Va(a.privateKey, de), Qt = to(new Uint8Array(Oe)), co = `${L}.${Qt}`; return s && s.end({ success: !0 }), co; }); }
    hashString(t) { return d(this, null, function* () { return Ci(t); }); }
} return n.POP_KEY_USAGES = ["sign", "verify"], n.EXTRACTABLE = !0, n; })();
function oc(n) { return JSON.stringify(n, Object.keys(n).sort()); }
var no = class {
    constructor() { if (!window.localStorage)
        throw q(ze); }
    getItem(e) { return window.localStorage.getItem(e); }
    setItem(e, t) { window.localStorage.setItem(e, t); }
    removeItem(e) { window.localStorage.removeItem(e); }
    getKeys() { return Object.keys(window.localStorage); }
    containsKey(e) { return window.localStorage.hasOwnProperty(e); }
};
var io = class {
    constructor() { if (!window.sessionStorage)
        throw q(ze); }
    getItem(e) { return window.sessionStorage.getItem(e); }
    setItem(e, t) { window.sessionStorage.setItem(e, t); }
    removeItem(e) { window.sessionStorage.removeItem(e); }
    getKeys() { return Object.keys(window.sessionStorage); }
    containsKey(e) { return window.sessionStorage.hasOwnProperty(e); }
};
function wi(n, e) { if (!e)
    return null; try {
    return ne.parseRequestState(n, e).libraryState.meta;
}
catch {
    throw m(F.invalidState);
} }
var Ri = class {
    getItem(e) { let t = `${encodeURIComponent(e)}`, r = document.cookie.split(";"); for (let o = 0; o < r.length; o++) {
        let i = r[o], [s, ...a] = decodeURIComponent(i).trim().split("="), l = a.join("=");
        if (s === t)
            return l;
    } return ""; }
    setItem(e, t, r, o = !0) { let i = `${encodeURIComponent(e)}=${encodeURIComponent(t)};path=/;SameSite=Lax;`; if (r) {
        let s = kl(r);
        i += `expires=${s};`;
    } o && (i += "Secure;"), document.cookie = i; }
    removeItem(e) { this.setItem(e, "", -1); }
    getKeys() { let e = document.cookie.split(";"), t = []; return e.forEach(r => { let o = decodeURIComponent(r).trim().split("="); t.push(o[0]); }), t; }
    containsKey(e) { return this.getKeys().includes(e); }
};
function kl(n) { let e = new Date; return new Date(e.getTime() + n * 864e5).toUTCString(); }
var Ze = class n extends dt {
    constructor(e, t, r, o, i, s) { super(e, r, o, i), this.cacheConfig = t, this.logger = o, this.internalStorage = new Gt, this.browserStorage = this.setupBrowserStorage(this.cacheConfig.cacheLocation), this.temporaryCacheStorage = this.setupBrowserStorage(this.cacheConfig.temporaryCacheLocation), this.cookieStorage = new Ri, t.cacheMigrationEnabled && (this.migrateCacheEntries(), this.createKeyMaps()), this.performanceClient = s; }
    setupBrowserStorage(e) { try {
        switch (e) {
            case $.LocalStorage: return new no;
            case $.SessionStorage: return new io;
            case $.MemoryStorage:
            default: break;
        }
    }
    catch (t) {
        this.logger.error(t);
    } return this.cacheConfig.cacheLocation = $.MemoryStorage, new Gt; }
    migrateCacheEntries() { let e = `${u.CACHE_PREFIX}.${X.ID_TOKEN}`, t = `${u.CACHE_PREFIX}.${X.CLIENT_INFO}`, r = `${u.CACHE_PREFIX}.${X.ERROR}`, o = `${u.CACHE_PREFIX}.${X.ERROR_DESC}`, i = this.browserStorage.getItem(e), s = this.browserStorage.getItem(t), a = this.browserStorage.getItem(r), l = this.browserStorage.getItem(o), h = [i, s, a, l]; [X.ID_TOKEN, X.CLIENT_INFO, X.ERROR, X.ERROR_DESC].forEach((T, y) => { let v = h[y]; v && this.setTemporaryCache(T, v, !0); }); }
    createKeyMaps() { this.logger.trace("BrowserCacheManager - createKeyMaps called."); let e = this.getItem(Et.ACCOUNT_KEYS), t = this.getItem(`${Et.TOKEN_KEYS}.${this.clientId}`); if (e && t) {
        this.logger.verbose("BrowserCacheManager:createKeyMaps - account and token key maps already exist, skipping migration.");
        return;
    } this.browserStorage.getKeys().forEach(o => { if (this.isCredentialKey(o)) {
        let i = this.getItem(o);
        if (i) {
            let s = this.validateAndParseJson(i);
            if (s && s.hasOwnProperty("credentialType"))
                switch (s.credentialType) {
                    case S.ID_TOKEN:
                        if (K.isIdTokenEntity(s)) {
                            this.logger.trace("BrowserCacheManager:createKeyMaps - idToken found, saving key to token key map"), this.logger.tracePii(`BrowserCacheManager:createKeyMaps - idToken with key: ${o} found, saving key to token key map`);
                            let a = s, l = this.updateCredentialCacheKey(o, a);
                            this.addTokenKey(l, S.ID_TOKEN);
                            return;
                        }
                        else
                            this.logger.trace("BrowserCacheManager:createKeyMaps - key found matching idToken schema with value containing idToken credentialType field but value failed IdTokenEntity validation, skipping."), this.logger.tracePii(`BrowserCacheManager:createKeyMaps - failed idToken validation on key: ${o}`);
                        break;
                    case S.ACCESS_TOKEN:
                    case S.ACCESS_TOKEN_WITH_AUTH_SCHEME:
                        if (K.isAccessTokenEntity(s)) {
                            this.logger.trace("BrowserCacheManager:createKeyMaps - accessToken found, saving key to token key map"), this.logger.tracePii(`BrowserCacheManager:createKeyMaps - accessToken with key: ${o} found, saving key to token key map`);
                            let a = s, l = this.updateCredentialCacheKey(o, a);
                            this.addTokenKey(l, S.ACCESS_TOKEN);
                            return;
                        }
                        else
                            this.logger.trace("BrowserCacheManager:createKeyMaps - key found matching accessToken schema with value containing accessToken credentialType field but value failed AccessTokenEntity validation, skipping."), this.logger.tracePii(`BrowserCacheManager:createKeyMaps - failed accessToken validation on key: ${o}`);
                        break;
                    case S.REFRESH_TOKEN:
                        if (K.isRefreshTokenEntity(s)) {
                            this.logger.trace("BrowserCacheManager:createKeyMaps - refreshToken found, saving key to token key map"), this.logger.tracePii(`BrowserCacheManager:createKeyMaps - refreshToken with key: ${o} found, saving key to token key map`);
                            let a = s, l = this.updateCredentialCacheKey(o, a);
                            this.addTokenKey(l, S.REFRESH_TOKEN);
                            return;
                        }
                        else
                            this.logger.trace("BrowserCacheManager:createKeyMaps - key found matching refreshToken schema with value containing refreshToken credentialType field but value failed RefreshTokenEntity validation, skipping."), this.logger.tracePii(`BrowserCacheManager:createKeyMaps - failed refreshToken validation on key: ${o}`);
                        break;
                }
        }
    } if (this.isAccountKey(o)) {
        let i = this.getItem(o);
        if (i) {
            let s = this.validateAndParseJson(i);
            s && B.isAccountEntity(s) && (this.logger.trace("BrowserCacheManager:createKeyMaps - account found, saving key to account key map"), this.logger.tracePii(`BrowserCacheManager:createKeyMaps - account with key: ${o} found, saving key to account key map`), this.addAccountKeyToMap(o));
        }
    } }); }
    validateAndParseJson(e) { try {
        let t = JSON.parse(e);
        return t && typeof t == "object" ? t : null;
    }
    catch {
        return null;
    } }
    getItem(e) { return this.browserStorage.getItem(e); }
    setItem(e, t) { this.browserStorage.setItem(e, t); }
    getAccount(e, t) { this.logger.trace("BrowserCacheManager.getAccount called"); let r = this.getCachedAccountEntity(e); return this.updateOutdatedCachedAccount(e, r, t); }
    getCachedAccountEntity(e) { let t = this.getItem(e); if (!t)
        return this.removeAccountKeyFromMap(e), null; let r = this.validateAndParseJson(t); return !r || !B.isAccountEntity(r) ? (this.removeAccountKeyFromMap(e), null) : dt.toObject(new B, r); }
    setAccount(e) { this.logger.trace("BrowserCacheManager.setAccount called"); let t = e.generateAccountKey(); this.setItem(t, JSON.stringify(e)), this.addAccountKeyToMap(t); }
    getAccountKeys() { this.logger.trace("BrowserCacheManager.getAccountKeys called"); let e = this.getItem(Et.ACCOUNT_KEYS); return e ? JSON.parse(e) : (this.logger.verbose("BrowserCacheManager.getAccountKeys - No account keys found"), []); }
    addAccountKeyToMap(e) { this.logger.trace("BrowserCacheManager.addAccountKeyToMap called"), this.logger.tracePii(`BrowserCacheManager.addAccountKeyToMap called with key: ${e}`); let t = this.getAccountKeys(); t.indexOf(e) === -1 ? (t.push(e), this.setItem(Et.ACCOUNT_KEYS, JSON.stringify(t)), this.logger.verbose("BrowserCacheManager.addAccountKeyToMap account key added")) : this.logger.verbose("BrowserCacheManager.addAccountKeyToMap account key already exists in map"); }
    removeAccountKeyFromMap(e) { this.logger.trace("BrowserCacheManager.removeAccountKeyFromMap called"), this.logger.tracePii(`BrowserCacheManager.removeAccountKeyFromMap called with key: ${e}`); let t = this.getAccountKeys(), r = t.indexOf(e); r > -1 ? (t.splice(r, 1), this.setItem(Et.ACCOUNT_KEYS, JSON.stringify(t)), this.logger.trace("BrowserCacheManager.removeAccountKeyFromMap account key removed")) : this.logger.trace("BrowserCacheManager.removeAccountKeyFromMap key not found in existing map"); }
    removeAccount(e) { return d(this, null, function* () { Fn(n.prototype, this, "removeAccount").call(this, e), this.removeAccountKeyFromMap(e); }); }
    removeOutdatedAccount(e) { this.removeItem(e), this.removeAccountKeyFromMap(e); }
    removeIdToken(e) { super.removeIdToken(e), this.removeTokenKey(e, S.ID_TOKEN); }
    removeAccessToken(e) { return d(this, null, function* () { Fn(n.prototype, this, "removeAccessToken").call(this, e), this.removeTokenKey(e, S.ACCESS_TOKEN); }); }
    removeRefreshToken(e) { super.removeRefreshToken(e), this.removeTokenKey(e, S.REFRESH_TOKEN); }
    getTokenKeys() { this.logger.trace("BrowserCacheManager.getTokenKeys called"); let e = this.getItem(`${Et.TOKEN_KEYS}.${this.clientId}`); if (e) {
        let t = this.validateAndParseJson(e);
        if (t && t.hasOwnProperty("idToken") && t.hasOwnProperty("accessToken") && t.hasOwnProperty("refreshToken"))
            return t;
        this.logger.error("BrowserCacheManager.getTokenKeys - Token keys found but in an unknown format. Returning empty key map.");
    }
    else
        this.logger.verbose("BrowserCacheManager.getTokenKeys - No token keys found"); return { idToken: [], accessToken: [], refreshToken: [] }; }
    addTokenKey(e, t) { this.logger.trace("BrowserCacheManager addTokenKey called"); let r = this.getTokenKeys(); switch (t) {
        case S.ID_TOKEN:
            r.idToken.indexOf(e) === -1 && (this.logger.info("BrowserCacheManager: addTokenKey - idToken added to map"), r.idToken.push(e));
            break;
        case S.ACCESS_TOKEN:
            r.accessToken.indexOf(e) === -1 && (this.logger.info("BrowserCacheManager: addTokenKey - accessToken added to map"), r.accessToken.push(e));
            break;
        case S.REFRESH_TOKEN:
            r.refreshToken.indexOf(e) === -1 && (this.logger.info("BrowserCacheManager: addTokenKey - refreshToken added to map"), r.refreshToken.push(e));
            break;
        default: throw this.logger.error(`BrowserCacheManager:addTokenKey - CredentialType provided invalid. CredentialType: ${t}`), m(F.unexpectedCredentialType);
    } this.setItem(`${Et.TOKEN_KEYS}.${this.clientId}`, JSON.stringify(r)); }
    removeTokenKey(e, t) { this.logger.trace("BrowserCacheManager removeTokenKey called"); let r = this.getTokenKeys(); switch (t) {
        case S.ID_TOKEN:
            this.logger.infoPii(`BrowserCacheManager: removeTokenKey - attempting to remove idToken with key: ${e} from map`);
            let o = r.idToken.indexOf(e);
            o > -1 ? (this.logger.info("BrowserCacheManager: removeTokenKey - idToken removed from map"), r.idToken.splice(o, 1)) : this.logger.info("BrowserCacheManager: removeTokenKey - idToken does not exist in map. Either it was previously removed or it was never added.");
            break;
        case S.ACCESS_TOKEN:
            this.logger.infoPii(`BrowserCacheManager: removeTokenKey - attempting to remove accessToken with key: ${e} from map`);
            let i = r.accessToken.indexOf(e);
            i > -1 ? (this.logger.info("BrowserCacheManager: removeTokenKey - accessToken removed from map"), r.accessToken.splice(i, 1)) : this.logger.info("BrowserCacheManager: removeTokenKey - accessToken does not exist in map. Either it was previously removed or it was never added.");
            break;
        case S.REFRESH_TOKEN:
            this.logger.infoPii(`BrowserCacheManager: removeTokenKey - attempting to remove refreshToken with key: ${e} from map`);
            let s = r.refreshToken.indexOf(e);
            s > -1 ? (this.logger.info("BrowserCacheManager: removeTokenKey - refreshToken removed from map"), r.refreshToken.splice(s, 1)) : this.logger.info("BrowserCacheManager: removeTokenKey - refreshToken does not exist in map. Either it was previously removed or it was never added.");
            break;
        default: throw this.logger.error(`BrowserCacheManager:removeTokenKey - CredentialType provided invalid. CredentialType: ${t}`), m(F.unexpectedCredentialType);
    } this.setItem(`${Et.TOKEN_KEYS}.${this.clientId}`, JSON.stringify(r)); }
    getIdTokenCredential(e) { let t = this.getItem(e); if (!t)
        return this.logger.trace("BrowserCacheManager.getIdTokenCredential: called, no cache hit"), this.removeTokenKey(e, S.ID_TOKEN), null; let r = this.validateAndParseJson(t); return !r || !K.isIdTokenEntity(r) ? (this.logger.trace("BrowserCacheManager.getIdTokenCredential: called, no cache hit"), this.removeTokenKey(e, S.ID_TOKEN), null) : (this.logger.trace("BrowserCacheManager.getIdTokenCredential: cache hit"), r); }
    setIdTokenCredential(e) { this.logger.trace("BrowserCacheManager.setIdTokenCredential called"); let t = K.generateCredentialKey(e); this.setItem(t, JSON.stringify(e)), this.addTokenKey(t, S.ID_TOKEN); }
    getAccessTokenCredential(e) { let t = this.getItem(e); if (!t)
        return this.logger.trace("BrowserCacheManager.getAccessTokenCredential: called, no cache hit"), this.removeTokenKey(e, S.ACCESS_TOKEN), null; let r = this.validateAndParseJson(t); return !r || !K.isAccessTokenEntity(r) ? (this.logger.trace("BrowserCacheManager.getAccessTokenCredential: called, no cache hit"), this.removeTokenKey(e, S.ACCESS_TOKEN), null) : (this.logger.trace("BrowserCacheManager.getAccessTokenCredential: cache hit"), r); }
    setAccessTokenCredential(e) { this.logger.trace("BrowserCacheManager.setAccessTokenCredential called"); let t = K.generateCredentialKey(e); this.setItem(t, JSON.stringify(e)), this.addTokenKey(t, S.ACCESS_TOKEN); }
    getRefreshTokenCredential(e) { let t = this.getItem(e); if (!t)
        return this.logger.trace("BrowserCacheManager.getRefreshTokenCredential: called, no cache hit"), this.removeTokenKey(e, S.REFRESH_TOKEN), null; let r = this.validateAndParseJson(t); return !r || !K.isRefreshTokenEntity(r) ? (this.logger.trace("BrowserCacheManager.getRefreshTokenCredential: called, no cache hit"), this.removeTokenKey(e, S.REFRESH_TOKEN), null) : (this.logger.trace("BrowserCacheManager.getRefreshTokenCredential: cache hit"), r); }
    setRefreshTokenCredential(e) { this.logger.trace("BrowserCacheManager.setRefreshTokenCredential called"); let t = K.generateCredentialKey(e); this.setItem(t, JSON.stringify(e)), this.addTokenKey(t, S.REFRESH_TOKEN); }
    getAppMetadata(e) { let t = this.getItem(e); if (!t)
        return this.logger.trace("BrowserCacheManager.getAppMetadata: called, no cache hit"), null; let r = this.validateAndParseJson(t); return !r || !K.isAppMetadataEntity(e, r) ? (this.logger.trace("BrowserCacheManager.getAppMetadata: called, no cache hit"), null) : (this.logger.trace("BrowserCacheManager.getAppMetadata: cache hit"), r); }
    setAppMetadata(e) { this.logger.trace("BrowserCacheManager.setAppMetadata called"); let t = K.generateAppMetadataKey(e); this.setItem(t, JSON.stringify(e)); }
    getServerTelemetry(e) { let t = this.getItem(e); if (!t)
        return this.logger.trace("BrowserCacheManager.getServerTelemetry: called, no cache hit"), null; let r = this.validateAndParseJson(t); return !r || !K.isServerTelemetryEntity(e, r) ? (this.logger.trace("BrowserCacheManager.getServerTelemetry: called, no cache hit"), null) : (this.logger.trace("BrowserCacheManager.getServerTelemetry: cache hit"), r); }
    setServerTelemetry(e, t) { this.logger.trace("BrowserCacheManager.setServerTelemetry called"), this.setItem(e, JSON.stringify(t)); }
    getAuthorityMetadata(e) { let t = this.internalStorage.getItem(e); if (!t)
        return this.logger.trace("BrowserCacheManager.getAuthorityMetadata: called, no cache hit"), null; let r = this.validateAndParseJson(t); return r && K.isAuthorityMetadataEntity(e, r) ? (this.logger.trace("BrowserCacheManager.getAuthorityMetadata: cache hit"), r) : null; }
    getAuthorityMetadataKeys() { return this.internalStorage.getKeys().filter(t => this.isAuthorityMetadata(t)); }
    setWrapperMetadata(e, t) { this.internalStorage.setItem(Sn.WRAPPER_SKU, e), this.internalStorage.setItem(Sn.WRAPPER_VER, t); }
    getWrapperMetadata() { let e = this.internalStorage.getItem(Sn.WRAPPER_SKU) || u.EMPTY_STRING, t = this.internalStorage.getItem(Sn.WRAPPER_VER) || u.EMPTY_STRING; return [e, t]; }
    setAuthorityMetadata(e, t) { this.logger.trace("BrowserCacheManager.setAuthorityMetadata called"), this.internalStorage.setItem(e, JSON.stringify(t)); }
    getActiveAccount() { let e = this.generateCacheKey(X.ACTIVE_ACCOUNT_FILTERS), t = this.getItem(e); if (!t) {
        this.logger.trace("BrowserCacheManager.getActiveAccount: No active account filters cache schema found, looking for legacy schema");
        let o = this.generateCacheKey(X.ACTIVE_ACCOUNT), i = this.getItem(o);
        if (!i)
            return this.logger.trace("BrowserCacheManager.getActiveAccount: No active account found"), null;
        let s = this.getAccountInfoFilteredBy({ localAccountId: i });
        return s ? (this.logger.trace("BrowserCacheManager.getActiveAccount: Legacy active account cache schema found"), this.logger.trace("BrowserCacheManager.getActiveAccount: Adding active account filters cache schema"), this.setActiveAccount(s), s) : null;
    } let r = this.validateAndParseJson(t); return r ? (this.logger.trace("BrowserCacheManager.getActiveAccount: Active account filters schema found"), this.getAccountInfoFilteredBy({ homeAccountId: r.homeAccountId, localAccountId: r.localAccountId, tenantId: r.tenantId })) : (this.logger.trace("BrowserCacheManager.getActiveAccount: No active account found"), null); }
    setActiveAccount(e) { let t = this.generateCacheKey(X.ACTIVE_ACCOUNT_FILTERS), r = this.generateCacheKey(X.ACTIVE_ACCOUNT); if (e) {
        this.logger.verbose("setActiveAccount: Active account set");
        let o = { homeAccountId: e.homeAccountId, localAccountId: e.localAccountId, tenantId: e.tenantId };
        this.browserStorage.setItem(t, JSON.stringify(o)), this.browserStorage.setItem(r, e.localAccountId);
    }
    else
        this.logger.verbose("setActiveAccount: No account passed, active account not set"), this.browserStorage.removeItem(t), this.browserStorage.removeItem(r); }
    getThrottlingCache(e) { let t = this.getItem(e); if (!t)
        return this.logger.trace("BrowserCacheManager.getThrottlingCache: called, no cache hit"), null; let r = this.validateAndParseJson(t); return !r || !K.isThrottlingEntity(e, r) ? (this.logger.trace("BrowserCacheManager.getThrottlingCache: called, no cache hit"), null) : (this.logger.trace("BrowserCacheManager.getThrottlingCache: cache hit"), r); }
    setThrottlingCache(e, t) { this.logger.trace("BrowserCacheManager.setThrottlingCache called"), this.setItem(e, JSON.stringify(t)); }
    getTemporaryCache(e, t) { let r = t ? this.generateCacheKey(e) : e; if (this.cacheConfig.storeAuthStateInCookie) {
        let i = this.cookieStorage.getItem(r);
        if (i)
            return this.logger.trace("BrowserCacheManager.getTemporaryCache: storeAuthStateInCookies set to true, retrieving from cookies"), i;
    } let o = this.temporaryCacheStorage.getItem(r); if (!o) {
        if (this.cacheConfig.cacheLocation === $.LocalStorage) {
            let i = this.browserStorage.getItem(r);
            if (i)
                return this.logger.trace("BrowserCacheManager.getTemporaryCache: Temporary cache item found in local storage"), i;
        }
        return this.logger.trace("BrowserCacheManager.getTemporaryCache: No cache item found in local storage"), null;
    } return this.logger.trace("BrowserCacheManager.getTemporaryCache: Temporary cache item returned"), o; }
    setTemporaryCache(e, t, r) { let o = r ? this.generateCacheKey(e) : e; this.temporaryCacheStorage.setItem(o, t), this.cacheConfig.storeAuthStateInCookie && (this.logger.trace("BrowserCacheManager.setTemporaryCache: storeAuthStateInCookie set to true, setting item cookie"), this.cookieStorage.setItem(o, t, void 0, this.cacheConfig.secureCookies)); }
    removeItem(e) { this.browserStorage.removeItem(e); }
    removeTemporaryItem(e) { this.temporaryCacheStorage.removeItem(e), this.cacheConfig.storeAuthStateInCookie && (this.logger.trace("BrowserCacheManager.removeItem: storeAuthStateInCookie is true, clearing item cookie"), this.cookieStorage.removeItem(e)); }
    getKeys() { return this.browserStorage.getKeys(); }
    clear() { return d(this, null, function* () { yield this.removeAllAccounts(), this.removeAppMetadata(), this.temporaryCacheStorage.getKeys().forEach(e => { (e.indexOf(u.CACHE_PREFIX) !== -1 || e.indexOf(this.clientId) !== -1) && this.removeTemporaryItem(e); }), this.browserStorage.getKeys().forEach(e => { (e.indexOf(u.CACHE_PREFIX) !== -1 || e.indexOf(this.clientId) !== -1) && this.browserStorage.removeItem(e); }), this.internalStorage.clear(); }); }
    clearTokensAndKeysWithClaims(e, t) { return d(this, null, function* () { e.addQueueMeasurement(c.ClearTokensAndKeysWithClaims, t); let r = this.getTokenKeys(), o = []; r.accessToken.forEach(i => { let s = this.getAccessTokenCredential(i); s?.requestedClaimsHash && i.includes(s.requestedClaimsHash.toLowerCase()) && o.push(this.removeAccessToken(i)); }), yield Promise.all(o), o.length > 0 && this.logger.warning(`${o.length} access tokens with claims in the cache keys have been removed from the cache.`); }); }
    generateCacheKey(e) { return this.validateAndParseJson(e) ? JSON.stringify(e) : Q.startsWith(e, u.CACHE_PREFIX) || Q.startsWith(e, X.ADAL_ID_TOKEN) ? e : `${u.CACHE_PREFIX}.${this.clientId}.${e}`; }
    generateAuthorityKey(e) { let { libraryState: { id: t } } = ne.parseRequestState(this.cryptoImpl, e); return this.generateCacheKey(`${O.AUTHORITY}.${t}`); }
    generateNonceKey(e) { let { libraryState: { id: t } } = ne.parseRequestState(this.cryptoImpl, e); return this.generateCacheKey(`${O.NONCE_IDTOKEN}.${t}`); }
    generateStateKey(e) { let { libraryState: { id: t } } = ne.parseRequestState(this.cryptoImpl, e); return this.generateCacheKey(`${O.REQUEST_STATE}.${t}`); }
    getCachedAuthority(e) { let t = this.generateStateKey(e), r = this.getTemporaryCache(t); if (!r)
        return null; let o = this.generateAuthorityKey(r); return this.getTemporaryCache(o); }
    updateCacheEntries(e, t, r, o, i) { this.logger.trace("BrowserCacheManager.updateCacheEntries called"); let s = this.generateStateKey(e); this.setTemporaryCache(s, e, !1); let a = this.generateNonceKey(e); this.setTemporaryCache(a, t, !1); let l = this.generateAuthorityKey(e); if (this.setTemporaryCache(l, r, !1), i) {
        let h = { credential: i.homeAccountId, type: re.HOME_ACCOUNT_ID };
        this.setTemporaryCache(O.CCS_CREDENTIAL, JSON.stringify(h), !0);
    }
    else if (o) {
        let h = { credential: o, type: re.UPN };
        this.setTemporaryCache(O.CCS_CREDENTIAL, JSON.stringify(h), !0);
    } }
    resetRequestCache(e) { this.logger.trace("BrowserCacheManager.resetRequestCache called"), e && (this.temporaryCacheStorage.getKeys().forEach(t => { t.indexOf(e) !== -1 && this.removeTemporaryItem(t); }), this.removeTemporaryItem(this.generateStateKey(e)), this.removeTemporaryItem(this.generateNonceKey(e)), this.removeTemporaryItem(this.generateAuthorityKey(e))), this.removeTemporaryItem(this.generateCacheKey(O.REQUEST_PARAMS)), this.removeTemporaryItem(this.generateCacheKey(O.ORIGIN_URI)), this.removeTemporaryItem(this.generateCacheKey(O.URL_HASH)), this.removeTemporaryItem(this.generateCacheKey(O.CORRELATION_ID)), this.removeTemporaryItem(this.generateCacheKey(O.CCS_CREDENTIAL)), this.removeTemporaryItem(this.generateCacheKey(O.NATIVE_REQUEST)), this.setInteractionInProgress(!1); }
    cleanRequestByState(e) { if (this.logger.trace("BrowserCacheManager.cleanRequestByState called"), e) {
        let t = this.generateStateKey(e), r = this.temporaryCacheStorage.getItem(t);
        this.logger.infoPii(`BrowserCacheManager.cleanRequestByState: Removing temporary cache items for state: ${r}`), this.resetRequestCache(r || u.EMPTY_STRING);
    } }
    cleanRequestByInteractionType(e) { this.logger.trace("BrowserCacheManager.cleanRequestByInteractionType called"), this.temporaryCacheStorage.getKeys().forEach(t => { if (t.indexOf(O.REQUEST_STATE) === -1)
        return; let r = this.temporaryCacheStorage.getItem(t); if (!r)
        return; let o = wi(this.cryptoImpl, r); o && o.interactionType === e && (this.logger.infoPii(`BrowserCacheManager.cleanRequestByInteractionType: Removing temporary cache items for state: ${r}`), this.resetRequestCache(r)); }), this.setInteractionInProgress(!1); }
    cacheCodeRequest(e) { this.logger.trace("BrowserCacheManager.cacheCodeRequest called"); let t = Rn(JSON.stringify(e)); this.setTemporaryCache(O.REQUEST_PARAMS, t, !0); }
    getCachedRequest(e) { this.logger.trace("BrowserCacheManager.getCachedRequest called"); let t = this.getTemporaryCache(O.REQUEST_PARAMS, !0); if (!t)
        throw C(Fr); let r; try {
        r = JSON.parse(Ee(t));
    }
    catch (o) {
        throw this.logger.errorPii(`Attempted to parse: ${t}`), this.logger.error(`Parsing cached token request threw with error: ${o}`), C(Kr);
    } if (this.removeTemporaryItem(this.generateCacheKey(O.REQUEST_PARAMS)), !r.authority) {
        let o = this.generateAuthorityKey(e), i = this.getTemporaryCache(o);
        if (!i)
            throw C(pt);
        r.authority = i;
    } return r; }
    getCachedNativeRequest() { this.logger.trace("BrowserCacheManager.getCachedNativeRequest called"); let e = this.getTemporaryCache(O.NATIVE_REQUEST, !0); if (!e)
        return this.logger.trace("BrowserCacheManager.getCachedNativeRequest: No cached native request found"), null; let t = this.validateAndParseJson(e); return t || (this.logger.error("BrowserCacheManager.getCachedNativeRequest: Unable to parse native request"), null); }
    isInteractionInProgress(e) { let t = this.getInteractionInProgress(); return e ? t === this.clientId : !!t; }
    getInteractionInProgress() { let e = `${u.CACHE_PREFIX}.${O.INTERACTION_STATUS_KEY}`; return this.getTemporaryCache(e, !1); }
    setInteractionInProgress(e) { let t = `${u.CACHE_PREFIX}.${O.INTERACTION_STATUS_KEY}`; if (e) {
        if (this.getInteractionInProgress())
            throw C(Or);
        this.setTemporaryCache(t, this.clientId, !1);
    }
    else
        !e && this.getInteractionInProgress() === this.clientId && this.removeTemporaryItem(t); }
    getLegacyLoginHint() { let e = this.getTemporaryCache(X.ADAL_ID_TOKEN); e && (this.browserStorage.removeItem(X.ADAL_ID_TOKEN), this.logger.verbose("Cached ADAL id token retrieved.")); let t = this.getTemporaryCache(X.ID_TOKEN, !0); t && (this.browserStorage.removeItem(this.generateCacheKey(X.ID_TOKEN)), this.logger.verbose("Cached MSAL.js v1 id token retrieved")); let r = t || e; if (r) {
        let o = xe.extractTokenClaims(r, Ee);
        if (o.preferred_username)
            return this.logger.verbose("No SSO params used and ADAL/MSAL v1 token retrieved, setting ADAL/MSAL v1 preferred_username as loginHint"), o.preferred_username;
        if (o.upn)
            return this.logger.verbose("No SSO params used and ADAL/MSAL v1 token retrieved, setting ADAL/MSAL v1 upn as loginHint"), o.upn;
        this.logger.verbose("No SSO params used and ADAL/MSAL v1 token retrieved, however, no account hint claim found. Enable preferred_username or upn id token claim to get SSO.");
    } return null; }
    updateCredentialCacheKey(e, t) { let r = K.generateCredentialKey(t); if (e !== r) {
        let o = this.getItem(e);
        if (o)
            return this.browserStorage.removeItem(e), this.setItem(r, o), this.logger.verbose(`Updated an outdated ${t.credentialType} cache key`), r;
        this.logger.error(`Attempted to update an outdated ${t.credentialType} cache key but no item matching the outdated key was found in storage`);
    } return e; }
    hydrateCache(e, t) { return d(this, null, function* () { let r = K.createIdTokenEntity(e.account?.homeAccountId, e.account?.environment, e.idToken, this.clientId, e.tenantId), o; t.claims && (o = yield this.cryptoImpl.hashString(t.claims)); let i = K.createAccessTokenEntity(e.account?.homeAccountId, e.account.environment, e.accessToken, this.clientId, e.tenantId, e.scopes.join(" "), e.expiresOn ? e.expiresOn.getTime() / 1e3 : 0, e.extExpiresOn ? e.extExpiresOn.getTime() / 1e3 : 0, Ee, void 0, e.tokenType, void 0, t.sshKid, t.claims, o), s = { idToken: r, accessToken: i }; return this.saveCacheRecord(s); }); }
    saveCacheRecord(e, t, r) { return d(this, null, function* () { try {
        yield Fn(n.prototype, this, "saveCacheRecord").call(this, e, t, r);
    }
    catch (o) {
        if (o instanceof Be && this.performanceClient && r)
            try {
                let i = this.getTokenKeys();
                this.performanceClient.addFields({ cacheRtCount: i.refreshToken.length, cacheIdCount: i.idToken.length, cacheAtCount: i.accessToken.length }, r);
            }
            catch { }
        throw o;
    } }); }
}, wo = (n, e) => { let t = { cacheLocation: $.MemoryStorage, temporaryCacheLocation: $.MemoryStorage, storeAuthStateInCookie: !1, secureCookies: !1, cacheMigrationEnabled: !1, claimsBasedCachingEnabled: !1 }; return new Ze(n, t, _e, e); };
function ki(n, e, t, r) { return n.verbose("getAllAccounts called"), t ? e.getAllAccounts(r) : []; }
function Ro(n, e, t) { if (e.trace("getAccount called"), Object.keys(n).length === 0)
    return e.warning("getAccount: No accountFilter provided"), null; let r = t.getAccountInfoFilteredBy(n); return r ? (e.verbose("getAccount: Account matching provided filter found, returning"), r) : (e.verbose("getAccount: No matching account found, returning null"), null); }
function _i(n, e, t) { if (e.trace("getAccountByUsername called"), !n)
    return e.warning("getAccountByUsername: No username provided"), null; let r = t.getAccountInfoFilteredBy({ username: n }); return r ? (e.verbose("getAccountByUsername: Account matching username found, returning"), e.verbosePii(`getAccountByUsername: Returning signed-in accounts matching username: ${n}`), r) : (e.verbose("getAccountByUsername: No matching account found, returning null"), null); }
function bi(n, e, t) { if (e.trace("getAccountByHomeId called"), !n)
    return e.warning("getAccountByHomeId: No homeAccountId provided"), null; let r = t.getAccountInfoFilteredBy({ homeAccountId: n }); return r ? (e.verbose("getAccountByHomeId: Account matching homeAccountId found, returning"), e.verbosePii(`getAccountByHomeId: Returning signed-in accounts matching homeAccountId: ${n}`), r) : (e.verbose("getAccountByHomeId: No matching account found, returning null"), null); }
function Pi(n, e, t) { if (e.trace("getAccountByLocalId called"), !n)
    return e.warning("getAccountByLocalId: No localAccountId provided"), null; let r = t.getAccountInfoFilteredBy({ localAccountId: n }); return r ? (e.verbose("getAccountByLocalId: Account matching localAccountId found, returning"), e.verbosePii(`getAccountByLocalId: Returning signed-in accounts matching localAccountId: ${n}`), r) : (e.verbose("getAccountByLocalId: No matching account found, returning null"), null); }
function Mn(n, e) { e.setActiveAccount(n); }
function Ni(n) { return n.getActiveAccount(); }
var A = { INITIALIZE_START: "msal:initializeStart", INITIALIZE_END: "msal:initializeEnd", ACCOUNT_ADDED: "msal:accountAdded", ACCOUNT_REMOVED: "msal:accountRemoved", ACTIVE_ACCOUNT_CHANGED: "msal:activeAccountChanged", LOGIN_START: "msal:loginStart", LOGIN_SUCCESS: "msal:loginSuccess", LOGIN_FAILURE: "msal:loginFailure", ACQUIRE_TOKEN_START: "msal:acquireTokenStart", ACQUIRE_TOKEN_SUCCESS: "msal:acquireTokenSuccess", ACQUIRE_TOKEN_FAILURE: "msal:acquireTokenFailure", ACQUIRE_TOKEN_NETWORK_START: "msal:acquireTokenFromNetworkStart", SSO_SILENT_START: "msal:ssoSilentStart", SSO_SILENT_SUCCESS: "msal:ssoSilentSuccess", SSO_SILENT_FAILURE: "msal:ssoSilentFailure", ACQUIRE_TOKEN_BY_CODE_START: "msal:acquireTokenByCodeStart", ACQUIRE_TOKEN_BY_CODE_SUCCESS: "msal:acquireTokenByCodeSuccess", ACQUIRE_TOKEN_BY_CODE_FAILURE: "msal:acquireTokenByCodeFailure", HANDLE_REDIRECT_START: "msal:handleRedirectStart", HANDLE_REDIRECT_END: "msal:handleRedirectEnd", POPUP_OPENED: "msal:popupOpened", LOGOUT_START: "msal:logoutStart", LOGOUT_SUCCESS: "msal:logoutSuccess", LOGOUT_FAILURE: "msal:logoutFailure", LOGOUT_END: "msal:logoutEnd", RESTORE_FROM_BFCACHE: "msal:restoreFromBFCache" };
var so = class {
    constructor(e) { this.eventCallbacks = new Map, this.logger = e || new ae({}); }
    addEventCallback(e, t, r) { if (typeof window < "u") {
        let o = r || oa();
        return this.eventCallbacks.has(o) ? (this.logger.error(`Event callback with id: ${o} is already registered. Please provide a unique id or remove the existing callback and try again.`), null) : (this.eventCallbacks.set(o, [e, t || []]), this.logger.verbose(`Event callback registered with id: ${o}`), o);
    } return null; }
    removeEventCallback(e) { this.eventCallbacks.delete(e), this.logger.verbose(`Event callback ${e} removed.`); }
    emitEvent(e, t, r, o) { if (typeof window < "u") {
        let i = { eventType: e, interactionType: t || null, payload: r || null, error: o || null, timestamp: Date.now() };
        this.eventCallbacks.forEach(([s, a], l) => { (a.length === 0 || a.includes(e)) && (this.logger.verbose(`Emitting event to callback ${l}: ${e}`), s.apply(null, [i])); });
    } }
};
var ko = class {
    constructor(e, t, r, o, i, s, a, l, h) { this.config = e, this.browserStorage = t, this.browserCrypto = r, this.networkClient = this.config.system.networkClient, this.eventHandler = i, this.navigationClient = s, this.nativeMessageHandler = l, this.correlationId = h || ee(), this.logger = o.clone(W.MSAL_SKU, ue, this.correlationId), this.performanceClient = a; }
    clearCacheOnLogout(e) { return d(this, null, function* () { if (e) {
        B.accountInfoIsEqual(e, this.browserStorage.getActiveAccount(), !1) && (this.logger.verbose("Setting active account to null"), this.browserStorage.setActiveAccount(null));
        try {
            yield this.browserStorage.removeAccount(B.generateAccountCacheKey(e)), this.logger.verbose("Cleared cache items belonging to the account provided in the logout request.");
        }
        catch {
            this.logger.error("Account provided in logout request was not found. Local cache unchanged.");
        }
    }
    else
        try {
            this.logger.verbose("No account provided in logout request, clearing all cache items.", this.correlationId), yield this.browserStorage.clear(), yield this.browserCrypto.clearKeystore();
        }
        catch {
            this.logger.error("Attempted to clear all MSAL cache items and failed. Local cache unchanged.");
        } }); }
    getRedirectUri(e) { this.logger.verbose("getRedirectUri called"); let t = e || this.config.auth.redirectUri; return P.getAbsoluteUrl(t, Ae()); }
    initializeServerTelemetryManager(e, t) { this.logger.verbose("initializeServerTelemetryManager called"); let r = { clientId: this.config.auth.clientId, correlationId: this.correlationId, apiId: e, forceRefresh: t || !1, wrapperSKU: this.browserStorage.getWrapperMetadata()[0], wrapperVer: this.browserStorage.getWrapperMetadata()[1] }; return new kr(r, this.browserStorage); }
    getDiscoveredAuthority(e) { return d(this, null, function* () { let { account: t } = e, r = e.requestExtraQueryParameters && e.requestExtraQueryParameters.hasOwnProperty("instance_aware") ? e.requestExtraQueryParameters.instance_aware : void 0; this.performanceClient.addQueueMeasurement(c.StandardInteractionClientGetDiscoveredAuthority, this.correlationId); let o = { protocolMode: this.config.auth.protocolMode, OIDCOptions: this.config.auth.OIDCOptions, knownAuthorities: this.config.auth.knownAuthorities, cloudDiscoveryMetadata: this.config.auth.cloudDiscoveryMetadata, authorityMetadata: this.config.auth.authorityMetadata, skipAuthorityMetadataCache: this.config.auth.skipAuthorityMetadataCache }, i = e.requestAuthority || this.config.auth.authority, s = r?.length ? r === "true" : this.config.auth.instanceAware, a = t && s ? this.config.auth.authority.replace(P.getDomainFromUrl(i), t.environment) : i, l = be.generateAuthority(a, e.requestAzureCloudOptions || this.config.auth.azureCloudOptions), h = yield f(ai.createDiscoveredInstance, c.AuthorityFactoryCreateDiscoveredInstance, this.logger, this.performanceClient, this.correlationId)(l, this.config.system.networkClient, this.browserStorage, o, this.logger, this.correlationId, this.performanceClient); if (t && !h.isAlias(t.environment))
        throw N(He.authorityMismatch); return h; }); }
};
var _l = 32;
function nc(n, e, t) { return d(this, null, function* () { n.addQueueMeasurement(c.GeneratePkceCodes, t); let r = fe(bl, c.GenerateCodeVerifier, e, n, t)(n, e, t), o = yield f(Pl, c.GenerateCodeChallengeFromVerifier, e, n, t)(r, n, e, t); return { verifier: r, challenge: o }; }); }
function bl(n, e, t) { try {
    let r = new Uint8Array(_l);
    return fe(Ga, c.GetRandomValues, e, n, t)(r), to(r);
}
catch {
    throw C(xt);
} }
function Pl(n, e, t, r) { return d(this, null, function* () { e.addQueueMeasurement(c.GenerateCodeChallengeFromVerifier, r); try {
    let o = yield f(Zs, c.Sha256Digest, t, e, r)(n, e, r);
    return to(new Uint8Array(o));
}
catch {
    throw C(xt);
} }); }
function Un(n, e, t, r) { return d(this, null, function* () { t.addQueueMeasurement(c.InitializeBaseRequest, n.correlationId); let o = n.authority || e.auth.authority, i = [...n && n.scopes || []], s = I(p({}, n), { correlationId: n.correlationId, authority: o, scopes: i }); if (!s.authenticationScheme)
    s.authenticationScheme = b.BEARER, r.verbose(`Authentication Scheme wasn't explicitly set in request, defaulting to "Bearer" request`);
else {
    if (s.authenticationScheme === b.SSH) {
        if (!n.sshJwk)
            throw N(He.missingSshJwk);
        if (!n.sshKid)
            throw N(He.missingSshKid);
    }
    r.verbose(`Authentication Scheme set to "${s.authenticationScheme}" as configured in Auth request`);
} return e.cache.claimsBasedCachingEnabled && n.claims && !Q.isEmptyObj(n.claims) && (s.requestedClaimsHash = yield Ci(n.claims)), s; }); }
function ic(n, e, t, r, o) { return d(this, null, function* () { r.addQueueMeasurement(c.InitializeSilentRequest, n.correlationId); let i = yield f(Un, c.InitializeBaseRequest, o, r, n.correlationId)(n, t, r, o); return I(p(p({}, n), i), { account: e, forceRefresh: n.forceRefresh || !1 }); }); }
var ye = class extends ko {
    initializeAuthorizationCodeRequest(e) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.StandardInteractionClientInitializeAuthorizationCodeRequest, this.correlationId); let t = yield f(nc, c.GeneratePkceCodes, this.logger, this.performanceClient, this.correlationId)(this.performanceClient, this.logger, this.correlationId), r = I(p({}, e), { redirectUri: e.redirectUri, code: u.EMPTY_STRING, codeVerifier: t.verifier }); return e.codeChallenge = t.challenge, e.codeChallengeMethod = u.S256_CODE_CHALLENGE_METHOD, r; }); }
    initializeLogoutRequest(e) { this.logger.verbose("initializeLogoutRequest called", e?.correlationId); let t = p({ correlationId: this.correlationId || ee() }, e); if (e)
        if (e.logoutHint)
            this.logger.verbose("logoutHint has already been set in logoutRequest");
        else if (e.account) {
            let r = this.getLogoutHintFromIdTokenClaims(e.account);
            r && (this.logger.verbose("Setting logoutHint to login_hint ID Token Claim value for the account provided"), t.logoutHint = r);
        }
        else
            this.logger.verbose("logoutHint was not set and account was not passed into logout request, logoutHint will not be set");
    else
        this.logger.verbose("logoutHint will not be set since no logout request was configured"); return !e || e.postLogoutRedirectUri !== null ? e && e.postLogoutRedirectUri ? (this.logger.verbose("Setting postLogoutRedirectUri to uri set on logout request", t.correlationId), t.postLogoutRedirectUri = P.getAbsoluteUrl(e.postLogoutRedirectUri, Ae())) : this.config.auth.postLogoutRedirectUri === null ? this.logger.verbose("postLogoutRedirectUri configured as null and no uri set on request, not passing post logout redirect", t.correlationId) : this.config.auth.postLogoutRedirectUri ? (this.logger.verbose("Setting postLogoutRedirectUri to configured uri", t.correlationId), t.postLogoutRedirectUri = P.getAbsoluteUrl(this.config.auth.postLogoutRedirectUri, Ae())) : (this.logger.verbose("Setting postLogoutRedirectUri to current page", t.correlationId), t.postLogoutRedirectUri = P.getAbsoluteUrl(Ae(), Ae())) : this.logger.verbose("postLogoutRedirectUri passed as null, not setting post logout redirect uri", t.correlationId), t; }
    getLogoutHintFromIdTokenClaims(e) { let t = e.idTokenClaims; if (t) {
        if (t.login_hint)
            return t.login_hint;
        this.logger.verbose("The ID Token Claims tied to the provided account do not contain a login_hint claim, logoutHint will not be added to logout request");
    }
    else
        this.logger.verbose("The provided account does not contain ID Token Claims, logoutHint will not be added to logout request"); return null; }
    createAuthCodeClient(e) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.StandardInteractionClientCreateAuthCodeClient, this.correlationId); let t = yield f(this.getClientConfiguration.bind(this), c.StandardInteractionClientGetClientConfiguration, this.logger, this.performanceClient, this.correlationId)(e); return new Rr(t, this.performanceClient); }); }
    getClientConfiguration(e) { return d(this, null, function* () { let { serverTelemetryManager: t, requestAuthority: r, requestAzureCloudOptions: o, requestExtraQueryParameters: i, account: s } = e; this.performanceClient.addQueueMeasurement(c.StandardInteractionClientGetClientConfiguration, this.correlationId); let a = yield f(this.getDiscoveredAuthority.bind(this), c.StandardInteractionClientGetDiscoveredAuthority, this.logger, this.performanceClient, this.correlationId)({ requestAuthority: r, requestAzureCloudOptions: o, requestExtraQueryParameters: i, account: s }), l = this.config.system.loggerOptions; return { authOptions: { clientId: this.config.auth.clientId, authority: a, clientCapabilities: this.config.auth.clientCapabilities, redirectUri: this.config.auth.redirectUri }, systemOptions: { tokenRenewalOffsetSeconds: this.config.system.tokenRenewalOffsetSeconds, preventCorsPreflight: !0 }, loggerOptions: { loggerCallback: l.loggerCallback, piiLoggingEnabled: l.piiLoggingEnabled, logLevel: l.logLevel, correlationId: this.correlationId }, cacheOptions: { claimsBasedCachingEnabled: this.config.cache.claimsBasedCachingEnabled }, cryptoInterface: this.browserCrypto, networkInterface: this.networkClient, storageInterface: this.browserStorage, serverTelemetryManager: t, libraryInfo: { sku: W.MSAL_SKU, version: ue, cpu: u.EMPTY_STRING, os: u.EMPTY_STRING }, telemetry: this.config.telemetry }; }); }
    initializeAuthorizationRequest(e, t) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.StandardInteractionClientInitializeAuthorizationRequest, this.correlationId); let r = this.getRedirectUri(e.redirectUri), o = { interactionType: t }, i = ne.setRequestState(this.browserCrypto, e && e.state || u.EMPTY_STRING, o), s = yield f(Un, c.InitializeBaseRequest, this.logger, this.performanceClient, this.correlationId)(I(p({}, e), { correlationId: this.correlationId }), this.config, this.performanceClient, this.logger), a = I(p({}, s), { redirectUri: r, state: i, nonce: e.nonce || ee(), responseMode: this.config.auth.OIDCOptions.serverResponseType }); if (e.loginHint || e.sid)
        return a; let l = e.account || this.browserStorage.getActiveAccount(); if (l && (this.logger.verbose("Setting validated request account", this.correlationId), this.logger.verbosePii(`Setting validated request account: ${l.homeAccountId}`, this.correlationId), a.account = l), !a.loginHint && !l) {
        let h = this.browserStorage.getLegacyLoginHint();
        h && (a.loginHint = h);
    } return a; }); }
};
var sc = "ContentError", Oi = "user_switch";
var ac = "USER_INTERACTION_REQUIRED", cc = "USER_CANCEL", lc = "NO_NETWORK", dc = "PERSISTENT_ERROR", hc = "DISABLED", uc = "ACCOUNT_UNAVAILABLE";
var Nl = -2147186943, Ol = { [Oi]: "User attempted to switch accounts in the native broker, which is not allowed. All new accounts must sign-in through the standard web flow first, please try again." }, Pe = class n extends w {
    constructor(e, t, r) { super(e, t), Object.setPrototypeOf(this, n.prototype), this.name = "NativeAuthError", this.ext = r; }
};
function $t(n) { if (n.ext && n.ext.status && (n.ext.status === dc || n.ext.status === hc) || n.ext && n.ext.error && n.ext.error === Nl)
    return !0; switch (n.errorCode) {
    case sc: return !0;
    default: return !1;
} }
function Ln(n, e, t) { if (t && t.status)
    switch (t.status) {
        case uc: return yo(mt.nativeAccountUnavailable);
        case ac: return new Z(n, e);
        case cc: return C(Te);
        case lc: return C(Xe);
    } return new Pe(n, Ol[n] || e, t); }
var _o = class extends ye {
    acquireToken(e) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.SilentCacheClientAcquireToken, e.correlationId); let t = this.initializeServerTelemetryManager(M.acquireTokenSilent_silentFlow), r = yield f(this.getClientConfiguration.bind(this), c.StandardInteractionClientGetClientConfiguration, this.logger, this.performanceClient, this.correlationId)({ serverTelemetryManager: t, requestAuthority: e.authority, requestAzureCloudOptions: e.azureCloudOptions, account: e.account }), o = new mn(r, this.performanceClient); this.logger.verbose("Silent auth client created"); try {
        let s = (yield f(o.acquireCachedToken.bind(o), c.SilentFlowClientAcquireCachedToken, this.logger, this.performanceClient, e.correlationId)(e))[0];
        return this.performanceClient.addFields({ fromCache: !0 }, e.correlationId), s;
    }
    catch (i) {
        throw i instanceof Ft && i.errorCode === ft && this.logger.verbose("Signing keypair for bound access token not found. Refreshing bound access token and generating a new crypto keypair."), i;
    } }); }
    logout(e) { this.logger.verbose("logoutRedirect called"); let t = this.initializeLogoutRequest(e); return this.clearCacheOnLogout(t?.account); }
};
var Ne = class extends ko {
    constructor(e, t, r, o, i, s, a, l, h, g, T, y) { super(e, t, r, o, i, s, l, h, y), this.apiId = a, this.accountId = g, this.nativeMessageHandler = h, this.nativeStorageManager = T, this.silentCacheClient = new _o(e, this.nativeStorageManager, r, o, i, s, l, h, y), this.serverTelemetryManager = this.initializeServerTelemetryManager(this.apiId); let v = this.nativeMessageHandler.getExtensionId() === Kt.PREFERRED_EXTENSION_ID ? "chrome" : this.nativeMessageHandler.getExtensionId()?.length ? "unknown" : void 0; this.skus = kr.makeExtraSkuString({ libraryName: W.MSAL_SKU, libraryVersion: ue, extensionName: v, extensionVersion: this.nativeMessageHandler.getExtensionVersion() }); }
    addRequestSKUs(e) { e.extraParameters = I(p({}, e.extraParameters), { [ut.X_CLIENT_EXTRA_SKU]: this.skus }); }
    acquireToken(e) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.NativeInteractionClientAcquireToken, e.correlationId), this.logger.trace("NativeInteractionClient - acquireToken called."); let t = this.performanceClient.startMeasurement(c.NativeInteractionClientAcquireToken, e.correlationId), r = Qe.nowSeconds(); try {
        let o = yield this.initializeNativeRequest(e);
        try {
            let h = yield this.acquireTokensFromCache(this.accountId, o);
            return t.end({ success: !0, isNativeBroker: !1, fromCache: !0 }), h;
        }
        catch {
            this.logger.info("MSAL internal Cache does not contain tokens, proceed to make a native call");
        }
        let i = yt(o, []), s = { method: At.GetToken, request: i }, a = yield this.nativeMessageHandler.sendMessage(s), l = this.validateNativeResponse(a);
        return yield this.handleNativeResponse(l, o, r).then(h => (t.end({ success: !0, isNativeBroker: !0, requestId: h.requestId }), this.serverTelemetryManager.clearNativeBrokerErrorCode(), h)).catch(h => { throw t.end({ success: !1, errorCode: h.errorCode, subErrorCode: h.subError, isNativeBroker: !0 }), h; });
    }
    catch (o) {
        throw o instanceof Pe && this.serverTelemetryManager.setNativeBrokerErrorCode(o.errorCode), o;
    } }); }
    createSilentCacheRequest(e, t) { return { authority: e.authority, correlationId: this.correlationId, scopes: z.fromString(e.scope).asArray(), account: t, forceRefresh: !1 }; }
    acquireTokensFromCache(e, t) { return d(this, null, function* () { if (!e)
        throw this.logger.warning("NativeInteractionClient:acquireTokensFromCache - No nativeAccountId provided"), m(F.noAccountFound); let r = this.browserStorage.getBaseAccountInfo({ nativeAccountId: e }); if (!r)
        throw m(F.noAccountFound); try {
        let o = this.createSilentCacheRequest(t, r), i = yield this.silentCacheClient.acquireToken(o), s = I(p({}, r), { idTokenClaims: i?.idTokenClaims, idToken: i?.idToken });
        return I(p({}, i), { account: s });
    }
    catch (o) {
        throw o;
    } }); }
    acquireTokenRedirect(e, t) { return d(this, null, function* () { this.logger.trace("NativeInteractionClient - acquireTokenRedirect called."); let r = yt(e, []); delete r.onRedirectNavigate; let o = yield this.initializeNativeRequest(r), i = { method: At.GetToken, request: o }; try {
        let l = yield this.nativeMessageHandler.sendMessage(i);
        this.validateNativeResponse(l);
    }
    catch (l) {
        if (l instanceof Pe && (this.serverTelemetryManager.setNativeBrokerErrorCode(l.errorCode), $t(l)))
            throw l;
    } this.browserStorage.setTemporaryCache(O.NATIVE_REQUEST, JSON.stringify(o), !0); let s = { apiId: M.acquireTokenRedirect, timeout: this.config.system.redirectNavigationTimeout, noHistory: !1 }, a = this.config.auth.navigateToLoginRequestUrl ? window.location.href : this.getRedirectUri(e.redirectUri); t.end({ success: !0 }), yield this.navigationClient.navigateExternal(a, s); }); }
    handleRedirectPromise(e, t) { return d(this, null, function* () { if (this.logger.trace("NativeInteractionClient - handleRedirectPromise called."), !this.browserStorage.isInteractionInProgress(!0))
        return this.logger.info("handleRedirectPromise called but there is no interaction in progress, returning null."), null; let r = this.browserStorage.getCachedNativeRequest(); if (!r)
        return this.logger.verbose("NativeInteractionClient - handleRedirectPromise called but there is no cached request, returning null."), e && t && e?.addFields({ errorCode: "no_cached_request" }, t), null; let l = r, { prompt: o } = l, i = yt(l, ["prompt"]); o && this.logger.verbose("NativeInteractionClient - handleRedirectPromise called and prompt was included in the original request, removing prompt from cached request to prevent second interaction with native broker window."), this.browserStorage.removeItem(this.browserStorage.generateCacheKey(O.NATIVE_REQUEST)); let s = { method: At.GetToken, request: i }, a = Qe.nowSeconds(); try {
        this.logger.verbose("NativeInteractionClient - handleRedirectPromise sending message to native broker.");
        let h = yield this.nativeMessageHandler.sendMessage(s);
        this.validateNativeResponse(h);
        let g = this.handleNativeResponse(h, i, a);
        this.browserStorage.setInteractionInProgress(!1);
        let T = yield g;
        return this.serverTelemetryManager.clearNativeBrokerErrorCode(), T;
    }
    catch (h) {
        throw this.browserStorage.setInteractionInProgress(!1), h;
    } }); }
    logout() { return this.logger.trace("NativeInteractionClient - logout called."), Promise.reject("Logout not implemented yet"); }
    handleNativeResponse(e, t, r) { return d(this, null, function* () { this.logger.trace("NativeInteractionClient - handleNativeResponse called."); let o = xe.extractTokenClaims(e.id_token, Ee), i = this.createHomeAccountIdentifier(e, o), s = this.browserStorage.getAccountInfoFilteredBy({ nativeAccountId: t.accountId })?.homeAccountId; if (i !== s && e.account.id !== t.accountId)
        throw Ln(Oi); let a = yield this.getDiscoveredAuthority({ requestAuthority: t.authority }), l = Io(this.browserStorage, a, i, Ee, o, e.client_info, void 0, o.tid, void 0, e.account.id, this.logger), h = yield this.generateAuthenticationResult(e, t, o, l, a.canonicalAuthority, r); return this.cacheAccount(l), this.cacheNativeTokens(e, t, i, o, e.access_token, h.tenantId, r), h; }); }
    createHomeAccountIdentifier(e, t) { return B.generateHomeAccountId(e.client_info || u.EMPTY_STRING, pe.Default, this.logger, this.browserCrypto, t); }
    generateScopes(e, t) { return e.scope ? z.fromString(e.scope) : z.fromString(t.scope); }
    generatePopAccessToken(e, t) { return d(this, null, function* () { if (t.tokenType === b.POP && t.signPopToken) {
        if (e.shr)
            return this.logger.trace("handleNativeServerResponse: SHR is enabled in native layer"), e.shr;
        let r = new Ce(this.browserCrypto), o = { resourceRequestMethod: t.resourceRequestMethod, resourceRequestUri: t.resourceRequestUri, shrClaims: t.shrClaims, shrNonce: t.shrNonce };
        if (!t.keyId)
            throw m(F.keyIdMissing);
        return r.signPopToken(e.access_token, t.keyId, o);
    }
    else
        return e.access_token; }); }
    generateAuthenticationResult(e, t, r, o, i, s) { return d(this, null, function* () { let a = this.addTelemetryFromNativeResponse(e), l = e.scope ? z.fromString(e.scope) : z.fromString(t.scope), h = e.account.properties || {}, g = h.UID || r.oid || r.sub || u.EMPTY_STRING, T = h.TenantId || r.tid || u.EMPTY_STRING, y = wr(o.getAccountInfo(), void 0, r, e.id_token); y.nativeAccountId !== e.account.id && (y.nativeAccountId = e.account.id); let v = yield this.generatePopAccessToken(e, t), L = t.tokenType === b.POP ? b.POP : b.BEARER; return { authority: i, uniqueId: g, tenantId: T, scopes: l.asArray(), account: y, idToken: e.id_token, idTokenClaims: r, accessToken: v, fromCache: a ? this.isResponseFromCache(a) : !1, expiresOn: new Date(Number(s + e.expires_in) * 1e3), tokenType: L, correlationId: this.correlationId, state: e.state, fromNativeBroker: !0 }; }); }
    cacheAccount(e) { this.browserStorage.setAccount(e), this.browserStorage.removeAccountContext(e).catch(t => { this.logger.error(`Error occurred while removing account context from browser storage. ${t}`); }); }
    cacheNativeTokens(e, t, r, o, i, s, a) { let l = K.createIdTokenEntity(r, t.authority, e.id_token || "", t.clientId, o.tid || ""), h = t.tokenType === b.POP ? u.SHR_NONCE_VALIDITY : (typeof e.expires_in == "string" ? parseInt(e.expires_in, 10) : e.expires_in) || 0, g = a + h, T = this.generateScopes(e, t), y = K.createAccessTokenEntity(r, t.authority, i, t.clientId, o.tid || s, T.printScopes(), g, 0, Ee, void 0, t.tokenType, void 0, t.keyId), v = { idToken: l, accessToken: y }; this.nativeStorageManager.saveCacheRecord(v, t.storeInCache); }
    addTelemetryFromNativeResponse(e) { let t = this.getMATSFromResponse(e); return t ? (this.performanceClient.addFields({ extensionId: this.nativeMessageHandler.getExtensionId(), extensionVersion: this.nativeMessageHandler.getExtensionVersion(), matsBrokerVersion: t.broker_version, matsAccountJoinOnStart: t.account_join_on_start, matsAccountJoinOnEnd: t.account_join_on_end, matsDeviceJoin: t.device_join, matsPromptBehavior: t.prompt_behavior, matsApiErrorCode: t.api_error_code, matsUiVisible: t.ui_visible, matsSilentCode: t.silent_code, matsSilentBiSubCode: t.silent_bi_sub_code, matsSilentMessage: t.silent_message, matsSilentStatus: t.silent_status, matsHttpStatus: t.http_status, matsHttpEventCount: t.http_event_count }, this.correlationId), t) : null; }
    validateNativeResponse(e) { if (e.hasOwnProperty("access_token") && e.hasOwnProperty("id_token") && e.hasOwnProperty("client_info") && e.hasOwnProperty("account") && e.hasOwnProperty("scope") && e.hasOwnProperty("expires_in"))
        return e; throw Lo(Wt.unexpectedError, "Response missing expected properties."); }
    getMATSFromResponse(e) { if (e.properties.MATS)
        try {
            return JSON.parse(e.properties.MATS);
        }
        catch {
            this.logger.error("NativeInteractionClient - Error parsing MATS telemetry, returning null instead");
        } return null; }
    isResponseFromCache(e) { return typeof e.is_cached > "u" ? (this.logger.verbose("NativeInteractionClient - MATS telemetry does not contain field indicating if response was served from cache. Returning false."), !1) : !!e.is_cached; }
    initializeNativeRequest(e) { return d(this, null, function* () { this.logger.trace("NativeInteractionClient - initializeNativeRequest called"); let t = e.authority || this.config.auth.authority; e.account && (yield this.getDiscoveredAuthority({ requestAuthority: t, requestAzureCloudOptions: e.azureCloudOptions, account: e.account })); let r = new P(t); r.validateAsUri(); let h = e, { scopes: o } = h, i = yt(h, ["scopes"]), s = new z(o || []); s.appendScopes(ce); let a = () => { switch (this.apiId) {
        case M.ssoSilent:
        case M.acquireTokenSilent_silentFlow: return this.logger.trace("initializeNativeRequest: silent request sets prompt to none"), G.NONE;
    } if (!e.prompt) {
        this.logger.trace("initializeNativeRequest: prompt was not provided");
        return;
    } switch (e.prompt) {
        case G.NONE:
        case G.CONSENT:
        case G.LOGIN: return this.logger.trace("initializeNativeRequest: prompt is compatible with native flow"), e.prompt;
        default: throw this.logger.trace(`initializeNativeRequest: prompt = ${e.prompt} is not compatible with native flow`), C(Xr);
    } }, l = I(p({}, i), { accountId: this.accountId, clientId: this.config.auth.clientId, authority: r.urlString, scope: s.printScopes(), redirectUri: this.getRedirectUri(e.redirectUri), prompt: a(), correlationId: this.correlationId, tokenType: e.authenticationScheme, windowTitleSubstring: document.title, extraParameters: p(p({}, e.extraQueryParameters), e.tokenQueryParameters), extendedExpiryToken: !1, keyId: e.popKid }); if (l.signPopToken && e.popKid)
        throw C(eo); if (this.handleExtraBrokerParams(l), l.extraParameters = l.extraParameters || {}, l.extraParameters.telemetry = Kt.MATS_TELEMETRY, e.authenticationScheme === b.POP) {
        let g = { resourceRequestUri: e.resourceRequestUri, resourceRequestMethod: e.resourceRequestMethod, shrClaims: e.shrClaims, shrNonce: e.shrNonce }, T = new Ce(this.browserCrypto), y;
        if (l.keyId)
            y = this.browserCrypto.base64UrlEncode(JSON.stringify({ kid: l.keyId })), l.signPopToken = !1;
        else {
            let v = yield f(T.generateCnf.bind(T), c.PopTokenGenerateCnf, this.logger, this.performanceClient, e.correlationId)(g, this.logger);
            y = v.reqCnfString, l.keyId = v.kid, l.signPopToken = !0;
        }
        l.reqCnf = y;
    } return this.addRequestSKUs(l), l; }); }
    handleExtraBrokerParams(e) { let t = e.extraParameters && e.extraParameters.hasOwnProperty(ut.BROKER_CLIENT_ID) && e.extraParameters.hasOwnProperty(ut.BROKER_REDIRECT_URI) && e.extraParameters.hasOwnProperty(ut.CLIENT_ID); if (!e.embeddedClientId && !t)
        return; let r = "", o = e.redirectUri; e.embeddedClientId ? (e.redirectUri = this.config.auth.redirectUri, r = e.embeddedClientId) : e.extraParameters && (e.redirectUri = e.extraParameters[ut.BROKER_REDIRECT_URI], r = e.extraParameters[ut.CLIENT_ID]), e.extraParameters = { child_client_id: r, child_redirect_uri: o }, this.performanceClient?.addFields({ embeddedClientId: r, embeddedRedirectUri: o }, e.correlationId); }
};
var ke = class n {
    constructor(e, t, r, o) { this.logger = e, this.handshakeTimeoutMs = t, this.extensionId = o, this.resolvers = new Map, this.handshakeResolvers = new Map, this.messageChannel = new MessageChannel, this.windowListener = this.onWindowMessage.bind(this), this.performanceClient = r, this.handshakeEvent = r.startMeasurement(c.NativeMessageHandlerHandshake); }
    sendMessage(e) { return d(this, null, function* () { this.logger.trace("NativeMessageHandler - sendMessage called."); let t = { channel: Kt.CHANNEL_ID, extensionId: this.extensionId, responseId: ee(), body: e }; return this.logger.trace("NativeMessageHandler - Sending request to browser extension"), this.logger.tracePii(`NativeMessageHandler - Sending request to browser extension: ${JSON.stringify(t)}`), this.messageChannel.port1.postMessage(t), new Promise((r, o) => { this.resolvers.set(t.responseId, { resolve: r, reject: o }); }); }); }
    static createProvider(e, t, r) { return d(this, null, function* () { e.trace("NativeMessageHandler - createProvider called."); try {
        let o = new n(e, t, r, Kt.PREFERRED_EXTENSION_ID);
        return yield o.sendHandshakeRequest(), o;
    }
    catch {
        let i = new n(e, t, r);
        return yield i.sendHandshakeRequest(), i;
    } }); }
    sendHandshakeRequest() { return d(this, null, function* () { this.logger.trace("NativeMessageHandler - sendHandshakeRequest called."), window.addEventListener("message", this.windowListener, !1); let e = { channel: Kt.CHANNEL_ID, extensionId: this.extensionId, responseId: ee(), body: { method: At.HandshakeRequest } }; return this.handshakeEvent.add({ extensionId: this.extensionId, extensionHandshakeTimeoutMs: this.handshakeTimeoutMs }), this.messageChannel.port1.onmessage = t => { this.onChannelMessage(t); }, window.postMessage(e, window.origin, [this.messageChannel.port2]), new Promise((t, r) => { this.handshakeResolvers.set(e.responseId, { resolve: t, reject: r }), this.timeoutId = window.setTimeout(() => { window.removeEventListener("message", this.windowListener, !1), this.messageChannel.port1.close(), this.messageChannel.port2.close(), this.handshakeEvent.end({ extensionHandshakeTimedOut: !0, success: !1 }), r(C(Wr)), this.handshakeResolvers.delete(e.responseId); }, this.handshakeTimeoutMs); }); }); }
    onWindowMessage(e) { if (this.logger.trace("NativeMessageHandler - onWindowMessage called"), e.source !== window)
        return; let t = e.data; if (!(!t.channel || t.channel !== Kt.CHANNEL_ID) && !(t.extensionId && t.extensionId !== this.extensionId) && t.body.method === At.HandshakeRequest) {
        let r = this.handshakeResolvers.get(t.responseId);
        if (!r) {
            this.logger.trace(`NativeMessageHandler.onWindowMessage - resolver can't be found for request ${t.responseId}`);
            return;
        }
        this.logger.verbose(t.extensionId ? `Extension with id: ${t.extensionId} not installed` : "No extension installed"), clearTimeout(this.timeoutId), this.messageChannel.port1.close(), this.messageChannel.port2.close(), window.removeEventListener("message", this.windowListener, !1), this.handshakeEvent.end({ success: !1, extensionInstalled: !1 }), r.reject(C(jr));
    } }
    onChannelMessage(e) { this.logger.trace("NativeMessageHandler - onChannelMessage called."); let t = e.data, r = this.resolvers.get(t.responseId), o = this.handshakeResolvers.get(t.responseId); try {
        let i = t.body.method;
        if (i === At.Response) {
            if (!r)
                return;
            let s = t.body.response;
            if (this.logger.trace("NativeMessageHandler - Received response from browser extension"), this.logger.tracePii(`NativeMessageHandler - Received response from browser extension: ${JSON.stringify(s)}`), s.status !== "Success")
                r.reject(Ln(s.code, s.description, s.ext));
            else if (s.result)
                s.result.code && s.result.description ? r.reject(Ln(s.result.code, s.result.description, s.result.ext)) : r.resolve(s.result);
            else
                throw Lo(Wt.unexpectedError, "Event does not contain result.");
            this.resolvers.delete(t.responseId);
        }
        else if (i === At.HandshakeResponse) {
            if (!o) {
                this.logger.trace(`NativeMessageHandler.onChannelMessage - resolver can't be found for request ${t.responseId}`);
                return;
            }
            clearTimeout(this.timeoutId), window.removeEventListener("message", this.windowListener, !1), this.extensionId = t.extensionId, this.extensionVersion = t.body.version, this.logger.verbose(`NativeMessageHandler - Received HandshakeResponse from extension: ${this.extensionId}`), this.handshakeEvent.end({ extensionInstalled: !0, success: !0 }), o.resolve(), this.handshakeResolvers.delete(t.responseId);
        }
    }
    catch (i) {
        this.logger.error("Error parsing response from WAM Extension"), this.logger.errorPii(`Error parsing response from WAM Extension: ${i}`), this.logger.errorPii(`Unable to parse ${e}`), r ? r.reject(i) : o && o.reject(i);
    } }
    getExtensionId() { return this.extensionId; }
    getExtensionVersion() { return this.extensionVersion; }
    static isNativeAvailable(e, t, r, o) { if (t.trace("isNativeAvailable called"), !e.system.allowNativeBroker)
        return t.trace("isNativeAvailable: allowNativeBroker is not enabled, returning false"), !1; if (!r)
        return t.trace("isNativeAvailable: WAM extension provider is not initialized, returning false"), !1; if (o)
        switch (o) {
            case b.BEARER:
            case b.POP: return t.trace("isNativeAvailable: authenticationScheme is supported, returning true"), !0;
            default: return t.trace("isNativeAvailable: authenticationScheme is not supported, returning false"), !1;
        } return !0; }
};
var Vt = class {
    constructor(e, t, r, o, i) { this.authModule = e, this.browserStorage = t, this.authCodeRequest = r, this.logger = o, this.performanceClient = i; }
    handleCodeResponse(e, t) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.HandleCodeResponse, t.correlationId); let r; try {
        r = this.authModule.handleFragmentResponse(e, t.state);
    }
    catch (o) {
        throw o instanceof oe && o.subError === Te ? C(Te) : o;
    } return f(this.handleCodeResponseFromServer.bind(this), c.HandleCodeResponseFromServer, this.logger, this.performanceClient, t.correlationId)(r, t); }); }
    handleCodeResponseFromServer(e, t, r = !0) { return d(this, null, function* () { if (this.performanceClient.addQueueMeasurement(c.HandleCodeResponseFromServer, t.correlationId), this.logger.trace("InteractionHandler.handleCodeResponseFromServer called"), this.authCodeRequest.code = e.code, e.cloud_instance_host_name && (yield f(this.authModule.updateAuthority.bind(this.authModule), c.UpdateTokenEndpointAuthority, this.logger, this.performanceClient, t.correlationId)(e.cloud_instance_host_name, t.correlationId)), r && (e.nonce = t.nonce || void 0), e.state = t.state, e.client_info)
        this.authCodeRequest.clientInfo = e.client_info;
    else {
        let i = this.createCcsCredentials(t);
        i && (this.authCodeRequest.ccsCredential = i);
    } return yield f(this.authModule.acquireToken.bind(this.authModule), c.AuthClientAcquireToken, this.logger, this.performanceClient, t.correlationId)(this.authCodeRequest, e); }); }
    createCcsCredentials(e) { return e.account ? { credential: e.account.homeAccountId, type: re.HOME_ACCOUNT_ID } : e.loginHint ? { credential: e.loginHint, type: re.UPN } : null; }
};
function Mi(n, e, t) { let r = Ot.getDeserializedResponse(n); if (!r)
    throw Ot.stripLeadingHashOrQuery(n) ? (t.error(`A ${e} is present in the iframe but it does not contain known properties. It's likely that the ${e} has been replaced by code running on the redirectUri page.`), t.errorPii(`The ${e} detected is: ${n}`), C(br)) : (t.error(`The request has returned to the redirectUri but a ${e} is not present. It's likely that the ${e} has been removed or the page has been redirected by code running on the redirectUri page.`), C(_r)); return r; }
function mc(n, e, t) { if (!n.state)
    throw C(gt); let r = wi(e, n.state); if (!r)
    throw C(Pr); if (r.interactionType !== t)
    throw C(Nr); }
var Ui = class extends ye {
    constructor(e, t, r, o, i, s, a, l, h, g) { super(e, t, r, o, i, s, a, h, g), this.unloadWindow = this.unloadWindow.bind(this), this.nativeStorage = l; }
    acquireToken(e) { try {
        let r = { popupName: this.generatePopupName(e.scopes || ce, e.authority || this.config.auth.authority), popupWindowAttributes: e.popupWindowAttributes || {}, popupWindowParent: e.popupWindowParent ?? window };
        return this.config.system.asyncPopups ? (this.logger.verbose("asyncPopups set to true, acquiring token"), this.acquireTokenPopupAsync(e, r)) : (this.logger.verbose("asyncPopup set to false, opening popup before acquiring token"), r.popup = this.openSizedPopup("about:blank", r), this.acquireTokenPopupAsync(e, r));
    }
    catch (t) {
        return Promise.reject(t);
    } }
    logout(e) { try {
        this.logger.verbose("logoutPopup called");
        let t = this.initializeLogoutRequest(e), r = { popupName: this.generateLogoutPopupName(t), popupWindowAttributes: e?.popupWindowAttributes || {}, popupWindowParent: e?.popupWindowParent ?? window }, o = e && e.authority, i = e && e.mainWindowRedirectUri;
        return this.config.system.asyncPopups ? (this.logger.verbose("asyncPopups set to true"), this.logoutPopupAsync(t, r, o, i)) : (this.logger.verbose("asyncPopup set to false, opening popup"), r.popup = this.openSizedPopup("about:blank", r), this.logoutPopupAsync(t, r, o, i));
    }
    catch (t) {
        return Promise.reject(t);
    } }
    acquireTokenPopupAsync(e, t) { return d(this, null, function* () { this.logger.verbose("acquireTokenPopupAsync called"); let r = this.initializeServerTelemetryManager(M.acquireTokenPopup), o = yield f(this.initializeAuthorizationRequest.bind(this), c.StandardInteractionClientInitializeAuthorizationRequest, this.logger, this.performanceClient, this.correlationId)(e, E.Popup); bn(o.authority); try {
        let i = yield f(this.initializeAuthorizationCodeRequest.bind(this), c.StandardInteractionClientInitializeAuthorizationCodeRequest, this.logger, this.performanceClient, this.correlationId)(o), s = yield f(this.createAuthCodeClient.bind(this), c.StandardInteractionClientCreateAuthCodeClient, this.logger, this.performanceClient, this.correlationId)({ serverTelemetryManager: r, requestAuthority: o.authority, requestAzureCloudOptions: o.azureCloudOptions, requestExtraQueryParameters: o.extraQueryParameters, account: o.account }), a = ke.isNativeAvailable(this.config, this.logger, this.nativeMessageHandler, e.authenticationScheme), l;
        a && (l = this.performanceClient.startMeasurement(c.FetchAccountIdWithNativeBroker, e.correlationId));
        let h = yield s.getAuthCodeUrl(I(p({}, o), { nativeBroker: a })), g = new Vt(s, this.browserStorage, i, this.logger, this.performanceClient), T = this.initiateAuthRequest(h, t);
        this.eventHandler.emitEvent(A.POPUP_OPENED, E.Popup, { popupWindow: T }, null);
        let y = yield this.monitorPopupForHash(T, t.popupWindowParent), v = fe(Mi, c.DeserializeResponse, this.logger, this.performanceClient, this.correlationId)(y, this.config.auth.OIDCOptions.serverResponseType, this.logger);
        if (je.removeThrottle(this.browserStorage, this.config.auth.clientId, i), v.accountId) {
            if (this.logger.verbose("Account id found in hash, calling WAM for token"), l && l.end({ success: !0, isNativeBroker: !0 }), !this.nativeMessageHandler)
                throw C(Re);
            let x = new Ne(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, M.acquireTokenPopup, this.performanceClient, this.nativeMessageHandler, v.accountId, this.nativeStorage, o.correlationId), { userRequestState: de } = ne.parseRequestState(this.browserCrypto, o.state);
            return yield x.acquireToken(I(p({}, o), { state: de, prompt: void 0 }));
        }
        return yield g.handleCodeResponse(v, o);
    }
    catch (i) {
        throw t.popup?.close(), i instanceof w && (i.setCorrelationId(this.correlationId), r.cacheFailedRequest(i)), i;
    } }); }
    logoutPopupAsync(e, t, r, o) { return d(this, null, function* () { this.logger.verbose("logoutPopupAsync called"), this.eventHandler.emitEvent(A.LOGOUT_START, E.Popup, e); let i = this.initializeServerTelemetryManager(M.logoutPopup); try {
        yield this.clearCacheOnLogout(e.account);
        let s = yield f(this.createAuthCodeClient.bind(this), c.StandardInteractionClientCreateAuthCodeClient, this.logger, this.performanceClient, this.correlationId)({ serverTelemetryManager: i, requestAuthority: r, account: e.account || void 0 });
        try {
            s.authority.endSessionEndpoint;
        }
        catch {
            if (e.account?.homeAccountId && e.postLogoutRedirectUri && s.authority.protocolMode === le.OIDC) {
                if (this.browserStorage.removeAccount(e.account?.homeAccountId), this.eventHandler.emitEvent(A.LOGOUT_SUCCESS, E.Popup, e), o) {
                    let h = { apiId: M.logoutPopup, timeout: this.config.system.redirectNavigationTimeout, noHistory: !1 }, g = P.getAbsoluteUrl(o, Ae());
                    yield this.navigationClient.navigateInternal(g, h);
                }
                t.popup?.close();
                return;
            }
        }
        let a = s.getLogoutUri(e);
        this.eventHandler.emitEvent(A.LOGOUT_SUCCESS, E.Popup, e);
        let l = this.openPopup(a, t);
        if (this.eventHandler.emitEvent(A.POPUP_OPENED, E.Popup, { popupWindow: l }, null), yield this.monitorPopupForHash(l, t.popupWindowParent).catch(() => { }), o) {
            let h = { apiId: M.logoutPopup, timeout: this.config.system.redirectNavigationTimeout, noHistory: !1 }, g = P.getAbsoluteUrl(o, Ae());
            this.logger.verbose("Redirecting main window to url specified in the request"), this.logger.verbosePii(`Redirecting main window to: ${g}`), yield this.navigationClient.navigateInternal(g, h);
        }
        else
            this.logger.verbose("No main window navigation requested");
    }
    catch (s) {
        throw t.popup?.close(), s instanceof w && (s.setCorrelationId(this.correlationId), i.cacheFailedRequest(s)), this.browserStorage.setInteractionInProgress(!1), this.eventHandler.emitEvent(A.LOGOUT_FAILURE, E.Popup, null, s), this.eventHandler.emitEvent(A.LOGOUT_END, E.Popup), s;
    } this.eventHandler.emitEvent(A.LOGOUT_END, E.Popup); }); }
    initiateAuthRequest(e, t) { if (e)
        return this.logger.infoPii(`Navigate to: ${e}`), this.openPopup(e, t); throw this.logger.error("Navigate url is empty"), C(Fe); }
    monitorPopupForHash(e, t) { return new Promise((r, o) => { this.logger.verbose("PopupHandler.monitorPopupForHash - polling started"); let i = setInterval(() => { if (e.closed) {
        this.logger.error("PopupHandler.monitorPopupForHash - window closed"), clearInterval(i), o(C(Te));
        return;
    } let s = ""; try {
        s = e.location.href;
    }
    catch { } if (!s || s === "about:blank")
        return; clearInterval(i); let a = "", l = this.config.auth.OIDCOptions.serverResponseType; e && (l === Ue.QUERY ? a = e.location.search : a = e.location.hash), this.logger.verbose("PopupHandler.monitorPopupForHash - popup window is on same origin as caller"), r(a); }, this.config.system.pollIntervalMilliseconds); }).finally(() => { this.cleanPopup(e, t); }); }
    openPopup(e, t) { try {
        let r;
        if (t.popup ? (r = t.popup, this.logger.verbosePii(`Navigating popup window to: ${e}`), r.location.assign(e)) : typeof t.popup > "u" && (this.logger.verbosePii(`Opening popup window to: ${e}`), r = this.openSizedPopup(e, t)), !r)
            throw C(Ur);
        return r.focus && r.focus(), this.currentWindow = r, t.popupWindowParent.addEventListener("beforeunload", this.unloadWindow), r;
    }
    catch (r) {
        throw this.logger.error("error opening popup " + r.message), this.browserStorage.setInteractionInProgress(!1), C(Mr);
    } }
    openSizedPopup(e, { popupName: t, popupWindowAttributes: r, popupWindowParent: o }) { let i = o.screenLeft ? o.screenLeft : o.screenX, s = o.screenTop ? o.screenTop : o.screenY, a = o.innerWidth || document.documentElement.clientWidth || document.body.clientWidth, l = o.innerHeight || document.documentElement.clientHeight || document.body.clientHeight, h = r.popupSize?.width, g = r.popupSize?.height, T = r.popupPosition?.top, y = r.popupPosition?.left; return (!h || h < 0 || h > a) && (this.logger.verbose("Default popup window width used. Window width not configured or invalid."), h = W.POPUP_WIDTH), (!g || g < 0 || g > l) && (this.logger.verbose("Default popup window height used. Window height not configured or invalid."), g = W.POPUP_HEIGHT), (!T || T < 0 || T > l) && (this.logger.verbose("Default popup window top position used. Window top not configured or invalid."), T = Math.max(0, l / 2 - W.POPUP_HEIGHT / 2 + s)), (!y || y < 0 || y > a) && (this.logger.verbose("Default popup window left position used. Window left not configured or invalid."), y = Math.max(0, a / 2 - W.POPUP_WIDTH / 2 + i)), o.open(e, t, `width=${h}, height=${g}, top=${T}, left=${y}, scrollbars=yes`); }
    unloadWindow(e) { this.browserStorage.cleanRequestByInteractionType(E.Popup), this.currentWindow && this.currentWindow.close(), e.preventDefault(); }
    cleanPopup(e, t) { e.close(), t.removeEventListener("beforeunload", this.unloadWindow), this.browserStorage.setInteractionInProgress(!1); }
    generatePopupName(e, t) { return `${W.POPUP_NAME_PREFIX}.${this.config.auth.clientId}.${e.join("-")}.${t}.${this.correlationId}`; }
    generateLogoutPopupName(e) { let t = e.account && e.account.homeAccountId; return `${W.POPUP_NAME_PREFIX}.${this.config.auth.clientId}.${t}.${this.correlationId}`; }
};
var Dn = class {
    constructor(e, t, r, o, i) { this.authModule = e, this.browserStorage = t, this.authCodeRequest = r, this.logger = o, this.performanceClient = i; }
    initiateAuthRequest(e, t) { return d(this, null, function* () { if (this.logger.verbose("RedirectHandler.initiateAuthRequest called"), e) {
        t.redirectStartPage && (this.logger.verbose("RedirectHandler.initiateAuthRequest: redirectStartPage set, caching start page"), this.browserStorage.setTemporaryCache(O.ORIGIN_URI, t.redirectStartPage, !0)), this.browserStorage.setTemporaryCache(O.CORRELATION_ID, this.authCodeRequest.correlationId, !0), this.browserStorage.cacheCodeRequest(this.authCodeRequest), this.logger.infoPii(`RedirectHandler.initiateAuthRequest: Navigate to: ${e}`);
        let r = { apiId: M.acquireTokenRedirect, timeout: t.redirectTimeout, noHistory: !1 };
        if (typeof t.onRedirectNavigate == "function")
            if (this.logger.verbose("RedirectHandler.initiateAuthRequest: Invoking onRedirectNavigate callback"), t.onRedirectNavigate(e) !== !1) {
                this.logger.verbose("RedirectHandler.initiateAuthRequest: onRedirectNavigate did not return false, navigating"), yield t.navigationClient.navigateExternal(e, r);
                return;
            }
            else {
                this.logger.verbose("RedirectHandler.initiateAuthRequest: onRedirectNavigate returned false, stopping navigation");
                return;
            }
        else {
            this.logger.verbose("RedirectHandler.initiateAuthRequest: Navigating window to navigate url"), yield t.navigationClient.navigateExternal(e, r);
            return;
        }
    }
    else
        throw this.logger.info("RedirectHandler.initiateAuthRequest: Navigate url is empty"), C(Fe); }); }
    handleCodeResponse(e, t) { return d(this, null, function* () { this.logger.verbose("RedirectHandler.handleCodeResponse called"), this.browserStorage.setInteractionInProgress(!1); let r = this.browserStorage.generateStateKey(t), o = this.browserStorage.getTemporaryCache(r); if (!o)
        throw m(F.stateNotFound, "Cached State"); let i; try {
        i = this.authModule.handleFragmentResponse(e, o);
    }
    catch (h) {
        throw h instanceof oe && h.subError === Te ? C(Te) : h;
    } let s = this.browserStorage.generateNonceKey(o), a = this.browserStorage.getTemporaryCache(s); if (this.authCodeRequest.code = i.code, i.cloud_instance_host_name && (yield f(this.authModule.updateAuthority.bind(this.authModule), c.UpdateTokenEndpointAuthority, this.logger, this.performanceClient, this.authCodeRequest.correlationId)(i.cloud_instance_host_name, this.authCodeRequest.correlationId)), i.nonce = a || void 0, i.state = o, i.client_info)
        this.authCodeRequest.clientInfo = i.client_info;
    else {
        let h = this.checkCcsCredentials();
        h && (this.authCodeRequest.ccsCredential = h);
    } let l = yield this.authModule.acquireToken(this.authCodeRequest, i); return this.browserStorage.cleanRequestByState(t), l; }); }
    checkCcsCredentials() { let e = this.browserStorage.getTemporaryCache(O.CCS_CREDENTIAL, !0); if (e)
        try {
            return JSON.parse(e);
        }
        catch {
            this.authModule.logger.error("Cache credential could not be parsed"), this.authModule.logger.errorPii(`Cache credential could not be parsed: ${e}`);
        } return null; }
};
function Ml() { if (typeof window > "u" || typeof window.performance > "u" || typeof window.performance.getEntriesByType != "function")
    return; let n = window.performance.getEntriesByType("navigation"); return (n.length ? n[0] : void 0)?.type; }
var Li = class extends ye {
    constructor(e, t, r, o, i, s, a, l, h, g) { super(e, t, r, o, i, s, a, h, g), this.nativeStorage = l; }
    acquireToken(e) { return d(this, null, function* () { let t = yield f(this.initializeAuthorizationRequest.bind(this), c.StandardInteractionClientInitializeAuthorizationRequest, this.logger, this.performanceClient, this.correlationId)(e, E.Redirect); this.browserStorage.updateCacheEntries(t.state, t.nonce, t.authority, t.loginHint || "", t.account || null); let r = this.initializeServerTelemetryManager(M.acquireTokenRedirect), o = i => { i.persisted && (this.logger.verbose("Page was restored from back/forward cache. Clearing temporary cache."), this.browserStorage.cleanRequestByState(t.state), this.eventHandler.emitEvent(A.RESTORE_FROM_BFCACHE, E.Redirect)); }; try {
        let i = yield f(this.initializeAuthorizationCodeRequest.bind(this), c.StandardInteractionClientInitializeAuthorizationCodeRequest, this.logger, this.performanceClient, this.correlationId)(t), s = yield f(this.createAuthCodeClient.bind(this), c.StandardInteractionClientCreateAuthCodeClient, this.logger, this.performanceClient, this.correlationId)({ serverTelemetryManager: r, requestAuthority: t.authority, requestAzureCloudOptions: t.azureCloudOptions, requestExtraQueryParameters: t.extraQueryParameters, account: t.account }), a = new Dn(s, this.browserStorage, i, this.logger, this.performanceClient), l = yield s.getAuthCodeUrl(I(p({}, t), { nativeBroker: ke.isNativeAvailable(this.config, this.logger, this.nativeMessageHandler, e.authenticationScheme) })), h = this.getRedirectStartPage(e.redirectStartPage);
        return this.logger.verbosePii(`Redirect start page: ${h}`), window.addEventListener("pageshow", o), yield a.initiateAuthRequest(l, { navigationClient: this.navigationClient, redirectTimeout: this.config.system.redirectNavigationTimeout, redirectStartPage: h, onRedirectNavigate: e.onRedirectNavigate || this.config.auth.onRedirectNavigate });
    }
    catch (i) {
        throw i instanceof w && (i.setCorrelationId(this.correlationId), r.cacheFailedRequest(i)), window.removeEventListener("pageshow", o), this.browserStorage.cleanRequestByState(t.state), i;
    } }); }
    handleRedirectPromise(e = "", t) { return d(this, null, function* () { let r = this.initializeServerTelemetryManager(M.handleRedirectPromise); try {
        if (!this.browserStorage.isInteractionInProgress(!0))
            return this.logger.info("handleRedirectPromise called but there is no interaction in progress, returning null."), null;
        let [o, i] = this.getRedirectResponse(e || "");
        if (!o)
            return this.logger.info("handleRedirectPromise did not detect a response as a result of a redirect. Cleaning temporary cache."), this.browserStorage.cleanRequestByInteractionType(E.Redirect), Ml() !== "back_forward" ? t.event.errorCode = "no_server_response" : this.logger.verbose("Back navigation event detected. Muting no_server_response error"), null;
        let s = this.browserStorage.getTemporaryCache(O.ORIGIN_URI, !0) || u.EMPTY_STRING, a = P.removeHashFromUrl(s), l = P.removeHashFromUrl(window.location.href);
        if (a === l && this.config.auth.navigateToLoginRequestUrl)
            return this.logger.verbose("Current page is loginRequestUrl, handling response"), s.indexOf("#") > -1 && ta(s), yield this.handleResponse(o, r);
        if (this.config.auth.navigateToLoginRequestUrl) {
            if (!kn() || this.config.system.allowRedirectInIframe) {
                this.browserStorage.setTemporaryCache(O.URL_HASH, i, !0);
                let h = { apiId: M.handleRedirectPromise, timeout: this.config.system.redirectNavigationTimeout, noHistory: !0 }, g = !0;
                if (!s || s === "null") {
                    let T = ra();
                    this.browserStorage.setTemporaryCache(O.ORIGIN_URI, T, !0), this.logger.warning("Unable to get valid login request url from cache, redirecting to home page"), g = yield this.navigationClient.navigateInternal(T, h);
                }
                else
                    this.logger.verbose(`Navigating to loginRequestUrl: ${s}`), g = yield this.navigationClient.navigateInternal(s, h);
                if (!g)
                    return yield this.handleResponse(o, r);
            }
        }
        else
            return this.logger.verbose("NavigateToLoginRequestUrl set to false, handling response"), yield this.handleResponse(o, r);
        return null;
    }
    catch (o) {
        throw o instanceof w && (o.setCorrelationId(this.correlationId), r.cacheFailedRequest(o)), this.browserStorage.cleanRequestByInteractionType(E.Redirect), o;
    } }); }
    getRedirectResponse(e) { this.logger.verbose("getRedirectResponseHash called"); let t = e; t || (this.config.auth.OIDCOptions.serverResponseType === Ue.QUERY ? t = window.location.search : t = window.location.hash); let r = Ot.getDeserializedResponse(t); if (r) {
        try {
            mc(r, this.browserCrypto, E.Redirect);
        }
        catch (i) {
            return i instanceof w && this.logger.error(`Interaction type validation failed due to ${i.errorCode}: ${i.errorMessage}`), [null, ""];
        }
        return ea(window), this.logger.verbose("Hash contains known properties, returning response hash"), [r, t];
    } let o = this.browserStorage.getTemporaryCache(O.URL_HASH, !0); return this.browserStorage.removeItem(this.browserStorage.generateCacheKey(O.URL_HASH)), o && (r = Ot.getDeserializedResponse(o), r) ? (this.logger.verbose("Hash does not contain known properties, returning cached hash"), [r, o]) : [null, ""]; }
    handleResponse(e, t) { return d(this, null, function* () { let r = e.state; if (!r)
        throw C(gt); let o = this.browserStorage.getCachedRequest(r); if (this.logger.verbose("handleResponse called, retrieved cached request"), e.accountId) {
        if (this.logger.verbose("Account id found in hash, calling WAM for token"), !this.nativeMessageHandler)
            throw C(Re);
        let l = new Ne(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, M.acquireTokenPopup, this.performanceClient, this.nativeMessageHandler, e.accountId, this.nativeStorage, o.correlationId), { userRequestState: h } = ne.parseRequestState(this.browserCrypto, r);
        return l.acquireToken(I(p({}, o), { state: h, prompt: void 0 })).finally(() => { this.browserStorage.cleanRequestByState(r); });
    } let i = this.browserStorage.getCachedAuthority(r); if (!i)
        throw C(pt); let s = yield f(this.createAuthCodeClient.bind(this), c.StandardInteractionClientCreateAuthCodeClient, this.logger, this.performanceClient, this.correlationId)({ serverTelemetryManager: t, requestAuthority: i }); return je.removeThrottle(this.browserStorage, this.config.auth.clientId, o), new Dn(s, this.browserStorage, o, this.logger, this.performanceClient).handleCodeResponse(e, r); }); }
    logout(e) { return d(this, null, function* () { this.logger.verbose("logoutRedirect called"); let t = this.initializeLogoutRequest(e), r = this.initializeServerTelemetryManager(M.logout); try {
        this.eventHandler.emitEvent(A.LOGOUT_START, E.Redirect, e), yield this.clearCacheOnLogout(t.account);
        let o = { apiId: M.logout, timeout: this.config.system.redirectNavigationTimeout, noHistory: !1 }, i = yield f(this.createAuthCodeClient.bind(this), c.StandardInteractionClientCreateAuthCodeClient, this.logger, this.performanceClient, this.correlationId)({ serverTelemetryManager: r, requestAuthority: e && e.authority, requestExtraQueryParameters: e?.extraQueryParameters, account: e && e.account || void 0 });
        if (i.authority.protocolMode === le.OIDC)
            try {
                i.authority.endSessionEndpoint;
            }
            catch {
                if (t.account?.homeAccountId) {
                    this.browserStorage.removeAccount(t.account?.homeAccountId), this.eventHandler.emitEvent(A.LOGOUT_SUCCESS, E.Redirect, t);
                    return;
                }
            }
        let s = i.getLogoutUri(t);
        if (this.eventHandler.emitEvent(A.LOGOUT_SUCCESS, E.Redirect, t), e && typeof e.onRedirectNavigate == "function")
            if (e.onRedirectNavigate(s) !== !1) {
                this.logger.verbose("Logout onRedirectNavigate did not return false, navigating"), this.browserStorage.getInteractionInProgress() || this.browserStorage.setInteractionInProgress(!0), yield this.navigationClient.navigateExternal(s, o);
                return;
            }
            else
                this.browserStorage.setInteractionInProgress(!1), this.logger.verbose("Logout onRedirectNavigate returned false, stopping navigation");
        else {
            this.browserStorage.getInteractionInProgress() || this.browserStorage.setInteractionInProgress(!0), yield this.navigationClient.navigateExternal(s, o);
            return;
        }
    }
    catch (o) {
        throw o instanceof w && (o.setCorrelationId(this.correlationId), r.cacheFailedRequest(o)), this.eventHandler.emitEvent(A.LOGOUT_FAILURE, E.Redirect, null, o), this.eventHandler.emitEvent(A.LOGOUT_END, E.Redirect), o;
    } this.eventHandler.emitEvent(A.LOGOUT_END, E.Redirect); }); }
    getRedirectStartPage(e) { let t = e || window.location.href; return P.getAbsoluteUrl(t, Ae()); }
};
function gc(n, e, t, r, o) { return d(this, null, function* () { if (e.addQueueMeasurement(c.SilentHandlerInitiateAuthRequest, r), !n)
    throw t.info("Navigate url is empty"), C(Fe); return o ? f(Ul, c.SilentHandlerLoadFrame, t, e, r)(n, o, e, r) : fe(Ll, c.SilentHandlerLoadFrameSync, t, e, r)(n); }); }
function pc(n, e, t, r, o, i, s) { return d(this, null, function* () { return r.addQueueMeasurement(c.SilentHandlerMonitorIframeForHash, i), new Promise((a, l) => { e < Nn && o.warning(`system.loadFrameTimeout or system.iframeHashTimeout set to lower (${e}ms) than the default (${Nn}ms). This may result in timeouts.`); let h = window.setTimeout(() => { window.clearInterval(g), l(C(Lr)); }, e), g = window.setInterval(() => { let T = "", y = n.contentWindow; try {
    T = y ? y.location.href : "";
}
catch { } if (!T || T === "about:blank")
    return; let v = ""; y && (s === Ue.QUERY ? v = y.location.search : v = y.location.hash), window.clearTimeout(h), window.clearInterval(g), a(v); }, t); }).finally(() => { fe(Dl, c.RemoveHiddenIframe, o, r, i)(n); }); }); }
function Ul(n, e, t, r) { return t.addQueueMeasurement(c.SilentHandlerLoadFrame, r), new Promise((o, i) => { let s = fc(); window.setTimeout(() => { if (!s) {
    i("Unable to load iframe");
    return;
} s.src = n, o(s); }, e); }); }
function Ll(n) { let e = fc(); return e.src = n, e; }
function fc() { let n = document.createElement("iframe"); return n.className = "msalSilentIframe", n.style.visibility = "hidden", n.style.position = "absolute", n.style.width = n.style.height = "0", n.style.border = "0", n.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms"), document.body.appendChild(n), n; }
function Dl(n) { document.body === n.parentNode && document.body.removeChild(n); }
var Di = class extends ye {
    constructor(e, t, r, o, i, s, a, l, h, g, T) { super(e, t, r, o, i, s, l, g, T), this.apiId = a, this.nativeStorage = h; }
    acquireToken(e) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.SilentIframeClientAcquireToken, e.correlationId), !e.loginHint && !e.sid && (!e.account || !e.account.username) && this.logger.warning("No user hint provided. The authorization server may need more information to complete this request."); let t = p({}, e); t.prompt ? t.prompt !== G.NONE && t.prompt !== G.NO_SESSION && (this.logger.warning(`SilentIframeClient. Replacing invalid prompt ${t.prompt} with ${G.NONE}`), t.prompt = G.NONE) : t.prompt = G.NONE; let r = yield f(this.initializeAuthorizationRequest.bind(this), c.StandardInteractionClientInitializeAuthorizationRequest, this.logger, this.performanceClient, e.correlationId)(t, E.Silent); bn(r.authority); let o = this.initializeServerTelemetryManager(this.apiId), i; try {
        return i = yield f(this.createAuthCodeClient.bind(this), c.StandardInteractionClientCreateAuthCodeClient, this.logger, this.performanceClient, e.correlationId)({ serverTelemetryManager: o, requestAuthority: r.authority, requestAzureCloudOptions: r.azureCloudOptions, requestExtraQueryParameters: r.extraQueryParameters, account: r.account }), yield f(this.silentTokenHelper.bind(this), c.SilentIframeClientTokenHelper, this.logger, this.performanceClient, e.correlationId)(i, r);
    }
    catch (s) {
        if (s instanceof w && (s.setCorrelationId(this.correlationId), o.cacheFailedRequest(s)), !i || !(s instanceof w) || s.errorCode !== W.INVALID_GRANT_ERROR)
            throw s;
        this.performanceClient.addFields({ retryError: s.errorCode }, this.correlationId);
        let a = yield f(this.initializeAuthorizationRequest.bind(this), c.StandardInteractionClientInitializeAuthorizationRequest, this.logger, this.performanceClient, e.correlationId)(t, E.Silent);
        return yield f(this.silentTokenHelper.bind(this), c.SilentIframeClientTokenHelper, this.logger, this.performanceClient, this.correlationId)(i, a);
    } }); }
    logout() { return Promise.reject(C(Ke)); }
    silentTokenHelper(e, t) { return d(this, null, function* () { let r = t.correlationId; this.performanceClient.addQueueMeasurement(c.SilentIframeClientTokenHelper, r); let o = yield f(this.initializeAuthorizationCodeRequest.bind(this), c.StandardInteractionClientInitializeAuthorizationCodeRequest, this.logger, this.performanceClient, r)(t), i = yield f(e.getAuthCodeUrl.bind(e), c.GetAuthCodeUrl, this.logger, this.performanceClient, r)(I(p({}, t), { nativeBroker: ke.isNativeAvailable(this.config, this.logger, this.nativeMessageHandler, t.authenticationScheme) })), s = new Vt(e, this.browserStorage, o, this.logger, this.performanceClient), a = yield f(gc, c.SilentHandlerInitiateAuthRequest, this.logger, this.performanceClient, r)(i, this.performanceClient, this.logger, r, this.config.system.navigateFrameWait), l = this.config.auth.OIDCOptions.serverResponseType, h = yield f(pc, c.SilentHandlerMonitorIframeForHash, this.logger, this.performanceClient, r)(a, this.config.system.iframeHashTimeout, this.config.system.pollIntervalMilliseconds, this.performanceClient, this.logger, r, l), g = fe(Mi, c.DeserializeResponse, this.logger, this.performanceClient, this.correlationId)(h, l, this.logger); if (g.accountId) {
        if (this.logger.verbose("Account id found in hash, calling WAM for token"), !this.nativeMessageHandler)
            throw C(Re);
        let T = new Ne(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, this.apiId, this.performanceClient, this.nativeMessageHandler, g.accountId, this.browserStorage, r), { userRequestState: y } = ne.parseRequestState(this.browserCrypto, t.state);
        return f(T.acquireToken.bind(T), c.NativeInteractionClientAcquireToken, this.logger, this.performanceClient, r)(I(p({}, t), { state: y, prompt: t.prompt || G.NONE }));
    } return f(s.handleCodeResponse.bind(s), c.HandleCodeResponse, this.logger, this.performanceClient, r)(g, t); }); }
};
var xi = class extends ye {
    acquireToken(e) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.SilentRefreshClientAcquireToken, e.correlationId); let t = yield f(Un, c.InitializeBaseRequest, this.logger, this.performanceClient, e.correlationId)(e, this.config, this.performanceClient, this.logger), r = p(p({}, e), t); e.redirectUri && (r.redirectUri = this.getRedirectUri(e.redirectUri)); let o = this.initializeServerTelemetryManager(M.acquireTokenSilent_silentFlow), i = yield this.createRefreshTokenClient({ serverTelemetryManager: o, authorityUrl: r.authority, azureCloudOptions: r.azureCloudOptions, account: r.account }); return f(i.acquireTokenByRefreshToken.bind(i), c.RefreshTokenClientAcquireTokenByRefreshToken, this.logger, this.performanceClient, e.correlationId)(r).catch(s => { throw s.setCorrelationId(this.correlationId), o.cacheFailedRequest(s), s; }); }); }
    logout() { return Promise.reject(C(Ke)); }
    createRefreshTokenClient(e) { return d(this, null, function* () { let t = yield f(this.getClientConfiguration.bind(this), c.StandardInteractionClientGetClientConfiguration, this.logger, this.performanceClient, this.correlationId)({ serverTelemetryManager: e.serverTelemetryManager, requestAuthority: e.authorityUrl, requestAzureCloudOptions: e.azureCloudOptions, requestExtraQueryParameters: e.extraQueryParameters, account: e.account }); return new Dt(t, this.performanceClient); }); }
};
var Hi = class {
    constructor(e, t, r, o) { this.isBrowserEnvironment = typeof window < "u", this.config = e, this.storage = t, this.logger = r, this.cryptoObj = o; }
    loadExternalTokens(e, t, r) { if (!this.isBrowserEnvironment)
        throw C(qe); let o = t.id_token ? xe.extractTokenClaims(t.id_token, Ee) : void 0, i = { protocolMode: this.config.auth.protocolMode, knownAuthorities: this.config.auth.knownAuthorities, cloudDiscoveryMetadata: this.config.auth.cloudDiscoveryMetadata, authorityMetadata: this.config.auth.authorityMetadata, skipAuthorityMetadataCache: this.config.auth.skipAuthorityMetadataCache }, s = e.authority ? new be(be.generateAuthority(e.authority, e.azureCloudOptions), this.config.system.networkClient, this.storage, i, this.logger, e.correlationId || ee()) : void 0, a = this.loadAccount(e, r.clientInfo || t.client_info || "", o, s), l = this.loadIdToken(t, a.homeAccountId, a.environment, a.realm), h = this.loadAccessToken(e, t, a.homeAccountId, a.environment, a.realm, r), g = this.loadRefreshToken(t, a.homeAccountId, a.environment); return this.generateAuthenticationResult(e, { account: a, idToken: l, accessToken: h, refreshToken: g }, o, s); }
    loadAccount(e, t, r, o) { if (this.logger.verbose("TokenCache - loading account"), e.account) {
        let l = B.createFromAccountInfo(e.account);
        return this.storage.setAccount(l), l;
    }
    else if (!o || !t && !r)
        throw this.logger.error("TokenCache - if an account is not provided on the request, authority and either clientInfo or idToken must be provided instead."), C(zr); let i = B.generateHomeAccountId(t, o.authorityType, this.logger, this.cryptoObj, r), s = r?.tid, a = Io(this.storage, o, i, Ee, r, t, o.hostnameAndPort, s, void 0, void 0, this.logger); return this.storage.setAccount(a), a; }
    loadIdToken(e, t, r, o) { if (!e.id_token)
        return this.logger.verbose("TokenCache - no id token found in response"), null; this.logger.verbose("TokenCache - loading id token"); let i = K.createIdTokenEntity(t, r, e.id_token, this.config.auth.clientId, o); return this.storage.setIdTokenCredential(i), i; }
    loadAccessToken(e, t, r, o, i, s) { if (t.access_token)
        if (t.expires_in) {
            if (!t.scope && (!e.scopes || !e.scopes.length))
                return this.logger.error("TokenCache - scopes not specified in the request or response. Cannot add token to the cache."), null;
        }
        else
            return this.logger.error("TokenCache - no expiration set on the access token. Cannot add it to the cache."), null;
    else
        return this.logger.verbose("TokenCache - no access token found in response"), null; this.logger.verbose("TokenCache - loading access token"); let a = t.scope ? z.fromString(t.scope) : new z(e.scopes), l = s.expiresOn || t.expires_in + new Date().getTime() / 1e3, h = s.extendedExpiresOn || (t.ext_expires_in || t.expires_in) + new Date().getTime() / 1e3, g = K.createAccessTokenEntity(r, o, t.access_token, this.config.auth.clientId, i, a.printScopes(), l, h, Ee); return this.storage.setAccessTokenCredential(g), g; }
    loadRefreshToken(e, t, r) { if (!e.refresh_token)
        return this.logger.verbose("TokenCache - no refresh token found in response"), null; this.logger.verbose("TokenCache - loading refresh token"); let o = K.createRefreshTokenEntity(t, r, e.refresh_token, this.config.auth.clientId, e.foci, void 0, e.refresh_token_expires_in); return this.storage.setRefreshTokenCredential(o), o; }
    generateAuthenticationResult(e, t, r, o) { let i = "", s = [], a = null, l; t?.accessToken && (i = t.accessToken.secret, s = z.fromString(t.accessToken.target).asArray(), a = new Date(Number(t.accessToken.expiresOn) * 1e3), l = new Date(Number(t.accessToken.extendedExpiresOn) * 1e3)); let h = t.account; return { authority: o ? o.canonicalAuthority : "", uniqueId: t.account.localAccountId, tenantId: t.account.realm, scopes: s, account: h.getAccountInfo(), idToken: t.idToken?.secret || "", idTokenClaims: r || {}, accessToken: i, fromCache: !0, expiresOn: a, correlationId: e.correlationId || "", requestId: "", extExpiresOn: l, familyId: t.refreshToken?.familyId || "", tokenType: t?.accessToken?.tokenType || "", state: e.state || "", cloudGraphHostName: h.cloudGraphHostName || "", msGraphHost: h.msGraphHost || "", fromNativeBroker: !1 }; }
};
var Bi = class extends Rr {
    constructor(e) { super(e), this.includeRedirectUri = !1; }
};
var Fi = class extends ye {
    constructor(e, t, r, o, i, s, a, l, h, g) { super(e, t, r, o, i, s, l, h, g), this.apiId = a; }
    acquireToken(e) { return d(this, null, function* () { if (!e.code)
        throw C($r); let t = yield f(this.initializeAuthorizationRequest.bind(this), c.StandardInteractionClientInitializeAuthorizationRequest, this.logger, this.performanceClient, e.correlationId)(e, E.Silent), r = this.initializeServerTelemetryManager(this.apiId); try {
        let o = I(p({}, t), { code: e.code }), i = yield f(this.getClientConfiguration.bind(this), c.StandardInteractionClientGetClientConfiguration, this.logger, this.performanceClient, e.correlationId)({ serverTelemetryManager: r, requestAuthority: t.authority, requestAzureCloudOptions: t.azureCloudOptions, requestExtraQueryParameters: t.extraQueryParameters, account: t.account }), s = new Bi(i);
        this.logger.verbose("Auth code client created");
        let a = new Vt(s, this.browserStorage, o, this.logger, this.performanceClient);
        return yield f(a.handleCodeResponseFromServer.bind(a), c.HandleCodeResponseFromServer, this.logger, this.performanceClient, e.correlationId)({ code: e.code, msgraph_host: e.msGraphHost, cloud_graph_host_name: e.cloudGraphHostName, cloud_instance_host_name: e.cloudInstanceHostName }, t, !1);
    }
    catch (o) {
        throw o instanceof w && (o.setCorrelationId(this.correlationId), r.cacheFailedRequest(o)), o;
    } }); }
    logout() { return Promise.reject(C(Ke)); }
};
function et(n) { let e = n?.idTokenClaims; if (e?.tfp || e?.acr)
    return "B2C"; if (e?.tid) {
    if (e?.tid === "9188040d-6c67-4c5b-b112-36a304b66dad")
        return "MSA";
}
else
    return; return "AAD"; }
function Ki(n, e) { try {
    _n(n);
}
catch (t) {
    throw e.end({ success: !1 }, t), t;
} }
var ao = class n {
    constructor(e) { this.operatingContext = e, this.isBrowserEnvironment = this.operatingContext.isBrowserEnvironment(), this.config = e.getConfig(), this.initialized = !1, this.logger = this.operatingContext.getLogger(), this.networkClient = this.config.system.networkClient, this.navigationClient = this.config.system.navigationClient, this.redirectResponse = new Map, this.hybridAuthCodeResponses = new Map, this.performanceClient = this.config.telemetry.client, this.browserCrypto = this.isBrowserEnvironment ? new zt(this.logger, this.performanceClient) : _e, this.eventHandler = new so(this.logger), this.browserStorage = this.isBrowserEnvironment ? new Ze(this.config.auth.clientId, this.config.cache, this.browserCrypto, this.logger, dn(this.config.auth), this.performanceClient) : wo(this.config.auth.clientId, this.logger); let t = { cacheLocation: $.MemoryStorage, temporaryCacheLocation: $.MemoryStorage, storeAuthStateInCookie: !1, secureCookies: !1, cacheMigrationEnabled: !1, claimsBasedCachingEnabled: !1 }; this.nativeInternalStorage = new Ze(this.config.auth.clientId, t, this.browserCrypto, this.logger, void 0, this.performanceClient), this.tokenCache = new Hi(this.config, this.browserStorage, this.logger, this.browserCrypto), this.activeSilentTokenRequests = new Map, this.trackPageVisibility = this.trackPageVisibility.bind(this), this.trackPageVisibilityWithMeasurement = this.trackPageVisibilityWithMeasurement.bind(this), this.listeningToStorageEvents = !1, this.handleAccountCacheChange = this.handleAccountCacheChange.bind(this); }
    static createController(e, t) { return d(this, null, function* () { let r = new n(e); return yield r.initialize(t), r; }); }
    trackPageVisibility(e) { e && (this.logger.info("Perf: Visibility change detected"), this.performanceClient.incrementFields({ visibilityChangeCount: 1 }, e)); }
    initialize(e) { return d(this, null, function* () { if (this.logger.trace("initialize called"), this.initialized) {
        this.logger.info("initialize has already been called, exiting early.");
        return;
    } if (!this.isBrowserEnvironment) {
        this.logger.info("in non-browser environment, exiting early."), this.initialized = !0, this.eventHandler.emitEvent(A.INITIALIZE_END);
        return;
    } let t = e?.correlationId || this.getRequestCorrelationId(), r = this.config.system.allowNativeBroker, o = this.performanceClient.startMeasurement(c.InitializeClientApplication, t); if (this.eventHandler.emitEvent(A.INITIALIZE_START), r)
        try {
            this.nativeExtensionProvider = yield ke.createProvider(this.logger, this.config.system.nativeBrokerHandshakeTimeout, this.performanceClient);
        }
        catch (i) {
            this.logger.verbose(i);
        } this.config.cache.claimsBasedCachingEnabled || (this.logger.verbose("Claims-based caching is disabled. Clearing the previous cache with claims"), yield f(this.browserStorage.clearTokensAndKeysWithClaims.bind(this.browserStorage), c.ClearTokensAndKeysWithClaims, this.logger, this.performanceClient, t)(this.performanceClient, t)), this.initialized = !0, this.eventHandler.emitEvent(A.INITIALIZE_END), o.end({ allowNativeBroker: r, success: !0 }); }); }
    handleRedirectPromise(e) { return d(this, null, function* () { if (this.logger.verbose("handleRedirectPromise called"), U(this.initialized), this.isBrowserEnvironment) {
        let t = e || "", r = this.redirectResponse.get(t);
        return typeof r > "u" ? (r = this.handleRedirectPromiseInternal(e), this.redirectResponse.set(t, r), this.logger.verbose("handleRedirectPromise has been called for the first time, storing the promise")) : this.logger.verbose("handleRedirectPromise has been called previously, returning the result from the first call"), r;
    } return this.logger.verbose("handleRedirectPromise returns null, not browser environment"), null; }); }
    handleRedirectPromiseInternal(e) { return d(this, null, function* () { let t = this.getAllAccounts(), r = this.browserStorage.getCachedNativeRequest(), o = r && ke.isNativeAvailable(this.config, this.logger, this.nativeExtensionProvider) && this.nativeExtensionProvider && !e, i = o ? r?.correlationId : this.browserStorage.getTemporaryCache(O.CORRELATION_ID, !0) || "", s = this.performanceClient.startMeasurement(c.AcquireTokenRedirect, i); this.eventHandler.emitEvent(A.HANDLE_REDIRECT_START, E.Redirect); let a; if (o && this.nativeExtensionProvider) {
        this.logger.trace("handleRedirectPromise - acquiring token from native platform");
        let l = new Ne(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, M.handleRedirectPromise, this.performanceClient, this.nativeExtensionProvider, r.accountId, this.nativeInternalStorage, r.correlationId);
        a = f(l.handleRedirectPromise.bind(l), c.HandleNativeRedirectPromiseMeasurement, this.logger, this.performanceClient, s.event.correlationId)(this.performanceClient, s.event.correlationId);
    }
    else {
        this.logger.trace("handleRedirectPromise - acquiring token from web flow");
        let l = this.createRedirectClient(i);
        a = f(l.handleRedirectPromise.bind(l), c.HandleRedirectPromiseMeasurement, this.logger, this.performanceClient, s.event.correlationId)(e, s);
    } return a.then(l => (l ? (t.length < this.getAllAccounts().length ? (this.eventHandler.emitEvent(A.LOGIN_SUCCESS, E.Redirect, l), this.logger.verbose("handleRedirectResponse returned result, login success")) : (this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_SUCCESS, E.Redirect, l), this.logger.verbose("handleRedirectResponse returned result, acquire token success")), s.end({ success: !0, accountType: et(l.account) })) : s.event.errorCode ? s.end({ success: !1 }) : s.discard(), this.eventHandler.emitEvent(A.HANDLE_REDIRECT_END, E.Redirect), l)).catch(l => { let h = l; throw t.length > 0 ? this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_FAILURE, E.Redirect, null, h) : this.eventHandler.emitEvent(A.LOGIN_FAILURE, E.Redirect, null, h), this.eventHandler.emitEvent(A.HANDLE_REDIRECT_END, E.Redirect), s.end({ success: !1 }, h), l; }); }); }
    acquireTokenRedirect(e) { return d(this, null, function* () { let t = this.getRequestCorrelationId(e); this.logger.verbose("acquireTokenRedirect called", t); let r = this.performanceClient.startMeasurement(c.AcquireTokenPreRedirect, t); r.add({ accountType: et(e.account), scenarioId: e.scenarioId }); let o = e.onRedirectNavigate; if (o)
        e.onRedirectNavigate = s => { let a = typeof o == "function" ? o(s) : void 0; return a !== !1 ? r.end({ success: !0 }) : r.discard(), a; };
    else {
        let s = this.config.auth.onRedirectNavigate;
        this.config.auth.onRedirectNavigate = a => { let l = typeof s == "function" ? s(a) : void 0; return l !== !1 ? r.end({ success: !0 }) : r.discard(), l; };
    } let i = this.getAllAccounts().length > 0; try {
        Ei(this.initialized, this.config), this.browserStorage.setInteractionInProgress(!0), i ? this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_START, E.Redirect, e) : this.eventHandler.emitEvent(A.LOGIN_START, E.Redirect, e);
        let s;
        return this.nativeExtensionProvider && this.canUseNative(e) ? s = new Ne(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, M.acquireTokenRedirect, this.performanceClient, this.nativeExtensionProvider, this.getNativeAccountId(e), this.nativeInternalStorage, t).acquireTokenRedirect(e, r).catch(l => { if (l instanceof Pe && $t(l))
            return this.nativeExtensionProvider = void 0, this.createRedirectClient(t).acquireToken(e); if (l instanceof Z)
            return this.logger.verbose("acquireTokenRedirect - Resolving interaction required error thrown by native broker by falling back to web flow"), this.createRedirectClient(t).acquireToken(e); throw this.browserStorage.setInteractionInProgress(!1), l; }) : s = this.createRedirectClient(t).acquireToken(e), yield s;
    }
    catch (s) {
        throw r.end({ success: !1 }, s), i ? this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_FAILURE, E.Redirect, null, s) : this.eventHandler.emitEvent(A.LOGIN_FAILURE, E.Redirect, null, s), s;
    } }); }
    acquireTokenPopup(e) { let t = this.getRequestCorrelationId(e), r = this.performanceClient.startMeasurement(c.AcquireTokenPopup, t); r.add({ scenarioId: e.scenarioId, accountType: et(e.account) }); try {
        this.logger.verbose("acquireTokenPopup called", t), Ki(this.initialized, r), this.browserStorage.setInteractionInProgress(!0);
    }
    catch (s) {
        return Promise.reject(s);
    } let o = this.getAllAccounts(); o.length > 0 ? this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_START, E.Popup, e) : this.eventHandler.emitEvent(A.LOGIN_START, E.Popup, e); let i; return this.canUseNative(e) ? i = this.acquireTokenNative(I(p({}, e), { correlationId: t }), M.acquireTokenPopup).then(s => (this.browserStorage.setInteractionInProgress(!1), r.end({ success: !0, isNativeBroker: !0, accountType: et(s.account) }), s)).catch(s => { if (s instanceof Pe && $t(s))
        return this.nativeExtensionProvider = void 0, this.createPopupClient(t).acquireToken(e); if (s instanceof Z)
        return this.logger.verbose("acquireTokenPopup - Resolving interaction required error thrown by native broker by falling back to web flow"), this.createPopupClient(t).acquireToken(e); throw this.browserStorage.setInteractionInProgress(!1), s; }) : i = this.createPopupClient(t).acquireToken(e), i.then(s => (o.length < this.getAllAccounts().length ? this.eventHandler.emitEvent(A.LOGIN_SUCCESS, E.Popup, s) : this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_SUCCESS, E.Popup, s), r.end({ success: !0, accessTokenSize: s.accessToken.length, idTokenSize: s.idToken.length, accountType: et(s.account) }), s)).catch(s => (o.length > 0 ? this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_FAILURE, E.Popup, null, s) : this.eventHandler.emitEvent(A.LOGIN_FAILURE, E.Popup, null, s), r.end({ success: !1 }, s), Promise.reject(s))); }
    trackPageVisibilityWithMeasurement() { let e = this.ssoSilentMeasurement || this.acquireTokenByCodeAsyncMeasurement; e && (this.logger.info("Perf: Visibility change detected in ", e.event.name), e.increment({ visibilityChangeCount: 1 })); }
    ssoSilent(e) { return d(this, null, function* () { let t = this.getRequestCorrelationId(e), r = I(p({}, e), { prompt: e.prompt, correlationId: t }); this.ssoSilentMeasurement = this.performanceClient.startMeasurement(c.SsoSilent, t), this.ssoSilentMeasurement?.add({ scenarioId: e.scenarioId, accountType: et(e.account) }), Ki(this.initialized, this.ssoSilentMeasurement), this.ssoSilentMeasurement?.increment({ visibilityChangeCount: 0 }), document.addEventListener("visibilitychange", this.trackPageVisibilityWithMeasurement), this.logger.verbose("ssoSilent called", t), this.eventHandler.emitEvent(A.SSO_SILENT_START, E.Silent, r); let o; return this.canUseNative(r) ? o = this.acquireTokenNative(r, M.ssoSilent).catch(i => { if (i instanceof Pe && $t(i))
        return this.nativeExtensionProvider = void 0, this.createSilentIframeClient(r.correlationId).acquireToken(r); throw i; }) : o = this.createSilentIframeClient(r.correlationId).acquireToken(r), o.then(i => (this.eventHandler.emitEvent(A.SSO_SILENT_SUCCESS, E.Silent, i), this.ssoSilentMeasurement?.end({ success: !0, isNativeBroker: i.fromNativeBroker, accessTokenSize: i.accessToken.length, idTokenSize: i.idToken.length, accountType: et(i.account) }), i)).catch(i => { throw this.eventHandler.emitEvent(A.SSO_SILENT_FAILURE, E.Silent, null, i), this.ssoSilentMeasurement?.end({ success: !1 }, i), i; }).finally(() => { document.removeEventListener("visibilitychange", this.trackPageVisibilityWithMeasurement); }); }); }
    acquireTokenByCode(e) { return d(this, null, function* () { let t = this.getRequestCorrelationId(e); this.logger.trace("acquireTokenByCode called", t); let r = this.performanceClient.startMeasurement(c.AcquireTokenByCode, t); Ki(this.initialized, r), this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_BY_CODE_START, E.Silent, e), r.add({ scenarioId: e.scenarioId }); try {
        if (e.code && e.nativeAccountId)
            throw C(Qr);
        if (e.code) {
            let o = e.code, i = this.hybridAuthCodeResponses.get(o);
            return i ? (this.logger.verbose("Existing acquireTokenByCode request found", t), r.discard()) : (this.logger.verbose("Initiating new acquireTokenByCode request", t), i = this.acquireTokenByCodeAsync(I(p({}, e), { correlationId: t })).then(s => (this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_BY_CODE_SUCCESS, E.Silent, s), this.hybridAuthCodeResponses.delete(o), r.end({ success: !0, isNativeBroker: s.fromNativeBroker, accessTokenSize: s.accessToken.length, idTokenSize: s.idToken.length, accountType: et(s.account) }), s)).catch(s => { throw this.hybridAuthCodeResponses.delete(o), this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_BY_CODE_FAILURE, E.Silent, null, s), r.end({ success: !1 }, s), s; }), this.hybridAuthCodeResponses.set(o, i)), yield i;
        }
        else if (e.nativeAccountId)
            if (this.canUseNative(e, e.nativeAccountId)) {
                let o = yield this.acquireTokenNative(I(p({}, e), { correlationId: t }), M.acquireTokenByCode, e.nativeAccountId).catch(i => { throw i instanceof Pe && $t(i) && (this.nativeExtensionProvider = void 0), i; });
                return r.end({ accountType: et(o.account), success: !0 }), o;
            }
            else
                throw C(Yr);
        else
            throw C(Vr);
    }
    catch (o) {
        throw this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_BY_CODE_FAILURE, E.Silent, null, o), r.end({ success: !1 }, o), o;
    } }); }
    acquireTokenByCodeAsync(e) { return d(this, null, function* () { return this.logger.trace("acquireTokenByCodeAsync called", e.correlationId), this.acquireTokenByCodeAsyncMeasurement = this.performanceClient.startMeasurement(c.AcquireTokenByCodeAsync, e.correlationId), this.acquireTokenByCodeAsyncMeasurement?.increment({ visibilityChangeCount: 0 }), document.addEventListener("visibilitychange", this.trackPageVisibilityWithMeasurement), yield this.createSilentAuthCodeClient(e.correlationId).acquireToken(e).then(o => (this.acquireTokenByCodeAsyncMeasurement?.end({ success: !0, fromCache: o.fromCache, isNativeBroker: o.fromNativeBroker }), o)).catch(o => { throw this.acquireTokenByCodeAsyncMeasurement?.end({ success: !1 }, o), o; }).finally(() => { document.removeEventListener("visibilitychange", this.trackPageVisibilityWithMeasurement); }); }); }
    acquireTokenFromCache(e, t) { return d(this, null, function* () { switch (this.performanceClient.addQueueMeasurement(c.AcquireTokenFromCache, e.correlationId), t) {
        case ie.Default:
        case ie.AccessToken:
        case ie.AccessTokenAndRefreshToken:
            let r = this.createSilentCacheClient(e.correlationId);
            return f(r.acquireToken.bind(r), c.SilentCacheClientAcquireToken, this.logger, this.performanceClient, e.correlationId)(e);
        default: throw m(F.tokenRefreshRequired);
    } }); }
    acquireTokenByRefreshToken(e, t) { return d(this, null, function* () { switch (this.performanceClient.addQueueMeasurement(c.AcquireTokenByRefreshToken, e.correlationId), t) {
        case ie.Default:
        case ie.AccessTokenAndRefreshToken:
        case ie.RefreshToken:
        case ie.RefreshTokenAndNetwork:
            let r = this.createSilentRefreshClient(e.correlationId);
            return f(r.acquireToken.bind(r), c.SilentRefreshClientAcquireToken, this.logger, this.performanceClient, e.correlationId)(e);
        default: throw m(F.tokenRefreshRequired);
    } }); }
    acquireTokenBySilentIframe(e) { return d(this, null, function* () { this.performanceClient.addQueueMeasurement(c.AcquireTokenBySilentIframe, e.correlationId); let t = this.createSilentIframeClient(e.correlationId); return f(t.acquireToken.bind(t), c.SilentIframeClientAcquireToken, this.logger, this.performanceClient, e.correlationId)(e); }); }
    logout(e) { return d(this, null, function* () { let t = this.getRequestCorrelationId(e); return this.logger.warning("logout API is deprecated and will be removed in msal-browser v3.0.0. Use logoutRedirect instead.", t), this.logoutRedirect(p({ correlationId: t }, e)); }); }
    logoutRedirect(e) { return d(this, null, function* () { let t = this.getRequestCorrelationId(e); return Ei(this.initialized, this.config), this.browserStorage.setInteractionInProgress(!0), this.createRedirectClient(t).logout(e); }); }
    logoutPopup(e) { try {
        let t = this.getRequestCorrelationId(e);
        return _n(this.initialized), this.browserStorage.setInteractionInProgress(!0), this.createPopupClient(t).logout(e);
    }
    catch (t) {
        return Promise.reject(t);
    } }
    clearCache(e) { return d(this, null, function* () { if (!this.isBrowserEnvironment) {
        this.logger.info("in non-browser environment, returning early.");
        return;
    } let t = this.getRequestCorrelationId(e); return this.createSilentCacheClient(t).logout(e); }); }
    getAllAccounts(e) { return ki(this.logger, this.browserStorage, this.isBrowserEnvironment, e); }
    getAccount(e) { return Ro(e, this.logger, this.browserStorage); }
    getAccountByUsername(e) { return _i(e, this.logger, this.browserStorage); }
    getAccountByHomeId(e) { return bi(e, this.logger, this.browserStorage); }
    getAccountByLocalId(e) { return Pi(e, this.logger, this.browserStorage); }
    setActiveAccount(e) { Mn(e, this.browserStorage); }
    getActiveAccount() { return Ni(this.browserStorage); }
    hydrateCache(e, t) { return d(this, null, function* () { this.logger.verbose("hydrateCache called"); let r = B.createFromAccountInfo(e.account, e.cloudGraphHostName, e.msGraphHost); return this.browserStorage.setAccount(r), e.fromNativeBroker ? (this.logger.verbose("Response was from native broker, storing in-memory"), this.nativeInternalStorage.hydrateCache(e, t)) : this.browserStorage.hydrateCache(e, t); }); }
    acquireTokenNative(e, t, r) { return d(this, null, function* () { if (this.logger.trace("acquireTokenNative called"), !this.nativeExtensionProvider)
        throw C(Re); return new Ne(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, t, this.performanceClient, this.nativeExtensionProvider, r || this.getNativeAccountId(e), this.nativeInternalStorage, e.correlationId).acquireToken(e); }); }
    canUseNative(e, t) { if (this.logger.trace("canUseNative called"), !ke.isNativeAvailable(this.config, this.logger, this.nativeExtensionProvider, e.authenticationScheme))
        return this.logger.trace("canUseNative: isNativeAvailable returned false, returning false"), !1; if (e.prompt)
        switch (e.prompt) {
            case G.NONE:
            case G.CONSENT:
            case G.LOGIN:
                this.logger.trace("canUseNative: prompt is compatible with native flow");
                break;
            default: return this.logger.trace(`canUseNative: prompt = ${e.prompt} is not compatible with native flow, returning false`), !1;
        } return !t && !this.getNativeAccountId(e) ? (this.logger.trace("canUseNative: nativeAccountId is not available, returning false"), !1) : !0; }
    getNativeAccountId(e) { let t = e.account || this.getAccount({ loginHint: e.loginHint, sid: e.sid }) || this.getActiveAccount(); return t && t.nativeAccountId || ""; }
    createPopupClient(e) { return new Ui(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, this.performanceClient, this.nativeInternalStorage, this.nativeExtensionProvider, e); }
    createRedirectClient(e) { return new Li(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, this.performanceClient, this.nativeInternalStorage, this.nativeExtensionProvider, e); }
    createSilentIframeClient(e) { return new Di(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, M.ssoSilent, this.performanceClient, this.nativeInternalStorage, this.nativeExtensionProvider, e); }
    createSilentCacheClient(e) { return new _o(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, this.performanceClient, this.nativeExtensionProvider, e); }
    createSilentRefreshClient(e) { return new xi(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, this.performanceClient, this.nativeExtensionProvider, e); }
    createSilentAuthCodeClient(e) { return new Fi(this.config, this.browserStorage, this.browserCrypto, this.logger, this.eventHandler, this.navigationClient, M.acquireTokenByCode, this.performanceClient, this.nativeExtensionProvider, e); }
    addEventCallback(e, t) { return this.eventHandler.addEventCallback(e, t); }
    removeEventCallback(e) { this.eventHandler.removeEventCallback(e); }
    addPerformanceCallback(e) { return D(), this.performanceClient.addPerformanceCallback(e); }
    removePerformanceCallback(e) { return this.performanceClient.removePerformanceCallback(e); }
    enableAccountStorageEvents() { typeof window > "u" || (this.listeningToStorageEvents ? this.logger.verbose("Account storage listener already registered.") : (this.logger.verbose("Adding account storage listener."), this.listeningToStorageEvents = !0, window.addEventListener("storage", this.handleAccountCacheChange))); }
    disableAccountStorageEvents() { typeof window > "u" || (this.listeningToStorageEvents ? (this.logger.verbose("Removing account storage listener."), window.removeEventListener("storage", this.handleAccountCacheChange), this.listeningToStorageEvents = !1) : this.logger.verbose("No account storage listener registered.")); }
    handleAccountCacheChange(e) { try {
        e.key?.includes(X.ACTIVE_ACCOUNT_FILTERS) && this.eventHandler.emitEvent(A.ACTIVE_ACCOUNT_CHANGED);
        let t = e.newValue || e.oldValue;
        if (!t)
            return;
        let r = JSON.parse(t);
        if (typeof r != "object" || !B.isAccountEntity(r))
            return;
        let i = dt.toObject(new B, r).getAccountInfo();
        !e.oldValue && e.newValue ? (this.logger.info("Account was added to cache in a different window"), this.eventHandler.emitEvent(A.ACCOUNT_ADDED, void 0, i)) : !e.newValue && e.oldValue && (this.logger.info("Account was removed from cache in a different window"), this.eventHandler.emitEvent(A.ACCOUNT_REMOVED, void 0, i));
    }
    catch {
        return;
    } }
    getTokenCache() { return this.tokenCache; }
    getLogger() { return this.logger; }
    setLogger(e) { this.logger = e; }
    initializeWrapperLibrary(e, t) { this.browserStorage.setWrapperMetadata(e, t); }
    setNavigationClient(e) { this.navigationClient = e; }
    getConfiguration() { return this.config; }
    getPerformanceClient() { return this.performanceClient; }
    isBrowserEnv() { return this.isBrowserEnvironment; }
    getRequestCorrelationId(e) { return e?.correlationId ? e.correlationId : this.isBrowserEnvironment ? ee() : u.EMPTY_STRING; }
    loginRedirect(e) { return d(this, null, function* () { let t = this.getRequestCorrelationId(e); return this.logger.verbose("loginRedirect called", t), this.acquireTokenRedirect(p({ correlationId: t }, e || vn)); }); }
    loginPopup(e) { let t = this.getRequestCorrelationId(e); return this.logger.verbose("loginPopup called", t), this.acquireTokenPopup(p({ correlationId: t }, e || vn)); }
    acquireTokenSilent(e) { return d(this, null, function* () { let t = this.getRequestCorrelationId(e), r = this.performanceClient.startMeasurement(c.AcquireTokenSilent, t); r.add({ cacheLookupPolicy: e.cacheLookupPolicy, scenarioId: e.scenarioId }), Ki(this.initialized, r), this.logger.verbose("acquireTokenSilent called", t); let o = e.account || this.getActiveAccount(); if (!o)
        throw C(Br); r.add({ accountType: et(o) }); let i = { clientId: this.config.auth.clientId, authority: e.authority || u.EMPTY_STRING, scopes: e.scopes, homeAccountIdentifier: o.homeAccountId, claims: e.claims, authenticationScheme: e.authenticationScheme, resourceRequestMethod: e.resourceRequestMethod, resourceRequestUri: e.resourceRequestUri, shrClaims: e.shrClaims, sshKid: e.sshKid, shrOptions: e.shrOptions }, s = JSON.stringify(i), a = this.activeSilentTokenRequests.get(s); if (typeof a > "u") {
        this.logger.verbose("acquireTokenSilent called for the first time, storing active request", t);
        let l = f(this.acquireTokenSilentAsync.bind(this), c.AcquireTokenSilentAsync, this.logger, this.performanceClient, t)(I(p({}, e), { correlationId: t }), o).then(h => (this.activeSilentTokenRequests.delete(s), r.end({ success: !0, fromCache: h.fromCache, isNativeBroker: h.fromNativeBroker, cacheLookupPolicy: e.cacheLookupPolicy, accessTokenSize: h.accessToken.length, idTokenSize: h.idToken.length }), h)).catch(h => { throw this.activeSilentTokenRequests.delete(s), r.end({ success: !1 }, h), h; });
        return this.activeSilentTokenRequests.set(s, l), I(p({}, yield l), { state: e.state });
    }
    else
        return this.logger.verbose("acquireTokenSilent has been called previously, returning the result from the first call", t), r.discard(), I(p({}, yield a), { state: e.state }); }); }
    acquireTokenSilentAsync(e, t) { return d(this, null, function* () { let r = () => this.trackPageVisibility(e.correlationId); this.performanceClient.addQueueMeasurement(c.AcquireTokenSilentAsync, e.correlationId), this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_START, E.Silent, e), e.correlationId && this.performanceClient.incrementFields({ visibilityChangeCount: 0 }, e.correlationId), document.addEventListener("visibilitychange", r); let o = yield f(ic, c.InitializeSilentRequest, this.logger, this.performanceClient, e.correlationId)(e, t, this.config, this.performanceClient, this.logger), i = e.cacheLookupPolicy || ie.Default; return this.acquireTokenSilentNoIframe(o, i).catch(a => d(this, null, function* () { if (xl(a, i))
        if (this.activeIframeRequest)
            if (i !== ie.Skip) {
                let [h, g] = this.activeIframeRequest;
                this.logger.verbose(`Iframe request is already in progress, awaiting resolution for request with correlationId: ${g}`, o.correlationId);
                let T = this.performanceClient.startMeasurement(c.AwaitConcurrentIframe, o.correlationId);
                T.add({ awaitIframeCorrelationId: g });
                let y = yield h;
                if (T.end({ success: y }), y)
                    return this.logger.verbose(`Parallel iframe request with correlationId: ${g} succeeded. Retrying cache and/or RT redemption`, o.correlationId), this.acquireTokenSilentNoIframe(o, i);
                throw this.logger.info(`Iframe request with correlationId: ${g} failed. Interaction is required.`), a;
            }
            else
                return this.logger.warning("Another iframe request is currently in progress and CacheLookupPolicy is set to Skip. This may result in degraded performance and/or reliability for both calls. Please consider changing the CacheLookupPolicy to take advantage of request queuing and token cache.", o.correlationId), f(this.acquireTokenBySilentIframe.bind(this), c.AcquireTokenBySilentIframe, this.logger, this.performanceClient, o.correlationId)(o);
        else {
            let h;
            return this.activeIframeRequest = [new Promise(g => { h = g; }), o.correlationId], this.logger.verbose("Refresh token expired/invalid or CacheLookupPolicy is set to Skip, attempting acquire token by iframe.", o.correlationId), f(this.acquireTokenBySilentIframe.bind(this), c.AcquireTokenBySilentIframe, this.logger, this.performanceClient, o.correlationId)(o).then(g => (h(!0), g)).catch(g => { throw h(!1), g; }).finally(() => { this.activeIframeRequest = void 0; });
        }
    else
        throw a; })).then(a => (this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_SUCCESS, E.Silent, a), e.correlationId && this.performanceClient.addFields({ fromCache: a.fromCache, isNativeBroker: a.fromNativeBroker }, e.correlationId), a)).catch(a => { throw this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_FAILURE, E.Silent, null, a), a; }).finally(() => { document.removeEventListener("visibilitychange", r); }); }); }
    acquireTokenSilentNoIframe(e, t) { return d(this, null, function* () { return ke.isNativeAvailable(this.config, this.logger, this.nativeExtensionProvider, e.authenticationScheme) && e.account.nativeAccountId ? (this.logger.verbose("acquireTokenSilent - attempting to acquire token from native platform"), this.acquireTokenNative(e, M.acquireTokenSilent_silentFlow).catch(r => d(this, null, function* () { throw r instanceof Pe && $t(r) ? (this.logger.verbose("acquireTokenSilent - native platform unavailable, falling back to web flow"), this.nativeExtensionProvider = void 0, m(F.tokenRefreshRequired)) : r; }))) : (this.logger.verbose("acquireTokenSilent - attempting to acquire token from web flow"), f(this.acquireTokenFromCache.bind(this), c.AcquireTokenFromCache, this.logger, this.performanceClient, e.correlationId)(e, t).catch(r => { if (t === ie.AccessToken)
        throw r; return this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_NETWORK_START, E.Silent, e), f(this.acquireTokenByRefreshToken.bind(this), c.AcquireTokenByRefreshToken, this.logger, this.performanceClient, e.correlationId)(e, t); })); }); }
};
function xl(n, e) { let t = !(n instanceof Z && n.subError !== mt.badToken), r = n.errorCode === W.INVALID_GRANT_ERROR || n.errorCode === F.tokenRefreshRequired, o = t && r || n.errorCode === mt.noTokensFound || n.errorCode === mt.refreshTokenExpired, i = Ua.includes(e); return o && i; }
function Cc(n) { return n.status !== void 0; }
var qi = class {
    constructor(e, t, r, o) { this.clientId = e, this.clientCapabilities = t, this.crypto = r, this.logger = o; }
    toNaaTokenRequest(e) { let t; e.extraQueryParameters === void 0 ? t = new Map : t = new Map(Object.entries(e.extraQueryParameters)); let r = e.correlationId || this.crypto.createNewGuid(), i = new we(r).addClientCapabilitiesToClaims(e.claims, this.clientCapabilities), s = e.scopes || ce; return { platformBrokerId: e.account?.homeAccountId, clientId: this.clientId, authority: e.authority, scope: s.join(" "), correlationId: r, claims: Q.isEmptyObj(i) ? void 0 : i, state: e.state, authenticationScheme: e.authenticationScheme || b.BEARER, extraParameters: t }; }
    fromNaaTokenResponse(e, t, r) { if (!t.token.id_token || !t.token.access_token)
        throw m(F.nullOrEmptyToken); let o = new Date((r + (t.token.expires_in || 0)) * 1e3), i = xe.extractTokenClaims(t.token.id_token, this.crypto.base64Decode), s = this.fromNaaAccountInfo(t.account, t.token.id_token, i), a = t.token.scope || e.scope; return { authority: t.token.authority || s.environment, uniqueId: s.localAccountId, tenantId: s.tenantId, scopes: a.split(" "), account: s, idToken: t.token.id_token, idTokenClaims: i, accessToken: t.token.access_token, fromCache: !1, expiresOn: o, tokenType: e.authenticationScheme || b.BEARER, correlationId: e.correlationId, extExpiresOn: o, state: e.state }; }
    fromNaaAccountInfo(e, t, r) { let o = r || e.idTokenClaims, i = e.localAccountId || o?.oid || o?.sub || "", s = e.tenantId || o?.tid || "", a = e.homeAccountId || `${i}.${s}`, l = e.username || o?.preferred_username || "", h = e.name || o?.name, g = new Map, T = Nt(a, i, s, o); return g.set(s, T), { homeAccountId: a, environment: e.environment, tenantId: s, username: l, localAccountId: i, name: h, idToken: t, idTokenClaims: o, tenantProfiles: g }; }
    fromBridgeError(e) { if (Cc(e))
        switch (e.status) {
            case $e.UserCancel: return new Se(F.userCanceled);
            case $e.NoNetwork: return new Se(F.noNetworkConnectivity);
            case $e.AccountUnavailable: return new Se(F.noAccountFound);
            case $e.Disabled: return new Se(F.nestedAppAuthBridgeDisabled);
            case $e.NestedAppAuthUnavailable: return new Se(e.code || F.nestedAppAuthBridgeDisabled, e.description);
            case $e.TransientError:
            case $e.PersistentError: return new oe(e.code, e.description);
            case $e.UserInteractionRequired: return new Z(e.code, e.description);
            default: return new w(e.code, e.description);
        }
    else
        return new w("unknown_error", "An unknown error occurred"); }
    toAuthenticationResultFromCache(e, t, r, o, i) { if (!t || !r)
        throw m(F.nullOrEmptyToken); let s = xe.extractTokenClaims(t.secret, this.crypto.base64Decode), a = r.target || o.scopes.join(" "); return { authority: r.environment || e.environment, uniqueId: e.localAccountId, tenantId: e.tenantId, scopes: a.split(" "), account: e, idToken: t.secret, idTokenClaims: s || {}, accessToken: r.secret, fromCache: !0, expiresOn: new Date(Number(r.expiresOn) * 1e3), tokenType: o.authenticationScheme || b.BEARER, correlationId: i, extExpiresOn: new Date(Number(r.extendedExpiresOn) * 1e3), state: o.state }; }
};
var Tc = { unsupportedMethod: { code: "unsupported_method", desc: "This method is not supported in nested app environment." } }, se = class n extends w {
    constructor(e, t) { super(e, t), Object.setPrototypeOf(this, n.prototype), this.name = "NestedAppAuthError"; }
    static createUnsupportedError() { return new n(Tc.unsupportedMethod.code, Tc.unsupportedMethod.desc); }
};
var bo = class n {
    constructor(e) { this.operatingContext = e; let t = this.operatingContext.getBridgeProxy(); if (t !== void 0)
        this.bridgeProxy = t;
    else
        throw new Error("unexpected: bridgeProxy is undefined"); this.config = e.getConfig(), this.logger = this.operatingContext.getLogger(), this.performanceClient = this.config.telemetry.client, this.browserCrypto = e.isBrowserEnvironment() ? new zt(this.logger, this.performanceClient, !0) : _e, this.browserStorage = this.operatingContext.isBrowserEnvironment() ? new Ze(this.config.auth.clientId, this.config.cache, this.browserCrypto, this.logger, dn(this.config.auth)) : wo(this.config.auth.clientId, this.logger), this.eventHandler = new so(this.logger), this.nestedAppAuthAdapter = new qi(this.config.auth.clientId, this.config.auth.clientCapabilities, this.browserCrypto, this.logger); let r = this.bridgeProxy.getAccountContext(); if (r) {
        let o = Ro(r, this.logger, this.browserStorage);
        Mn(o, this.browserStorage);
    } }
    static createController(e) { return d(this, null, function* () { let t = new n(e); return Promise.resolve(t); }); }
    initialize() { return Promise.resolve(); }
    ensureValidRequest(e) { return e?.correlationId ? e : I(p({}, e), { correlationId: this.browserCrypto.createNewGuid() }); }
    acquireTokenInteractive(e) { return d(this, null, function* () { let t = this.ensureValidRequest(e); this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_START, E.Popup, t); let r = this.performanceClient.startMeasurement(c.AcquireTokenPopup, t.correlationId); r?.add({ nestedAppAuthRequest: !0 }); try {
        let o = this.nestedAppAuthAdapter.toNaaTokenRequest(t), i = Qe.nowSeconds(), s = yield this.bridgeProxy.getTokenInteractive(o), a = p({}, this.nestedAppAuthAdapter.fromNaaTokenResponse(o, s, i));
        return yield this.hydrateCache(a, e), this.browserStorage.setActiveAccount(a.account), this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_SUCCESS, E.Popup, a), r.add({ accessTokenSize: a.accessToken.length, idTokenSize: a.idToken.length }), r.end({ success: !0, requestId: a.requestId }), a;
    }
    catch (o) {
        let i = this.nestedAppAuthAdapter.fromBridgeError(o);
        throw this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_FAILURE, E.Popup, null, o), r.end({ success: !1 }, o), i;
    } }); }
    acquireTokenSilentInternal(e) { return d(this, null, function* () { let t = this.ensureValidRequest(e); this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_START, E.Silent, t); let r = yield this.acquireTokenFromCache(t); if (r)
        return this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_SUCCESS, E.Silent, r), r; let o = this.performanceClient.startMeasurement(c.SsoSilent, t.correlationId); o?.increment({ visibilityChangeCount: 0 }), o?.add({ nestedAppAuthRequest: !0 }); try {
        let i = this.nestedAppAuthAdapter.toNaaTokenRequest(t), s = Qe.nowSeconds(), a = yield this.bridgeProxy.getTokenSilent(i), l = this.nestedAppAuthAdapter.fromNaaTokenResponse(i, a, s);
        return yield this.hydrateCache(l, e), this.browserStorage.setActiveAccount(l.account), this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_SUCCESS, E.Silent, l), o?.add({ accessTokenSize: l.accessToken.length, idTokenSize: l.idToken.length }), o?.end({ success: !0, requestId: l.requestId }), l;
    }
    catch (i) {
        let s = this.nestedAppAuthAdapter.fromBridgeError(i);
        throw this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_FAILURE, E.Silent, null, i), o?.end({ success: !1 }, i), s;
    } }); }
    acquireTokenFromCache(e) { return d(this, null, function* () { let t = this.performanceClient.startMeasurement(c.AcquireTokenSilent, e.correlationId); if (t?.add({ nestedAppAuthRequest: !0 }), e.claims)
        return this.logger.verbose("Claims are present in the request, skipping cache lookup"), null; let r = null; switch (e.cacheLookupPolicy) {
        case ie.Default:
        case ie.AccessToken:
        case ie.AccessTokenAndRefreshToken:
            r = yield this.acquireTokenFromCacheInternal(e);
            break;
        default: return null;
    } return r ? (this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_SUCCESS, E.Silent, r), t?.add({ accessTokenSize: r?.accessToken.length, idTokenSize: r?.idToken.length }), t?.end({ success: !0 }), r) : (this.logger.error("Cached tokens are not found for the account, proceeding with silent token request."), this.eventHandler.emitEvent(A.ACQUIRE_TOKEN_FAILURE, E.Silent, null), t?.end({ success: !1 }), null); }); }
    acquireTokenFromCacheInternal(e) { return d(this, null, function* () { let t = this.bridgeProxy.getAccountContext(), r = null; if (t && (r = Ro(t, this.logger, this.browserStorage) || e.account), !r)
        return this.logger.verbose("No active account found, falling back to the host"), Promise.resolve(null); this.logger.verbose("active account found, attempting to acquire token silently"); let o = I(p({}, e), { correlationId: e.correlationId || this.browserCrypto.createNewGuid(), authority: e.authority || r.environment, scopes: e.scopes?.length ? e.scopes : [...ce] }), i = this.browserStorage.getTokenKeys(), s = this.browserStorage.getAccessToken(r, o, i, r.tenantId, this.performanceClient, o.correlationId); if (s) {
        if (Qe.wasClockTurnedBack(s.cachedAt) || Qe.isTokenExpired(s.expiresOn, this.config.system.tokenRenewalOffsetSeconds))
            return this.logger.verbose("Cached access token has expired"), Promise.resolve(null);
    }
    else
        return this.logger.verbose("No cached access token found"), Promise.resolve(null); let a = this.browserStorage.getIdToken(r, i, r.tenantId, this.performanceClient, o.correlationId); return a ? this.nestedAppAuthAdapter.toAuthenticationResultFromCache(r, a, s, o, o.correlationId) : (this.logger.verbose("No cached id token found"), Promise.resolve(null)); }); }
    acquireTokenPopup(e) { return d(this, null, function* () { return this.acquireTokenInteractive(e); }); }
    acquireTokenRedirect(e) { throw se.createUnsupportedError(); }
    acquireTokenSilent(e) { return d(this, null, function* () { return this.acquireTokenSilentInternal(e); }); }
    acquireTokenByCode(e) { throw se.createUnsupportedError(); }
    acquireTokenNative(e, t, r) { throw se.createUnsupportedError(); }
    acquireTokenByRefreshToken(e, t) { throw se.createUnsupportedError(); }
    addEventCallback(e, t) { return this.eventHandler.addEventCallback(e, t); }
    removeEventCallback(e) { this.eventHandler.removeEventCallback(e); }
    addPerformanceCallback(e) { throw se.createUnsupportedError(); }
    removePerformanceCallback(e) { throw se.createUnsupportedError(); }
    enableAccountStorageEvents() { throw se.createUnsupportedError(); }
    disableAccountStorageEvents() { throw se.createUnsupportedError(); }
    getAllAccounts(e) { return ki(this.logger, this.browserStorage, this.isBrowserEnv(), e); }
    getAccount(e) { return Ro(e, this.logger, this.browserStorage); }
    getAccountByUsername(e) { return _i(e, this.logger, this.browserStorage); }
    getAccountByHomeId(e) { return bi(e, this.logger, this.browserStorage); }
    getAccountByLocalId(e) { return Pi(e, this.logger, this.browserStorage); }
    setActiveAccount(e) { return Mn(e, this.browserStorage); }
    getActiveAccount() { return Ni(this.browserStorage); }
    handleRedirectPromise(e) { return Promise.resolve(null); }
    loginPopup(e) { return this.acquireTokenInteractive(e || vn); }
    loginRedirect(e) { throw se.createUnsupportedError(); }
    logout(e) { throw se.createUnsupportedError(); }
    logoutRedirect(e) { throw se.createUnsupportedError(); }
    logoutPopup(e) { throw se.createUnsupportedError(); }
    ssoSilent(e) { return this.acquireTokenSilentInternal(e); }
    getTokenCache() { throw se.createUnsupportedError(); }
    getLogger() { return this.logger; }
    setLogger(e) { this.logger = e; }
    initializeWrapperLibrary(e, t) { }
    setNavigationClient(e) { this.logger.warning("setNavigationClient is not supported in nested app auth"); }
    getConfiguration() { return this.config; }
    isBrowserEnv() { return this.operatingContext.isBrowserEnvironment(); }
    getBrowserCrypto() { return this.browserCrypto; }
    getPerformanceClient() { throw se.createUnsupportedError(); }
    getRedirectResponse() { throw se.createUnsupportedError(); }
    clearCache(e) { return d(this, null, function* () { throw se.createUnsupportedError(); }); }
    hydrateCache(e, t) { return d(this, null, function* () { this.logger.verbose("hydrateCache called"); let r = B.createFromAccountInfo(e.account, e.cloudGraphHostName, e.msGraphHost); return this.browserStorage.setAccount(r), this.browserStorage.hydrateCache(e, t); }); }
};
function Ac(n, e) { return d(this, null, function* () { let t = new On(n); return yield t.initialize(), ao.createController(t, e); }); }
function na(n) { return d(this, null, function* () { let e = new On(n), t = new Ii(n), r = [e.initialize(), t.initialize()]; return yield Promise.all(r), t.isAvailable() && n.auth.supportsNestedAppAuth ? bo.createController(t) : e.isAvailable() ? ao.createController(e) : null; }); }
var xn = class n {
    static createPublicClientApplication(e) { return d(this, null, function* () { let t = yield Ac(e); return new n(e, t); }); }
    constructor(e, t) { this.controller = t || new ao(new On(e)); }
    initialize(e) { return d(this, null, function* () { return this.controller.initialize(e); }); }
    acquireTokenPopup(e) { return d(this, null, function* () { return this.controller.acquireTokenPopup(e); }); }
    acquireTokenRedirect(e) { return this.controller.acquireTokenRedirect(e); }
    acquireTokenSilent(e) { return this.controller.acquireTokenSilent(e); }
    acquireTokenByCode(e) { return this.controller.acquireTokenByCode(e); }
    addEventCallback(e, t) { return this.controller.addEventCallback(e, t); }
    removeEventCallback(e) { return this.controller.removeEventCallback(e); }
    addPerformanceCallback(e) { return this.controller.addPerformanceCallback(e); }
    removePerformanceCallback(e) { return this.controller.removePerformanceCallback(e); }
    enableAccountStorageEvents() { this.controller.enableAccountStorageEvents(); }
    disableAccountStorageEvents() { this.controller.disableAccountStorageEvents(); }
    getAccount(e) { return this.controller.getAccount(e); }
    getAccountByHomeId(e) { return this.controller.getAccountByHomeId(e); }
    getAccountByLocalId(e) { return this.controller.getAccountByLocalId(e); }
    getAccountByUsername(e) { return this.controller.getAccountByUsername(e); }
    getAllAccounts(e) { return this.controller.getAllAccounts(e); }
    handleRedirectPromise(e) { return this.controller.handleRedirectPromise(e); }
    loginPopup(e) { return this.controller.loginPopup(e); }
    loginRedirect(e) { return this.controller.loginRedirect(e); }
    logout(e) { return this.controller.logout(e); }
    logoutRedirect(e) { return this.controller.logoutRedirect(e); }
    logoutPopup(e) { return this.controller.logoutPopup(e); }
    ssoSilent(e) { return this.controller.ssoSilent(e); }
    getTokenCache() { return this.controller.getTokenCache(); }
    getLogger() { return this.controller.getLogger(); }
    setLogger(e) { this.controller.setLogger(e); }
    setActiveAccount(e) { this.controller.setActiveAccount(e); }
    getActiveAccount() { return this.controller.getActiveAccount(); }
    initializeWrapperLibrary(e, t) { return this.controller.initializeWrapperLibrary(e, t); }
    setNavigationClient(e) { this.controller.setNavigationClient(e); }
    getConfiguration() { return this.controller.getConfiguration(); }
    hydrateCache(e, t) { return d(this, null, function* () { return this.controller.hydrateCache(e, t); }); }
    clearCache(e) { return this.controller.clearCache(e); }
};
function Hl(n) { return d(this, null, function* () { let e = new Ii(n); if (yield e.initialize(), e.isAvailable()) {
    let t = new bo(e);
    return new xn(n, t);
} return Ec(n); }); }
function Ec(n) { return d(this, null, function* () { let e = new xn(n); return yield e.initialize(), e; }); }
var Hn = class {
    constructor(e) { this.initialized = !1, this.operatingContext = e, this.isBrowserEnvironment = this.operatingContext.isBrowserEnvironment(), this.config = e.getConfig(), this.logger = e.getLogger(), this.performanceClient = this.config.telemetry.client, this.browserCrypto = this.isBrowserEnvironment ? new zt(this.logger, this.performanceClient) : _e, this.browserStorage = this.isBrowserEnvironment ? new Ze(this.config.auth.clientId, this.config.cache, this.browserCrypto, this.logger, void 0, this.performanceClient) : wo(this.config.auth.clientId, this.logger); }
    getBrowserStorage() { return this.browserStorage; }
    getAccount(e) { return null; }
    getAccountByHomeId(e) { return null; }
    getAccountByLocalId(e) { return null; }
    getAccountByUsername(e) { return null; }
    getAllAccounts() { return []; }
    initialize() { return this.initialized = !0, Promise.resolve(); }
    acquireTokenPopup(e) { return U(this.initialized), D(), {}; }
    acquireTokenRedirect(e) { return U(this.initialized), D(), Promise.resolve(); }
    acquireTokenSilent(e) { return U(this.initialized), D(), {}; }
    acquireTokenByCode(e) { return U(this.initialized), D(), {}; }
    acquireTokenNative(e, t, r) { return U(this.initialized), D(), {}; }
    acquireTokenByRefreshToken(e, t) { return U(this.initialized), D(), {}; }
    addEventCallback(e, t) { return null; }
    removeEventCallback(e) { }
    addPerformanceCallback(e) { return U(this.initialized), D(), ""; }
    removePerformanceCallback(e) { return U(this.initialized), D(), !0; }
    enableAccountStorageEvents() { U(this.initialized), D(); }
    disableAccountStorageEvents() { U(this.initialized), D(); }
    handleRedirectPromise(e) { return U(this.initialized), Promise.resolve(null); }
    loginPopup(e) { return U(this.initialized), D(), {}; }
    loginRedirect(e) { return U(this.initialized), D(), {}; }
    logout(e) { return U(this.initialized), D(), {}; }
    logoutRedirect(e) { return U(this.initialized), D(), {}; }
    logoutPopup(e) { return U(this.initialized), D(), {}; }
    ssoSilent(e) { return U(this.initialized), D(), {}; }
    getTokenCache() { return U(this.initialized), D(), {}; }
    getLogger() { return this.logger; }
    setLogger(e) { U(this.initialized), D(); }
    setActiveAccount(e) { U(this.initialized), D(); }
    getActiveAccount() { return U(this.initialized), D(), null; }
    initializeWrapperLibrary(e, t) { this.browserStorage.setWrapperMetadata(e, t); }
    setNavigationClient(e) { U(this.initialized), D(); }
    getConfiguration() { return this.config; }
    isBrowserEnv() { return U(this.initialized), D(), !0; }
    getBrowserCrypto() { return U(this.initialized), D(), {}; }
    getPerformanceClient() { return U(this.initialized), D(), {}; }
    getRedirectResponse() { return U(this.initialized), D(), {}; }
    clearCache(e) { return d(this, null, function* () { U(this.initialized), D(); }); }
    hydrateCache(e, t) { return d(this, null, function* () { U(this.initialized), D(); }); }
};
var yc = (() => { class n extends qt {
    getId() { return n.ID; }
    getModuleName() { return n.MODULE_NAME; }
    initialize() { return d(this, null, function* () { return !0; }); }
} return n.MODULE_NAME = "", n.ID = "UnknownOperatingContext", n; })();
var ia = class n {
    static createPublicClientApplication(e) { return d(this, null, function* () { let t = yield na(e), r; return t !== null ? r = new n(e, t) : r = new n(e), r; }); }
    constructor(e, t) { if (this.configuration = e, t)
        this.controller = t;
    else {
        let r = new yc(e);
        this.controller = new Hn(r);
    } }
    initialize() { return d(this, null, function* () { if (this.controller instanceof Hn) {
        let e = yield na(this.configuration);
        return e !== null && (this.controller = e), this.controller.initialize();
    } return Promise.resolve(); }); }
    acquireTokenPopup(e) { return d(this, null, function* () { return this.controller.acquireTokenPopup(e); }); }
    acquireTokenRedirect(e) { return this.controller.acquireTokenRedirect(e); }
    acquireTokenSilent(e) { return this.controller.acquireTokenSilent(e); }
    acquireTokenByCode(e) { return this.controller.acquireTokenByCode(e); }
    addEventCallback(e, t) { return this.controller.addEventCallback(e, t); }
    removeEventCallback(e) { return this.controller.removeEventCallback(e); }
    addPerformanceCallback(e) { return this.controller.addPerformanceCallback(e); }
    removePerformanceCallback(e) { return this.controller.removePerformanceCallback(e); }
    enableAccountStorageEvents() { this.controller.enableAccountStorageEvents(); }
    disableAccountStorageEvents() { this.controller.disableAccountStorageEvents(); }
    getAccount(e) { return this.controller.getAccount(e); }
    getAccountByHomeId(e) { return this.controller.getAccountByHomeId(e); }
    getAccountByLocalId(e) { return this.controller.getAccountByLocalId(e); }
    getAccountByUsername(e) { return this.controller.getAccountByUsername(e); }
    getAllAccounts(e) { return this.controller.getAllAccounts(e); }
    handleRedirectPromise(e) { return this.controller.handleRedirectPromise(e); }
    loginPopup(e) { return this.controller.loginPopup(e); }
    loginRedirect(e) { return this.controller.loginRedirect(e); }
    logout(e) { return this.controller.logout(e); }
    logoutRedirect(e) { return this.controller.logoutRedirect(e); }
    logoutPopup(e) { return this.controller.logoutPopup(e); }
    ssoSilent(e) { return this.controller.ssoSilent(e); }
    getTokenCache() { return this.controller.getTokenCache(); }
    getLogger() { return this.controller.getLogger(); }
    setLogger(e) { this.controller.setLogger(e); }
    setActiveAccount(e) { this.controller.setActiveAccount(e); }
    getActiveAccount() { return this.controller.getActiveAccount(); }
    initializeWrapperLibrary(e, t) { return this.controller.initializeWrapperLibrary(e, t); }
    setNavigationClient(e) { this.controller.setNavigationClient(e); }
    getConfiguration() { return this.controller.getConfiguration(); }
    hydrateCache(e, t) { return d(this, null, function* () { return this.controller.hydrateCache(e, t); }); }
    clearCache(e) { return this.controller.clearCache(e); }
};
var Bl = { initialize: () => Promise.reject(q(j)), acquireTokenPopup: () => Promise.reject(q(j)), acquireTokenRedirect: () => Promise.reject(q(j)), acquireTokenSilent: () => Promise.reject(q(j)), acquireTokenByCode: () => Promise.reject(q(j)), getAllAccounts: () => [], getAccount: () => null, getAccountByHomeId: () => null, getAccountByUsername: () => null, getAccountByLocalId: () => null, handleRedirectPromise: () => Promise.reject(q(j)), loginPopup: () => Promise.reject(q(j)), loginRedirect: () => Promise.reject(q(j)), logout: () => Promise.reject(q(j)), logoutRedirect: () => Promise.reject(q(j)), logoutPopup: () => Promise.reject(q(j)), ssoSilent: () => Promise.reject(q(j)), addEventCallback: () => null, removeEventCallback: () => { }, addPerformanceCallback: () => "", removePerformanceCallback: () => !1, enableAccountStorageEvents: () => { }, disableAccountStorageEvents: () => { }, getTokenCache: () => { throw q(j); }, getLogger: () => { throw q(j); }, setLogger: () => { }, setActiveAccount: () => { }, getActiveAccount: () => null, initializeWrapperLibrary: () => { }, setNavigationClient: () => { }, getConfiguration: () => { throw q(j); }, hydrateCache: () => Promise.reject(q(j)), clearCache: () => Promise.reject(q(j)) };
var sa = class {
    constructor(e) { if (e === $.LocalStorage)
        this.windowStorage = new no;
    else if (e === $.SessionStorage)
        this.windowStorage = new io;
    else
        throw q(ze); }
    getItem(e) { return this.windowStorage.getItem(e); }
    setItem(e, t) { this.windowStorage.setItem(e, t); }
    removeItem(e) { this.windowStorage.removeItem(e); }
    getKeys() { return Object.keys(this.windowStorage); }
    containsKey(e) { return this.windowStorage.hasOwnProperty(e); }
};
var aa = class {
    static getInteractionStatusFromEvent(e, t) { switch (e.eventType) {
        case A.LOGIN_START: return he.Login;
        case A.SSO_SILENT_START: return he.SsoSilent;
        case A.ACQUIRE_TOKEN_START:
            if (e.interactionType === E.Redirect || e.interactionType === E.Popup)
                return he.AcquireToken;
            break;
        case A.HANDLE_REDIRECT_START: return he.HandleRedirect;
        case A.LOGOUT_START: return he.Logout;
        case A.SSO_SILENT_SUCCESS:
        case A.SSO_SILENT_FAILURE:
            if (t && t !== he.SsoSilent)
                break;
            return he.None;
        case A.LOGOUT_END:
            if (t && t !== he.Logout)
                break;
            return he.None;
        case A.HANDLE_REDIRECT_END:
            if (t && t !== he.HandleRedirect)
                break;
            return he.None;
        case A.LOGIN_SUCCESS:
        case A.LOGIN_FAILURE:
        case A.ACQUIRE_TOKEN_SUCCESS:
        case A.ACQUIRE_TOKEN_FAILURE:
        case A.RESTORE_FROM_BFCACHE:
            if (e.interactionType === E.Redirect || e.interactionType === E.Popup) {
                if (t && t !== he.Login && t !== he.AcquireToken)
                    break;
                return he.None;
            }
            break;
    } return null; }
};
var ca = class {
    constructor(e, t) { let r = t && t.loggerOptions || {}; this.logger = new ae(r, oo, ue), this.cryptoOps = new zt(this.logger), this.popTokenGenerator = new Ce(this.cryptoOps), this.shrParameters = e; }
    generatePublicKeyThumbprint() { return d(this, null, function* () { let { kid: e } = yield this.popTokenGenerator.generateKid(this.shrParameters); return e; }); }
    signRequest(e, t, r) { return d(this, null, function* () { return this.popTokenGenerator.signPayload(e, t, this.shrParameters, r); }); }
    removeKeys(e) { return d(this, null, function* () { return this.cryptoOps.removeTokenBindingKey(e); }); }
};
function Ic() { let n; try {
    n = window[$.SessionStorage];
    let e = n?.getItem(xa);
    if (Number(e) === 1)
        return import("@nf-internal/BrowserPerformanceMeasurement-KG4CHSYC");
}
catch { } }
function Gi() { return typeof window < "u" && typeof window.performance < "u" && typeof window.performance.now == "function"; }
function Fl(n) { if (!(!n || !Gi()))
    return Math.round(window.performance.now() - n); }
var la = class extends pn {
    constructor(e, t, r) { super(e.auth.clientId, e.auth.authority || `${u.DEFAULT_AUTHORITY}`, new ae(e.system?.loggerOptions || {}, oo, ue), oo, ue, e.telemetry?.application || { appName: "", appVersion: "" }, t, r); }
    generateId() { return ee(); }
    getPageVisibility() { return document.visibilityState?.toString() || null; }
    deleteIncompleteSubMeasurements(e) { Ic()?.then(t => { let r = this.eventsByCorrelationId.get(e.event.correlationId), o = r && r.eventId === e.event.eventId, i = []; o && r?.incompleteSubMeasurements && r.incompleteSubMeasurements.forEach(s => { i.push(p({}, s)); }), t.BrowserPerformanceMeasurement.flushMeasurements(e.event.correlationId, i); }); }
    startMeasurement(e, t) { let r = this.getPageVisibility(), o = super.startMeasurement(e, t), i = Gi() ? window.performance.now() : void 0, s = Ic()?.then(a => new a.BrowserPerformanceMeasurement(e, o.event.correlationId)); return s?.then(a => a.startMeasurement()), I(p({}, o), { end: (a, l) => { let h = o.end(I(p({}, a), { startPageVisibility: r, endPageVisibility: this.getPageVisibility(), durationMs: Fl(i) }), l); return s?.then(g => g.endMeasurement()), this.deleteIncompleteSubMeasurements(o), h; }, discard: () => { o.discard(), s?.then(a => a.flushMeasurement()), this.deleteIncompleteSubMeasurements(o); } }); }
    setPreQueueTime(e, t) { if (!Gi()) {
        this.logger.trace(`BrowserPerformanceClient: window performance API not available, unable to set telemetry queue time for ${e}`);
        return;
    } if (!t) {
        this.logger.trace(`BrowserPerformanceClient: correlationId for ${e} not provided, unable to set telemetry queue time`);
        return;
    } let r = this.preQueueTimeByCorrelationId.get(t); r && (this.logger.trace(`BrowserPerformanceClient: Incomplete pre-queue ${r.name} found`, t), this.addQueueMeasurement(r.name, t, void 0, !0)), this.preQueueTimeByCorrelationId.set(t, { name: e, time: window.performance.now() }); }
    addQueueMeasurement(e, t, r, o) { if (!Gi()) {
        this.logger.trace(`BrowserPerformanceClient: window performance API not available, unable to add queue measurement for ${e}`);
        return;
    } if (!t) {
        this.logger.trace(`BrowserPerformanceClient: correlationId for ${e} not provided, unable to add queue measurement`);
        return;
    } let i = super.getPreQueueTime(e, t); if (!i)
        return; let s = window.performance.now(), a = r || super.calculateQueuedTime(i, s); return super.addQueueMeasurement(e, t, a, o); }
};
export { B as AccountEntity, M as ApiId, w as AuthError, Wt as AuthErrorCodes, ha as AuthErrorMessage, ui as AuthenticationHeaderParser, b as AuthenticationScheme, _t as AzureCloudInstance, Ft as BrowserAuthError, Na as BrowserAuthErrorCodes, fl as BrowserAuthErrorMessage, $ as BrowserCacheLocation, Ai as BrowserConfigurationAuthError, Qa as BrowserConfigurationAuthErrorCodes, Il as BrowserConfigurationAuthErrorMessage, la as BrowserPerformanceClient, Sc as BrowserPerformanceMeasurement, sa as BrowserStorage, Xa as BrowserUtils, ie as CacheLookupPolicy, Se as ClientAuthError, F as ClientAuthErrorCodes, ua as ClientAuthErrorMessage, nn as ClientConfigurationError, He as ClientConfigurationErrorCodes, ga as ClientConfigurationErrorMessage, Nn as DEFAULT_IFRAME_TIMEOUT_MS, so as EventHandler, aa as EventMessageUtils, A as EventType, Z as InteractionRequiredAuthError, mt as InteractionRequiredAuthErrorCodes, _a as InteractionRequiredAuthErrorMessage, he as InteractionStatus, E as InteractionType, $n as JsonWebTokenTypes, no as LocalStorage, H as LogLevel, ae as Logger, Gt as MemoryStorage, Pn as NavigationClient, ce as OIDC_DEFAULT_SCOPES, c as PerformanceEvents, G as PromptValue, le as ProtocolMode, xn as PublicClientApplication, ia as PublicClientNext, oe as ServerError, Ue as ServerResponseType, io as SessionStorage, ca as SignedHttpRequest, Q as StringUtils, vo as StubPerformanceClient, P as UrlString, Cl as WrapperSKU, Hl as createNestablePublicClientApplication, Ec as createStandardPublicClientApplication, Bl as stubbedPublicClientApplication, ue as version };
/*! Bundled license information:

@azure/msal-common/dist/utils/Constants.mjs:
@azure/msal-common/dist/error/AuthErrorCodes.mjs:
@azure/msal-common/dist/error/AuthError.mjs:
@azure/msal-common/dist/error/ClientAuthErrorCodes.mjs:
@azure/msal-common/dist/error/ClientAuthError.mjs:
@azure/msal-common/dist/crypto/ICrypto.mjs:
@azure/msal-common/dist/logger/Logger.mjs:
@azure/msal-common/dist/packageMetadata.mjs:
@azure/msal-common/dist/authority/AuthorityOptions.mjs:
@azure/msal-common/dist/account/AuthToken.mjs:
@azure/msal-common/dist/utils/TimeUtils.mjs:
@azure/msal-common/dist/cache/utils/CacheHelpers.mjs:
@azure/msal-common/dist/error/ClientConfigurationErrorCodes.mjs:
@azure/msal-common/dist/error/ClientConfigurationError.mjs:
@azure/msal-common/dist/utils/StringUtils.mjs:
@azure/msal-common/dist/request/ScopeSet.mjs:
@azure/msal-common/dist/account/ClientInfo.mjs:
@azure/msal-common/dist/account/AccountInfo.mjs:
@azure/msal-common/dist/authority/AuthorityType.mjs:
@azure/msal-common/dist/account/TokenClaims.mjs:
@azure/msal-common/dist/authority/ProtocolMode.mjs:
@azure/msal-common/dist/cache/entities/AccountEntity.mjs:
@azure/msal-common/dist/utils/UrlUtils.mjs:
@azure/msal-common/dist/url/UrlString.mjs:
@azure/msal-common/dist/authority/AuthorityMetadata.mjs:
@azure/msal-common/dist/error/CacheErrorCodes.mjs:
@azure/msal-common/dist/error/CacheError.mjs:
@azure/msal-common/dist/cache/CacheManager.mjs:
@azure/msal-common/dist/config/ClientConfiguration.mjs:
@azure/msal-common/dist/account/CcsCredential.mjs:
@azure/msal-common/dist/constants/AADServerParamKeys.mjs:
@azure/msal-common/dist/request/RequestValidator.mjs:
@azure/msal-common/dist/request/RequestParameterBuilder.mjs:
@azure/msal-common/dist/authority/OpenIdConfigResponse.mjs:
@azure/msal-common/dist/authority/CloudInstanceDiscoveryResponse.mjs:
@azure/msal-common/dist/authority/CloudInstanceDiscoveryErrorResponse.mjs:
@azure/msal-common/dist/telemetry/performance/PerformanceEvent.mjs:
@azure/msal-common/dist/utils/FunctionWrappers.mjs:
@azure/msal-common/dist/authority/RegionDiscovery.mjs:
@azure/msal-common/dist/authority/Authority.mjs:
@azure/msal-common/dist/authority/AuthorityFactory.mjs:
@azure/msal-common/dist/error/ServerError.mjs:
@azure/msal-common/dist/network/ThrottlingUtils.mjs:
@azure/msal-common/dist/error/NetworkError.mjs:
@azure/msal-common/dist/client/BaseClient.mjs:
@azure/msal-common/dist/error/InteractionRequiredAuthErrorCodes.mjs:
@azure/msal-common/dist/error/InteractionRequiredAuthError.mjs:
@azure/msal-common/dist/utils/ProtocolUtils.mjs:
@azure/msal-common/dist/crypto/PopTokenGenerator.mjs:
@azure/msal-common/dist/cache/persistence/TokenCacheContext.mjs:
@azure/msal-common/dist/response/ResponseHandler.mjs:
@azure/msal-common/dist/utils/ClientAssertionUtils.mjs:
@azure/msal-common/dist/client/AuthorizationCodeClient.mjs:
@azure/msal-common/dist/client/RefreshTokenClient.mjs:
@azure/msal-common/dist/client/SilentFlowClient.mjs:
@azure/msal-common/dist/network/INetworkModule.mjs:
@azure/msal-common/dist/request/AuthenticationHeaderParser.mjs:
@azure/msal-common/dist/telemetry/server/ServerTelemetryManager.mjs:
@azure/msal-common/dist/error/JoseHeaderErrorCodes.mjs:
@azure/msal-common/dist/error/JoseHeaderError.mjs:
@azure/msal-common/dist/crypto/JoseHeader.mjs:
@azure/msal-common/dist/telemetry/performance/StubPerformanceClient.mjs:
@azure/msal-common/dist/telemetry/performance/PerformanceClient.mjs:
@azure/msal-common/dist/index-browser.mjs:
  (*! @azure/msal-common v14.16.0 2024-11-05 *)

@azure/msal-browser/dist/error/BrowserAuthErrorCodes.mjs:
@azure/msal-browser/dist/error/BrowserAuthError.mjs:
@azure/msal-browser/dist/utils/BrowserConstants.mjs:
@azure/msal-browser/dist/encode/Base64Encode.mjs:
@azure/msal-browser/dist/crypto/BrowserCrypto.mjs:
@azure/msal-browser/dist/error/BrowserConfigurationAuthErrorCodes.mjs:
@azure/msal-browser/dist/error/BrowserConfigurationAuthError.mjs:
@azure/msal-browser/dist/utils/BrowserUtils.mjs:
@azure/msal-browser/dist/navigation/NavigationClient.mjs:
@azure/msal-browser/dist/network/FetchClient.mjs:
@azure/msal-browser/dist/config/Configuration.mjs:
@azure/msal-browser/dist/packageMetadata.mjs:
@azure/msal-browser/dist/operatingcontext/BaseOperatingContext.mjs:
@azure/msal-browser/dist/naa/BridgeStatusCode.mjs:
@azure/msal-browser/dist/naa/BridgeProxy.mjs:
@azure/msal-browser/dist/operatingcontext/NestedAppOperatingContext.mjs:
@azure/msal-browser/dist/operatingcontext/StandardOperatingContext.mjs:
@azure/msal-browser/dist/encode/Base64Decode.mjs:
@azure/msal-browser/dist/cache/DatabaseStorage.mjs:
@azure/msal-browser/dist/cache/MemoryStorage.mjs:
@azure/msal-browser/dist/cache/AsyncMemoryStorage.mjs:
@azure/msal-browser/dist/crypto/CryptoOps.mjs:
@azure/msal-browser/dist/cache/LocalStorage.mjs:
@azure/msal-browser/dist/cache/SessionStorage.mjs:
@azure/msal-browser/dist/utils/BrowserProtocolUtils.mjs:
@azure/msal-browser/dist/cache/CookieStorage.mjs:
@azure/msal-browser/dist/cache/BrowserCacheManager.mjs:
@azure/msal-browser/dist/cache/AccountManager.mjs:
@azure/msal-browser/dist/event/EventType.mjs:
@azure/msal-browser/dist/event/EventHandler.mjs:
@azure/msal-browser/dist/interaction_client/BaseInteractionClient.mjs:
@azure/msal-browser/dist/crypto/PkceGenerator.mjs:
@azure/msal-browser/dist/request/RequestHelpers.mjs:
@azure/msal-browser/dist/interaction_client/StandardInteractionClient.mjs:
@azure/msal-browser/dist/error/NativeAuthErrorCodes.mjs:
@azure/msal-browser/dist/broker/nativeBroker/NativeStatusCodes.mjs:
@azure/msal-browser/dist/error/NativeAuthError.mjs:
@azure/msal-browser/dist/interaction_client/SilentCacheClient.mjs:
@azure/msal-browser/dist/interaction_client/NativeInteractionClient.mjs:
@azure/msal-browser/dist/broker/nativeBroker/NativeMessageHandler.mjs:
@azure/msal-browser/dist/interaction_handler/InteractionHandler.mjs:
@azure/msal-browser/dist/response/ResponseHandler.mjs:
@azure/msal-browser/dist/interaction_client/PopupClient.mjs:
@azure/msal-browser/dist/interaction_handler/RedirectHandler.mjs:
@azure/msal-browser/dist/interaction_client/RedirectClient.mjs:
@azure/msal-browser/dist/interaction_handler/SilentHandler.mjs:
@azure/msal-browser/dist/interaction_client/SilentIframeClient.mjs:
@azure/msal-browser/dist/interaction_client/SilentRefreshClient.mjs:
@azure/msal-browser/dist/cache/TokenCache.mjs:
@azure/msal-browser/dist/interaction_client/HybridSpaAuthorizationCodeClient.mjs:
@azure/msal-browser/dist/interaction_client/SilentAuthCodeClient.mjs:
@azure/msal-browser/dist/controllers/StandardController.mjs:
@azure/msal-browser/dist/naa/BridgeError.mjs:
@azure/msal-browser/dist/naa/mapping/NestedAppAuthAdapter.mjs:
@azure/msal-browser/dist/error/NestedAppAuthError.mjs:
@azure/msal-browser/dist/controllers/NestedAppAuthController.mjs:
@azure/msal-browser/dist/controllers/ControllerFactory.mjs:
@azure/msal-browser/dist/app/PublicClientApplication.mjs:
@azure/msal-browser/dist/controllers/UnknownOperatingContextController.mjs:
@azure/msal-browser/dist/operatingcontext/UnknownOperatingContext.mjs:
@azure/msal-browser/dist/app/PublicClientNext.mjs:
@azure/msal-browser/dist/app/IPublicClientApplication.mjs:
@azure/msal-browser/dist/cache/BrowserStorage.mjs:
@azure/msal-browser/dist/event/EventMessage.mjs:
@azure/msal-browser/dist/crypto/SignedHttpRequest.mjs:
@azure/msal-browser/dist/telemetry/BrowserPerformanceClient.mjs:
@azure/msal-browser/dist/index.mjs:
  (*! @azure/msal-browser v3.28.1 2025-01-14 *)
*/
