import { a as r, b as t, c as o, d as u, e as d, f as i } from "@nf-internal/chunk-6KUZPJZH";
import "@nf-internal/chunk-66YHNWRR";
function c(e) { return { token: e.token, providedIn: e.providedIn || null, factory: e.factory, value: void 0 }; }
function f(e, n) { return e.\u0275prov = n, e; }
export { u as NOT_FOUND, d as NotFoundError, c as defineInjectable, r as getCurrentInjector, o as inject, i as isNotFound, f as registerInjectable, t as setCurrentInjector };
/*! Bundled license information:

@angular/core/fesm2022/primitives/di.mjs:
  (**
   * @license Angular v20.2.1
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)
*/
