import { $ as ji, $a as os, A as W, Aa as qi, B as Y, Ba as dt, Ca as je, Da as de, Ea as Ji, F as Q, Fa as ut, Ga as Yt, Ha as Ut, I as Ot, Ia as Zi, J as at, Ja as Qi, K as re, Ka as ft, L as Le, La as Et, M as Vi, N as Mt, Na as ts, O as Ni, Oa as es, P as Oe, Pa as gt, Q as tt, Qa as j, R as le, Ra as V, S as Te, Sa as Rt, T as Ee, Ta as is, U as Wi, Ua as pt, Va as ss, W as rt, Wa as $e, X as jt, Xa as ns, Y as U, Ya as Ye, Z as Hi, _ as lt, a as st, aa as Tt, ab as Ue, b as Ei, ba as $i, bb as Xe, c as L, ca as Yi, d as K, da as Ui, db as mt, e as z, ea as Re, eb as as, f as B, fa as Ie, fb as Ke, g as G, gb as rs, h as C, ha as Xi, hb as Ge, i as Ri, ia as ze, ib as ls, j as Ii, ja as Ki, jb as cs, k as E, ka as ce, kb as hs, l as O, la as H, lb as St, m as Nt, ma as Gi, mb as qe, na as Fe, nb as Je, oa as Be, ob as ds, p as zi, pa as Ve, pb as Ze, q as Wt, qb as us, ra as Ne, rb as Qe, ta as $t, u as vt, ua as he, v as Fi, va as kt, w as Lt, wa as We, x as Ht, xa as I, y as Ae, z as Bi, za as He } from "@nf-internal/chunk-3LXDCEJB";
import { a as oe, b as ae } from "@nf-internal/chunk-66YHNWRR";
var di = class {
    constructor() { this._request = null, this._charts = new Map, this._running = !1, this._lastDate = void 0; }
    _notify(i, t, e, s) { let o = t.listeners[s], a = t.duration; o.forEach(r => r({ chart: i, initial: t.initial, numSteps: a, currentStep: Math.min(e - t.start, a) })); }
    _refresh() { this._request || (this._running = !0, this._request = Xi.call(window, () => { this._update(), this._request = null, this._running && this._refresh(); })); }
    _update(i = Date.now()) { let t = 0; this._charts.forEach((e, s) => { if (!e.running || !e.items.length)
        return; let o = e.items, a = o.length - 1, r = !1, l; for (; a >= 0; --a)
        l = o[a], l._active ? (l._total > e.duration && (e.duration = l._total), l.tick(i), r = !0) : (o[a] = o[o.length - 1], o.pop()); r && (s.draw(), this._notify(s, e, i, "progress")), o.length || (e.running = !1, this._notify(s, e, i, "complete"), e.initial = !1), t += o.length; }), this._lastDate = i, t === 0 && (this._running = !1); }
    _getAnims(i) { let t = this._charts, e = t.get(i); return e || (e = { running: !1, initial: !0, items: [], listeners: { complete: [], progress: [] } }, t.set(i, e)), e; }
    listen(i, t, e) { this._getAnims(i).listeners[t].push(e); }
    add(i, t) { !t || !t.length || this._getAnims(i).items.push(...t); }
    has(i) { return this._getAnims(i).items.length > 0; }
    start(i) { let t = this._charts.get(i); t && (t.running = !0, t.start = Date.now(), t.duration = t.items.reduce((e, s) => Math.max(e, s._duration), 0), this._refresh()); }
    running(i) { if (!this._running)
        return !1; let t = this._charts.get(i); return !(!t || !t.running || !t.items.length); }
    stop(i) { let t = this._charts.get(i); if (!t || !t.items.length)
        return; let e = t.items, s = e.length - 1; for (; s >= 0; --s)
        e[s].cancel(); t.items = [], this._notify(i, t, Date.now(), "complete"); }
    remove(i) { return this._charts.delete(i); }
}, ct = new di, fs = "transparent", In = { boolean(n, i, t) { return t > .5 ? i : n; }, color(n, i, t) { let e = Ne(n || fs), s = e.valid && Ne(i || fs); return s && s.valid ? s.mix(e, t).hexString() : i; }, number(n, i, t) { return n + (i - n) * t; } }, ui = class {
    constructor(i, t, e, s) { let o = t[e]; s = Rt([i.to, s, o, i.from]); let a = Rt([i.from, o, s]); this._active = !0, this._fn = i.fn || In[i.type || typeof a], this._easing = Ve[i.easing] || Ve.linear, this._start = Math.floor(Date.now() + (i.delay || 0)), this._duration = this._total = Math.floor(i.duration), this._loop = !!i.loop, this._target = t, this._prop = e, this._from = a, this._to = s, this._promises = void 0; }
    active() { return this._active; }
    update(i, t, e) { if (this._active) {
        this._notify(!1);
        let s = this._target[this._prop], o = e - this._start, a = this._duration - o;
        this._start = e, this._duration = Math.floor(Math.max(a, i.duration)), this._total += o, this._loop = !!i.loop, this._to = Rt([i.to, t, s, i.from]), this._from = Rt([i.from, s, t]);
    } }
    cancel() { this._active && (this.tick(Date.now()), this._active = !1, this._notify(!1)); }
    tick(i) { let t = i - this._start, e = this._duration, s = this._prop, o = this._from, a = this._loop, r = this._to, l; if (this._active = o !== r && (a || t < e), !this._active) {
        this._target[s] = r, this._notify(!0);
        return;
    } if (t < 0) {
        this._target[s] = o;
        return;
    } l = t / e % 2, l = a && l > 1 ? 2 - l : l, l = this._easing(Math.min(1, Math.max(0, l))), this._target[s] = this._fn(o, r, l); }
    wait() { let i = this._promises || (this._promises = []); return new Promise((t, e) => { i.push({ res: t, rej: e }); }); }
    _notify(i) { let t = i ? "res" : "rej", e = this._promises || []; for (let s = 0; s < e.length; s++)
        e[s][t](); }
}, ye = class {
    constructor(i, t) { this._chart = i, this._properties = new Map, this.configure(t); }
    configure(i) { if (!z(i))
        return; let t = Object.keys(I.animation), e = this._properties; Object.getOwnPropertyNames(i).forEach(s => { let o = i[s]; if (!z(o))
        return; let a = {}; for (let r of t)
        a[r] = o[r]; (K(o.properties) && o.properties || [s]).forEach(r => { (r === s || !e.has(r)) && e.set(r, a); }); }); }
    _animateOptions(i, t) { let e = t.options, s = Fn(i, e); if (!s)
        return []; let o = this._createAnimations(s, e); return e.$shared && zn(i.options.$animations, e).then(() => { i.options = e; }, () => { }), o; }
    _createAnimations(i, t) { let e = this._properties, s = [], o = i.$animations || (i.$animations = {}), a = Object.keys(t), r = Date.now(), l; for (l = a.length - 1; l >= 0; --l) {
        let c = a[l];
        if (c.charAt(0) === "$")
            continue;
        if (c === "options") {
            s.push(...this._animateOptions(i, t));
            continue;
        }
        let h = t[c], d = o[c], u = e.get(c);
        if (d)
            if (u && d.active()) {
                d.update(u, h, r);
                continue;
            }
            else
                d.cancel();
        if (!u || !u.duration) {
            i[c] = h;
            continue;
        }
        o[c] = d = new ui(u, i, c, h), s.push(d);
    } return s; }
    update(i, t) { if (this._properties.size === 0) {
        Object.assign(i, t);
        return;
    } let e = this._createAnimations(i, t); if (e.length)
        return ct.add(this._chart, e), !0; }
};
function zn(n, i) { let t = [], e = Object.keys(i); for (let s = 0; s < e.length; s++) {
    let o = n[e[s]];
    o && o.active() && t.push(o.wait());
} return Promise.all(t); }
function Fn(n, i) { if (!i)
    return; let t = n.options; if (!t) {
    n.options = i;
    return;
} return t.$shared && (n.options = t = Object.assign({}, t, { $shared: !1, $animations: {} })), t; }
function gs(n, i) { let t = n && n.options || {}, e = t.reverse, s = t.min === void 0 ? i : 0, o = t.max === void 0 ? i : 0; return { start: e ? o : s, end: e ? s : o }; }
function Bn(n, i, t) { if (t === !1)
    return !1; let e = gs(n, t), s = gs(i, t); return { top: s.end, right: e.end, bottom: s.start, left: e.start }; }
function Vn(n) { let i, t, e, s; return z(n) ? (i = n.top, t = n.right, e = n.bottom, s = n.left) : i = t = e = s = n, { top: i, right: t, bottom: e, left: s, disabled: n === !1 }; }
function gn(n, i) { let t = [], e = n._getSortedDatasetMetas(i), s, o; for (s = 0, o = e.length; s < o; ++s)
    t.push(e[s].index); return t; }
function ps(n, i, t, e = {}) { let s = n.keys, o = e.mode === "single", a, r, l, c; if (i === null)
    return; let h = !1; for (a = 0, r = s.length; a < r; ++a) {
    if (l = +s[a], l === t) {
        if (h = !0, e.all)
            continue;
        break;
    }
    c = n.values[l], B(c) && (o || i === 0 || at(i) === at(c)) && (i += c);
} return !h && !e.all ? 0 : i; }
function Nn(n, i) { let { iScale: t, vScale: e } = i, s = t.axis === "x" ? "x" : "y", o = e.axis === "x" ? "x" : "y", a = Object.keys(n), r = new Array(a.length), l, c, h; for (l = 0, c = a.length; l < c; ++l)
    h = a[l], r[l] = { [s]: h, [o]: n[h] }; return r; }
function ti(n, i) { let t = n && n.options.stacked; return t || t === void 0 && i.stack !== void 0; }
function Wn(n, i, t) { return `${n.id}.${i.id}.${t.stack || t.type}`; }
function Hn(n) { let { min: i, max: t, minDefined: e, maxDefined: s } = n.getUserBounds(); return { min: e ? i : Number.NEGATIVE_INFINITY, max: s ? t : Number.POSITIVE_INFINITY }; }
function jn(n, i, t) { let e = n[i] || (n[i] = {}); return e[t] || (e[t] = {}); }
function ms(n, i, t, e) { for (let s of i.getMatchingVisibleMetas(e).reverse()) {
    let o = n[s.index];
    if (t && o > 0 || !t && o < 0)
        return s.index;
} return null; }
function bs(n, i) { let { chart: t, _cachedMeta: e } = n, s = t._stacks || (t._stacks = {}), { iScale: o, vScale: a, index: r } = e, l = o.axis, c = a.axis, h = Wn(o, a, e), d = i.length, u; for (let f = 0; f < d; ++f) {
    let g = i[f], { [l]: p, [c]: m } = g, x = g._stacks || (g._stacks = {});
    u = x[c] = jn(s, h, p), u[r] = m, u._top = ms(u, a, !0, e.type), u._bottom = ms(u, a, !1, e.type);
    let b = u._visualValues || (u._visualValues = {});
    b[r] = m;
} }
function ei(n, i) { let t = n.scales; return Object.keys(t).filter(e => t[e].axis === i).shift(); }
function $n(n, i) { return pt(n, { active: !1, dataset: void 0, datasetIndex: i, index: i, mode: "default", type: "dataset" }); }
function Yn(n, i, t) { return pt(n, { active: !1, dataIndex: i, parsed: void 0, raw: void 0, element: t, index: i, mode: "default", type: "data" }); }
function Xt(n, i) { let t = n.controller.index, e = n.vScale && n.vScale.axis; if (e) {
    i = i || n._parsed;
    for (let s of i) {
        let o = s._stacks;
        if (!o || o[e] === void 0 || o[e][t] === void 0)
            return;
        delete o[e][t], o[e]._visualValues !== void 0 && o[e]._visualValues[t] !== void 0 && delete o[e]._visualValues[t];
    }
} }
var ii = n => n === "reset" || n === "none", xs = (n, i) => i ? n : Object.assign({}, n), Un = (n, i, t) => n && !i.hidden && i._stacked && { keys: gn(t, !0), values: null }, xt = (() => { class n {
    static defaults = {};
    static datasetElementType = null;
    static dataElementType = null;
    constructor(t, e) { this.chart = t, this._ctx = t.ctx, this.index = e, this._cachedDataOpts = {}, this._cachedMeta = this.getMeta(), this._type = this._cachedMeta.type, this.options = void 0, this._parsing = !1, this._data = void 0, this._objectData = void 0, this._sharedOptions = void 0, this._drawStart = void 0, this._drawCount = void 0, this.enableOptionSharing = !1, this.supportsDecimation = !1, this.$context = void 0, this._syncList = [], this.datasetElementType = new.target.datasetElementType, this.dataElementType = new.target.dataElementType, this.initialize(); }
    initialize() { let t = this._cachedMeta; this.configure(), this.linkScales(), t._stacked = ti(t.vScale, t), this.addElements(), this.options.fill && !this.chart.isPluginEnabled("filler") && console.warn("Tried to use the 'fill' option without the 'Filler' plugin enabled. Please import and register the 'Filler' plugin and make sure it is not disabled in the options"); }
    updateIndex(t) { this.index !== t && Xt(this._cachedMeta), this.index = t; }
    linkScales() { let t = this.chart, e = this._cachedMeta, s = this.getDataset(), o = (u, f, g, p) => u === "x" ? f : u === "r" ? p : g, a = e.xAxisID = C(s.xAxisID, ei(t, "x")), r = e.yAxisID = C(s.yAxisID, ei(t, "y")), l = e.rAxisID = C(s.rAxisID, ei(t, "r")), c = e.indexAxis, h = e.iAxisID = o(c, a, r, l), d = e.vAxisID = o(c, r, a, l); e.xScale = this.getScaleForId(a), e.yScale = this.getScaleForId(r), e.rScale = this.getScaleForId(l), e.iScale = this.getScaleForId(h), e.vScale = this.getScaleForId(d); }
    getDataset() { return this.chart.data.datasets[this.index]; }
    getMeta() { return this.chart.getDatasetMeta(this.index); }
    getScaleForId(t) { return this.chart.scales[t]; }
    _getOtherScale(t) { let e = this._cachedMeta; return t === e.iScale ? e.vScale : e.iScale; }
    reset() { this._update("reset"); }
    _destroy() { let t = this._cachedMeta; this._data && Re(this._data, this), t._stacked && Xt(t); }
    _dataCheck() { let t = this.getDataset(), e = t.data || (t.data = []), s = this._data; if (z(e)) {
        let o = this._cachedMeta;
        this._data = Nn(e, o);
    }
    else if (s !== e) {
        if (s) {
            Re(s, this);
            let o = this._cachedMeta;
            Xt(o), o._parsed = [];
        }
        e && Object.isExtensible(e) && Ui(e, this), this._syncList = [], this._data = e;
    } }
    addElements() { let t = this._cachedMeta; this._dataCheck(), this.datasetElementType && (t.dataset = new this.datasetElementType); }
    buildOrUpdateElements(t) { let e = this._cachedMeta, s = this.getDataset(), o = !1; this._dataCheck(); let a = e._stacked; e._stacked = ti(e.vScale, e), e.stack !== s.stack && (o = !0, Xt(e), e.stack = s.stack), this._resyncElements(t), (o || a !== e._stacked) && (bs(this, e._parsed), e._stacked = ti(e.vScale, e)); }
    configure() { let t = this.chart.config, e = t.datasetScopeKeys(this._type), s = t.getOptionScopes(this.getDataset(), e, !0); this.options = t.createResolver(s, this.getContext()), this._parsing = this.options.parsing, this._cachedDataOpts = {}; }
    parse(t, e) { let { _cachedMeta: s, _data: o } = this, { iScale: a, _stacked: r } = s, l = a.axis, c = t === 0 && e === o.length ? !0 : s._sorted, h = t > 0 && s._parsed[t - 1], d, u, f; if (this._parsing === !1)
        s._parsed = o, s._sorted = !0, f = o;
    else {
        K(o[t]) ? f = this.parseArrayData(s, o, t, e) : z(o[t]) ? f = this.parseObjectData(s, o, t, e) : f = this.parsePrimitiveData(s, o, t, e);
        let g = () => u[l] === null || h && u[l] < h[l];
        for (d = 0; d < e; ++d)
            s._parsed[d + t] = u = f[d], c && (g() && (c = !1), h = u);
        s._sorted = c;
    } r && bs(this, f); }
    parsePrimitiveData(t, e, s, o) { let { iScale: a, vScale: r } = t, l = a.axis, c = r.axis, h = a.getLabels(), d = a === r, u = new Array(o), f, g, p; for (f = 0, g = o; f < g; ++f)
        p = f + s, u[f] = { [l]: d || a.parse(h[p], p), [c]: r.parse(e[p], p) }; return u; }
    parseArrayData(t, e, s, o) { let { xScale: a, yScale: r } = t, l = new Array(o), c, h, d, u; for (c = 0, h = o; c < h; ++c)
        d = c + s, u = e[d], l[c] = { x: a.parse(u[0], d), y: r.parse(u[1], d) }; return l; }
    parseObjectData(t, e, s, o) { let { xScale: a, yScale: r } = t, { xAxisKey: l = "x", yAxisKey: c = "y" } = this._parsing, h = new Array(o), d, u, f, g; for (d = 0, u = o; d < u; ++d)
        f = d + s, g = e[f], h[d] = { x: a.parse(vt(g, l), f), y: r.parse(vt(g, c), f) }; return h; }
    getParsed(t) { return this._cachedMeta._parsed[t]; }
    getDataElement(t) { return this._cachedMeta.data[t]; }
    applyStack(t, e, s) { let o = this.chart, a = this._cachedMeta, r = e[t.axis], l = { keys: gn(o, !0), values: e._stacks[t.axis]._visualValues }; return ps(l, r, a.index, { mode: s }); }
    updateRangeFromParsed(t, e, s, o) { let a = s[e.axis], r = a === null ? NaN : a, l = o && s._stacks[e.axis]; o && l && (o.values = l, r = ps(o, a, this._cachedMeta.index)), t.min = Math.min(t.min, r), t.max = Math.max(t.max, r); }
    getMinMax(t, e) { let s = this._cachedMeta, o = s._parsed, a = s._sorted && t === s.iScale, r = o.length, l = this._getOtherScale(t), c = Un(e, s, this.chart), h = { min: Number.POSITIVE_INFINITY, max: Number.NEGATIVE_INFINITY }, { min: d, max: u } = Hn(l), f, g; function p() { g = o[f]; let m = g[l.axis]; return !B(g[t.axis]) || d > m || u < m; } for (f = 0; f < r && !(!p() && (this.updateRangeFromParsed(h, t, g, c), a)); ++f)
        ; if (a) {
        for (f = r - 1; f >= 0; --f)
            if (!p()) {
                this.updateRangeFromParsed(h, t, g, c);
                break;
            }
    } return h; }
    getAllParsedValues(t) { let e = this._cachedMeta._parsed, s = [], o, a, r; for (o = 0, a = e.length; o < a; ++o)
        r = e[o][t.axis], B(r) && s.push(r); return s; }
    getMaxOverflow() { return !1; }
    getLabelAndValue(t) { let e = this._cachedMeta, s = e.iScale, o = e.vScale, a = this.getParsed(t); return { label: s ? "" + s.getLabelForValue(a[s.axis]) : "", value: o ? "" + o.getLabelForValue(a[o.axis]) : "" }; }
    _update(t) { let e = this._cachedMeta; this.update(t || "default"), e._clip = Vn(C(this.options.clip, Bn(e.xScale, e.yScale, this.getMaxOverflow()))); }
    update(t) { }
    draw() { let t = this._ctx, e = this.chart, s = this._cachedMeta, o = s.data || [], a = e.chartArea, r = [], l = this._drawStart || 0, c = this._drawCount || o.length - l, h = this.options.drawActiveElementsOnTop, d; for (s.dataset && s.dataset.draw(t, a, l, c), d = l; d < l + c; ++d) {
        let u = o[d];
        u.hidden || (u.active && h ? r.push(u) : u.draw(t, a));
    } for (d = 0; d < r.length; ++d)
        r[d].draw(t, a); }
    getStyle(t, e) { let s = e ? "active" : "default"; return t === void 0 && this._cachedMeta.dataset ? this.resolveDatasetElementOptions(s) : this.resolveDataElementOptions(t || 0, s); }
    getContext(t, e, s) { let o = this.getDataset(), a; if (t >= 0 && t < this._cachedMeta.data.length) {
        let r = this._cachedMeta.data[t];
        a = r.$context || (r.$context = Yn(this.getContext(), t, r)), a.parsed = this.getParsed(t), a.raw = o.data[t], a.index = a.dataIndex = t;
    }
    else
        a = this.$context || (this.$context = $n(this.chart.getContext(), this.index)), a.dataset = o, a.index = a.datasetIndex = this.index; return a.active = !!e, a.mode = s, a; }
    resolveDatasetElementOptions(t) { return this._resolveElementOptions(this.datasetElementType.id, t); }
    resolveDataElementOptions(t, e) { return this._resolveElementOptions(this.dataElementType.id, e, t); }
    _resolveElementOptions(t, e = "default", s) { let o = e === "active", a = this._cachedDataOpts, r = t + "-" + e, l = a[r], c = this.enableOptionSharing && Lt(s); if (l)
        return xs(l, c); let h = this.chart.config, d = h.datasetElementScopeKeys(this._type, t), u = o ? [`${t}Hover`, "hover", t, ""] : [t, ""], f = h.getOptionScopes(this.getDataset(), d), g = Object.keys(I.elements[t]), p = () => this.getContext(s, o, e), m = h.resolveNamedOptions(f, g, p, u); return m.$shared && (m.$shared = c, a[r] = Object.freeze(xs(m, c))), m; }
    _resolveAnimations(t, e, s) { let o = this.chart, a = this._cachedDataOpts, r = `animation-${e}`, l = a[r]; if (l)
        return l; let c; if (o.options.animation !== !1) {
        let d = this.chart.config, u = d.datasetAnimationScopeKeys(this._type, e), f = d.getOptionScopes(this.getDataset(), u);
        c = d.createResolver(f, this.getContext(t, s, e));
    } let h = new ye(o, c && c.animations); return c && c._cacheable && (a[r] = Object.freeze(h)), h; }
    getSharedOptions(t) { if (t.$shared)
        return this._sharedOptions || (this._sharedOptions = Object.assign({}, t)); }
    includeOptions(t, e) { return !e || ii(t) || this.chart._animationsDisabled; }
    _getSharedOptions(t, e) { let s = this.resolveDataElementOptions(t, e), o = this._sharedOptions, a = this.getSharedOptions(s), r = this.includeOptions(e, a) || a !== o; return this.updateSharedOptions(a, e, s), { sharedOptions: a, includeOptions: r }; }
    updateElement(t, e, s, o) { ii(o) ? Object.assign(t, s) : this._resolveAnimations(e, o).update(t, s); }
    updateSharedOptions(t, e, s) { t && !ii(e) && this._resolveAnimations(void 0, e).update(t, s); }
    _setStyle(t, e, s, o) { t.active = o; let a = this.getStyle(e, o); this._resolveAnimations(e, s, o).update(t, { options: !o && this.getSharedOptions(a) || a }); }
    removeHoverStyle(t, e, s) { this._setStyle(t, s, "active", !1); }
    setHoverStyle(t, e, s) { this._setStyle(t, s, "active", !0); }
    _removeDatasetHoverStyle() { let t = this._cachedMeta.dataset; t && this._setStyle(t, void 0, "active", !1); }
    _setDatasetHoverStyle() { let t = this._cachedMeta.dataset; t && this._setStyle(t, void 0, "active", !0); }
    _resyncElements(t) { let e = this._data, s = this._cachedMeta.data; for (let [l, c, h] of this._syncList)
        this[l](c, h); this._syncList = []; let o = s.length, a = e.length, r = Math.min(a, o); r && this.parse(0, r), a > o ? this._insertElements(o, a - o, t) : a < o && this._removeElements(a, o - a); }
    _insertElements(t, e, s = !0) { let o = this._cachedMeta, a = o.data, r = t + e, l, c = h => { for (h.length += e, l = h.length - 1; l >= r; l--)
        h[l] = h[l - e]; }; for (c(a), l = t; l < r; ++l)
        a[l] = new this.dataElementType; this._parsing && c(o._parsed), this.parse(t, e), s && this.updateElements(a, t, e, "reset"); }
    updateElements(t, e, s, o) { }
    _removeElements(t, e) { let s = this._cachedMeta; if (this._parsing) {
        let o = s._parsed.splice(t, e);
        s._stacked && Xt(s, o);
    } s.data.splice(t, e); }
    _sync(t) { if (this._parsing)
        this._syncList.push(t);
    else {
        let [e, s, o] = t;
        this[e](s, o);
    } this.chart._dataChanges.push([this.index, ...t]); }
    _onDataPush() { let t = arguments.length; this._sync(["_insertElements", this.getDataset().data.length - t, t]); }
    _onDataPop() { this._sync(["_removeElements", this._cachedMeta.data.length - 1, 1]); }
    _onDataShift() { this._sync(["_removeElements", 0, 1]); }
    _onDataSplice(t, e) { e && this._sync(["_removeElements", t, e]); let s = arguments.length - 2; s && this._sync(["_insertElements", t, s]); }
    _onDataUnshift() { this._sync(["_insertElements", 0, arguments.length]); }
} return n; })();
function Xn(n, i) { if (!n._cache.$bar) {
    let t = n.getMatchingVisibleMetas(i), e = [];
    for (let s = 0, o = t.length; s < o; s++)
        e = e.concat(t[s].controller.getAllParsedValues(n));
    n._cache.$bar = Ie(e.sort((s, o) => s - o));
} return n._cache.$bar; }
function Kn(n) { let i = n.iScale, t = Xn(i, n.type), e = i._length, s, o, a, r, l = () => { a === 32767 || a === -32768 || (Lt(r) && (e = Math.min(e, Math.abs(a - r) || e)), r = a); }; for (s = 0, o = t.length; s < o; ++s)
    a = i.getPixelForValue(t[s]), l(); for (r = void 0, s = 0, o = i.ticks.length; s < o; ++s)
    a = i.getPixelForTick(s), l(); return e; }
function Gn(n, i, t, e) { let s = t.barThickness, o, a; return L(s) ? (o = i.min * t.categoryPercentage, a = t.barPercentage) : (o = s * e, a = 1), { chunk: o / e, ratio: a, start: i.pixels[n] - o / 2 }; }
function qn(n, i, t, e) { let s = i.pixels, o = s[n], a = n > 0 ? s[n - 1] : null, r = n < s.length - 1 ? s[n + 1] : null, l = t.categoryPercentage; a === null && (a = o - (r === null ? i.end - i.start : r - o)), r === null && (r = o + o - a); let c = o - (o - Math.min(a, r)) / 2 * l; return { chunk: Math.abs(r - a) / 2 * l / e, ratio: t.barPercentage, start: c }; }
function Jn(n, i, t, e) { let s = t.parse(n[0], e), o = t.parse(n[1], e), a = Math.min(s, o), r = Math.max(s, o), l = a, c = r; Math.abs(a) > Math.abs(r) && (l = r, c = a), i[t.axis] = c, i._custom = { barStart: l, barEnd: c, start: s, end: o, min: a, max: r }; }
function pn(n, i, t, e) { return K(n) ? Jn(n, i, t, e) : i[t.axis] = t.parse(n, e), i; }
function _s(n, i, t, e) { let s = n.iScale, o = n.vScale, a = s.getLabels(), r = s === o, l = [], c, h, d, u; for (c = t, h = t + e; c < h; ++c)
    u = i[c], d = {}, d[s.axis] = r || s.parse(a[c], c), l.push(pn(u, d, o, c)); return l; }
function si(n) { return n && n.barStart !== void 0 && n.barEnd !== void 0; }
function Zn(n, i, t) { return n !== 0 ? at(n) : (i.isHorizontal() ? 1 : -1) * (i.min >= t ? 1 : -1); }
function Qn(n) { let i, t, e, s, o; return n.horizontal ? (i = n.base > n.x, t = "left", e = "right") : (i = n.base < n.y, t = "bottom", e = "top"), i ? (s = "end", o = "start") : (s = "start", o = "end"), { start: t, end: e, reverse: i, top: s, bottom: o }; }
function to(n, i, t, e) { let s = i.borderSkipped, o = {}; if (!s) {
    n.borderSkipped = o;
    return;
} if (s === !0) {
    n.borderSkipped = { top: !0, right: !0, bottom: !0, left: !0 };
    return;
} let { start: a, end: r, reverse: l, top: c, bottom: h } = Qn(n); s === "middle" && t && (n.enableBorderRadius = !0, (t._top || 0) === e ? s = c : (t._bottom || 0) === e ? s = h : (o[ys(h, a, r, l)] = !0, s = c)), o[ys(s, a, r, l)] = !0, n.borderSkipped = o; }
function ys(n, i, t, e) { return e ? (n = eo(n, i, t), n = vs(n, t, i)) : n = vs(n, i, t), n; }
function eo(n, i, t) { return n === i ? t : n === t ? i : n; }
function vs(n, i, t) { return n === "start" ? i : n === "end" ? t : n; }
function io(n, { inflateAmount: i }, t) { n.inflateAmount = i === "auto" ? t === 1 ? .33 : 0 : i; }
var so = (() => { class n extends xt {
    static id = "bar";
    static defaults = { datasetElementType: !1, dataElementType: "bar", categoryPercentage: .8, barPercentage: .9, grouped: !0, animations: { numbers: { type: "number", properties: ["x", "y", "base", "width", "height"] } } };
    static overrides = { scales: { _index_: { type: "category", offset: !0, grid: { offset: !0 } }, _value_: { type: "linear", beginAtZero: !0 } } };
    parsePrimitiveData(t, e, s, o) { return _s(t, e, s, o); }
    parseArrayData(t, e, s, o) { return _s(t, e, s, o); }
    parseObjectData(t, e, s, o) { let { iScale: a, vScale: r } = t, { xAxisKey: l = "x", yAxisKey: c = "y" } = this._parsing, h = a.axis === "x" ? l : c, d = r.axis === "x" ? l : c, u = [], f, g, p, m; for (f = s, g = s + o; f < g; ++f)
        m = e[f], p = {}, p[a.axis] = a.parse(vt(m, h), f), u.push(pn(vt(m, d), p, r, f)); return u; }
    updateRangeFromParsed(t, e, s, o) { super.updateRangeFromParsed(t, e, s, o); let a = s._custom; a && e === this._cachedMeta.vScale && (t.min = Math.min(t.min, a.min), t.max = Math.max(t.max, a.max)); }
    getMaxOverflow() { return 0; }
    getLabelAndValue(t) { let e = this._cachedMeta, { iScale: s, vScale: o } = e, a = this.getParsed(t), r = a._custom, l = si(r) ? "[" + r.start + ", " + r.end + "]" : "" + o.getLabelForValue(a[o.axis]); return { label: "" + s.getLabelForValue(a[s.axis]), value: l }; }
    initialize() { this.enableOptionSharing = !0, super.initialize(); let t = this._cachedMeta; t.stack = this.getDataset().stack; }
    update(t) { let e = this._cachedMeta; this.updateElements(e.data, 0, e.data.length, t); }
    updateElements(t, e, s, o) { let a = o === "reset", { index: r, _cachedMeta: { vScale: l } } = this, c = l.getBasePixel(), h = l.isHorizontal(), d = this._getRuler(), { sharedOptions: u, includeOptions: f } = this._getSharedOptions(e, o); for (let g = e; g < e + s; g++) {
        let p = this.getParsed(g), m = a || L(p[l.axis]) ? { base: c, head: c } : this._calculateBarValuePixels(g), x = this._calculateBarIndexPixels(g, d), b = (p._stacks || {})[l.axis], y = { horizontal: h, base: m.base, enableBorderRadius: !b || si(p._custom) || r === b._top || r === b._bottom, x: h ? m.head : x.center, y: h ? x.center : m.head, height: h ? x.size : Math.abs(m.size), width: h ? Math.abs(m.size) : x.size };
        f && (y.options = u || this.resolveDataElementOptions(g, t[g].active ? "active" : o));
        let M = y.options || t[g].options;
        to(y, M, b, r), io(y, M, d.ratio), this.updateElement(t[g], g, y, o);
    } }
    _getStacks(t, e) { let { iScale: s } = this._cachedMeta, o = s.getMatchingVisibleMetas(this._type).filter(d => d.controller.options.grouped), a = s.options.stacked, r = [], l = this._cachedMeta.controller.getParsed(e), c = l && l[s.axis], h = d => { let u = d._parsed.find(g => g[s.axis] === c), f = u && u[d.vScale.axis]; if (L(f) || isNaN(f))
        return !0; }; for (let d of o)
        if (!(e !== void 0 && h(d)) && ((a === !1 || r.indexOf(d.stack) === -1 || a === void 0 && d.stack === void 0) && r.push(d.stack), d.index === t))
            break; return r.length || r.push(void 0), r; }
    _getStackCount(t) { return this._getStacks(void 0, t).length; }
    _getAxisCount() { return this._getAxis().length; }
    getFirstScaleIdForIndexAxis() { let t = this.chart.scales, e = this.chart.options.indexAxis; return Object.keys(t).filter(s => t[s].axis === e).shift(); }
    _getAxis() { let t = {}, e = this.getFirstScaleIdForIndexAxis(); for (let s of this.chart.data.datasets)
        t[C(this.chart.options.indexAxis === "x" ? s.xAxisID : s.yAxisID, e)] = !0; return Object.keys(t); }
    _getStackIndex(t, e, s) { let o = this._getStacks(t, s), a = e !== void 0 ? o.indexOf(e) : -1; return a === -1 ? o.length - 1 : a; }
    _getRuler() { let t = this.options, e = this._cachedMeta, s = e.iScale, o = [], a, r; for (a = 0, r = e.data.length; a < r; ++a)
        o.push(s.getPixelForValue(this.getParsed(a)[s.axis], a)); let l = t.barThickness; return { min: l || Kn(e), pixels: o, start: s._startPixel, end: s._endPixel, stackCount: this._getStackCount(), scale: s, grouped: t.grouped, ratio: l ? 1 : t.categoryPercentage * t.barPercentage }; }
    _calculateBarValuePixels(t) { let { _cachedMeta: { vScale: e, _stacked: s, index: o }, options: { base: a, minBarLength: r } } = this, l = a || 0, c = this.getParsed(t), h = c._custom, d = si(h), u = c[e.axis], f = 0, g = s ? this.applyStack(e, c, s) : u, p, m; g !== u && (f = g - u, g = u), d && (u = h.barStart, g = h.barEnd - h.barStart, u !== 0 && at(u) !== at(h.barEnd) && (f = 0), f += u); let x = !L(a) && !d ? a : f, b = e.getPixelForValue(x); if (this.chart.getDataVisibility(t) ? p = e.getPixelForValue(f + g) : p = b, m = p - b, Math.abs(m) < r) {
        m = Zn(m, e, l) * r, u === l && (b -= m / 2);
        let y = e.getPixelForDecimal(0), M = e.getPixelForDecimal(1), _ = Math.min(y, M), v = Math.max(y, M);
        b = Math.max(Math.min(b, v), _), p = b + m, s && !d && (c._stacks[e.axis]._visualValues[o] = e.getValueForPixel(p) - e.getValueForPixel(b));
    } if (b === e.getPixelForValue(l)) {
        let y = at(m) * e.getLineWidthForValue(l) / 2;
        b += y, m -= y;
    } return { size: m, base: b, head: p, center: p + m / 2 }; }
    _calculateBarIndexPixels(t, e) { let s = e.scale, o = this.options, a = o.skipNull, r = C(o.maxBarThickness, 1 / 0), l, c, h = this._getAxisCount(); if (e.grouped) {
        let d = a ? this._getStackCount(t) : e.stackCount, u = o.barThickness === "flex" ? qn(t, e, o, d * h) : Gn(t, e, o, d * h), f = this.chart.options.indexAxis === "x" ? this.getDataset().xAxisID : this.getDataset().yAxisID, g = this._getAxis().indexOf(C(f, this.getFirstScaleIdForIndexAxis())), p = this._getStackIndex(this.index, this._cachedMeta.stack, a ? t : void 0) + g;
        l = u.start + u.chunk * p + u.chunk / 2, c = Math.min(r, u.chunk * u.ratio);
    }
    else
        l = s.getPixelForValue(this.getParsed(t)[s.axis], t), c = Math.min(r, e.min * e.ratio); return { base: l - c / 2, head: l + c / 2, center: l, size: c }; }
    draw() { let t = this._cachedMeta, e = t.vScale, s = t.data, o = s.length, a = 0; for (; a < o; ++a)
        this.getParsed(a)[e.axis] !== null && !s[a].hidden && s[a].draw(this._ctx); }
} return n; })(), no = (() => { class n extends xt {
    static id = "bubble";
    static defaults = { datasetElementType: !1, dataElementType: "point", animations: { numbers: { type: "number", properties: ["x", "y", "borderWidth", "radius"] } } };
    static overrides = { scales: { x: { type: "linear" }, y: { type: "linear" } } };
    initialize() { this.enableOptionSharing = !0, super.initialize(); }
    parsePrimitiveData(t, e, s, o) { let a = super.parsePrimitiveData(t, e, s, o); for (let r = 0; r < a.length; r++)
        a[r]._custom = this.resolveDataElementOptions(r + s).radius; return a; }
    parseArrayData(t, e, s, o) { let a = super.parseArrayData(t, e, s, o); for (let r = 0; r < a.length; r++) {
        let l = e[s + r];
        a[r]._custom = C(l[2], this.resolveDataElementOptions(r + s).radius);
    } return a; }
    parseObjectData(t, e, s, o) { let a = super.parseObjectData(t, e, s, o); for (let r = 0; r < a.length; r++) {
        let l = e[s + r];
        a[r]._custom = C(l && l.r && +l.r, this.resolveDataElementOptions(r + s).radius);
    } return a; }
    getMaxOverflow() { let t = this._cachedMeta.data, e = 0; for (let s = t.length - 1; s >= 0; --s)
        e = Math.max(e, t[s].size(this.resolveDataElementOptions(s)) / 2); return e > 0 && e; }
    getLabelAndValue(t) { let e = this._cachedMeta, s = this.chart.data.labels || [], { xScale: o, yScale: a } = e, r = this.getParsed(t), l = o.getLabelForValue(r.x), c = a.getLabelForValue(r.y), h = r._custom; return { label: s[t] || "", value: "(" + l + ", " + c + (h ? ", " + h : "") + ")" }; }
    update(t) { let e = this._cachedMeta.data; this.updateElements(e, 0, e.length, t); }
    updateElements(t, e, s, o) { let a = o === "reset", { iScale: r, vScale: l } = this._cachedMeta, { sharedOptions: c, includeOptions: h } = this._getSharedOptions(e, o), d = r.axis, u = l.axis; for (let f = e; f < e + s; f++) {
        let g = t[f], p = !a && this.getParsed(f), m = {}, x = m[d] = a ? r.getPixelForDecimal(.5) : r.getPixelForValue(p[d]), b = m[u] = a ? l.getBasePixel() : l.getPixelForValue(p[u]);
        m.skip = isNaN(x) || isNaN(b), h && (m.options = c || this.resolveDataElementOptions(f, g.active ? "active" : o), a && (m.options.radius = 0)), this.updateElement(g, f, m, o);
    } }
    resolveDataElementOptions(t, e) { let s = this.getParsed(t), o = super.resolveDataElementOptions(t, e); o.$shared && (o = Object.assign({}, o, { $shared: !1 })); let a = o.radius; return e !== "active" && (o.radius = 0), o.radius += C(s && s._custom, a), o; }
} return n; })();
function oo(n, i, t) { let e = 1, s = 1, o = 0, a = 0; if (i < Y) {
    let r = n, l = r + i, c = Math.cos(r), h = Math.sin(r), d = Math.cos(l), u = Math.sin(l), f = (y, M, _) => jt(y, r, l, !0) ? 1 : Math.max(M, M * t, _, _ * t), g = (y, M, _) => jt(y, r, l, !0) ? -1 : Math.min(M, M * t, _, _ * t), p = f(0, c, d), m = f(Q, h, u), x = g(W, c, d), b = g(W + Q, h, u);
    e = (p - x) / 2, s = (m - b) / 2, o = -(p + x) / 2, a = -(m + b) / 2;
} return { ratioX: e, ratioY: s, offsetX: o, offsetY: a }; }
var Ti = (() => { class n extends xt {
    static id = "doughnut";
    static defaults = { datasetElementType: !1, dataElementType: "arc", animation: { animateRotate: !0, animateScale: !1 }, animations: { numbers: { type: "number", properties: ["circumference", "endAngle", "innerRadius", "outerRadius", "startAngle", "x", "y", "offset", "borderWidth", "spacing"] } }, cutout: "50%", rotation: 0, circumference: 360, radius: "100%", spacing: 0, indexAxis: "r" };
    static descriptors = { _scriptable: t => t !== "spacing", _indexable: t => t !== "spacing" && !t.startsWith("borderDash") && !t.startsWith("hoverBorderDash") };
    static overrides = { aspectRatio: 1, plugins: { legend: { labels: { generateLabels(t) { let e = t.data; if (e.labels.length && e.datasets.length) {
                        let { labels: { pointStyle: s, color: o } } = t.legend.options;
                        return e.labels.map((a, r) => { let c = t.getDatasetMeta(0).controller.getStyle(r); return { text: a, fillStyle: c.backgroundColor, strokeStyle: c.borderColor, fontColor: o, lineWidth: c.borderWidth, pointStyle: s, hidden: !t.getDataVisibility(r), index: r }; });
                    } return []; } }, onClick(t, e, s) { s.chart.toggleDataVisibility(e.index), s.chart.update(); } } } };
    constructor(t, e) { super(t, e), this.enableOptionSharing = !0, this.innerRadius = void 0, this.outerRadius = void 0, this.offsetX = void 0, this.offsetY = void 0; }
    linkScales() { }
    parse(t, e) { let s = this.getDataset().data, o = this._cachedMeta; if (this._parsing === !1)
        o._parsed = s;
    else {
        let a = c => +s[c];
        if (z(s[t])) {
            let { key: c = "value" } = this._parsing;
            a = h => +vt(s[h], c);
        }
        let r, l;
        for (r = t, l = t + e; r < l; ++r)
            o._parsed[r] = a(r);
    } }
    _getRotation() { return tt(this.options.rotation - 90); }
    _getCircumference() { return tt(this.options.circumference); }
    _getRotationExtents() { let t = Y, e = -Y; for (let s = 0; s < this.chart.data.datasets.length; ++s)
        if (this.chart.isDatasetVisible(s) && this.chart.getDatasetMeta(s).type === this._type) {
            let o = this.chart.getDatasetMeta(s).controller, a = o._getRotation(), r = o._getCircumference();
            t = Math.min(t, a), e = Math.max(e, a + r);
        } return { rotation: t, circumference: e - t }; }
    update(t) { let e = this.chart, { chartArea: s } = e, o = this._cachedMeta, a = o.data, r = this.getMaxBorderWidth() + this.getMaxOffset(a) + this.options.spacing, l = Math.max((Math.min(s.width, s.height) - r) / 2, 0), c = Math.min(Ri(this.options.cutout, l), 1), h = this._getRingWeight(this.index), { circumference: d, rotation: u } = this._getRotationExtents(), { ratioX: f, ratioY: g, offsetX: p, offsetY: m } = oo(u, d, c), x = (s.width - r) / f, b = (s.height - r) / g, y = Math.max(Math.min(x, b) / 2, 0), M = Ii(this.options.radius, y), _ = Math.max(M * c, 0), v = (M - _) / this._getVisibleDatasetWeightTotal(); this.offsetX = p * M, this.offsetY = m * M, o.total = this.calculateTotal(), this.outerRadius = M - v * this._getRingWeightOffset(this.index), this.innerRadius = Math.max(this.outerRadius - v * h, 0), this.updateElements(a, 0, a.length, t); }
    _circumference(t, e) { let s = this.options, o = this._cachedMeta, a = this._getCircumference(); return e && s.animation.animateRotate || !this.chart.getDataVisibility(t) || o._parsed[t] === null || o.data[t].hidden ? 0 : this.calculateCircumference(o._parsed[t] * a / Y); }
    updateElements(t, e, s, o) { let a = o === "reset", r = this.chart, l = r.chartArea, h = r.options.animation, d = (l.left + l.right) / 2, u = (l.top + l.bottom) / 2, f = a && h.animateScale, g = f ? 0 : this.innerRadius, p = f ? 0 : this.outerRadius, { sharedOptions: m, includeOptions: x } = this._getSharedOptions(e, o), b = this._getRotation(), y; for (y = 0; y < e; ++y)
        b += this._circumference(y, a); for (y = e; y < e + s; ++y) {
        let M = this._circumference(y, a), _ = t[y], v = { x: d + this.offsetX, y: u + this.offsetY, startAngle: b, endAngle: b + M, circumference: M, outerRadius: p, innerRadius: g };
        x && (v.options = m || this.resolveDataElementOptions(y, _.active ? "active" : o)), b += M, this.updateElement(_, y, v, o);
    } }
    calculateTotal() { let t = this._cachedMeta, e = t.data, s = 0, o; for (o = 0; o < e.length; o++) {
        let a = t._parsed[o];
        a !== null && !isNaN(a) && this.chart.getDataVisibility(o) && !e[o].hidden && (s += Math.abs(a));
    } return s; }
    calculateCircumference(t) { let e = this._cachedMeta.total; return e > 0 && !isNaN(t) ? Y * (Math.abs(t) / e) : 0; }
    getLabelAndValue(t) { let e = this._cachedMeta, s = this.chart, o = s.data.labels || [], a = $t(e._parsed[t], s.options.locale); return { label: o[t] || "", value: a }; }
    getMaxBorderWidth(t) { let e = 0, s = this.chart, o, a, r, l, c; if (!t) {
        for (o = 0, a = s.data.datasets.length; o < a; ++o)
            if (s.isDatasetVisible(o)) {
                r = s.getDatasetMeta(o), t = r.data, l = r.controller;
                break;
            }
    } if (!t)
        return 0; for (o = 0, a = t.length; o < a; ++o)
        c = l.resolveDataElementOptions(o), c.borderAlign !== "inner" && (e = Math.max(e, c.borderWidth || 0, c.hoverBorderWidth || 0)); return e; }
    getMaxOffset(t) { let e = 0; for (let s = 0, o = t.length; s < o; ++s) {
        let a = this.resolveDataElementOptions(s);
        e = Math.max(e, a.offset || 0, a.hoverOffset || 0);
    } return e; }
    _getRingWeightOffset(t) { let e = 0; for (let s = 0; s < t; ++s)
        this.chart.isDatasetVisible(s) && (e += this._getRingWeight(s)); return e; }
    _getRingWeight(t) { return Math.max(C(this.chart.data.datasets[t].weight, 1), 0); }
    _getVisibleDatasetWeightTotal() { return this._getRingWeightOffset(this.chart.data.datasets.length) || 1; }
} return n; })(), ao = (() => { class n extends xt {
    static id = "line";
    static defaults = { datasetElementType: "line", dataElementType: "point", showLine: !0, spanGaps: !1 };
    static overrides = { scales: { _index_: { type: "category" }, _value_: { type: "linear" } } };
    initialize() { this.enableOptionSharing = !0, this.supportsDecimation = !0, super.initialize(); }
    update(t) { let e = this._cachedMeta, { dataset: s, data: o = [], _dataset: a } = e, r = this.chart._animationsDisabled, { start: l, count: c } = Fe(e, o, r); this._drawStart = l, this._drawCount = c, Be(e) && (l = 0, c = o.length), s._chart = this.chart, s._datasetIndex = this.index, s._decimated = !!a._decimated, s.points = o; let h = this.resolveDatasetElementOptions(t); this.options.showLine || (h.borderWidth = 0), h.segment = this.options.segment, this.updateElement(s, void 0, { animated: !r, options: h }, t), this.updateElements(o, l, c, t); }
    updateElements(t, e, s, o) { let a = o === "reset", { iScale: r, vScale: l, _stacked: c, _dataset: h } = this._cachedMeta, { sharedOptions: d, includeOptions: u } = this._getSharedOptions(e, o), f = r.axis, g = l.axis, { spanGaps: p, segment: m } = this.options, x = Mt(p) ? p : Number.POSITIVE_INFINITY, b = this.chart._animationsDisabled || a || o === "none", y = e + s, M = t.length, _ = e > 0 && this.getParsed(e - 1); for (let v = 0; v < M; ++v) {
        let S = t[v], k = b ? S : {};
        if (v < e || v >= y) {
            k.skip = !0;
            continue;
        }
        let w = this.getParsed(v), P = L(w[g]), D = k[f] = r.getPixelForValue(w[f], v), A = k[g] = a || P ? l.getBasePixel() : l.getPixelForValue(c ? this.applyStack(l, w, c) : w[g], v);
        k.skip = isNaN(D) || isNaN(A) || P, k.stop = v > 0 && Math.abs(w[f] - _[f]) > x, m && (k.parsed = w, k.raw = h.data[v]), u && (k.options = d || this.resolveDataElementOptions(v, S.active ? "active" : o)), b || this.updateElement(S, v, k, o), _ = w;
    } }
    getMaxOverflow() { let t = this._cachedMeta, e = t.dataset, s = e.options && e.options.borderWidth || 0, o = t.data || []; if (!o.length)
        return s; let a = o[0].size(this.resolveDataElementOptions(0)), r = o[o.length - 1].size(this.resolveDataElementOptions(o.length - 1)); return Math.max(s, a, r) / 2; }
    draw() { let t = this._cachedMeta; t.dataset.updateControlPoints(this.chart.chartArea, t.iScale.axis), super.draw(); }
} return n; })(), mn = (() => { class n extends xt {
    static id = "polarArea";
    static defaults = { dataElementType: "arc", animation: { animateRotate: !0, animateScale: !0 }, animations: { numbers: { type: "number", properties: ["x", "y", "startAngle", "endAngle", "innerRadius", "outerRadius"] } }, indexAxis: "r", startAngle: 0 };
    static overrides = { aspectRatio: 1, plugins: { legend: { labels: { generateLabels(t) { let e = t.data; if (e.labels.length && e.datasets.length) {
                        let { labels: { pointStyle: s, color: o } } = t.legend.options;
                        return e.labels.map((a, r) => { let c = t.getDatasetMeta(0).controller.getStyle(r); return { text: a, fillStyle: c.backgroundColor, strokeStyle: c.borderColor, fontColor: o, lineWidth: c.borderWidth, pointStyle: s, hidden: !t.getDataVisibility(r), index: r }; });
                    } return []; } }, onClick(t, e, s) { s.chart.toggleDataVisibility(e.index), s.chart.update(); } } }, scales: { r: { type: "radialLinear", angleLines: { display: !1 }, beginAtZero: !0, grid: { circular: !0 }, pointLabels: { display: !1 }, startAngle: 0 } } };
    constructor(t, e) { super(t, e), this.innerRadius = void 0, this.outerRadius = void 0; }
    getLabelAndValue(t) { let e = this._cachedMeta, s = this.chart, o = s.data.labels || [], a = $t(e._parsed[t].r, s.options.locale); return { label: o[t] || "", value: a }; }
    parseObjectData(t, e, s, o) { return Ye.bind(this)(t, e, s, o); }
    update(t) { let e = this._cachedMeta.data; this._updateRadius(), this.updateElements(e, 0, e.length, t); }
    getMinMax() { let t = this._cachedMeta, e = { min: Number.POSITIVE_INFINITY, max: Number.NEGATIVE_INFINITY }; return t.data.forEach((s, o) => { let a = this.getParsed(o).r; !isNaN(a) && this.chart.getDataVisibility(o) && (a < e.min && (e.min = a), a > e.max && (e.max = a)); }), e; }
    _updateRadius() { let t = this.chart, e = t.chartArea, s = t.options, o = Math.min(e.right - e.left, e.bottom - e.top), a = Math.max(o / 2, 0), r = Math.max(s.cutoutPercentage ? a / 100 * s.cutoutPercentage : 1, 0), l = (a - r) / t.getVisibleDatasetCount(); this.outerRadius = a - l * this.index, this.innerRadius = this.outerRadius - l; }
    updateElements(t, e, s, o) { let a = o === "reset", r = this.chart, c = r.options.animation, h = this._cachedMeta.rScale, d = h.xCenter, u = h.yCenter, f = h.getIndexAngle(0) - .5 * W, g = f, p, m = 360 / this.countVisibleElements(); for (p = 0; p < e; ++p)
        g += this._computeAngle(p, o, m); for (p = e; p < e + s; p++) {
        let x = t[p], b = g, y = g + this._computeAngle(p, o, m), M = r.getDataVisibility(p) ? h.getDistanceFromCenterForValue(this.getParsed(p).r) : 0;
        g = y, a && (c.animateScale && (M = 0), c.animateRotate && (b = y = f));
        let _ = { x: d, y: u, innerRadius: 0, outerRadius: M, startAngle: b, endAngle: y, options: this.resolveDataElementOptions(p, x.active ? "active" : o) };
        this.updateElement(x, p, _, o);
    } }
    countVisibleElements() { let t = this._cachedMeta, e = 0; return t.data.forEach((s, o) => { !isNaN(this.getParsed(o).r) && this.chart.getDataVisibility(o) && e++; }), e; }
    _computeAngle(t, e, s) { return this.chart.getDataVisibility(t) ? tt(this.resolveDataElementOptions(t, e).angle || s) : 0; }
} return n; })(), ro = (() => { class n extends Ti {
    static id = "pie";
    static defaults = { cutout: 0, rotation: 0, circumference: 360, radius: "100%" };
} return n; })(), lo = (() => { class n extends xt {
    static id = "radar";
    static defaults = { datasetElementType: "line", dataElementType: "point", indexAxis: "r", showLine: !0, elements: { line: { fill: "start" } } };
    static overrides = { aspectRatio: 1, scales: { r: { type: "radialLinear" } } };
    getLabelAndValue(t) { let e = this._cachedMeta.vScale, s = this.getParsed(t); return { label: e.getLabels()[t], value: "" + e.getLabelForValue(s[e.axis]) }; }
    parseObjectData(t, e, s, o) { return Ye.bind(this)(t, e, s, o); }
    update(t) { let e = this._cachedMeta, s = e.dataset, o = e.data || [], a = e.iScale.getLabels(); if (s.points = o, t !== "resize") {
        let r = this.resolveDatasetElementOptions(t);
        this.options.showLine || (r.borderWidth = 0);
        let l = { _loop: !0, _fullLoop: a.length === o.length, options: r };
        this.updateElement(s, void 0, l, t);
    } this.updateElements(o, 0, o.length, t); }
    updateElements(t, e, s, o) { let a = this._cachedMeta.rScale, r = o === "reset"; for (let l = e; l < e + s; l++) {
        let c = t[l], h = this.resolveDataElementOptions(l, c.active ? "active" : o), d = a.getPointPositionForValue(l, this.getParsed(l).r), u = r ? a.xCenter : d.x, f = r ? a.yCenter : d.y, g = { x: u, y: f, angle: d.angle, skip: isNaN(u) || isNaN(f), options: h };
        this.updateElement(c, l, g, o);
    } }
} return n; })(), co = (() => { class n extends xt {
    static id = "scatter";
    static defaults = { datasetElementType: !1, dataElementType: "point", showLine: !1, fill: !1 };
    static overrides = { interaction: { mode: "point" }, scales: { x: { type: "linear" }, y: { type: "linear" } } };
    getLabelAndValue(t) { let e = this._cachedMeta, s = this.chart.data.labels || [], { xScale: o, yScale: a } = e, r = this.getParsed(t), l = o.getLabelForValue(r.x), c = a.getLabelForValue(r.y); return { label: s[t] || "", value: "(" + l + ", " + c + ")" }; }
    update(t) { let e = this._cachedMeta, { data: s = [] } = e, o = this.chart._animationsDisabled, { start: a, count: r } = Fe(e, s, o); if (this._drawStart = a, this._drawCount = r, Be(e) && (a = 0, r = s.length), this.options.showLine) {
        this.datasetElementType || this.addElements();
        let { dataset: l, _dataset: c } = e;
        l._chart = this.chart, l._datasetIndex = this.index, l._decimated = !!c._decimated, l.points = s;
        let h = this.resolveDatasetElementOptions(t);
        h.segment = this.options.segment, this.updateElement(l, void 0, { animated: !o, options: h }, t);
    }
    else
        this.datasetElementType && (delete e.dataset, this.datasetElementType = !1); this.updateElements(s, a, r, t); }
    addElements() { let { showLine: t } = this.options; !this.datasetElementType && t && (this.datasetElementType = this.chart.registry.getElement("line")), super.addElements(); }
    updateElements(t, e, s, o) { let a = o === "reset", { iScale: r, vScale: l, _stacked: c, _dataset: h } = this._cachedMeta, d = this.resolveDataElementOptions(e, o), u = this.getSharedOptions(d), f = this.includeOptions(o, u), g = r.axis, p = l.axis, { spanGaps: m, segment: x } = this.options, b = Mt(m) ? m : Number.POSITIVE_INFINITY, y = this.chart._animationsDisabled || a || o === "none", M = e > 0 && this.getParsed(e - 1); for (let _ = e; _ < e + s; ++_) {
        let v = t[_], S = this.getParsed(_), k = y ? v : {}, w = L(S[p]), P = k[g] = r.getPixelForValue(S[g], _), D = k[p] = a || w ? l.getBasePixel() : l.getPixelForValue(c ? this.applyStack(l, S, c) : S[p], _);
        k.skip = isNaN(P) || isNaN(D) || w, k.stop = _ > 0 && Math.abs(S[g] - M[g]) > b, x && (k.parsed = S, k.raw = h.data[_]), f && (k.options = u || this.resolveDataElementOptions(_, v.active ? "active" : o)), y || this.updateElement(v, _, k, o), M = S;
    } this.updateSharedOptions(u, o, d); }
    getMaxOverflow() { let t = this._cachedMeta, e = t.data || []; if (!this.options.showLine) {
        let l = 0;
        for (let c = e.length - 1; c >= 0; --c)
            l = Math.max(l, e[c].size(this.resolveDataElementOptions(c)) / 2);
        return l > 0 && l;
    } let s = t.dataset, o = s.options && s.options.borderWidth || 0; if (!e.length)
        return o; let a = e[0].size(this.resolveDataElementOptions(0)), r = e[e.length - 1].size(this.resolveDataElementOptions(e.length - 1)); return Math.max(o, a, r) / 2; }
} return n; })(), ho = Object.freeze({ __proto__: null, BarController: so, BubbleController: no, DoughnutController: Ti, LineController: ao, PieController: ro, PolarAreaController: mn, RadarController: lo, ScatterController: co });
function wt() { throw new Error("This method is not implemented: Check that a complete date adapter is provided."); }
var fi = class n {
    static override(i) { Object.assign(n.prototype, i); }
    options;
    constructor(i) { this.options = i || {}; }
    init() { }
    formats() { return wt(); }
    parse() { return wt(); }
    format() { return wt(); }
    add() { return wt(); }
    diff() { return wt(); }
    startOf() { return wt(); }
    endOf() { return wt(); }
}, uo = { _date: fi };
function fo(n, i, t, e) { let { controller: s, data: o, _sorted: a } = n, r = s._cachedMeta.iScale, l = n.dataset && n.dataset.options ? n.dataset.options.spanGaps : null; if (r && i === r.axis && i !== "r" && a && o.length) {
    let c = r._reversePixels ? $i : Tt;
    if (e) {
        if (s._sharedOptions) {
            let h = o[0], d = typeof h.getRange == "function" && h.getRange(i);
            if (d) {
                let u = c(o, i, t - d), f = c(o, i, t + d);
                return { lo: u.lo, hi: f.hi };
            }
        }
    }
    else {
        let h = c(o, i, t);
        if (l) {
            let { vScale: d } = s._cachedMeta, { _parsed: u } = n, f = u.slice(0, h.lo + 1).reverse().findIndex(p => !L(p[d.axis]));
            h.lo -= Math.max(0, f);
            let g = u.slice(h.hi).findIndex(p => !L(p[d.axis]));
            h.hi += Math.max(0, g);
        }
        return h;
    }
} return { lo: 0, hi: o.length - 1 }; }
function se(n, i, t, e, s) { let o = n.getSortedVisibleDatasetMetas(), a = t[i]; for (let r = 0, l = o.length; r < l; ++r) {
    let { index: c, data: h } = o[r], { lo: d, hi: u } = fo(o[r], i, a, s);
    for (let f = d; f <= u; ++f) {
        let g = h[f];
        g.skip || e(g, c, f);
    }
} }
function go(n) { let i = n.indexOf("x") !== -1, t = n.indexOf("y") !== -1; return function (e, s) { let o = i ? Math.abs(e.x - s.x) : 0, a = t ? Math.abs(e.y - s.y) : 0; return Math.sqrt(Math.pow(o, 2) + Math.pow(a, 2)); }; }
function ni(n, i, t, e, s) { let o = []; return !s && !n.isPointInArea(i) || se(n, t, i, function (r, l, c) { !s && !ut(r, n.chartArea, 0) || r.inRange(i.x, i.y, e) && o.push({ element: r, datasetIndex: l, index: c }); }, !0), o; }
function po(n, i, t, e) { let s = []; function o(a, r, l) { let { startAngle: c, endAngle: h } = a.getProps(["startAngle", "endAngle"], e), { angle: d } = Ee(a, { x: i.x, y: i.y }); jt(d, c, h) && s.push({ element: a, datasetIndex: r, index: l }); } return se(n, t, i, o), s; }
function mo(n, i, t, e, s, o) { let a = [], r = go(t), l = Number.POSITIVE_INFINITY; function c(h, d, u) { let f = h.inRange(i.x, i.y, s); if (e && !f)
    return; let g = h.getCenterPoint(s); if (!(!!o || n.isPointInArea(g)) && !f)
    return; let m = r(i, g); m < l ? (a = [{ element: h, datasetIndex: d, index: u }], l = m) : m === l && a.push({ element: h, datasetIndex: d, index: u }); } return se(n, t, i, c), a; }
function oi(n, i, t, e, s, o) { return !o && !n.isPointInArea(i) ? [] : t === "r" && !e ? po(n, i, t, s) : mo(n, i, t, e, s, o); }
function Ms(n, i, t, e, s) { let o = [], a = t === "x" ? "inXRange" : "inYRange", r = !1; return se(n, t, i, (l, c, h) => { l[a] && l[a](i[t], s) && (o.push({ element: l, datasetIndex: c, index: h }), r = r || l.inRange(i.x, i.y, s)); }), e && !r ? [] : o; }
var bo = { evaluateInteractionItems: se, modes: { index(n, i, t, e) { let s = mt(i, n), o = t.axis || "x", a = t.includeInvisible || !1, r = t.intersect ? ni(n, s, o, e, a) : oi(n, s, o, !1, e, a), l = []; return r.length ? (n.getSortedVisibleDatasetMetas().forEach(c => { let h = r[0].index, d = c.data[h]; d && !d.skip && l.push({ element: d, datasetIndex: c.index, index: h }); }), l) : []; }, dataset(n, i, t, e) { let s = mt(i, n), o = t.axis || "xy", a = t.includeInvisible || !1, r = t.intersect ? ni(n, s, o, e, a) : oi(n, s, o, !1, e, a); if (r.length > 0) {
            let l = r[0].datasetIndex, c = n.getDatasetMeta(l).data;
            r = [];
            for (let h = 0; h < c.length; ++h)
                r.push({ element: c[h], datasetIndex: l, index: h });
        } return r; }, point(n, i, t, e) { let s = mt(i, n), o = t.axis || "xy", a = t.includeInvisible || !1; return ni(n, s, o, e, a); }, nearest(n, i, t, e) { let s = mt(i, n), o = t.axis || "xy", a = t.includeInvisible || !1; return oi(n, s, o, t.intersect, e, a); }, x(n, i, t, e) { let s = mt(i, n); return Ms(n, s, "x", t.intersect, e); }, y(n, i, t, e) { let s = mt(i, n); return Ms(n, s, "y", t.intersect, e); } } }, bn = ["left", "top", "right", "bottom"];
function Kt(n, i) { return n.filter(t => t.pos === i); }
function ks(n, i) { return n.filter(t => bn.indexOf(t.pos) === -1 && t.box.axis === i); }
function Gt(n, i) { return n.sort((t, e) => { let s = i ? e : t, o = i ? t : e; return s.weight === o.weight ? s.index - o.index : s.weight - o.weight; }); }
function xo(n) { let i = [], t, e, s, o, a, r; for (t = 0, e = (n || []).length; t < e; ++t)
    s = n[t], { position: o, options: { stack: a, stackWeight: r = 1 } } = s, i.push({ index: t, box: s, pos: o, horizontal: s.isHorizontal(), weight: s.weight, stack: a && o + a, stackWeight: r }); return i; }
function _o(n) { let i = {}; for (let t of n) {
    let { stack: e, pos: s, stackWeight: o } = t;
    if (!e || !bn.includes(s))
        continue;
    let a = i[e] || (i[e] = { count: 0, placed: 0, weight: 0, size: 0 });
    a.count++, a.weight += o;
} return i; }
function yo(n, i) { let t = _o(n), { vBoxMaxWidth: e, hBoxMaxHeight: s } = i, o, a, r; for (o = 0, a = n.length; o < a; ++o) {
    r = n[o];
    let { fullSize: l } = r.box, c = t[r.stack], h = c && r.stackWeight / c.weight;
    r.horizontal ? (r.width = h ? h * e : l && i.availableWidth, r.height = s) : (r.width = e, r.height = h ? h * s : l && i.availableHeight);
} return t; }
function vo(n) { let i = xo(n), t = Gt(i.filter(c => c.box.fullSize), !0), e = Gt(Kt(i, "left"), !0), s = Gt(Kt(i, "right")), o = Gt(Kt(i, "top"), !0), a = Gt(Kt(i, "bottom")), r = ks(i, "x"), l = ks(i, "y"); return { fullSize: t, leftAndTop: e.concat(o), rightAndBottom: s.concat(l).concat(a).concat(r), chartArea: Kt(i, "chartArea"), vertical: e.concat(s).concat(l), horizontal: o.concat(a).concat(r) }; }
function Ss(n, i, t, e) { return Math.max(n[t], i[t]) + Math.max(n[e], i[e]); }
function xn(n, i) { n.top = Math.max(n.top, i.top), n.left = Math.max(n.left, i.left), n.bottom = Math.max(n.bottom, i.bottom), n.right = Math.max(n.right, i.right); }
function Mo(n, i, t, e) { let { pos: s, box: o } = t, a = n.maxPadding; if (!z(s)) {
    t.size && (n[s] -= t.size);
    let d = e[t.stack] || { size: 0, count: 1 };
    d.size = Math.max(d.size, t.horizontal ? o.height : o.width), t.size = d.size / d.count, n[s] += t.size;
} o.getPadding && xn(a, o.getPadding()); let r = Math.max(0, i.outerWidth - Ss(a, n, "left", "right")), l = Math.max(0, i.outerHeight - Ss(a, n, "top", "bottom")), c = r !== n.w, h = l !== n.h; return n.w = r, n.h = l, t.horizontal ? { same: c, other: h } : { same: h, other: c }; }
function ko(n) { let i = n.maxPadding; function t(e) { let s = Math.max(i[e] - n[e], 0); return n[e] += s, s; } n.y += t("top"), n.x += t("left"), t("right"), t("bottom"); }
function So(n, i) { let t = i.maxPadding; function e(s) { let o = { left: 0, top: 0, right: 0, bottom: 0 }; return s.forEach(a => { o[a] = Math.max(i[a], t[a]); }), o; } return e(n ? ["left", "right"] : ["top", "bottom"]); }
function Zt(n, i, t, e) { let s = [], o, a, r, l, c, h; for (o = 0, a = n.length, c = 0; o < a; ++o) {
    r = n[o], l = r.box, l.update(r.width || i.w, r.height || i.h, So(r.horizontal, i));
    let { same: d, other: u } = Mo(i, t, r, e);
    c |= d && s.length, h = h || u, l.fullSize || s.push(r);
} return c && Zt(s, i, t, e) || h; }
function ue(n, i, t, e, s) { n.top = t, n.left = i, n.right = i + e, n.bottom = t + s, n.width = e, n.height = s; }
function ws(n, i, t, e) { let s = t.padding, { x: o, y: a } = i; for (let r of n) {
    let l = r.box, c = e[r.stack] || { count: 1, placed: 0, weight: 1 }, h = r.stackWeight / c.weight || 1;
    if (r.horizontal) {
        let d = i.w * h, u = c.size || l.height;
        Lt(c.start) && (a = c.start), l.fullSize ? ue(l, s.left, a, t.outerWidth - s.right - s.left, u) : ue(l, i.left + c.placed, a, d, u), c.start = a, c.placed += d, a = l.bottom;
    }
    else {
        let d = i.h * h, u = c.size || l.width;
        Lt(c.start) && (o = c.start), l.fullSize ? ue(l, o, s.top, u, t.outerHeight - s.bottom - s.top) : ue(l, o, i.top + c.placed, u, d), c.start = o, c.placed += d, o = l.right;
    }
} i.x = o, i.y = a; }
var X = { addBox(n, i) { n.boxes || (n.boxes = []), i.fullSize = i.fullSize || !1, i.position = i.position || "top", i.weight = i.weight || 0, i._layers = i._layers || function () { return [{ z: 0, draw(t) { i.draw(t); } }]; }, n.boxes.push(i); }, removeBox(n, i) { let t = n.boxes ? n.boxes.indexOf(i) : -1; t !== -1 && n.boxes.splice(t, 1); }, configure(n, i, t) { i.fullSize = t.fullSize, i.position = t.position, i.weight = t.weight; }, update(n, i, t, e) { if (!n)
        return; let s = j(n.options.layout.padding), o = Math.max(i - s.width, 0), a = Math.max(t - s.height, 0), r = vo(n.boxes), l = r.vertical, c = r.horizontal; O(n.boxes, p => { typeof p.beforeLayout == "function" && p.beforeLayout(); }); let h = l.reduce((p, m) => m.box.options && m.box.options.display === !1 ? p : p + 1, 0) || 1, d = Object.freeze({ outerWidth: i, outerHeight: t, padding: s, availableWidth: o, availableHeight: a, vBoxMaxWidth: o / 2 / h, hBoxMaxHeight: a / 2 }), u = Object.assign({}, s); xn(u, j(e)); let f = Object.assign({ maxPadding: u, w: o, h: a, x: s.left, y: s.top }, s), g = yo(l.concat(c), d); Zt(r.fullSize, f, d, g), Zt(l, f, d, g), Zt(c, f, d, g) && Zt(l, f, d, g), ko(f), ws(r.leftAndTop, f, d, g), f.x += f.w, f.y += f.h, ws(r.rightAndBottom, f, d, g), n.chartArea = { left: f.left, top: f.top, right: f.left + f.w, bottom: f.top + f.h, height: f.h, width: f.w }, O(r.chartArea, p => { let m = p.box; Object.assign(m, n.chartArea), m.update(f.w, f.h, { left: 0, top: 0, right: 0, bottom: 0 }); }); } }, ve = class {
    acquireContext(i, t) { }
    releaseContext(i) { return !1; }
    addEventListener(i, t, e) { }
    removeEventListener(i, t, e) { }
    getDevicePixelRatio() { return 1; }
    getMaximumSize(i, t, e, s) { return t = Math.max(0, t || i.width), e = e || i.height, { width: t, height: Math.max(0, s ? Math.floor(t / s) : e) }; }
    isAttached(i) { return !0; }
    updateConfig(i) { }
}, gi = class extends ve {
    acquireContext(i) { return i && i.getContext && i.getContext("2d") || null; }
    updateConfig(i) { i.options.animation = !1; }
}, xe = "$chartjs", wo = { touchstart: "mousedown", touchmove: "mousemove", touchend: "mouseup", pointerenter: "mouseenter", pointerdown: "mousedown", pointermove: "mousemove", pointerup: "mouseup", pointerleave: "mouseout", pointerout: "mouseout" }, Ds = n => n === null || n === "";
function Do(n, i) { let t = n.style, e = n.getAttribute("height"), s = n.getAttribute("width"); if (n[xe] = { initial: { height: e, width: s, style: { display: t.display, height: t.height, width: t.width } } }, t.display = t.display || "block", t.boxSizing = t.boxSizing || "border-box", Ds(s)) {
    let o = Ge(n, "width");
    o !== void 0 && (n.width = o);
} if (Ds(e))
    if (n.style.height === "")
        n.height = n.width / (i || 2);
    else {
        let o = Ge(n, "height");
        o !== void 0 && (n.height = o);
    } return n; }
var _n = rs ? { passive: !0 } : !1;
function Po(n, i, t) { n && n.addEventListener(i, t, _n); }
function Co(n, i, t) { n && n.canvas && n.canvas.removeEventListener(i, t, _n); }
function Ao(n, i) { let t = wo[n.type] || n.type, { x: e, y: s } = mt(n, i); return { type: t, chart: i, native: n, x: e !== void 0 ? e : null, y: s !== void 0 ? s : null }; }
function Me(n, i) { for (let t of n)
    if (t === i || t.contains(i))
        return !0; }
function Lo(n, i, t) { let e = n.canvas, s = new MutationObserver(o => { let a = !1; for (let r of o)
    a = a || Me(r.addedNodes, e), a = a && !Me(r.removedNodes, e); a && t(); }); return s.observe(document, { childList: !0, subtree: !0 }), s; }
function Oo(n, i, t) { let e = n.canvas, s = new MutationObserver(o => { let a = !1; for (let r of o)
    a = a || Me(r.removedNodes, e), a = a && !Me(r.addedNodes, e); a && t(); }); return s.observe(document, { childList: !0, subtree: !0 }), s; }
var te = new Map, Ps = 0;
function yn() { let n = window.devicePixelRatio; n !== Ps && (Ps = n, te.forEach((i, t) => { t.currentDevicePixelRatio !== n && i(); })); }
function To(n, i) { te.size || window.addEventListener("resize", yn), te.set(n, i); }
function Eo(n) { te.delete(n), te.size || window.removeEventListener("resize", yn); }
function Ro(n, i, t) { let e = n.canvas, s = e && Xe(e); if (!s)
    return; let o = ze((r, l) => { let c = s.clientWidth; t(r, l), c < s.clientWidth && t(); }, window), a = new ResizeObserver(r => { let l = r[0], c = l.contentRect.width, h = l.contentRect.height; c === 0 && h === 0 || o(c, h); }); return a.observe(s), To(n, o), a; }
function ai(n, i, t) { t && t.disconnect(), i === "resize" && Eo(n); }
function Io(n, i, t) { let e = n.canvas, s = ze(o => { n.ctx !== null && t(Ao(o, n)); }, n); return Po(e, i, s), s; }
var pi = class extends ve {
    acquireContext(i, t) { let e = i && i.getContext && i.getContext("2d"); return e && e.canvas === i ? (Do(i, t), e) : null; }
    releaseContext(i) { let t = i.canvas; if (!t[xe])
        return !1; let e = t[xe].initial; ["height", "width"].forEach(o => { let a = e[o]; L(a) ? t.removeAttribute(o) : t.setAttribute(o, a); }); let s = e.style || {}; return Object.keys(s).forEach(o => { t.style[o] = s[o]; }), t.width = t.width, delete t[xe], !0; }
    addEventListener(i, t, e) { this.removeEventListener(i, t); let s = i.$proxies || (i.$proxies = {}), a = { attach: Lo, detach: Oo, resize: Ro }[t] || Io; s[t] = a(i, t, e); }
    removeEventListener(i, t) { let e = i.$proxies || (i.$proxies = {}), s = e[t]; if (!s)
        return; ({ attach: ai, detach: ai, resize: ai }[t] || Co)(i, t, s), e[t] = void 0; }
    getDevicePixelRatio() { return window.devicePixelRatio; }
    getMaximumSize(i, t, e, s) { return as(i, t, e, s); }
    isAttached(i) { let t = i && Xe(i); return !!(t && t.isConnected); }
};
function zo(n) { return !Ue() || typeof OffscreenCanvas < "u" && n instanceof OffscreenCanvas ? gi : pi; }
var it = class {
    static defaults = {};
    static defaultRoutes = void 0;
    x;
    y;
    active = !1;
    options;
    $animations;
    tooltipPosition(i) { let { x: t, y: e } = this.getProps(["x", "y"], i); return { x: t, y: e }; }
    hasValue() { return Mt(this.x) && Mt(this.y); }
    getProps(i, t) { let e = this.$animations; if (!t || !e)
        return this; let s = {}; return i.forEach(o => { s[o] = e[o] && e[o].active() ? e[o]._to : this[o]; }), s; }
};
function Fo(n, i) { let t = n.options.ticks, e = Bo(n), s = Math.min(t.maxTicksLimit || e, e), o = t.major.enabled ? No(i) : [], a = o.length, r = o[0], l = o[a - 1], c = []; if (a > s)
    return Wo(i, c, o, a / s), c; let h = Vo(o, i, s); if (a > 0) {
    let d, u, f = a > 1 ? Math.round((l - r) / (a - 1)) : null;
    for (fe(i, c, h, L(f) ? 0 : r - f, r), d = 0, u = a - 1; d < u; d++)
        fe(i, c, h, o[d], o[d + 1]);
    return fe(i, c, h, l, L(f) ? i.length : l + f), c;
} return fe(i, c, h), c; }
function Bo(n) { let i = n.options.offset, t = n._tickSize(), e = n._length / t + (i ? 0 : 1), s = n._maxLength / t; return Math.floor(Math.min(e, s)); }
function Vo(n, i, t) { let e = Ho(n), s = i.length / t; if (!e)
    return Math.max(s, 1); let o = Vi(e); for (let a = 0, r = o.length - 1; a < r; a++) {
    let l = o[a];
    if (l > s)
        return l;
} return Math.max(s, 1); }
function No(n) { let i = [], t, e; for (t = 0, e = n.length; t < e; t++)
    n[t].major && i.push(t); return i; }
function Wo(n, i, t, e) { let s = 0, o = t[0], a; for (e = Math.ceil(e), a = 0; a < n.length; a++)
    a === o && (i.push(n[a]), s++, o = t[s * e]); }
function fe(n, i, t, e, s) { let o = C(e, 0), a = Math.min(C(s, n.length), n.length), r = 0, l, c, h; for (t = Math.ceil(t), s && (l = s - e, t = l / Math.floor(l / t)), h = o; h < 0;)
    r++, h = Math.round(o + r * t); for (c = Math.max(o, 0); c < a; c++)
    c === h && (i.push(n[c]), r++, h = Math.round(o + r * t)); }
function Ho(n) { let i = n.length, t, e; if (i < 2)
    return !1; for (e = n[0], t = 1; t < i; ++t)
    if (n[t] - n[t - 1] !== e)
        return !1; return e; }
var jo = n => n === "left" ? "right" : n === "right" ? "left" : n, Cs = (n, i, t) => i === "top" || i === "left" ? n[i] + t : n[i] - t, As = (n, i) => Math.min(i || n, n);
function Ls(n, i) { let t = [], e = n.length / i, s = n.length, o = 0; for (; o < s; o += e)
    t.push(n[Math.floor(o)]); return t; }
function $o(n, i, t) { let e = n.ticks.length, s = Math.min(i, e - 1), o = n._startPixel, a = n._endPixel, r = 1e-6, l = n.getPixelForTick(s), c; if (!(t && (e === 1 ? c = Math.max(l - o, a - l) : i === 0 ? c = (n.getPixelForTick(1) - l) / 2 : c = (l - n.getPixelForTick(s - 1)) / 2, l += s < i ? c : -c, l < o - r || l > a + r)))
    return l; }
function Yo(n, i) { O(n, t => { let e = t.gc, s = e.length / 2, o; if (s > i) {
    for (o = 0; o < s; ++o)
        delete t.data[e[o]];
    e.splice(0, s);
} }); }
function qt(n) { return n.drawTicks ? n.tickLength : 0; }
function Os(n, i) { if (!n.display)
    return 0; let t = V(n.font, i), e = j(n.padding); return (K(n.text) ? n.text.length : 1) * t.lineHeight + e.height; }
function Uo(n, i) { return pt(n, { scale: i, type: "scale" }); }
function Xo(n, i, t) { return pt(n, { tick: t, index: i, type: "tick" }); }
function Ko(n, i, t) { let e = ce(n); return (t && i !== "right" || !t && i === "right") && (e = jo(e)), e; }
function Go(n, i, t, e) { let { top: s, left: o, bottom: a, right: r, chart: l } = n, { chartArea: c, scales: h } = l, d = 0, u, f, g, p = a - s, m = r - o; if (n.isHorizontal()) {
    if (f = H(e, o, r), z(t)) {
        let x = Object.keys(t)[0], b = t[x];
        g = h[x].getPixelForValue(b) + p - i;
    }
    else
        t === "center" ? g = (c.bottom + c.top) / 2 + p - i : g = Cs(n, t, i);
    u = r - o;
}
else {
    if (z(t)) {
        let x = Object.keys(t)[0], b = t[x];
        f = h[x].getPixelForValue(b) - m + i;
    }
    else
        t === "center" ? f = (c.left + c.right) / 2 - m + i : f = Cs(n, t, i);
    g = H(e, a, s), d = t === "left" ? -Q : Q;
} return { titleX: f, titleY: g, maxWidth: u, rotation: d }; }
var Pt = class n extends it {
    constructor(i) { super(), this.id = i.id, this.type = i.type, this.options = void 0, this.ctx = i.ctx, this.chart = i.chart, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this._margins = { left: 0, right: 0, top: 0, bottom: 0 }, this.maxWidth = void 0, this.maxHeight = void 0, this.paddingTop = void 0, this.paddingBottom = void 0, this.paddingLeft = void 0, this.paddingRight = void 0, this.axis = void 0, this.labelRotation = void 0, this.min = void 0, this.max = void 0, this._range = void 0, this.ticks = [], this._gridLineItems = null, this._labelItems = null, this._labelSizes = null, this._length = 0, this._maxLength = 0, this._longestTextCache = {}, this._startPixel = void 0, this._endPixel = void 0, this._reversePixels = !1, this._userMax = void 0, this._userMin = void 0, this._suggestedMax = void 0, this._suggestedMin = void 0, this._ticksLength = 0, this._borderValue = 0, this._cache = {}, this._dataLimitsCached = !1, this.$context = void 0; }
    init(i) { this.options = i.setContext(this.getContext()), this.axis = i.axis, this._userMin = this.parse(i.min), this._userMax = this.parse(i.max), this._suggestedMin = this.parse(i.suggestedMin), this._suggestedMax = this.parse(i.suggestedMax); }
    parse(i, t) { return i; }
    getUserBounds() { let { _userMin: i, _userMax: t, _suggestedMin: e, _suggestedMax: s } = this; return i = G(i, Number.POSITIVE_INFINITY), t = G(t, Number.NEGATIVE_INFINITY), e = G(e, Number.POSITIVE_INFINITY), s = G(s, Number.NEGATIVE_INFINITY), { min: G(i, e), max: G(t, s), minDefined: B(i), maxDefined: B(t) }; }
    getMinMax(i) { let { min: t, max: e, minDefined: s, maxDefined: o } = this.getUserBounds(), a; if (s && o)
        return { min: t, max: e }; let r = this.getMatchingVisibleMetas(); for (let l = 0, c = r.length; l < c; ++l)
        a = r[l].controller.getMinMax(this, i), s || (t = Math.min(t, a.min)), o || (e = Math.max(e, a.max)); return t = o && t > e ? e : t, e = s && t > e ? t : e, { min: G(t, G(e, t)), max: G(e, G(t, e)) }; }
    getPadding() { return { left: this.paddingLeft || 0, top: this.paddingTop || 0, right: this.paddingRight || 0, bottom: this.paddingBottom || 0 }; }
    getTicks() { return this.ticks; }
    getLabels() { let i = this.chart.data; return this.options.labels || (this.isHorizontal() ? i.xLabels : i.yLabels) || i.labels || []; }
    getLabelItems(i = this.chart.chartArea) { return this._labelItems || (this._labelItems = this._computeLabelItems(i)); }
    beforeLayout() { this._cache = {}, this._dataLimitsCached = !1; }
    beforeUpdate() { E(this.options.beforeUpdate, [this]); }
    update(i, t, e) { let { beginAtZero: s, grace: o, ticks: a } = this.options, r = a.sampleSize; this.beforeUpdate(), this.maxWidth = i, this.maxHeight = t, this._margins = e = Object.assign({ left: 0, right: 0, top: 0, bottom: 0 }, e), this.ticks = null, this._labelSizes = null, this._gridLineItems = null, this._labelItems = null, this.beforeSetDimensions(), this.setDimensions(), this.afterSetDimensions(), this._maxLength = this.isHorizontal() ? this.width + e.left + e.right : this.height + e.top + e.bottom, this._dataLimitsCached || (this.beforeDataLimits(), this.determineDataLimits(), this.afterDataLimits(), this._range = is(this, o, s), this._dataLimitsCached = !0), this.beforeBuildTicks(), this.ticks = this.buildTicks() || [], this.afterBuildTicks(); let l = r < this.ticks.length; this._convertTicksToLabels(l ? Ls(this.ticks, r) : this.ticks), this.configure(), this.beforeCalculateLabelRotation(), this.calculateLabelRotation(), this.afterCalculateLabelRotation(), a.display && (a.autoSkip || a.source === "auto") && (this.ticks = Fo(this, this.ticks), this._labelSizes = null, this.afterAutoSkip()), l && this._convertTicksToLabels(this.ticks), this.beforeFit(), this.fit(), this.afterFit(), this.afterUpdate(); }
    configure() { let i = this.options.reverse, t, e; this.isHorizontal() ? (t = this.left, e = this.right) : (t = this.top, e = this.bottom, i = !i), this._startPixel = t, this._endPixel = e, this._reversePixels = i, this._length = e - t, this._alignToPixels = this.options.alignToPixels; }
    afterUpdate() { E(this.options.afterUpdate, [this]); }
    beforeSetDimensions() { E(this.options.beforeSetDimensions, [this]); }
    setDimensions() { this.isHorizontal() ? (this.width = this.maxWidth, this.left = 0, this.right = this.width) : (this.height = this.maxHeight, this.top = 0, this.bottom = this.height), this.paddingLeft = 0, this.paddingTop = 0, this.paddingRight = 0, this.paddingBottom = 0; }
    afterSetDimensions() { E(this.options.afterSetDimensions, [this]); }
    _callHooks(i) { this.chart.notifyPlugins(i, this.getContext()), E(this.options[i], [this]); }
    beforeDataLimits() { this._callHooks("beforeDataLimits"); }
    determineDataLimits() { }
    afterDataLimits() { this._callHooks("afterDataLimits"); }
    beforeBuildTicks() { this._callHooks("beforeBuildTicks"); }
    buildTicks() { return []; }
    afterBuildTicks() { this._callHooks("afterBuildTicks"); }
    beforeTickToLabelConversion() { E(this.options.beforeTickToLabelConversion, [this]); }
    generateTickLabels(i) { let t = this.options.ticks, e, s, o; for (e = 0, s = i.length; e < s; e++)
        o = i[e], o.label = E(t.callback, [o.value, e, i], this); }
    afterTickToLabelConversion() { E(this.options.afterTickToLabelConversion, [this]); }
    beforeCalculateLabelRotation() { E(this.options.beforeCalculateLabelRotation, [this]); }
    calculateLabelRotation() { let i = this.options, t = i.ticks, e = As(this.ticks.length, i.ticks.maxTicksLimit), s = t.minRotation || 0, o = t.maxRotation, a = s, r, l, c; if (!this._isVisible() || !t.display || s >= o || e <= 1 || !this.isHorizontal()) {
        this.labelRotation = s;
        return;
    } let h = this._getLabelSizes(), d = h.widest.width, u = h.highest.height, f = U(this.chart.width - d, 0, this.maxWidth); r = i.offset ? this.maxWidth / e : f / (e - 1), d + 6 > r && (r = f / (e - (i.offset ? .5 : 1)), l = this.maxHeight - qt(i.grid) - t.padding - Os(i.title, this.chart.options.font), c = Math.sqrt(d * d + u * u), a = le(Math.min(Math.asin(U((h.highest.height + 6) / r, -1, 1)), Math.asin(U(l / c, -1, 1)) - Math.asin(U(u / c, -1, 1)))), a = Math.max(s, Math.min(o, a))), this.labelRotation = a; }
    afterCalculateLabelRotation() { E(this.options.afterCalculateLabelRotation, [this]); }
    afterAutoSkip() { }
    beforeFit() { E(this.options.beforeFit, [this]); }
    fit() { let i = { width: 0, height: 0 }, { chart: t, options: { ticks: e, title: s, grid: o } } = this, a = this._isVisible(), r = this.isHorizontal(); if (a) {
        let l = Os(s, t.options.font);
        if (r ? (i.width = this.maxWidth, i.height = qt(o) + l) : (i.height = this.maxHeight, i.width = qt(o) + l), e.display && this.ticks.length) {
            let { first: c, last: h, widest: d, highest: u } = this._getLabelSizes(), f = e.padding * 2, g = tt(this.labelRotation), p = Math.cos(g), m = Math.sin(g);
            if (r) {
                let x = e.mirror ? 0 : m * d.width + p * u.height;
                i.height = Math.min(this.maxHeight, i.height + x + f);
            }
            else {
                let x = e.mirror ? 0 : p * d.width + m * u.height;
                i.width = Math.min(this.maxWidth, i.width + x + f);
            }
            this._calculatePadding(c, h, m, p);
        }
    } this._handleMargins(), r ? (this.width = this._length = t.width - this._margins.left - this._margins.right, this.height = i.height) : (this.width = i.width, this.height = this._length = t.height - this._margins.top - this._margins.bottom); }
    _calculatePadding(i, t, e, s) { let { ticks: { align: o, padding: a }, position: r } = this.options, l = this.labelRotation !== 0, c = r !== "top" && this.axis === "x"; if (this.isHorizontal()) {
        let h = this.getPixelForTick(0) - this.left, d = this.right - this.getPixelForTick(this.ticks.length - 1), u = 0, f = 0;
        l ? c ? (u = s * i.width, f = e * t.height) : (u = e * i.height, f = s * t.width) : o === "start" ? f = t.width : o === "end" ? u = i.width : o !== "inner" && (u = i.width / 2, f = t.width / 2), this.paddingLeft = Math.max((u - h + a) * this.width / (this.width - h), 0), this.paddingRight = Math.max((f - d + a) * this.width / (this.width - d), 0);
    }
    else {
        let h = t.height / 2, d = i.height / 2;
        o === "start" ? (h = 0, d = i.height) : o === "end" && (h = t.height, d = 0), this.paddingTop = h + a, this.paddingBottom = d + a;
    } }
    _handleMargins() { this._margins && (this._margins.left = Math.max(this.paddingLeft, this._margins.left), this._margins.top = Math.max(this.paddingTop, this._margins.top), this._margins.right = Math.max(this.paddingRight, this._margins.right), this._margins.bottom = Math.max(this.paddingBottom, this._margins.bottom)); }
    afterFit() { E(this.options.afterFit, [this]); }
    isHorizontal() { let { axis: i, position: t } = this.options; return t === "top" || t === "bottom" || i === "x"; }
    isFullSize() { return this.options.fullSize; }
    _convertTicksToLabels(i) { this.beforeTickToLabelConversion(), this.generateTickLabels(i); let t, e; for (t = 0, e = i.length; t < e; t++)
        L(i[t].label) && (i.splice(t, 1), e--, t--); this.afterTickToLabelConversion(); }
    _getLabelSizes() { let i = this._labelSizes; if (!i) {
        let t = this.options.ticks.sampleSize, e = this.ticks;
        t < e.length && (e = Ls(e, t)), this._labelSizes = i = this._computeLabelSizes(e, e.length, this.options.ticks.maxTicksLimit);
    } return i; }
    _computeLabelSizes(i, t, e) { let { ctx: s, _longestTextCache: o } = this, a = [], r = [], l = Math.floor(t / As(t, e)), c = 0, h = 0, d, u, f, g, p, m, x, b, y, M, _; for (d = 0; d < t; d += l) {
        if (g = i[d].label, p = this._resolveTickFontOptions(d), s.font = m = p.string, x = o[m] = o[m] || { data: {}, gc: [] }, b = p.lineHeight, y = M = 0, !L(g) && !K(g))
            y = He(s, x.data, x.gc, y, g), M = b;
        else if (K(g))
            for (u = 0, f = g.length; u < f; ++u)
                _ = g[u], !L(_) && !K(_) && (y = He(s, x.data, x.gc, y, _), M += b);
        a.push(y), r.push(M), c = Math.max(y, c), h = Math.max(M, h);
    } Yo(o, t); let v = a.indexOf(c), S = r.indexOf(h), k = w => ({ width: a[w] || 0, height: r[w] || 0 }); return { first: k(0), last: k(t - 1), widest: k(v), highest: k(S), widths: a, heights: r }; }
    getLabelForValue(i) { return i; }
    getPixelForValue(i, t) { return NaN; }
    getValueForPixel(i) { }
    getPixelForTick(i) { let t = this.ticks; return i < 0 || i > t.length - 1 ? null : this.getPixelForValue(t[i].value); }
    getPixelForDecimal(i) { this._reversePixels && (i = 1 - i); let t = this._startPixel + i * this._length; return Hi(this._alignToPixels ? dt(this.chart, t, 0) : t); }
    getDecimalForPixel(i) { let t = (i - this._startPixel) / this._length; return this._reversePixels ? 1 - t : t; }
    getBasePixel() { return this.getPixelForValue(this.getBaseValue()); }
    getBaseValue() { let { min: i, max: t } = this; return i < 0 && t < 0 ? t : i > 0 && t > 0 ? i : 0; }
    getContext(i) { let t = this.ticks || []; if (i >= 0 && i < t.length) {
        let e = t[i];
        return e.$context || (e.$context = Xo(this.getContext(), i, e));
    } return this.$context || (this.$context = Uo(this.chart.getContext(), this)); }
    _tickSize() { let i = this.options.ticks, t = tt(this.labelRotation), e = Math.abs(Math.cos(t)), s = Math.abs(Math.sin(t)), o = this._getLabelSizes(), a = i.autoSkipPadding || 0, r = o ? o.widest.width + a : 0, l = o ? o.highest.height + a : 0; return this.isHorizontal() ? l * e > r * s ? r / e : l / s : l * s < r * e ? l / e : r / s; }
    _isVisible() { let i = this.options.display; return i !== "auto" ? !!i : this.getMatchingVisibleMetas().length > 0; }
    _computeGridLineItems(i) { let t = this.axis, e = this.chart, s = this.options, { grid: o, position: a, border: r } = s, l = o.offset, c = this.isHorizontal(), d = this.ticks.length + (l ? 1 : 0), u = qt(o), f = [], g = r.setContext(this.getContext()), p = g.display ? g.width : 0, m = p / 2, x = function (R) { return dt(e, R, p); }, b, y, M, _, v, S, k, w, P, D, A, N; if (a === "top")
        b = x(this.bottom), S = this.bottom - u, w = b - m, D = x(i.top) + m, N = i.bottom;
    else if (a === "bottom")
        b = x(this.top), D = i.top, N = x(i.bottom) - m, S = b + m, w = this.top + u;
    else if (a === "left")
        b = x(this.right), v = this.right - u, k = b - m, P = x(i.left) + m, A = i.right;
    else if (a === "right")
        b = x(this.left), P = i.left, A = x(i.right) - m, v = b + m, k = this.left + u;
    else if (t === "x") {
        if (a === "center")
            b = x((i.top + i.bottom) / 2 + .5);
        else if (z(a)) {
            let R = Object.keys(a)[0], F = a[R];
            b = x(this.chart.scales[R].getPixelForValue(F));
        }
        D = i.top, N = i.bottom, S = b + m, w = S + u;
    }
    else if (t === "y") {
        if (a === "center")
            b = x((i.left + i.right) / 2);
        else if (z(a)) {
            let R = Object.keys(a)[0], F = a[R];
            b = x(this.chart.scales[R].getPixelForValue(F));
        }
        v = b - m, k = v - u, P = i.left, A = i.right;
    } let Z = C(s.ticks.maxTicksLimit, d), T = Math.max(1, Math.ceil(d / Z)); for (y = 0; y < d; y += T) {
        let R = this.getContext(y), F = o.setContext(R), et = r.setContext(R), $ = F.lineWidth, Ct = F.color, ne = et.dash || [], At = et.dashOffset, Bt = F.tickWidth, _t = F.tickColor, Vt = F.tickBorderDash || [], yt = F.tickBorderDashOffset;
        M = $o(this, y, l), M !== void 0 && (_ = dt(e, M, $), c ? v = k = P = A = _ : S = w = D = N = _, f.push({ tx1: v, ty1: S, tx2: k, ty2: w, x1: P, y1: D, x2: A, y2: N, width: $, color: Ct, borderDash: ne, borderDashOffset: At, tickWidth: Bt, tickColor: _t, tickBorderDash: Vt, tickBorderDashOffset: yt }));
    } return this._ticksLength = d, this._borderValue = b, f; }
    _computeLabelItems(i) { let t = this.axis, e = this.options, { position: s, ticks: o } = e, a = this.isHorizontal(), r = this.ticks, { align: l, crossAlign: c, padding: h, mirror: d } = o, u = qt(e.grid), f = u + h, g = d ? -h : f, p = -tt(this.labelRotation), m = [], x, b, y, M, _, v, S, k, w, P, D, A, N = "middle"; if (s === "top")
        v = this.bottom - g, S = this._getXAxisLabelAlignment();
    else if (s === "bottom")
        v = this.top + g, S = this._getXAxisLabelAlignment();
    else if (s === "left") {
        let T = this._getYAxisLabelAlignment(u);
        S = T.textAlign, _ = T.x;
    }
    else if (s === "right") {
        let T = this._getYAxisLabelAlignment(u);
        S = T.textAlign, _ = T.x;
    }
    else if (t === "x") {
        if (s === "center")
            v = (i.top + i.bottom) / 2 + f;
        else if (z(s)) {
            let T = Object.keys(s)[0], R = s[T];
            v = this.chart.scales[T].getPixelForValue(R) + f;
        }
        S = this._getXAxisLabelAlignment();
    }
    else if (t === "y") {
        if (s === "center")
            _ = (i.left + i.right) / 2 - f;
        else if (z(s)) {
            let T = Object.keys(s)[0], R = s[T];
            _ = this.chart.scales[T].getPixelForValue(R);
        }
        S = this._getYAxisLabelAlignment(u).textAlign;
    } t === "y" && (l === "start" ? N = "top" : l === "end" && (N = "bottom")); let Z = this._getLabelSizes(); for (x = 0, b = r.length; x < b; ++x) {
        y = r[x], M = y.label;
        let T = o.setContext(this.getContext(x));
        k = this.getPixelForTick(x) + o.labelOffset, w = this._resolveTickFontOptions(x), P = w.lineHeight, D = K(M) ? M.length : 1;
        let R = D / 2, F = T.color, et = T.textStrokeColor, $ = T.textStrokeWidth, Ct = S;
        a ? (_ = k, S === "inner" && (x === b - 1 ? Ct = this.options.reverse ? "left" : "right" : x === 0 ? Ct = this.options.reverse ? "right" : "left" : Ct = "center"), s === "top" ? c === "near" || p !== 0 ? A = -D * P + P / 2 : c === "center" ? A = -Z.highest.height / 2 - R * P + P : A = -Z.highest.height + P / 2 : c === "near" || p !== 0 ? A = P / 2 : c === "center" ? A = Z.highest.height / 2 - R * P : A = Z.highest.height - D * P, d && (A *= -1), p !== 0 && !T.showLabelBackdrop && (_ += P / 2 * Math.sin(p))) : (v = k, A = (1 - D) * P / 2);
        let ne;
        if (T.showLabelBackdrop) {
            let At = j(T.backdropPadding), Bt = Z.heights[x], _t = Z.widths[x], Vt = A - At.top, yt = 0 - At.left;
            switch (N) {
                case "middle":
                    Vt -= Bt / 2;
                    break;
                case "bottom":
                    Vt -= Bt;
                    break;
            }
            switch (S) {
                case "center":
                    yt -= _t / 2;
                    break;
                case "right":
                    yt -= _t;
                    break;
                case "inner":
                    x === b - 1 ? yt -= _t : x > 0 && (yt -= _t / 2);
                    break;
            }
            ne = { left: yt, top: Vt, width: _t + At.width, height: Bt + At.height, color: T.backdropColor };
        }
        m.push({ label: M, font: w, textOffset: A, options: { rotation: p, color: F, strokeColor: et, strokeWidth: $, textAlign: Ct, textBaseline: N, translation: [_, v], backdrop: ne } });
    } return m; }
    _getXAxisLabelAlignment() { let { position: i, ticks: t } = this.options; if (-tt(this.labelRotation))
        return i === "top" ? "left" : "right"; let s = "center"; return t.align === "start" ? s = "left" : t.align === "end" ? s = "right" : t.align === "inner" && (s = "inner"), s; }
    _getYAxisLabelAlignment(i) { let { position: t, ticks: { crossAlign: e, mirror: s, padding: o } } = this.options, a = this._getLabelSizes(), r = i + o, l = a.widest.width, c, h; return t === "left" ? s ? (h = this.right + o, e === "near" ? c = "left" : e === "center" ? (c = "center", h += l / 2) : (c = "right", h += l)) : (h = this.right - r, e === "near" ? c = "right" : e === "center" ? (c = "center", h -= l / 2) : (c = "left", h = this.left)) : t === "right" ? s ? (h = this.left + o, e === "near" ? c = "right" : e === "center" ? (c = "center", h -= l / 2) : (c = "left", h -= l)) : (h = this.left + r, e === "near" ? c = "left" : e === "center" ? (c = "center", h += l / 2) : (c = "right", h = this.right)) : c = "right", { textAlign: c, x: h }; }
    _computeLabelArea() { if (this.options.ticks.mirror)
        return; let i = this.chart, t = this.options.position; if (t === "left" || t === "right")
        return { top: 0, left: this.left, bottom: i.height, right: this.right }; if (t === "top" || t === "bottom")
        return { top: this.top, left: 0, bottom: this.bottom, right: i.width }; }
    drawBackground() { let { ctx: i, options: { backgroundColor: t }, left: e, top: s, width: o, height: a } = this; t && (i.save(), i.fillStyle = t, i.fillRect(e, s, o, a), i.restore()); }
    getLineWidthForValue(i) { let t = this.options.grid; if (!this._isVisible() || !t.display)
        return 0; let s = this.ticks.findIndex(o => o.value === i); return s >= 0 ? t.setContext(this.getContext(s)).lineWidth : 0; }
    drawGrid(i) { let t = this.options.grid, e = this.ctx, s = this._gridLineItems || (this._gridLineItems = this._computeGridLineItems(i)), o, a, r = (l, c, h) => { !h.width || !h.color || (e.save(), e.lineWidth = h.width, e.strokeStyle = h.color, e.setLineDash(h.borderDash || []), e.lineDashOffset = h.borderDashOffset, e.beginPath(), e.moveTo(l.x, l.y), e.lineTo(c.x, c.y), e.stroke(), e.restore()); }; if (t.display)
        for (o = 0, a = s.length; o < a; ++o) {
            let l = s[o];
            t.drawOnChartArea && r({ x: l.x1, y: l.y1 }, { x: l.x2, y: l.y2 }, l), t.drawTicks && r({ x: l.tx1, y: l.ty1 }, { x: l.tx2, y: l.ty2 }, { color: l.tickColor, width: l.tickWidth, borderDash: l.tickBorderDash, borderDashOffset: l.tickBorderDashOffset });
        } }
    drawBorder() { let { chart: i, ctx: t, options: { border: e, grid: s } } = this, o = e.setContext(this.getContext()), a = e.display ? o.width : 0; if (!a)
        return; let r = s.setContext(this.getContext(0)).lineWidth, l = this._borderValue, c, h, d, u; this.isHorizontal() ? (c = dt(i, this.left, a) - a / 2, h = dt(i, this.right, r) + r / 2, d = u = l) : (d = dt(i, this.top, a) - a / 2, u = dt(i, this.bottom, r) + r / 2, c = h = l), t.save(), t.lineWidth = o.width, t.strokeStyle = o.color, t.beginPath(), t.moveTo(c, d), t.lineTo(h, u), t.stroke(), t.restore(); }
    drawLabels(i) { if (!this.options.ticks.display)
        return; let e = this.ctx, s = this._computeLabelArea(); s && Yt(e, s); let o = this.getLabelItems(i); for (let a of o) {
        let r = a.options, l = a.font, c = a.label, h = a.textOffset;
        ft(e, c, 0, h, l, r);
    } s && Ut(e); }
    drawTitle() { let { ctx: i, options: { position: t, title: e, reverse: s } } = this; if (!e.display)
        return; let o = V(e.font), a = j(e.padding), r = e.align, l = o.lineHeight / 2; t === "bottom" || t === "center" || z(t) ? (l += a.bottom, K(e.text) && (l += o.lineHeight * (e.text.length - 1))) : l += a.top; let { titleX: c, titleY: h, maxWidth: d, rotation: u } = Go(this, l, t, r); ft(i, e.text, 0, 0, o, { color: e.color, maxWidth: d, rotation: u, textAlign: Ko(r, t, s), textBaseline: "middle", translation: [c, h] }); }
    draw(i) { this._isVisible() && (this.drawBackground(), this.drawGrid(i), this.drawBorder(), this.drawTitle(), this.drawLabels(i)); }
    _layers() { let i = this.options, t = i.ticks && i.ticks.z || 0, e = C(i.grid && i.grid.z, -1), s = C(i.border && i.border.z, 0); return !this._isVisible() || this.draw !== n.prototype.draw ? [{ z: t, draw: o => { this.draw(o); } }] : [{ z: e, draw: o => { this.drawBackground(), this.drawGrid(o), this.drawTitle(); } }, { z: s, draw: () => { this.drawBorder(); } }, { z: t, draw: o => { this.drawLabels(o); } }]; }
    getMatchingVisibleMetas(i) { let t = this.chart.getSortedVisibleDatasetMetas(), e = this.axis + "AxisID", s = [], o, a; for (o = 0, a = t.length; o < a; ++o) {
        let r = t[o];
        r[e] === this.id && (!i || r.type === i) && s.push(r);
    } return s; }
    _resolveTickFontOptions(i) { let t = this.options.ticks.setContext(this.getContext(i)); return V(t.font); }
    _maxDigits() { let i = this._resolveTickFontOptions(0).lineHeight; return (this.isHorizontal() ? this.width : this.height) / i; }
}, zt = class {
    constructor(i, t, e) { this.type = i, this.scope = t, this.override = e, this.items = Object.create(null); }
    isForType(i) { return Object.prototype.isPrototypeOf.call(this.type.prototype, i.prototype); }
    register(i) { let t = Object.getPrototypeOf(i), e; Zo(t) && (e = this.register(t)); let s = this.items, o = i.id, a = this.scope + "." + o; if (!o)
        throw new Error("class does not have id: " + i); return o in s || (s[o] = i, qo(i, a, e), this.override && I.override(i.id, i.overrides)), a; }
    get(i) { return this.items[i]; }
    unregister(i) { let t = this.items, e = i.id, s = this.scope; e in t && delete t[e], s && e in I[s] && (delete I[s][e], this.override && delete kt[e]); }
};
function qo(n, i, t) { let e = zi(Object.create(null), [t ? I.get(t) : {}, I.get(i), n.defaults]); I.set(i, e), n.defaultRoutes && Jo(i, n.defaultRoutes), n.descriptors && I.describe(i, n.descriptors); }
function Jo(n, i) { Object.keys(i).forEach(t => { let e = t.split("."), s = e.pop(), o = [n].concat(e).join("."), a = i[t].split("."), r = a.pop(), l = a.join("."); I.route(o, s, l, r); }); }
function Zo(n) { return "id" in n && "defaults" in n; }
var mi = class {
    constructor() { this.controllers = new zt(xt, "datasets", !0), this.elements = new zt(it, "elements"), this.plugins = new zt(Object, "plugins"), this.scales = new zt(Pt, "scales"), this._typedRegistries = [this.controllers, this.scales, this.elements]; }
    add(...i) { this._each("register", i); }
    remove(...i) { this._each("unregister", i); }
    addControllers(...i) { this._each("register", i, this.controllers); }
    addElements(...i) { this._each("register", i, this.elements); }
    addPlugins(...i) { this._each("register", i, this.plugins); }
    addScales(...i) { this._each("register", i, this.scales); }
    getController(i) { return this._get(i, this.controllers, "controller"); }
    getElement(i) { return this._get(i, this.elements, "element"); }
    getPlugin(i) { return this._get(i, this.plugins, "plugin"); }
    getScale(i) { return this._get(i, this.scales, "scale"); }
    removeControllers(...i) { this._each("unregister", i, this.controllers); }
    removeElements(...i) { this._each("unregister", i, this.elements); }
    removePlugins(...i) { this._each("unregister", i, this.plugins); }
    removeScales(...i) { this._each("unregister", i, this.scales); }
    _each(i, t, e) { [...t].forEach(s => { let o = e || this._getRegistryForType(s); e || o.isForType(s) || o === this.plugins && s.id ? this._exec(i, o, s) : O(s, a => { let r = e || this._getRegistryForType(a); this._exec(i, r, a); }); }); }
    _exec(i, t, e) { let s = Fi(i); E(e["before" + s], [], e), t[i](e), E(e["after" + s], [], e); }
    _getRegistryForType(i) { for (let t = 0; t < this._typedRegistries.length; t++) {
        let e = this._typedRegistries[t];
        if (e.isForType(i))
            return e;
    } return this.plugins; }
    _get(i, t, e) { let s = t.get(i); if (s === void 0)
        throw new Error('"' + i + '" is not a registered ' + e + "."); return s; }
}, ot = new mi, bi = class {
    constructor() { this._init = []; }
    notify(i, t, e, s) { t === "beforeInit" && (this._init = this._createDescriptors(i, !0), this._notify(this._init, i, "install")); let o = s ? this._descriptors(i).filter(s) : this._descriptors(i), a = this._notify(o, i, t, e); return t === "afterDestroy" && (this._notify(o, i, "stop"), this._notify(this._init, i, "uninstall")), a; }
    _notify(i, t, e, s) { s = s || {}; for (let o of i) {
        let a = o.plugin, r = a[e], l = [t, s, o.options];
        if (E(r, l, a) === !1 && s.cancelable)
            return !1;
    } return !0; }
    invalidate() { L(this._cache) || (this._oldCache = this._cache, this._cache = void 0); }
    _descriptors(i) { if (this._cache)
        return this._cache; let t = this._cache = this._createDescriptors(i); return this._notifyStateChanges(i), t; }
    _createDescriptors(i, t) { let e = i && i.config, s = C(e.options && e.options.plugins, {}), o = Qo(e); return s === !1 && !t ? [] : ea(i, o, s, t); }
    _notifyStateChanges(i) { let t = this._oldCache || [], e = this._cache, s = (o, a) => o.filter(r => !a.some(l => r.plugin.id === l.plugin.id)); this._notify(s(t, e), i, "stop"), this._notify(s(e, t), i, "start"); }
};
function Qo(n) { let i = {}, t = [], e = Object.keys(ot.plugins.items); for (let o = 0; o < e.length; o++)
    t.push(ot.getPlugin(e[o])); let s = n.plugins || []; for (let o = 0; o < s.length; o++) {
    let a = s[o];
    t.indexOf(a) === -1 && (t.push(a), i[a.id] = !0);
} return { plugins: t, localIds: i }; }
function ta(n, i) { return !i && n === !1 ? null : n === !0 ? {} : n; }
function ea(n, { plugins: i, localIds: t }, e, s) { let o = [], a = n.getContext(); for (let r of i) {
    let l = r.id, c = ta(e[l], s);
    c !== null && o.push({ plugin: r, options: ia(n.config, { plugin: r, local: t[l] }, c, a) });
} return o; }
function ia(n, { plugin: i, local: t }, e, s) { let o = n.pluginScopeKeys(i), a = n.getOptionScopes(e, o); return t && i.defaults && a.push(i.defaults), n.createResolver(a, s, [""], { scriptable: !1, indexable: !1, allKeys: !0 }); }
function xi(n, i) { let t = I.datasets[n] || {}; return ((i.datasets || {})[n] || {}).indexAxis || i.indexAxis || t.indexAxis || "x"; }
function sa(n, i) { let t = n; return n === "_index_" ? t = i : n === "_value_" && (t = i === "x" ? "y" : "x"), t; }
function na(n, i) { return n === i ? "_index_" : "_value_"; }
function Ts(n) { if (n === "x" || n === "y" || n === "r")
    return n; }
function oa(n) { if (n === "top" || n === "bottom")
    return "x"; if (n === "left" || n === "right")
    return "y"; }
function _i(n, ...i) { if (Ts(n))
    return n; for (let t of i) {
    let e = t.axis || oa(t.position) || n.length > 1 && Ts(n[0].toLowerCase());
    if (e)
        return e;
} throw new Error(`Cannot determine type of '${n}' axis. Please provide 'axis' or 'position' option.`); }
function Es(n, i, t) { if (t[i + "AxisID"] === n)
    return { axis: i }; }
function aa(n, i) { if (i.data && i.data.datasets) {
    let t = i.data.datasets.filter(e => e.xAxisID === n || e.yAxisID === n);
    if (t.length)
        return Es(n, "x", t[0]) || Es(n, "y", t[0]);
} return {}; }
function ra(n, i) { let t = kt[n.type] || { scales: {} }, e = i.scales || {}, s = xi(n.type, i), o = Object.create(null); return Object.keys(e).forEach(a => { let r = e[a]; if (!z(r))
    return console.error(`Invalid scale configuration for scale: ${a}`); if (r._proxy)
    return console.warn(`Ignoring resolver passed as options for scale: ${a}`); let l = _i(a, r, aa(a, n), I.scales[r.type]), c = na(l, s), h = t.scales || {}; o[a] = Wt(Object.create(null), [{ axis: l }, r, h[l], h[c]]); }), n.data.datasets.forEach(a => { let r = a.type || n.type, l = a.indexAxis || xi(r, i), h = (kt[r] || {}).scales || {}; Object.keys(h).forEach(d => { let u = sa(d, l), f = a[u + "AxisID"] || u; o[f] = o[f] || Object.create(null), Wt(o[f], [{ axis: u }, e[f], h[d]]); }); }), Object.keys(o).forEach(a => { let r = o[a]; Wt(r, [I.scales[r.type], I.scale]); }), o; }
function vn(n) { let i = n.options || (n.options = {}); i.plugins = C(i.plugins, {}), i.scales = ra(n, i); }
function Mn(n) { return n = n || {}, n.datasets = n.datasets || [], n.labels = n.labels || [], n; }
function la(n) { return n = n || {}, n.data = Mn(n.data), vn(n), n; }
var Rs = new Map, kn = new Set;
function ge(n, i) { let t = Rs.get(n); return t || (t = i(), Rs.set(n, t), kn.add(t)), t; }
var Jt = (n, i, t) => { let e = vt(i, t); e !== void 0 && n.add(e); }, yi = class {
    constructor(i) { this._config = la(i), this._scopeCache = new Map, this._resolverCache = new Map; }
    get platform() { return this._config.platform; }
    get type() { return this._config.type; }
    set type(i) { this._config.type = i; }
    get data() { return this._config.data; }
    set data(i) { this._config.data = Mn(i); }
    get options() { return this._config.options; }
    set options(i) { this._config.options = i; }
    get plugins() { return this._config.plugins; }
    update() { let i = this._config; this.clearCache(), vn(i); }
    clearCache() { this._scopeCache.clear(), this._resolverCache.clear(); }
    datasetScopeKeys(i) { return ge(i, () => [[`datasets.${i}`, ""]]); }
    datasetAnimationScopeKeys(i, t) { return ge(`${i}.transition.${t}`, () => [[`datasets.${i}.transitions.${t}`, `transitions.${t}`], [`datasets.${i}`, ""]]); }
    datasetElementScopeKeys(i, t) { return ge(`${i}-${t}`, () => [[`datasets.${i}.elements.${t}`, `datasets.${i}`, `elements.${t}`, ""]]); }
    pluginScopeKeys(i) { let t = i.id, e = this.type; return ge(`${e}-plugin-${t}`, () => [[`plugins.${t}`, ...i.additionalOptionScopes || []]]); }
    _cachedScopes(i, t) { let e = this._scopeCache, s = e.get(i); return (!s || t) && (s = new Map, e.set(i, s)), s; }
    getOptionScopes(i, t, e) { let { options: s, type: o } = this, a = this._cachedScopes(i, e), r = a.get(t); if (r)
        return r; let l = new Set; t.forEach(h => { i && (l.add(i), h.forEach(d => Jt(l, i, d))), h.forEach(d => Jt(l, s, d)), h.forEach(d => Jt(l, kt[o] || {}, d)), h.forEach(d => Jt(l, I, d)), h.forEach(d => Jt(l, We, d)); }); let c = Array.from(l); return c.length === 0 && c.push(Object.create(null)), kn.has(t) && a.set(t, c), c; }
    chartOptionScopes() { let { options: i, type: t } = this; return [i, kt[t] || {}, I.datasets[t] || {}, { type: t }, I, We]; }
    resolveNamedOptions(i, t, e, s = [""]) { let o = { $shared: !0 }, { resolver: a, subPrefixes: r } = Is(this._resolverCache, i, s), l = a; if (ha(a, t)) {
        o.$shared = !1, e = Ht(e) ? e() : e;
        let c = this.createResolver(i, e, r);
        l = $e(a, e, c);
    } for (let c of t)
        o[c] = l[c]; return o; }
    createResolver(i, t, e = [""], s) { let { resolver: o } = Is(this._resolverCache, i, e); return z(t) ? $e(o, t, void 0, s) : o; }
};
function Is(n, i, t) { let e = n.get(i); e || (e = new Map, n.set(i, e)); let s = t.join(), o = e.get(s); return o || (o = { resolver: ss(i, t), subPrefixes: t.filter(r => !r.toLowerCase().includes("hover")) }, e.set(s, o)), o; }
var ca = n => z(n) && Object.getOwnPropertyNames(n).some(i => Ht(n[i]));
function ha(n, i) { let { isScriptable: t, isIndexable: e } = ns(n); for (let s of i) {
    let o = t(s), a = e(s), r = (a || o) && n[s];
    if (o && (Ht(r) || ca(r)) || a && K(r))
        return !0;
} return !1; }
var da = "4.5.0", ua = ["top", "bottom", "left", "right", "chartArea"];
function zs(n, i) { return n === "top" || n === "bottom" || ua.indexOf(n) === -1 && i === "x"; }
function Fs(n, i) { return function (t, e) { return t[n] === e[n] ? t[i] - e[i] : t[n] - e[n]; }; }
function Bs(n) { let i = n.chart, t = i.options.animation; i.notifyPlugins("afterRender"), E(t && t.onComplete, [n], i); }
function fa(n) { let i = n.chart, t = i.options.animation; E(t && t.onProgress, [n], i); }
function Sn(n) { return Ue() && typeof n == "string" ? n = document.getElementById(n) : n && n.length && (n = n[0]), n && n.canvas && (n = n.canvas), n; }
var _e = {}, Vs = n => { let i = Sn(n); return Object.values(_e).filter(t => t.canvas === i).pop(); };
function ga(n, i, t) { let e = Object.keys(n); for (let s of e) {
    let o = +s;
    if (o >= i) {
        let a = n[s];
        delete n[s], (t > 0 || o > i) && (n[o + t] = a);
    }
} }
function pa(n, i, t, e) { return !t || n.type === "mouseout" ? null : e ? i : n; }
var ma = (() => { class n {
    static defaults = I;
    static instances = _e;
    static overrides = kt;
    static registry = ot;
    static version = da;
    static getChart = Vs;
    static register(...t) { ot.add(...t), Ns(); }
    static unregister(...t) { ot.remove(...t), Ns(); }
    constructor(t, e) { let s = this.config = new yi(e), o = Sn(t), a = Vs(o); if (a)
        throw new Error("Canvas is already in use. Chart with ID '" + a.id + "' must be destroyed before the canvas with ID '" + a.canvas.id + "' can be reused."); let r = s.createResolver(s.chartOptionScopes(), this.getContext()); this.platform = new (s.platform || zo(o)), this.platform.updateConfig(s); let l = this.platform.acquireContext(o, r.aspectRatio), c = l && l.canvas, h = c && c.height, d = c && c.width; if (this.id = Ei(), this.ctx = l, this.canvas = c, this.width = d, this.height = h, this._options = r, this._aspectRatio = this.aspectRatio, this._layers = [], this._metasets = [], this._stacks = void 0, this.boxes = [], this.currentDevicePixelRatio = void 0, this.chartArea = void 0, this._active = [], this._lastEvent = void 0, this._listeners = {}, this._responsiveListeners = void 0, this._sortedMetasets = [], this.scales = {}, this._plugins = new bi, this.$proxies = {}, this._hiddenIndices = {}, this.attached = !1, this._animationsDisabled = void 0, this.$context = void 0, this._doResize = Ki(u => this.update(u), r.resizeDelay || 0), this._dataChanges = [], _e[this.id] = this, !l || !c) {
        console.error("Failed to create chart: can't acquire context from the given item");
        return;
    } ct.listen(this, "complete", Bs), ct.listen(this, "progress", fa), this._initialize(), this.attached && this.update(); }
    get aspectRatio() { let { options: { aspectRatio: t, maintainAspectRatio: e }, width: s, height: o, _aspectRatio: a } = this; return L(t) ? e && a ? a : o ? s / o : null : t; }
    get data() { return this.config.data; }
    set data(t) { this.config.data = t; }
    get options() { return this._options; }
    set options(t) { this.config.options = t; }
    get registry() { return ot; }
    _initialize() { return this.notifyPlugins("beforeInit"), this.options.responsive ? this.resize() : Ke(this, this.options.devicePixelRatio), this.bindEvents(), this.notifyPlugins("afterInit"), this; }
    clear() { return je(this.canvas, this.ctx), this; }
    stop() { return ct.stop(this), this; }
    resize(t, e) { ct.running(this) ? this._resizeBeforeDraw = { width: t, height: e } : this._resize(t, e); }
    _resize(t, e) { let s = this.options, o = this.canvas, a = s.maintainAspectRatio && this.aspectRatio, r = this.platform.getMaximumSize(o, t, e, a), l = s.devicePixelRatio || this.platform.getDevicePixelRatio(), c = this.width ? "resize" : "attach"; this.width = r.width, this.height = r.height, this._aspectRatio = this.aspectRatio, Ke(this, l, !0) && (this.notifyPlugins("resize", { size: r }), E(s.onResize, [this, r], this), this.attached && this._doResize(c) && this.render()); }
    ensureScalesHaveIDs() { let e = this.options.scales || {}; O(e, (s, o) => { s.id = o; }); }
    buildOrUpdateScales() { let t = this.options, e = t.scales, s = this.scales, o = Object.keys(s).reduce((r, l) => (r[l] = !1, r), {}), a = []; e && (a = a.concat(Object.keys(e).map(r => { let l = e[r], c = _i(r, l), h = c === "r", d = c === "x"; return { options: l, dposition: h ? "chartArea" : d ? "bottom" : "left", dtype: h ? "radialLinear" : d ? "category" : "linear" }; }))), O(a, r => { let l = r.options, c = l.id, h = _i(c, l), d = C(l.type, r.dtype); (l.position === void 0 || zs(l.position, h) !== zs(r.dposition)) && (l.position = r.dposition), o[c] = !0; let u = null; if (c in s && s[c].type === d)
        u = s[c];
    else {
        let f = ot.getScale(d);
        u = new f({ id: c, type: d, ctx: this.ctx, chart: this }), s[u.id] = u;
    } u.init(l, t); }), O(o, (r, l) => { r || delete s[l]; }), O(s, r => { X.configure(this, r, r.options), X.addBox(this, r); }); }
    _updateMetasets() { let t = this._metasets, e = this.data.datasets.length, s = t.length; if (t.sort((o, a) => o.index - a.index), s > e) {
        for (let o = e; o < s; ++o)
            this._destroyDatasetMeta(o);
        t.splice(e, s - e);
    } this._sortedMetasets = t.slice(0).sort(Fs("order", "index")); }
    _removeUnreferencedMetasets() { let { _metasets: t, data: { datasets: e } } = this; t.length > e.length && delete this._stacks, t.forEach((s, o) => { e.filter(a => a === s._dataset).length === 0 && this._destroyDatasetMeta(o); }); }
    buildOrUpdateControllers() { let t = [], e = this.data.datasets, s, o; for (this._removeUnreferencedMetasets(), s = 0, o = e.length; s < o; s++) {
        let a = e[s], r = this.getDatasetMeta(s), l = a.type || this.config.type;
        if (r.type && r.type !== l && (this._destroyDatasetMeta(s), r = this.getDatasetMeta(s)), r.type = l, r.indexAxis = a.indexAxis || xi(l, this.options), r.order = a.order || 0, r.index = s, r.label = "" + a.label, r.visible = this.isDatasetVisible(s), r.controller)
            r.controller.updateIndex(s), r.controller.linkScales();
        else {
            let c = ot.getController(l), { datasetElementType: h, dataElementType: d } = I.datasets[l];
            Object.assign(c, { dataElementType: ot.getElement(d), datasetElementType: h && ot.getElement(h) }), r.controller = new c(this, s), t.push(r.controller);
        }
    } return this._updateMetasets(), t; }
    _resetElements() { O(this.data.datasets, (t, e) => { this.getDatasetMeta(e).controller.reset(); }, this); }
    reset() { this._resetElements(), this.notifyPlugins("reset"); }
    update(t) { let e = this.config; e.update(); let s = this._options = e.createResolver(e.chartOptionScopes(), this.getContext()), o = this._animationsDisabled = !s.animation; if (this._updateScales(), this._checkEventBindings(), this._updateHiddenIndices(), this._plugins.invalidate(), this.notifyPlugins("beforeUpdate", { mode: t, cancelable: !0 }) === !1)
        return; let a = this.buildOrUpdateControllers(); this.notifyPlugins("beforeElementsUpdate"); let r = 0; for (let h = 0, d = this.data.datasets.length; h < d; h++) {
        let { controller: u } = this.getDatasetMeta(h), f = !o && a.indexOf(u) === -1;
        u.buildOrUpdateElements(f), r = Math.max(+u.getMaxOverflow(), r);
    } r = this._minPadding = s.layout.autoPadding ? r : 0, this._updateLayout(r), o || O(a, h => { h.reset(); }), this._updateDatasets(t), this.notifyPlugins("afterUpdate", { mode: t }), this._layers.sort(Fs("z", "_idx")); let { _active: l, _lastEvent: c } = this; c ? this._eventHandler(c, !0) : l.length && this._updateHoverStyles(l, l, !0), this.render(); }
    _updateScales() { O(this.scales, t => { X.removeBox(this, t); }), this.ensureScalesHaveIDs(), this.buildOrUpdateScales(); }
    _checkEventBindings() { let t = this.options, e = new Set(Object.keys(this._listeners)), s = new Set(t.events); (!Ae(e, s) || !!this._responsiveListeners !== t.responsive) && (this.unbindEvents(), this.bindEvents()); }
    _updateHiddenIndices() { let { _hiddenIndices: t } = this, e = this._getUniformDataChanges() || []; for (let { method: s, start: o, count: a } of e) {
        let r = s === "_removeElements" ? -a : a;
        ga(t, o, r);
    } }
    _getUniformDataChanges() { let t = this._dataChanges; if (!t || !t.length)
        return; this._dataChanges = []; let e = this.data.datasets.length, s = a => new Set(t.filter(r => r[0] === a).map((r, l) => l + "," + r.splice(1).join(","))), o = s(0); for (let a = 1; a < e; a++)
        if (!Ae(o, s(a)))
            return; return Array.from(o).map(a => a.split(",")).map(a => ({ method: a[1], start: +a[2], count: +a[3] })); }
    _updateLayout(t) { if (this.notifyPlugins("beforeLayout", { cancelable: !0 }) === !1)
        return; X.update(this, this.width, this.height, t); let e = this.chartArea, s = e.width <= 0 || e.height <= 0; this._layers = [], O(this.boxes, o => { s && o.position === "chartArea" || (o.configure && o.configure(), this._layers.push(...o._layers())); }, this), this._layers.forEach((o, a) => { o._idx = a; }), this.notifyPlugins("afterLayout"); }
    _updateDatasets(t) { if (this.notifyPlugins("beforeDatasetsUpdate", { mode: t, cancelable: !0 }) !== !1) {
        for (let e = 0, s = this.data.datasets.length; e < s; ++e)
            this.getDatasetMeta(e).controller.configure();
        for (let e = 0, s = this.data.datasets.length; e < s; ++e)
            this._updateDataset(e, Ht(t) ? t({ datasetIndex: e }) : t);
        this.notifyPlugins("afterDatasetsUpdate", { mode: t });
    } }
    _updateDataset(t, e) { let s = this.getDatasetMeta(t), o = { meta: s, index: t, mode: e, cancelable: !0 }; this.notifyPlugins("beforeDatasetUpdate", o) !== !1 && (s.controller._update(e), o.cancelable = !1, this.notifyPlugins("afterDatasetUpdate", o)); }
    render() { this.notifyPlugins("beforeRender", { cancelable: !0 }) !== !1 && (ct.has(this) ? this.attached && !ct.running(this) && ct.start(this) : (this.draw(), Bs({ chart: this }))); }
    draw() { let t; if (this._resizeBeforeDraw) {
        let { width: s, height: o } = this._resizeBeforeDraw;
        this._resizeBeforeDraw = null, this._resize(s, o);
    } if (this.clear(), this.width <= 0 || this.height <= 0 || this.notifyPlugins("beforeDraw", { cancelable: !0 }) === !1)
        return; let e = this._layers; for (t = 0; t < e.length && e[t].z <= 0; ++t)
        e[t].draw(this.chartArea); for (this._drawDatasets(); t < e.length; ++t)
        e[t].draw(this.chartArea); this.notifyPlugins("afterDraw"); }
    _getSortedDatasetMetas(t) { let e = this._sortedMetasets, s = [], o, a; for (o = 0, a = e.length; o < a; ++o) {
        let r = e[o];
        (!t || r.visible) && s.push(r);
    } return s; }
    getSortedVisibleDatasetMetas() { return this._getSortedDatasetMetas(!0); }
    _drawDatasets() { if (this.notifyPlugins("beforeDatasetsDraw", { cancelable: !0 }) === !1)
        return; let t = this.getSortedVisibleDatasetMetas(); for (let e = t.length - 1; e >= 0; --e)
        this._drawDataset(t[e]); this.notifyPlugins("afterDatasetsDraw"); }
    _drawDataset(t) { let e = this.ctx, s = { meta: t, index: t.index, cancelable: !0 }, o = Qe(this, t); this.notifyPlugins("beforeDatasetDraw", s) !== !1 && (o && Yt(e, o), t.controller.draw(), o && Ut(e), s.cancelable = !1, this.notifyPlugins("afterDatasetDraw", s)); }
    isPointInArea(t) { return ut(t, this.chartArea, this._minPadding); }
    getElementsAtEventForMode(t, e, s, o) { let a = bo.modes[e]; return typeof a == "function" ? a(this, t, s, o) : []; }
    getDatasetMeta(t) { let e = this.data.datasets[t], s = this._metasets, o = s.filter(a => a && a._dataset === e).pop(); return o || (o = { type: null, data: [], dataset: null, controller: null, hidden: null, xAxisID: null, yAxisID: null, order: e && e.order || 0, index: t, _dataset: e, _parsed: [], _sorted: !1 }, s.push(o)), o; }
    getContext() { return this.$context || (this.$context = pt(null, { chart: this, type: "chart" })); }
    getVisibleDatasetCount() { return this.getSortedVisibleDatasetMetas().length; }
    isDatasetVisible(t) { let e = this.data.datasets[t]; if (!e)
        return !1; let s = this.getDatasetMeta(t); return typeof s.hidden == "boolean" ? !s.hidden : !e.hidden; }
    setDatasetVisibility(t, e) { let s = this.getDatasetMeta(t); s.hidden = !e; }
    toggleDataVisibility(t) { this._hiddenIndices[t] = !this._hiddenIndices[t]; }
    getDataVisibility(t) { return !this._hiddenIndices[t]; }
    _updateVisibility(t, e, s) { let o = s ? "show" : "hide", a = this.getDatasetMeta(t), r = a.controller._resolveAnimations(void 0, o); Lt(e) ? (a.data[e].hidden = !s, this.update()) : (this.setDatasetVisibility(t, s), r.update(a, { visible: s }), this.update(l => l.datasetIndex === t ? o : void 0)); }
    hide(t, e) { this._updateVisibility(t, e, !1); }
    show(t, e) { this._updateVisibility(t, e, !0); }
    _destroyDatasetMeta(t) { let e = this._metasets[t]; e && e.controller && e.controller._destroy(), delete this._metasets[t]; }
    _stop() { let t, e; for (this.stop(), ct.remove(this), t = 0, e = this.data.datasets.length; t < e; ++t)
        this._destroyDatasetMeta(t); }
    destroy() { this.notifyPlugins("beforeDestroy"); let { canvas: t, ctx: e } = this; this._stop(), this.config.clearCache(), t && (this.unbindEvents(), je(t, e), this.platform.releaseContext(e), this.canvas = null, this.ctx = null), delete _e[this.id], this.notifyPlugins("afterDestroy"); }
    toBase64Image(...t) { return this.canvas.toDataURL(...t); }
    bindEvents() { this.bindUserEvents(), this.options.responsive ? this.bindResponsiveEvents() : this.attached = !0; }
    bindUserEvents() { let t = this._listeners, e = this.platform, s = (a, r) => { e.addEventListener(this, a, r), t[a] = r; }, o = (a, r, l) => { a.offsetX = r, a.offsetY = l, this._eventHandler(a); }; O(this.options.events, a => s(a, o)); }
    bindResponsiveEvents() { this._responsiveListeners || (this._responsiveListeners = {}); let t = this._responsiveListeners, e = this.platform, s = (c, h) => { e.addEventListener(this, c, h), t[c] = h; }, o = (c, h) => { t[c] && (e.removeEventListener(this, c, h), delete t[c]); }, a = (c, h) => { this.canvas && this.resize(c, h); }, r, l = () => { o("attach", l), this.attached = !0, this.resize(), s("resize", a), s("detach", r); }; r = () => { this.attached = !1, o("resize", a), this._stop(), this._resize(0, 0), s("attach", l); }, e.isAttached(this.canvas) ? l() : r(); }
    unbindEvents() { O(this._listeners, (t, e) => { this.platform.removeEventListener(this, e, t); }), this._listeners = {}, O(this._responsiveListeners, (t, e) => { this.platform.removeEventListener(this, e, t); }), this._responsiveListeners = void 0; }
    updateHoverStyle(t, e, s) { let o = s ? "set" : "remove", a, r, l, c; for (e === "dataset" && (a = this.getDatasetMeta(t[0].datasetIndex), a.controller["_" + o + "DatasetHoverStyle"]()), l = 0, c = t.length; l < c; ++l) {
        r = t[l];
        let h = r && this.getDatasetMeta(r.datasetIndex).controller;
        h && h[o + "HoverStyle"](r.element, r.datasetIndex, r.index);
    } }
    getActiveElements() { return this._active || []; }
    setActiveElements(t) { let e = this._active || [], s = t.map(({ datasetIndex: a, index: r }) => { let l = this.getDatasetMeta(a); if (!l)
        throw new Error("No dataset found at index " + a); return { datasetIndex: a, element: l.data[r], index: r }; }); !Nt(s, e) && (this._active = s, this._lastEvent = null, this._updateHoverStyles(s, e)); }
    notifyPlugins(t, e, s) { return this._plugins.notify(this, t, e, s); }
    isPluginEnabled(t) { return this._plugins._cache.filter(e => e.plugin.id === t).length === 1; }
    _updateHoverStyles(t, e, s) { let o = this.options.hover, a = (c, h) => c.filter(d => !h.some(u => d.datasetIndex === u.datasetIndex && d.index === u.index)), r = a(e, t), l = s ? t : a(t, e); r.length && this.updateHoverStyle(r, o.mode, !1), l.length && o.mode && this.updateHoverStyle(l, o.mode, !0); }
    _eventHandler(t, e) { let s = { event: t, replay: e, cancelable: !0, inChartArea: this.isPointInArea(t) }, o = r => (r.options.events || this.options.events).includes(t.native.type); if (this.notifyPlugins("beforeEvent", s, o) === !1)
        return; let a = this._handleEvent(t, e, s.inChartArea); return s.cancelable = !1, this.notifyPlugins("afterEvent", s, o), (a || s.changed) && this.render(), this; }
    _handleEvent(t, e, s) { let { _active: o = [], options: a } = this, r = e, l = this._getActiveElements(t, o, s, r), c = Bi(t), h = pa(t, this._lastEvent, s, c); s && (this._lastEvent = null, E(a.onHover, [t, l, this], this), c && E(a.onClick, [t, l, this], this)); let d = !Nt(l, o); return (d || e) && (this._active = l, this._updateHoverStyles(l, o, e)), this._lastEvent = h, d; }
    _getActiveElements(t, e, s, o) { if (t.type === "mouseout")
        return []; if (!s)
        return e; let a = this.options.hover; return this.getElementsAtEventForMode(t, a.mode, a, o); }
} return n; })();
function Ns() { return O(ma.instances, n => n._plugins.invalidate()); }
function ba(n, i, t) { let { startAngle: e, x: s, y: o, outerRadius: a, innerRadius: r, options: l } = i, { borderWidth: c, borderJoinStyle: h } = l, d = Math.min(c / a, rt(e - t)); if (n.beginPath(), n.arc(s, o, a - c / 2, e + d / 2, t - d / 2), r > 0) {
    let u = Math.min(c / r, rt(e - t));
    n.arc(s, o, r + c / 2, t - u / 2, e + u / 2, !0);
}
else {
    let u = Math.min(c / 2, a * rt(e - t));
    if (h === "round")
        n.arc(s, o, u, t - W / 2, e + W / 2, !0);
    else if (h === "bevel") {
        let f = 2 * u * u, g = -f * Math.cos(t + W / 2) + s, p = -f * Math.sin(t + W / 2) + o, m = f * Math.cos(e + W / 2) + s, x = f * Math.sin(e + W / 2) + o;
        n.lineTo(g, p), n.lineTo(m, x);
    }
} n.closePath(), n.moveTo(0, 0), n.rect(0, 0, n.canvas.width, n.canvas.height), n.clip("evenodd"); }
function xa(n, i, t) { let { startAngle: e, pixelMargin: s, x: o, y: a, outerRadius: r, innerRadius: l } = i, c = s / r; n.beginPath(), n.arc(o, a, r, e - c, t + c), l > s ? (c = s / l, n.arc(o, a, l, t + c, e - c, !0)) : n.arc(o, a, s, t + Q, e - Q), n.closePath(), n.clip(); }
function _a(n) { return ts(n, ["outerStart", "outerEnd", "innerStart", "innerEnd"]); }
function ya(n, i, t, e) { let s = _a(n.options.borderRadius), o = (t - i) / 2, a = Math.min(o, e * i / 2), r = l => { let c = (t - Math.min(o, l)) * e / 2; return U(l, 0, Math.min(o, c)); }; return { outerStart: r(s.outerStart), outerEnd: r(s.outerEnd), innerStart: U(s.innerStart, 0, a), innerEnd: U(s.innerEnd, 0, a) }; }
function It(n, i, t, e) { return { x: t + n * Math.cos(i), y: e + n * Math.sin(i) }; }
function ke(n, i, t, e, s, o) { let { x: a, y: r, startAngle: l, pixelMargin: c, innerRadius: h } = i, d = Math.max(i.outerRadius + e + t - c, 0), u = h > 0 ? h + e + t + c : 0, f = 0, g = s - l; if (e) {
    let T = h > 0 ? h - e : 0, R = d > 0 ? d - e : 0, F = (T + R) / 2, et = F !== 0 ? g * F / (F + e) : g;
    f = (g - et) / 2;
} let p = Math.max(.001, g * d - t / W) / d, m = (g - p) / 2, x = l + m + f, b = s - m - f, { outerStart: y, outerEnd: M, innerStart: _, innerEnd: v } = ya(i, u, d, b - x), S = d - y, k = d - M, w = x + y / S, P = b - M / k, D = u + _, A = u + v, N = x + _ / D, Z = b - v / A; if (n.beginPath(), o) {
    let T = (w + P) / 2;
    if (n.arc(a, r, d, w, T), n.arc(a, r, d, T, P), M > 0) {
        let $ = It(k, P, a, r);
        n.arc($.x, $.y, M, P, b + Q);
    }
    let R = It(A, b, a, r);
    if (n.lineTo(R.x, R.y), v > 0) {
        let $ = It(A, Z, a, r);
        n.arc($.x, $.y, v, b + Q, Z + Math.PI);
    }
    let F = (b - v / u + (x + _ / u)) / 2;
    if (n.arc(a, r, u, b - v / u, F, !0), n.arc(a, r, u, F, x + _ / u, !0), _ > 0) {
        let $ = It(D, N, a, r);
        n.arc($.x, $.y, _, N + Math.PI, x - Q);
    }
    let et = It(S, x, a, r);
    if (n.lineTo(et.x, et.y), y > 0) {
        let $ = It(S, w, a, r);
        n.arc($.x, $.y, y, x - Q, w);
    }
}
else {
    n.moveTo(a, r);
    let T = Math.cos(w) * d + a, R = Math.sin(w) * d + r;
    n.lineTo(T, R);
    let F = Math.cos(P) * d + a, et = Math.sin(P) * d + r;
    n.lineTo(F, et);
} n.closePath(); }
function va(n, i, t, e, s) { let { fullCircles: o, startAngle: a, circumference: r } = i, l = i.endAngle; if (o) {
    ke(n, i, t, e, l, s);
    for (let c = 0; c < o; ++c)
        n.fill();
    isNaN(r) || (l = a + (r % Y || Y));
} return ke(n, i, t, e, l, s), n.fill(), l; }
function Ma(n, i, t, e, s) { let { fullCircles: o, startAngle: a, circumference: r, options: l } = i, { borderWidth: c, borderJoinStyle: h, borderDash: d, borderDashOffset: u, borderRadius: f } = l, g = l.borderAlign === "inner"; if (!c)
    return; n.setLineDash(d || []), n.lineDashOffset = u, g ? (n.lineWidth = c * 2, n.lineJoin = h || "round") : (n.lineWidth = c, n.lineJoin = h || "bevel"); let p = i.endAngle; if (o) {
    ke(n, i, t, e, p, s);
    for (let m = 0; m < o; ++m)
        n.stroke();
    isNaN(r) || (p = a + (r % Y || Y));
} g && xa(n, i, p), l.selfJoin && p - a >= W && f === 0 && h !== "miter" && ba(n, i, p), o || (ke(n, i, t, e, p, s), n.stroke()); }
var vi = class extends it {
    static id = "arc";
    static defaults = { borderAlign: "center", borderColor: "#fff", borderDash: [], borderDashOffset: 0, borderJoinStyle: void 0, borderRadius: 0, borderWidth: 2, offset: 0, spacing: 0, angle: void 0, circular: !0, selfJoin: !1 };
    static defaultRoutes = { backgroundColor: "backgroundColor" };
    static descriptors = { _scriptable: !0, _indexable: i => i !== "borderDash" };
    circumference;
    endAngle;
    fullCircles;
    innerRadius;
    outerRadius;
    pixelMargin;
    startAngle;
    constructor(i) { super(), this.options = void 0, this.circumference = void 0, this.startAngle = void 0, this.endAngle = void 0, this.innerRadius = void 0, this.outerRadius = void 0, this.pixelMargin = 0, this.fullCircles = 0, i && Object.assign(this, i); }
    inRange(i, t, e) { let s = this.getProps(["x", "y"], e), { angle: o, distance: a } = Ee(s, { x: i, y: t }), { startAngle: r, endAngle: l, innerRadius: c, outerRadius: h, circumference: d } = this.getProps(["startAngle", "endAngle", "innerRadius", "outerRadius", "circumference"], e), u = (this.options.spacing + this.options.borderWidth) / 2, f = C(d, l - r), g = jt(o, r, l) && r !== l, p = f >= Y || g, m = lt(a, c + u, h + u); return p && m; }
    getCenterPoint(i) { let { x: t, y: e, startAngle: s, endAngle: o, innerRadius: a, outerRadius: r } = this.getProps(["x", "y", "startAngle", "endAngle", "innerRadius", "outerRadius"], i), { offset: l, spacing: c } = this.options, h = (s + o) / 2, d = (a + r + c + l) / 2; return { x: t + Math.cos(h) * d, y: e + Math.sin(h) * d }; }
    tooltipPosition(i) { return this.getCenterPoint(i); }
    draw(i) { let { options: t, circumference: e } = this, s = (t.offset || 0) / 4, o = (t.spacing || 0) / 2, a = t.circular; if (this.pixelMargin = t.borderAlign === "inner" ? .33 : 0, this.fullCircles = e > Y ? Math.floor(e / Y) : 0, e === 0 || this.innerRadius < 0 || this.outerRadius < 0)
        return; i.save(); let r = (this.startAngle + this.endAngle) / 2; i.translate(Math.cos(r) * s, Math.sin(r) * s); let l = 1 - Math.sin(Math.min(W, e || 0)), c = s * l; i.fillStyle = t.backgroundColor, i.strokeStyle = t.borderColor, va(i, this, c, o, a), Ma(i, this, c, o, a), i.restore(); }
};
function wn(n, i, t = i) { n.lineCap = C(t.borderCapStyle, i.borderCapStyle), n.setLineDash(C(t.borderDash, i.borderDash)), n.lineDashOffset = C(t.borderDashOffset, i.borderDashOffset), n.lineJoin = C(t.borderJoinStyle, i.borderJoinStyle), n.lineWidth = C(t.borderWidth, i.borderWidth), n.strokeStyle = C(t.borderColor, i.borderColor); }
function ka(n, i, t) { n.lineTo(t.x, t.y); }
function Sa(n) { return n.stepped ? Zi : n.tension || n.cubicInterpolationMode === "monotone" ? Qi : ka; }
function Dn(n, i, t = {}) { let e = n.length, { start: s = 0, end: o = e - 1 } = t, { start: a, end: r } = i, l = Math.max(s, a), c = Math.min(o, r), h = s < a && o < a || s > r && o > r; return { count: e, start: l, loop: i.loop, ilen: c < l && !h ? e + c - l : c - l }; }
function wa(n, i, t, e) { let { points: s, options: o } = i, { count: a, start: r, loop: l, ilen: c } = Dn(s, t, e), h = Sa(o), { move: d = !0, reverse: u } = e || {}, f, g, p; for (f = 0; f <= c; ++f)
    g = s[(r + (u ? c - f : f)) % a], !g.skip && (d ? (n.moveTo(g.x, g.y), d = !1) : h(n, p, g, u, o.stepped), p = g); return l && (g = s[(r + (u ? c : 0)) % a], h(n, p, g, u, o.stepped)), !!l; }
function Da(n, i, t, e) { let s = i.points, { count: o, start: a, ilen: r } = Dn(s, t, e), { move: l = !0, reverse: c } = e || {}, h = 0, d = 0, u, f, g, p, m, x, b = M => (a + (c ? r - M : M)) % o, y = () => { p !== m && (n.lineTo(h, m), n.lineTo(h, p), n.lineTo(h, x)); }; for (l && (f = s[b(0)], n.moveTo(f.x, f.y)), u = 0; u <= r; ++u) {
    if (f = s[b(u)], f.skip)
        continue;
    let M = f.x, _ = f.y, v = M | 0;
    v === g ? (_ < p ? p = _ : _ > m && (m = _), h = (d * h + M) / ++d) : (y(), n.lineTo(M, _), g = v, d = 0, p = m = _), x = _;
} y(); }
function Mi(n) { let i = n.options, t = i.borderDash && i.borderDash.length; return !n._decimated && !n._loop && !i.tension && i.cubicInterpolationMode !== "monotone" && !i.stepped && !t ? Da : wa; }
function Pa(n) { return n.stepped ? cs : n.tension || n.cubicInterpolationMode === "monotone" ? hs : ls; }
function Ca(n, i, t, e) { let s = i._path; s || (s = i._path = new Path2D, i.path(s, t, e) && s.closePath()), wn(n, i.options), n.stroke(s); }
function Aa(n, i, t, e) { let { segments: s, options: o } = i, a = Mi(i); for (let r of s)
    wn(n, o, r.style), n.beginPath(), a(n, i, r, { start: t, end: t + e - 1 }) && n.closePath(), n.stroke(); }
var La = typeof Path2D == "function";
function Oa(n, i, t, e) { La && !i.options.segment ? Ca(n, i, t, e) : Aa(n, i, t, e); }
var De = (() => { class n extends it {
    static id = "line";
    static defaults = { borderCapStyle: "butt", borderDash: [], borderDashOffset: 0, borderJoinStyle: "miter", borderWidth: 3, capBezierPoints: !0, cubicInterpolationMode: "default", fill: !1, spanGaps: !1, stepped: !1, tension: 0 };
    static defaultRoutes = { backgroundColor: "backgroundColor", borderColor: "borderColor" };
    static descriptors = { _scriptable: !0, _indexable: t => t !== "borderDash" && t !== "fill" };
    constructor(t) { super(), this.animated = !0, this.options = void 0, this._chart = void 0, this._loop = void 0, this._fullLoop = void 0, this._path = void 0, this._points = void 0, this._segments = void 0, this._decimated = !1, this._pointsUpdated = !1, this._datasetIndex = void 0, t && Object.assign(this, t); }
    updateControlPoints(t, e) { let s = this.options; if ((s.tension || s.cubicInterpolationMode === "monotone") && !s.stepped && !this._pointsUpdated) {
        let o = s.spanGaps ? this._loop : this._fullLoop;
        os(this._points, s, t, o, e), this._pointsUpdated = !0;
    } }
    set points(t) { this._points = t, delete this._segments, delete this._path, this._pointsUpdated = !1; }
    get points() { return this._points; }
    get segments() { return this._segments || (this._segments = us(this, this.options.segment)); }
    first() { let t = this.segments, e = this.points; return t.length && e[t[0].start]; }
    last() { let t = this.segments, e = this.points, s = t.length; return s && e[t[s - 1].end]; }
    interpolate(t, e) { let s = this.options, o = t[e], a = this.points, r = Ze(this, { property: e, start: o, end: o }); if (!r.length)
        return; let l = [], c = Pa(s), h, d; for (h = 0, d = r.length; h < d; ++h) {
        let { start: u, end: f } = r[h], g = a[u], p = a[f];
        if (g === p) {
            l.push(g);
            continue;
        }
        let m = Math.abs((o - g[e]) / (p[e] - g[e])), x = c(g, p, m, s.stepped);
        x[e] = t[e], l.push(x);
    } return l.length === 1 ? l[0] : l; }
    pathSegment(t, e, s) { return Mi(this)(t, this, e, s); }
    path(t, e, s) { let o = this.segments, a = Mi(this), r = this._loop; e = e || 0, s = s || this.points.length - e; for (let l of o)
        r &= a(t, this, l, { start: e, end: e + s - 1 }); return !!r; }
    draw(t, e, s, o) { let a = this.options || {}; (this.points || []).length && a.borderWidth && (t.save(), Oa(t, this, s, o), t.restore()), this.animated && (this._pointsUpdated = !1, this._path = void 0); }
} return n; })();
function Ws(n, i, t, e) { let s = n.options, { [t]: o } = n.getProps([t], e); return Math.abs(i - o) < s.radius + s.hitRadius; }
var Ta = (() => { class n extends it {
    static id = "point";
    parsed;
    skip;
    stop;
    static defaults = { borderWidth: 1, hitRadius: 1, hoverBorderWidth: 1, hoverRadius: 4, pointStyle: "circle", radius: 3, rotation: 0 };
    static defaultRoutes = { backgroundColor: "backgroundColor", borderColor: "borderColor" };
    constructor(t) { super(), this.options = void 0, this.parsed = void 0, this.skip = void 0, this.stop = void 0, t && Object.assign(this, t); }
    inRange(t, e, s) { let o = this.options, { x: a, y: r } = this.getProps(["x", "y"], s); return Math.pow(t - a, 2) + Math.pow(e - r, 2) < Math.pow(o.hitRadius + o.radius, 2); }
    inXRange(t, e) { return Ws(this, t, "x", e); }
    inYRange(t, e) { return Ws(this, t, "y", e); }
    getCenterPoint(t) { let { x: e, y: s } = this.getProps(["x", "y"], t); return { x: e, y: s }; }
    size(t) { t = t || this.options || {}; let e = t.radius || 0; e = Math.max(e, e && t.hoverRadius || 0); let s = e && t.borderWidth || 0; return (e + s) * 2; }
    draw(t, e) { let s = this.options; this.skip || s.radius < .1 || !ut(this, e, this.size(s) / 2) || (t.strokeStyle = s.borderColor, t.lineWidth = s.borderWidth, t.fillStyle = s.backgroundColor, de(t, s, this.x, this.y)); }
    getRange() { let t = this.options || {}; return t.radius + t.hitRadius; }
} return n; })();
function Pn(n, i) { let { x: t, y: e, base: s, width: o, height: a } = n.getProps(["x", "y", "base", "width", "height"], i), r, l, c, h, d; return n.horizontal ? (d = a / 2, r = Math.min(t, s), l = Math.max(t, s), c = e - d, h = e + d) : (d = o / 2, r = t - d, l = t + d, c = Math.min(e, s), h = Math.max(e, s)), { left: r, top: c, right: l, bottom: h }; }
function bt(n, i, t, e) { return n ? 0 : U(i, t, e); }
function Ea(n, i, t) { let e = n.options.borderWidth, s = n.borderSkipped, o = es(e); return { t: bt(s.top, o.top, 0, t), r: bt(s.right, o.right, 0, i), b: bt(s.bottom, o.bottom, 0, t), l: bt(s.left, o.left, 0, i) }; }
function Ra(n, i, t) { let { enableBorderRadius: e } = n.getProps(["enableBorderRadius"]), s = n.options.borderRadius, o = gt(s), a = Math.min(i, t), r = n.borderSkipped, l = e || z(s); return { topLeft: bt(!l || r.top || r.left, o.topLeft, 0, a), topRight: bt(!l || r.top || r.right, o.topRight, 0, a), bottomLeft: bt(!l || r.bottom || r.left, o.bottomLeft, 0, a), bottomRight: bt(!l || r.bottom || r.right, o.bottomRight, 0, a) }; }
function Ia(n) { let i = Pn(n), t = i.right - i.left, e = i.bottom - i.top, s = Ea(n, t / 2, e / 2), o = Ra(n, t / 2, e / 2); return { outer: { x: i.left, y: i.top, w: t, h: e, radius: o }, inner: { x: i.left + s.l, y: i.top + s.t, w: t - s.l - s.r, h: e - s.t - s.b, radius: { topLeft: Math.max(0, o.topLeft - Math.max(s.t, s.l)), topRight: Math.max(0, o.topRight - Math.max(s.t, s.r)), bottomLeft: Math.max(0, o.bottomLeft - Math.max(s.b, s.l)), bottomRight: Math.max(0, o.bottomRight - Math.max(s.b, s.r)) } } }; }
function ri(n, i, t, e) { let s = i === null, o = t === null, r = n && !(s && o) && Pn(n, e); return r && (s || lt(i, r.left, r.right)) && (o || lt(t, r.top, r.bottom)); }
function za(n) { return n.topLeft || n.topRight || n.bottomLeft || n.bottomRight; }
function Fa(n, i) { n.rect(i.x, i.y, i.w, i.h); }
function li(n, i, t = {}) { let e = n.x !== t.x ? -i : 0, s = n.y !== t.y ? -i : 0, o = (n.x + n.w !== t.x + t.w ? i : 0) - e, a = (n.y + n.h !== t.y + t.h ? i : 0) - s; return { x: n.x + e, y: n.y + s, w: n.w + o, h: n.h + a, radius: n.radius }; }
var ki = class extends it {
    static id = "bar";
    static defaults = { borderSkipped: "start", borderWidth: 0, borderRadius: 0, inflateAmount: "auto", pointStyle: void 0 };
    static defaultRoutes = { backgroundColor: "backgroundColor", borderColor: "borderColor" };
    constructor(i) { super(), this.options = void 0, this.horizontal = void 0, this.base = void 0, this.width = void 0, this.height = void 0, this.inflateAmount = void 0, i && Object.assign(this, i); }
    draw(i) { let { inflateAmount: t, options: { borderColor: e, backgroundColor: s } } = this, { inner: o, outer: a } = Ia(this), r = za(a.radius) ? Et : Fa; i.save(), (a.w !== o.w || a.h !== o.h) && (i.beginPath(), r(i, li(a, t, o)), i.clip(), r(i, li(o, -t, a)), i.fillStyle = e, i.fill("evenodd")), i.beginPath(), r(i, li(o, t)), i.fillStyle = s, i.fill(), i.restore(); }
    inRange(i, t, e) { return ri(this, i, t, e); }
    inXRange(i, t) { return ri(this, i, null, t); }
    inYRange(i, t) { return ri(this, null, i, t); }
    getCenterPoint(i) { let { x: t, y: e, base: s, horizontal: o } = this.getProps(["x", "y", "base", "horizontal"], i); return { x: o ? (t + s) / 2 : t, y: o ? e : (e + s) / 2 }; }
    getRange(i) { return i === "x" ? this.width / 2 : this.height / 2; }
}, Ba = Object.freeze({ __proto__: null, ArcElement: vi, BarElement: ki, LineElement: De, PointElement: Ta }), Si = ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"], Hs = Si.map(n => n.replace("rgb(", "rgba(").replace(")", ", 0.5)"));
function Cn(n) { return Si[n % Si.length]; }
function An(n) { return Hs[n % Hs.length]; }
function Va(n, i) { return n.borderColor = Cn(i), n.backgroundColor = An(i), ++i; }
function Na(n, i) { return n.backgroundColor = n.data.map(() => Cn(i++)), i; }
function Wa(n, i) { return n.backgroundColor = n.data.map(() => An(i++)), i; }
function Ha(n) { let i = 0; return (t, e) => { let s = n.getDatasetMeta(e).controller; s instanceof Ti ? i = Na(t, i) : s instanceof mn ? i = Wa(t, i) : s && (i = Va(t, i)); }; }
function js(n) { let i; for (i in n)
    if (n[i].borderColor || n[i].backgroundColor)
        return !0; return !1; }
function ja(n) { return n && (n.borderColor || n.backgroundColor); }
function $a() { return I.borderColor !== "rgba(0,0,0,0.1)" || I.backgroundColor !== "rgba(0,0,0,0.1)"; }
var Ya = { id: "colors", defaults: { enabled: !0, forceOverride: !1 }, beforeLayout(n, i, t) { if (!t.enabled)
        return; let { data: { datasets: e }, options: s } = n.config, { elements: o } = s, a = js(e) || ja(s) || o && js(o) || $a(); if (!t.forceOverride && a)
        return; let r = Ha(n); e.forEach(r); } };
function Ua(n, i, t, e, s) { let o = s.samples || e; if (o >= t)
    return n.slice(i, i + t); let a = [], r = (t - 2) / (o - 2), l = 0, c = i + t - 1, h = i, d, u, f, g, p; for (a[l++] = n[h], d = 0; d < o - 2; d++) {
    let m = 0, x = 0, b, y = Math.floor((d + 1) * r) + 1 + i, M = Math.min(Math.floor((d + 2) * r) + 1, t) + i, _ = M - y;
    for (b = y; b < M; b++)
        m += n[b].x, x += n[b].y;
    m /= _, x /= _;
    let v = Math.floor(d * r) + 1 + i, S = Math.min(Math.floor((d + 1) * r) + 1, t) + i, { x: k, y: w } = n[h];
    for (f = g = -1, b = v; b < S; b++)
        g = .5 * Math.abs((k - m) * (n[b].y - w) - (k - n[b].x) * (x - w)), g > f && (f = g, u = n[b], p = b);
    a[l++] = u, h = p;
} return a[l++] = n[c], a; }
function Xa(n, i, t, e) { let s = 0, o = 0, a, r, l, c, h, d, u, f, g, p, m = [], x = i + t - 1, b = n[i].x, M = n[x].x - b; for (a = i; a < i + t; ++a) {
    r = n[a], l = (r.x - b) / M * e, c = r.y;
    let _ = l | 0;
    if (_ === h)
        c < g ? (g = c, d = a) : c > p && (p = c, u = a), s = (o * s + r.x) / ++o;
    else {
        let v = a - 1;
        if (!L(d) && !L(u)) {
            let S = Math.min(d, u), k = Math.max(d, u);
            S !== f && S !== v && m.push(ae(oe({}, n[S]), { x: s })), k !== f && k !== v && m.push(ae(oe({}, n[k]), { x: s }));
        }
        a > 0 && v !== f && m.push(n[v]), m.push(r), h = _, o = 0, g = p = c, d = u = f = a;
    }
} return m; }
function Ln(n) { if (n._decimated) {
    let i = n._data;
    delete n._decimated, delete n._data, Object.defineProperty(n, "data", { configurable: !0, enumerable: !0, writable: !0, value: i });
} }
function $s(n) { n.data.datasets.forEach(i => { Ln(i); }); }
function Ka(n, i) { let t = i.length, e = 0, s, { iScale: o } = n, { min: a, max: r, minDefined: l, maxDefined: c } = o.getUserBounds(); return l && (e = U(Tt(i, o.axis, a).lo, 0, t - 1)), c ? s = U(Tt(i, o.axis, r).hi + 1, e, t) - e : s = t - e, { start: e, count: s }; }
var Ga = { id: "decimation", defaults: { algorithm: "min-max", enabled: !1 }, beforeElementsUpdate: (n, i, t) => { if (!t.enabled) {
        $s(n);
        return;
    } let e = n.width; n.data.datasets.forEach((s, o) => { let { _data: a, indexAxis: r } = s, l = n.getDatasetMeta(o), c = a || s.data; if (Rt([r, n.options.indexAxis]) === "y" || !l.controller.supportsDecimation)
        return; let h = n.scales[l.xAxisID]; if (h.type !== "linear" && h.type !== "time" || n.options.parsing)
        return; let { start: d, count: u } = Ka(l, c), f = t.threshold || 4 * e; if (u <= f) {
        Ln(s);
        return;
    } L(a) && (s._data = c, delete s.data, Object.defineProperty(s, "data", { configurable: !0, enumerable: !0, get: function () { return this._decimated; }, set: function (p) { this._data = p; } })); let g; switch (t.algorithm) {
        case "lttb":
            g = Ua(c, d, u, e, t);
            break;
        case "min-max":
            g = Xa(c, d, u, e);
            break;
        default: throw new Error(`Unsupported decimation algorithm '${t.algorithm}'`);
    } s._decimated = g; }); }, destroy(n) { $s(n); } };
function qa(n, i, t) { let e = n.segments, s = n.points, o = i.points, a = []; for (let r of e) {
    let { start: l, end: c } = r;
    c = Pe(l, c, s);
    let h = wi(t, s[l], s[c], r.loop);
    if (!i.segments) {
        a.push({ source: r, target: h, start: s[l], end: s[c] });
        continue;
    }
    let d = Ze(i, h);
    for (let u of d) {
        let f = wi(t, o[u.start], o[u.end], u.loop), g = ds(r, s, f);
        for (let p of g)
            a.push({ source: p, target: u, start: { [t]: Ys(h, f, "start", Math.max) }, end: { [t]: Ys(h, f, "end", Math.min) } });
    }
} return a; }
function wi(n, i, t, e) { if (e)
    return; let s = i[n], o = t[n]; return n === "angle" && (s = rt(s), o = rt(o)), { property: n, start: s, end: o }; }
function Ja(n, i) { let { x: t = null, y: e = null } = n || {}, s = i.points, o = []; return i.segments.forEach(({ start: a, end: r }) => { r = Pe(a, r, s); let l = s[a], c = s[r]; e !== null ? (o.push({ x: l.x, y: e }), o.push({ x: c.x, y: e })) : t !== null && (o.push({ x: t, y: l.y }), o.push({ x: t, y: c.y })); }), o; }
function Pe(n, i, t) { for (; i > n; i--) {
    let e = t[i];
    if (!isNaN(e.x) && !isNaN(e.y))
        break;
} return i; }
function Ys(n, i, t, e) { return n && i ? e(n[t], i[t]) : n ? n[t] : i ? i[t] : 0; }
function On(n, i) { let t = [], e = !1; return K(n) ? (e = !0, t = n) : t = Ja(n, i), t.length ? new De({ points: t, options: { tension: 0 }, _loop: e, _fullLoop: e }) : null; }
function Us(n) { return n && n.fill !== !1; }
function Za(n, i, t) { let s = n[i].fill, o = [i], a; if (!t)
    return s; for (; s !== !1 && o.indexOf(s) === -1;) {
    if (!B(s))
        return s;
    if (a = n[s], !a)
        return !1;
    if (a.visible)
        return s;
    o.push(s), s = a.fill;
} return !1; }
function Qa(n, i, t) { let e = sr(n); if (z(e))
    return isNaN(e.value) ? !1 : e; let s = parseFloat(e); return B(s) && Math.floor(s) === s ? tr(e[0], i, s, t) : ["origin", "start", "end", "stack", "shape"].indexOf(e) >= 0 && e; }
function tr(n, i, t, e) { return (n === "-" || n === "+") && (t = i + t), t === i || t < 0 || t >= e ? !1 : t; }
function er(n, i) { let t = null; return n === "start" ? t = i.bottom : n === "end" ? t = i.top : z(n) ? t = i.getPixelForValue(n.value) : i.getBasePixel && (t = i.getBasePixel()), t; }
function ir(n, i, t) { let e; return n === "start" ? e = t : n === "end" ? e = i.options.reverse ? i.min : i.max : z(n) ? e = n.value : e = i.getBaseValue(), e; }
function sr(n) { let i = n.options, t = i.fill, e = C(t && t.target, t); return e === void 0 && (e = !!i.backgroundColor), e === !1 || e === null ? !1 : e === !0 ? "origin" : e; }
function nr(n) { let { scale: i, index: t, line: e } = n, s = [], o = e.segments, a = e.points, r = or(i, t); r.push(On({ x: null, y: i.bottom }, e)); for (let l = 0; l < o.length; l++) {
    let c = o[l];
    for (let h = c.start; h <= c.end; h++)
        ar(s, a[h], r);
} return new De({ points: s, options: {} }); }
function or(n, i) { let t = [], e = n.getMatchingVisibleMetas("line"); for (let s = 0; s < e.length; s++) {
    let o = e[s];
    if (o.index === i)
        break;
    o.hidden || t.unshift(o.dataset);
} return t; }
function ar(n, i, t) { let e = []; for (let s = 0; s < t.length; s++) {
    let o = t[s], { first: a, last: r, point: l } = rr(o, i, "x");
    if (!(!l || a && r)) {
        if (a)
            e.unshift(l);
        else if (n.push(l), !r)
            break;
    }
} n.push(...e); }
function rr(n, i, t) { let e = n.interpolate(i, t); if (!e)
    return {}; let s = e[t], o = n.segments, a = n.points, r = !1, l = !1; for (let c = 0; c < o.length; c++) {
    let h = o[c], d = a[h.start][t], u = a[h.end][t];
    if (lt(s, d, u)) {
        r = s === d, l = s === u;
        break;
    }
} return { first: r, last: l, point: e }; }
var Se = class {
    constructor(i) { this.x = i.x, this.y = i.y, this.radius = i.radius; }
    pathSegment(i, t, e) { let { x: s, y: o, radius: a } = this; return t = t || { start: 0, end: Y }, i.arc(s, o, a, t.end, t.start, !0), !e.bounds; }
    interpolate(i) { let { x: t, y: e, radius: s } = this, o = i.angle; return { x: t + Math.cos(o) * s, y: e + Math.sin(o) * s, angle: o }; }
};
function lr(n) { let { chart: i, fill: t, line: e } = n; if (B(t))
    return cr(i, t); if (t === "stack")
    return nr(n); if (t === "shape")
    return !0; let s = hr(n); return s instanceof Se ? s : On(s, e); }
function cr(n, i) { let t = n.getDatasetMeta(i); return t && n.isDatasetVisible(i) ? t.dataset : null; }
function hr(n) { return (n.scale || {}).getPointPositionForValue ? ur(n) : dr(n); }
function dr(n) { let { scale: i = {}, fill: t } = n, e = er(t, i); if (B(e)) {
    let s = i.isHorizontal();
    return { x: s ? e : null, y: s ? null : e };
} return null; }
function ur(n) { let { scale: i, fill: t } = n, e = i.options, s = i.getLabels().length, o = e.reverse ? i.max : i.min, a = ir(t, i, o), r = []; if (e.grid.circular) {
    let l = i.getPointPositionForValue(0, o);
    return new Se({ x: l.x, y: l.y, radius: i.getDistanceFromCenterForValue(a) });
} for (let l = 0; l < s; ++l)
    r.push(i.getPointPositionForValue(l, a)); return r; }
function ci(n, i, t) { let e = lr(i), { chart: s, index: o, line: a, scale: r, axis: l } = i, c = a.options, h = c.fill, d = c.backgroundColor, { above: u = d, below: f = d } = h || {}, g = s.getDatasetMeta(o), p = Qe(s, g); e && a.points.length && (Yt(n, t), fr(n, { line: a, target: e, above: u, below: f, area: t, scale: r, axis: l, clip: p }), Ut(n)); }
function fr(n, i) { let { line: t, target: e, above: s, below: o, area: a, scale: r, clip: l } = i, c = t._loop ? "angle" : i.axis; n.save(); let h = o; o !== s && (c === "x" ? (Xs(n, e, a.top), hi(n, { line: t, target: e, color: s, scale: r, property: c, clip: l }), n.restore(), n.save(), Xs(n, e, a.bottom)) : c === "y" && (Ks(n, e, a.left), hi(n, { line: t, target: e, color: o, scale: r, property: c, clip: l }), n.restore(), n.save(), Ks(n, e, a.right), h = s)), hi(n, { line: t, target: e, color: h, scale: r, property: c, clip: l }), n.restore(); }
function Xs(n, i, t) { let { segments: e, points: s } = i, o = !0, a = !1; n.beginPath(); for (let r of e) {
    let { start: l, end: c } = r, h = s[l], d = s[Pe(l, c, s)];
    o ? (n.moveTo(h.x, h.y), o = !1) : (n.lineTo(h.x, t), n.lineTo(h.x, h.y)), a = !!i.pathSegment(n, r, { move: a }), a ? n.closePath() : n.lineTo(d.x, t);
} n.lineTo(i.first().x, t), n.closePath(), n.clip(); }
function Ks(n, i, t) { let { segments: e, points: s } = i, o = !0, a = !1; n.beginPath(); for (let r of e) {
    let { start: l, end: c } = r, h = s[l], d = s[Pe(l, c, s)];
    o ? (n.moveTo(h.x, h.y), o = !1) : (n.lineTo(t, h.y), n.lineTo(h.x, h.y)), a = !!i.pathSegment(n, r, { move: a }), a ? n.closePath() : n.lineTo(t, d.y);
} n.lineTo(t, i.first().y), n.closePath(), n.clip(); }
function hi(n, i) { let { line: t, target: e, property: s, color: o, scale: a, clip: r } = i, l = qa(t, e, s); for (let { source: c, target: h, start: d, end: u } of l) {
    let { style: { backgroundColor: f = o } = {} } = c, g = e !== !0;
    n.save(), n.fillStyle = f, gr(n, a, r, g && wi(s, d, u)), n.beginPath();
    let p = !!t.pathSegment(n, c), m;
    if (g) {
        p ? n.closePath() : Gs(n, e, u, s);
        let x = !!e.pathSegment(n, h, { move: p, reverse: !0 });
        m = p && x, m || Gs(n, e, d, s);
    }
    n.closePath(), n.fill(m ? "evenodd" : "nonzero"), n.restore();
} }
function gr(n, i, t, e) { let s = i.chart.chartArea, { property: o, start: a, end: r } = e || {}; if (o === "x" || o === "y") {
    let l, c, h, d;
    o === "x" ? (l = a, c = s.top, h = r, d = s.bottom) : (l = s.left, c = a, h = s.right, d = r), n.beginPath(), t && (l = Math.max(l, t.left), h = Math.min(h, t.right), c = Math.max(c, t.top), d = Math.min(d, t.bottom)), n.rect(l, c, h - l, d - c), n.clip();
} }
function Gs(n, i, t, e) { let s = i.interpolate(t, e); s && n.lineTo(s.x, s.y); }
var pr = { id: "filler", afterDatasetsUpdate(n, i, t) { let e = (n.data.datasets || []).length, s = [], o, a, r, l; for (a = 0; a < e; ++a)
        o = n.getDatasetMeta(a), r = o.dataset, l = null, r && r.options && r instanceof De && (l = { visible: n.isDatasetVisible(a), index: a, fill: Qa(r, a, e), chart: n, axis: o.controller.options.indexAxis, scale: o.vScale, line: r }), o.$filler = l, s.push(l); for (a = 0; a < e; ++a)
        l = s[a], !(!l || l.fill === !1) && (l.fill = Za(s, a, t.propagate)); }, beforeDraw(n, i, t) { let e = t.drawTime === "beforeDraw", s = n.getSortedVisibleDatasetMetas(), o = n.chartArea; for (let a = s.length - 1; a >= 0; --a) {
        let r = s[a].$filler;
        r && (r.line.updateControlPoints(o, r.axis), e && r.fill && ci(n.ctx, r, o));
    } }, beforeDatasetsDraw(n, i, t) { if (t.drawTime !== "beforeDatasetsDraw")
        return; let e = n.getSortedVisibleDatasetMetas(); for (let s = e.length - 1; s >= 0; --s) {
        let o = e[s].$filler;
        Us(o) && ci(n.ctx, o, n.chartArea);
    } }, beforeDatasetDraw(n, i, t) { let e = i.meta.$filler; !Us(e) || t.drawTime !== "beforeDatasetDraw" || ci(n.ctx, e, n.chartArea); }, defaults: { propagate: !0, drawTime: "beforeDatasetDraw" } }, qs = (n, i) => { let { boxHeight: t = i, boxWidth: e = i } = n; return n.usePointStyle && (t = Math.min(t, i), e = n.pointStyleWidth || Math.min(e, i)), { boxWidth: e, boxHeight: t, itemHeight: Math.max(i, t) }; }, mr = (n, i) => n !== null && i !== null && n.datasetIndex === i.datasetIndex && n.index === i.index, we = class extends it {
    constructor(i) { super(), this._added = !1, this.legendHitBoxes = [], this._hoveredItem = null, this.doughnutMode = !1, this.chart = i.chart, this.options = i.options, this.ctx = i.ctx, this.legendItems = void 0, this.columnSizes = void 0, this.lineWidths = void 0, this.maxHeight = void 0, this.maxWidth = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.height = void 0, this.width = void 0, this._margins = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0; }
    update(i, t, e) { this.maxWidth = i, this.maxHeight = t, this._margins = e, this.setDimensions(), this.buildLabels(), this.fit(); }
    setDimensions() { this.isHorizontal() ? (this.width = this.maxWidth, this.left = this._margins.left, this.right = this.width) : (this.height = this.maxHeight, this.top = this._margins.top, this.bottom = this.height); }
    buildLabels() { let i = this.options.labels || {}, t = E(i.generateLabels, [this.chart], this) || []; i.filter && (t = t.filter(e => i.filter(e, this.chart.data))), i.sort && (t = t.sort((e, s) => i.sort(e, s, this.chart.data))), this.options.reverse && t.reverse(), this.legendItems = t; }
    fit() { let { options: i, ctx: t } = this; if (!i.display) {
        this.width = this.height = 0;
        return;
    } let e = i.labels, s = V(e.font), o = s.size, a = this._computeTitleHeight(), { boxWidth: r, itemHeight: l } = qs(e, o), c, h; t.font = s.string, this.isHorizontal() ? (c = this.maxWidth, h = this._fitRows(a, o, r, l) + 10) : (h = this.maxHeight, c = this._fitCols(a, s, r, l) + 10), this.width = Math.min(c, i.maxWidth || this.maxWidth), this.height = Math.min(h, i.maxHeight || this.maxHeight); }
    _fitRows(i, t, e, s) { let { ctx: o, maxWidth: a, options: { labels: { padding: r } } } = this, l = this.legendHitBoxes = [], c = this.lineWidths = [0], h = s + r, d = i; o.textAlign = "left", o.textBaseline = "middle"; let u = -1, f = -h; return this.legendItems.forEach((g, p) => { let m = e + t / 2 + o.measureText(g.text).width; (p === 0 || c[c.length - 1] + m + 2 * r > a) && (d += h, c[c.length - (p > 0 ? 0 : 1)] = 0, f += h, u++), l[p] = { left: 0, top: f, row: u, width: m, height: s }, c[c.length - 1] += m + r; }), d; }
    _fitCols(i, t, e, s) { let { ctx: o, maxHeight: a, options: { labels: { padding: r } } } = this, l = this.legendHitBoxes = [], c = this.columnSizes = [], h = a - i, d = r, u = 0, f = 0, g = 0, p = 0; return this.legendItems.forEach((m, x) => { let { itemWidth: b, itemHeight: y } = br(e, t, o, m, s); x > 0 && f + y + 2 * r > h && (d += u + r, c.push({ width: u, height: f }), g += u + r, p++, u = f = 0), l[x] = { left: g, top: f, col: p, width: b, height: y }, u = Math.max(u, b), f += y + r; }), d += u, c.push({ width: u, height: f }), d; }
    adjustHitBoxes() { if (!this.options.display)
        return; let i = this._computeTitleHeight(), { legendHitBoxes: t, options: { align: e, labels: { padding: s }, rtl: o } } = this, a = St(o, this.left, this.width); if (this.isHorizontal()) {
        let r = 0, l = H(e, this.left + s, this.right - this.lineWidths[r]);
        for (let c of t)
            r !== c.row && (r = c.row, l = H(e, this.left + s, this.right - this.lineWidths[r])), c.top += this.top + i + s, c.left = a.leftForLtr(a.x(l), c.width), l += c.width + s;
    }
    else {
        let r = 0, l = H(e, this.top + i + s, this.bottom - this.columnSizes[r].height);
        for (let c of t)
            c.col !== r && (r = c.col, l = H(e, this.top + i + s, this.bottom - this.columnSizes[r].height)), c.top = l, c.left += this.left + s, c.left = a.leftForLtr(a.x(c.left), c.width), l += c.height + s;
    } }
    isHorizontal() { return this.options.position === "top" || this.options.position === "bottom"; }
    draw() { if (this.options.display) {
        let i = this.ctx;
        Yt(i, this), this._draw(), Ut(i);
    } }
    _draw() { let { options: i, columnSizes: t, lineWidths: e, ctx: s } = this, { align: o, labels: a } = i, r = I.color, l = St(i.rtl, this.left, this.width), c = V(a.font), { padding: h } = a, d = c.size, u = d / 2, f; this.drawTitle(), s.textAlign = l.textAlign("left"), s.textBaseline = "middle", s.lineWidth = .5, s.font = c.string; let { boxWidth: g, boxHeight: p, itemHeight: m } = qs(a, d), x = function (v, S, k) { if (isNaN(g) || g <= 0 || isNaN(p) || p < 0)
        return; s.save(); let w = C(k.lineWidth, 1); if (s.fillStyle = C(k.fillStyle, r), s.lineCap = C(k.lineCap, "butt"), s.lineDashOffset = C(k.lineDashOffset, 0), s.lineJoin = C(k.lineJoin, "miter"), s.lineWidth = w, s.strokeStyle = C(k.strokeStyle, r), s.setLineDash(C(k.lineDash, [])), a.usePointStyle) {
        let P = { radius: p * Math.SQRT2 / 2, pointStyle: k.pointStyle, rotation: k.rotation, borderWidth: w }, D = l.xPlus(v, g / 2), A = S + u;
        Ji(s, P, D, A, a.pointStyleWidth && g);
    }
    else {
        let P = S + Math.max((d - p) / 2, 0), D = l.leftForLtr(v, g), A = gt(k.borderRadius);
        s.beginPath(), Object.values(A).some(N => N !== 0) ? Et(s, { x: D, y: P, w: g, h: p, radius: A }) : s.rect(D, P, g, p), s.fill(), w !== 0 && s.stroke();
    } s.restore(); }, b = function (v, S, k) { ft(s, k.text, v, S + m / 2, c, { strikethrough: k.hidden, textAlign: l.textAlign(k.textAlign) }); }, y = this.isHorizontal(), M = this._computeTitleHeight(); y ? f = { x: H(o, this.left + h, this.right - e[0]), y: this.top + h + M, line: 0 } : f = { x: this.left + h, y: H(o, this.top + M + h, this.bottom - t[0].height), line: 0 }, qe(this.ctx, i.textDirection); let _ = m + h; this.legendItems.forEach((v, S) => { s.strokeStyle = v.fontColor, s.fillStyle = v.fontColor; let k = s.measureText(v.text).width, w = l.textAlign(v.textAlign || (v.textAlign = a.textAlign)), P = g + u + k, D = f.x, A = f.y; l.setWidth(this.width), y ? S > 0 && D + P + h > this.right && (A = f.y += _, f.line++, D = f.x = H(o, this.left + h, this.right - e[f.line])) : S > 0 && A + _ > this.bottom && (D = f.x = D + t[f.line].width + h, f.line++, A = f.y = H(o, this.top + M + h, this.bottom - t[f.line].height)); let N = l.x(D); if (x(N, A, v), D = Gi(w, D + g + u, y ? D + P : this.right, i.rtl), b(l.x(D), A, v), y)
        f.x += P + h;
    else if (typeof v.text != "string") {
        let Z = c.lineHeight;
        f.y += Tn(v, Z) + h;
    }
    else
        f.y += _; }), Je(this.ctx, i.textDirection); }
    drawTitle() { let i = this.options, t = i.title, e = V(t.font), s = j(t.padding); if (!t.display)
        return; let o = St(i.rtl, this.left, this.width), a = this.ctx, r = t.position, l = e.size / 2, c = s.top + l, h, d = this.left, u = this.width; if (this.isHorizontal())
        u = Math.max(...this.lineWidths), h = this.top + c, d = H(i.align, d, this.right - u);
    else {
        let g = this.columnSizes.reduce((p, m) => Math.max(p, m.height), 0);
        h = c + H(i.align, this.top, this.bottom - g - i.labels.padding - this._computeTitleHeight());
    } let f = H(r, d, d + u); a.textAlign = o.textAlign(ce(r)), a.textBaseline = "middle", a.strokeStyle = t.color, a.fillStyle = t.color, a.font = e.string, ft(a, t.text, f, h, e); }
    _computeTitleHeight() { let i = this.options.title, t = V(i.font), e = j(i.padding); return i.display ? t.lineHeight + e.height : 0; }
    _getLegendItemAt(i, t) { let e, s, o; if (lt(i, this.left, this.right) && lt(t, this.top, this.bottom)) {
        for (o = this.legendHitBoxes, e = 0; e < o.length; ++e)
            if (s = o[e], lt(i, s.left, s.left + s.width) && lt(t, s.top, s.top + s.height))
                return this.legendItems[e];
    } return null; }
    handleEvent(i) { let t = this.options; if (!yr(i.type, t))
        return; let e = this._getLegendItemAt(i.x, i.y); if (i.type === "mousemove" || i.type === "mouseout") {
        let s = this._hoveredItem, o = mr(s, e);
        s && !o && E(t.onLeave, [i, s, this], this), this._hoveredItem = e, e && !o && E(t.onHover, [i, e, this], this);
    }
    else
        e && E(t.onClick, [i, e, this], this); }
};
function br(n, i, t, e, s) { let o = xr(e, n, i, t), a = _r(s, e, i.lineHeight); return { itemWidth: o, itemHeight: a }; }
function xr(n, i, t, e) { let s = n.text; return s && typeof s != "string" && (s = s.reduce((o, a) => o.length > a.length ? o : a)), i + t.size / 2 + e.measureText(s).width; }
function _r(n, i, t) { let e = n; return typeof i.text != "string" && (e = Tn(i, t)), e; }
function Tn(n, i) { let t = n.text ? n.text.length : 0; return i * t; }
function yr(n, i) { return !!((n === "mousemove" || n === "mouseout") && (i.onHover || i.onLeave) || i.onClick && (n === "click" || n === "mouseup")); }
var vr = { id: "legend", _element: we, start(n, i, t) { let e = n.legend = new we({ ctx: n.ctx, options: t, chart: n }); X.configure(n, e, t), X.addBox(n, e); }, stop(n) { X.removeBox(n, n.legend), delete n.legend; }, beforeUpdate(n, i, t) { let e = n.legend; X.configure(n, e, t), e.options = t; }, afterUpdate(n) { let i = n.legend; i.buildLabels(), i.adjustHitBoxes(); }, afterEvent(n, i) { i.replay || n.legend.handleEvent(i.event); }, defaults: { display: !0, position: "top", align: "center", fullSize: !0, reverse: !1, weight: 1e3, onClick(n, i, t) { let e = i.datasetIndex, s = t.chart; s.isDatasetVisible(e) ? (s.hide(e), i.hidden = !0) : (s.show(e), i.hidden = !1); }, onHover: null, onLeave: null, labels: { color: n => n.chart.options.color, boxWidth: 40, padding: 10, generateLabels(n) { let i = n.data.datasets, { labels: { usePointStyle: t, pointStyle: e, textAlign: s, color: o, useBorderRadius: a, borderRadius: r } } = n.legend.options; return n._getSortedDatasetMetas().map(l => { let c = l.controller.getStyle(t ? 0 : void 0), h = j(c.borderWidth); return { text: i[l.index].label, fillStyle: c.backgroundColor, fontColor: o, hidden: !l.visible, lineCap: c.borderCapStyle, lineDash: c.borderDash, lineDashOffset: c.borderDashOffset, lineJoin: c.borderJoinStyle, lineWidth: (h.width + h.height) / 4, strokeStyle: c.borderColor, pointStyle: e || c.pointStyle, rotation: c.rotation, textAlign: s || c.textAlign, borderRadius: a && (r || c.borderRadius), datasetIndex: l.index }; }, this); } }, title: { color: n => n.chart.options.color, display: !1, position: "center", text: "" } }, descriptors: { _scriptable: n => !n.startsWith("on"), labels: { _scriptable: n => !["generateLabels", "filter", "sort"].includes(n) } } }, ee = class extends it {
    constructor(i) { super(), this.chart = i.chart, this.options = i.options, this.ctx = i.ctx, this._padding = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0; }
    update(i, t) { let e = this.options; if (this.left = 0, this.top = 0, !e.display) {
        this.width = this.height = this.right = this.bottom = 0;
        return;
    } this.width = this.right = i, this.height = this.bottom = t; let s = K(e.text) ? e.text.length : 1; this._padding = j(e.padding); let o = s * V(e.font).lineHeight + this._padding.height; this.isHorizontal() ? this.height = o : this.width = o; }
    isHorizontal() { let i = this.options.position; return i === "top" || i === "bottom"; }
    _drawArgs(i) { let { top: t, left: e, bottom: s, right: o, options: a } = this, r = a.align, l = 0, c, h, d; return this.isHorizontal() ? (h = H(r, e, o), d = t + i, c = o - e) : (a.position === "left" ? (h = e + i, d = H(r, s, t), l = W * -.5) : (h = o - i, d = H(r, t, s), l = W * .5), c = s - t), { titleX: h, titleY: d, maxWidth: c, rotation: l }; }
    draw() { let i = this.ctx, t = this.options; if (!t.display)
        return; let e = V(t.font), o = e.lineHeight / 2 + this._padding.top, { titleX: a, titleY: r, maxWidth: l, rotation: c } = this._drawArgs(o); ft(i, t.text, 0, 0, e, { color: t.color, maxWidth: l, rotation: c, textAlign: ce(t.align), textBaseline: "middle", translation: [a, r] }); }
};
function Mr(n, i) { let t = new ee({ ctx: n.ctx, options: i, chart: n }); X.configure(n, t, i), X.addBox(n, t), n.titleBlock = t; }
var kr = { id: "title", _element: ee, start(n, i, t) { Mr(n, t); }, stop(n) { let i = n.titleBlock; X.removeBox(n, i), delete n.titleBlock; }, beforeUpdate(n, i, t) { let e = n.titleBlock; X.configure(n, e, t), e.options = t; }, defaults: { align: "center", display: !1, font: { weight: "bold" }, fullSize: !0, padding: 10, position: "top", text: "", weight: 2e3 }, defaultRoutes: { color: "color" }, descriptors: { _scriptable: !0, _indexable: !1 } }, pe = new WeakMap, Sr = { id: "subtitle", start(n, i, t) { let e = new ee({ ctx: n.ctx, options: t, chart: n }); X.configure(n, e, t), X.addBox(n, e), pe.set(n, e); }, stop(n) { X.removeBox(n, pe.get(n)), pe.delete(n); }, beforeUpdate(n, i, t) { let e = pe.get(n); X.configure(n, e, t), e.options = t; }, defaults: { align: "center", display: !1, font: { weight: "normal" }, fullSize: !0, padding: 0, position: "top", text: "", weight: 1500 }, defaultRoutes: { color: "color" }, descriptors: { _scriptable: !0, _indexable: !1 } }, Qt = { average(n) { if (!n.length)
        return !1; let i, t, e = new Set, s = 0, o = 0; for (i = 0, t = n.length; i < t; ++i) {
        let r = n[i].element;
        if (r && r.hasValue()) {
            let l = r.tooltipPosition();
            e.add(l.x), s += l.y, ++o;
        }
    } return o === 0 || e.size === 0 ? !1 : { x: [...e].reduce((r, l) => r + l) / e.size, y: s / o }; }, nearest(n, i) { if (!n.length)
        return !1; let t = i.x, e = i.y, s = Number.POSITIVE_INFINITY, o, a, r; for (o = 0, a = n.length; o < a; ++o) {
        let l = n[o].element;
        if (l && l.hasValue()) {
            let c = l.getCenterPoint(), h = Wi(i, c);
            h < s && (s = h, r = l);
        }
    } if (r) {
        let l = r.tooltipPosition();
        t = l.x, e = l.y;
    } return { x: t, y: e }; } };
function nt(n, i) { return i && (K(i) ? Array.prototype.push.apply(n, i) : n.push(i)), n; }
function ht(n) {
    return (typeof n == "string" || n instanceof String) && n.indexOf(`
`) > -1 ? n.split(`
`) : n;
}
function wr(n, i) { let { element: t, datasetIndex: e, index: s } = i, o = n.getDatasetMeta(e).controller, { label: a, value: r } = o.getLabelAndValue(s); return { chart: n, label: a, parsed: o.getParsed(s), raw: n.data.datasets[e].data[s], formattedValue: r, dataset: o.getDataset(), dataIndex: s, datasetIndex: e, element: t }; }
function Js(n, i) { let t = n.chart.ctx, { body: e, footer: s, title: o } = n, { boxWidth: a, boxHeight: r } = i, l = V(i.bodyFont), c = V(i.titleFont), h = V(i.footerFont), d = o.length, u = s.length, f = e.length, g = j(i.padding), p = g.height, m = 0, x = e.reduce((M, _) => M + _.before.length + _.lines.length + _.after.length, 0); if (x += n.beforeBody.length + n.afterBody.length, d && (p += d * c.lineHeight + (d - 1) * i.titleSpacing + i.titleMarginBottom), x) {
    let M = i.displayColors ? Math.max(r, l.lineHeight) : l.lineHeight;
    p += f * M + (x - f) * l.lineHeight + (x - 1) * i.bodySpacing;
} u && (p += i.footerMarginTop + u * h.lineHeight + (u - 1) * i.footerSpacing); let b = 0, y = function (M) { m = Math.max(m, t.measureText(M).width + b); }; return t.save(), t.font = c.string, O(n.title, y), t.font = l.string, O(n.beforeBody.concat(n.afterBody), y), b = i.displayColors ? a + 2 + i.boxPadding : 0, O(e, M => { O(M.before, y), O(M.lines, y), O(M.after, y); }), b = 0, t.font = h.string, O(n.footer, y), t.restore(), m += g.width, { width: m, height: p }; }
function Dr(n, i) { let { y: t, height: e } = i; return t < e / 2 ? "top" : t > n.height - e / 2 ? "bottom" : "center"; }
function Pr(n, i, t, e) { let { x: s, width: o } = e, a = t.caretSize + t.caretPadding; if (n === "left" && s + o + a > i.width || n === "right" && s - o - a < 0)
    return !0; }
function Cr(n, i, t, e) { let { x: s, width: o } = t, { width: a, chartArea: { left: r, right: l } } = n, c = "center"; return e === "center" ? c = s <= (r + l) / 2 ? "left" : "right" : s <= o / 2 ? c = "left" : s >= a - o / 2 && (c = "right"), Pr(c, n, i, t) && (c = "center"), c; }
function Zs(n, i, t) { let e = t.yAlign || i.yAlign || Dr(n, t); return { xAlign: t.xAlign || i.xAlign || Cr(n, i, t, e), yAlign: e }; }
function Ar(n, i) { let { x: t, width: e } = n; return i === "right" ? t -= e : i === "center" && (t -= e / 2), t; }
function Lr(n, i, t) { let { y: e, height: s } = n; return i === "top" ? e += t : i === "bottom" ? e -= s + t : e -= s / 2, e; }
function Qs(n, i, t, e) { let { caretSize: s, caretPadding: o, cornerRadius: a } = n, { xAlign: r, yAlign: l } = t, c = s + o, { topLeft: h, topRight: d, bottomLeft: u, bottomRight: f } = gt(a), g = Ar(i, r), p = Lr(i, l, c); return l === "center" ? r === "left" ? g += c : r === "right" && (g -= c) : r === "left" ? g -= Math.max(h, u) + s : r === "right" && (g += Math.max(d, f) + s), { x: U(g, 0, e.width - i.width), y: U(p, 0, e.height - i.height) }; }
function me(n, i, t) { let e = j(t.padding); return i === "center" ? n.x + n.width / 2 : i === "right" ? n.x + n.width - e.right : n.x + e.left; }
function tn(n) { return nt([], ht(n)); }
function Or(n, i, t) { return pt(n, { tooltip: i, tooltipItems: t, type: "tooltip" }); }
function en(n, i) { let t = i && i.dataset && i.dataset.tooltip && i.dataset.tooltip.callbacks; return t ? n.override(t) : n; }
var En = { beforeTitle: st, title(n) { if (n.length > 0) {
        let i = n[0], t = i.chart.data.labels, e = t ? t.length : 0;
        if (this && this.options && this.options.mode === "dataset")
            return i.dataset.label || "";
        if (i.label)
            return i.label;
        if (e > 0 && i.dataIndex < e)
            return t[i.dataIndex];
    } return ""; }, afterTitle: st, beforeBody: st, beforeLabel: st, label(n) { if (this && this.options && this.options.mode === "dataset")
        return n.label + ": " + n.formattedValue || n.formattedValue; let i = n.dataset.label || ""; i && (i += ": "); let t = n.formattedValue; return L(t) || (i += t), i; }, labelColor(n) { let t = n.chart.getDatasetMeta(n.datasetIndex).controller.getStyle(n.dataIndex); return { borderColor: t.borderColor, backgroundColor: t.backgroundColor, borderWidth: t.borderWidth, borderDash: t.borderDash, borderDashOffset: t.borderDashOffset, borderRadius: 0 }; }, labelTextColor() { return this.options.bodyColor; }, labelPointStyle(n) { let t = n.chart.getDatasetMeta(n.datasetIndex).controller.getStyle(n.dataIndex); return { pointStyle: t.pointStyle, rotation: t.rotation }; }, afterLabel: st, afterBody: st, beforeFooter: st, footer: st, afterFooter: st };
function q(n, i, t, e) { let s = n[i].call(t, e); return typeof s > "u" ? En[i].call(t, e) : s; }
var sn = (() => { class n extends it {
    static positioners = Qt;
    constructor(t) { super(), this.opacity = 0, this._active = [], this._eventPosition = void 0, this._size = void 0, this._cachedAnimations = void 0, this._tooltipItems = [], this.$animations = void 0, this.$context = void 0, this.chart = t.chart, this.options = t.options, this.dataPoints = void 0, this.title = void 0, this.beforeBody = void 0, this.body = void 0, this.afterBody = void 0, this.footer = void 0, this.xAlign = void 0, this.yAlign = void 0, this.x = void 0, this.y = void 0, this.height = void 0, this.width = void 0, this.caretX = void 0, this.caretY = void 0, this.labelColors = void 0, this.labelPointStyles = void 0, this.labelTextColors = void 0; }
    initialize(t) { this.options = t, this._cachedAnimations = void 0, this.$context = void 0; }
    _resolveAnimations() { let t = this._cachedAnimations; if (t)
        return t; let e = this.chart, s = this.options.setContext(this.getContext()), o = s.enabled && e.options.animation && s.animations, a = new ye(this.chart, o); return o._cacheable && (this._cachedAnimations = Object.freeze(a)), a; }
    getContext() { return this.$context || (this.$context = Or(this.chart.getContext(), this, this._tooltipItems)); }
    getTitle(t, e) { let { callbacks: s } = e, o = q(s, "beforeTitle", this, t), a = q(s, "title", this, t), r = q(s, "afterTitle", this, t), l = []; return l = nt(l, ht(o)), l = nt(l, ht(a)), l = nt(l, ht(r)), l; }
    getBeforeBody(t, e) { return tn(q(e.callbacks, "beforeBody", this, t)); }
    getBody(t, e) { let { callbacks: s } = e, o = []; return O(t, a => { let r = { before: [], lines: [], after: [] }, l = en(s, a); nt(r.before, ht(q(l, "beforeLabel", this, a))), nt(r.lines, q(l, "label", this, a)), nt(r.after, ht(q(l, "afterLabel", this, a))), o.push(r); }), o; }
    getAfterBody(t, e) { return tn(q(e.callbacks, "afterBody", this, t)); }
    getFooter(t, e) { let { callbacks: s } = e, o = q(s, "beforeFooter", this, t), a = q(s, "footer", this, t), r = q(s, "afterFooter", this, t), l = []; return l = nt(l, ht(o)), l = nt(l, ht(a)), l = nt(l, ht(r)), l; }
    _createItems(t) { let e = this._active, s = this.chart.data, o = [], a = [], r = [], l = [], c, h; for (c = 0, h = e.length; c < h; ++c)
        l.push(wr(this.chart, e[c])); return t.filter && (l = l.filter((d, u, f) => t.filter(d, u, f, s))), t.itemSort && (l = l.sort((d, u) => t.itemSort(d, u, s))), O(l, d => { let u = en(t.callbacks, d); o.push(q(u, "labelColor", this, d)), a.push(q(u, "labelPointStyle", this, d)), r.push(q(u, "labelTextColor", this, d)); }), this.labelColors = o, this.labelPointStyles = a, this.labelTextColors = r, this.dataPoints = l, l; }
    update(t, e) { let s = this.options.setContext(this.getContext()), o = this._active, a, r = []; if (!o.length)
        this.opacity !== 0 && (a = { opacity: 0 });
    else {
        let l = Qt[s.position].call(this, o, this._eventPosition);
        r = this._createItems(s), this.title = this.getTitle(r, s), this.beforeBody = this.getBeforeBody(r, s), this.body = this.getBody(r, s), this.afterBody = this.getAfterBody(r, s), this.footer = this.getFooter(r, s);
        let c = this._size = Js(this, s), h = Object.assign({}, l, c), d = Zs(this.chart, s, h), u = Qs(s, h, d, this.chart);
        this.xAlign = d.xAlign, this.yAlign = d.yAlign, a = { opacity: 1, x: u.x, y: u.y, width: c.width, height: c.height, caretX: l.x, caretY: l.y };
    } this._tooltipItems = r, this.$context = void 0, a && this._resolveAnimations().update(this, a), t && s.external && s.external.call(this, { chart: this.chart, tooltip: this, replay: e }); }
    drawCaret(t, e, s, o) { let a = this.getCaretPosition(t, s, o); e.lineTo(a.x1, a.y1), e.lineTo(a.x2, a.y2), e.lineTo(a.x3, a.y3); }
    getCaretPosition(t, e, s) { let { xAlign: o, yAlign: a } = this, { caretSize: r, cornerRadius: l } = s, { topLeft: c, topRight: h, bottomLeft: d, bottomRight: u } = gt(l), { x: f, y: g } = t, { width: p, height: m } = e, x, b, y, M, _, v; return a === "center" ? (_ = g + m / 2, o === "left" ? (x = f, b = x - r, M = _ + r, v = _ - r) : (x = f + p, b = x + r, M = _ - r, v = _ + r), y = x) : (o === "left" ? b = f + Math.max(c, d) + r : o === "right" ? b = f + p - Math.max(h, u) - r : b = this.caretX, a === "top" ? (M = g, _ = M - r, x = b - r, y = b + r) : (M = g + m, _ = M + r, x = b + r, y = b - r), v = M), { x1: x, x2: b, x3: y, y1: M, y2: _, y3: v }; }
    drawTitle(t, e, s) { let o = this.title, a = o.length, r, l, c; if (a) {
        let h = St(s.rtl, this.x, this.width);
        for (t.x = me(this, s.titleAlign, s), e.textAlign = h.textAlign(s.titleAlign), e.textBaseline = "middle", r = V(s.titleFont), l = s.titleSpacing, e.fillStyle = s.titleColor, e.font = r.string, c = 0; c < a; ++c)
            e.fillText(o[c], h.x(t.x), t.y + r.lineHeight / 2), t.y += r.lineHeight + l, c + 1 === a && (t.y += s.titleMarginBottom - l);
    } }
    _drawColorBox(t, e, s, o, a) { let r = this.labelColors[s], l = this.labelPointStyles[s], { boxHeight: c, boxWidth: h } = a, d = V(a.bodyFont), u = me(this, "left", a), f = o.x(u), g = c < d.lineHeight ? (d.lineHeight - c) / 2 : 0, p = e.y + g; if (a.usePointStyle) {
        let m = { radius: Math.min(h, c) / 2, pointStyle: l.pointStyle, rotation: l.rotation, borderWidth: 1 }, x = o.leftForLtr(f, h) + h / 2, b = p + c / 2;
        t.strokeStyle = a.multiKeyBackground, t.fillStyle = a.multiKeyBackground, de(t, m, x, b), t.strokeStyle = r.borderColor, t.fillStyle = r.backgroundColor, de(t, m, x, b);
    }
    else {
        t.lineWidth = z(r.borderWidth) ? Math.max(...Object.values(r.borderWidth)) : r.borderWidth || 1, t.strokeStyle = r.borderColor, t.setLineDash(r.borderDash || []), t.lineDashOffset = r.borderDashOffset || 0;
        let m = o.leftForLtr(f, h), x = o.leftForLtr(o.xPlus(f, 1), h - 2), b = gt(r.borderRadius);
        Object.values(b).some(y => y !== 0) ? (t.beginPath(), t.fillStyle = a.multiKeyBackground, Et(t, { x: m, y: p, w: h, h: c, radius: b }), t.fill(), t.stroke(), t.fillStyle = r.backgroundColor, t.beginPath(), Et(t, { x, y: p + 1, w: h - 2, h: c - 2, radius: b }), t.fill()) : (t.fillStyle = a.multiKeyBackground, t.fillRect(m, p, h, c), t.strokeRect(m, p, h, c), t.fillStyle = r.backgroundColor, t.fillRect(x, p + 1, h - 2, c - 2));
    } t.fillStyle = this.labelTextColors[s]; }
    drawBody(t, e, s) { let { body: o } = this, { bodySpacing: a, bodyAlign: r, displayColors: l, boxHeight: c, boxWidth: h, boxPadding: d } = s, u = V(s.bodyFont), f = u.lineHeight, g = 0, p = St(s.rtl, this.x, this.width), m = function (w) { e.fillText(w, p.x(t.x + g), t.y + f / 2), t.y += f + a; }, x = p.textAlign(r), b, y, M, _, v, S, k; for (e.textAlign = r, e.textBaseline = "middle", e.font = u.string, t.x = me(this, x, s), e.fillStyle = s.bodyColor, O(this.beforeBody, m), g = l && x !== "right" ? r === "center" ? h / 2 + d : h + 2 + d : 0, _ = 0, S = o.length; _ < S; ++_) {
        for (b = o[_], y = this.labelTextColors[_], e.fillStyle = y, O(b.before, m), M = b.lines, l && M.length && (this._drawColorBox(e, t, _, p, s), f = Math.max(u.lineHeight, c)), v = 0, k = M.length; v < k; ++v)
            m(M[v]), f = u.lineHeight;
        O(b.after, m);
    } g = 0, f = u.lineHeight, O(this.afterBody, m), t.y -= a; }
    drawFooter(t, e, s) { let o = this.footer, a = o.length, r, l; if (a) {
        let c = St(s.rtl, this.x, this.width);
        for (t.x = me(this, s.footerAlign, s), t.y += s.footerMarginTop, e.textAlign = c.textAlign(s.footerAlign), e.textBaseline = "middle", r = V(s.footerFont), e.fillStyle = s.footerColor, e.font = r.string, l = 0; l < a; ++l)
            e.fillText(o[l], c.x(t.x), t.y + r.lineHeight / 2), t.y += r.lineHeight + s.footerSpacing;
    } }
    drawBackground(t, e, s, o) { let { xAlign: a, yAlign: r } = this, { x: l, y: c } = t, { width: h, height: d } = s, { topLeft: u, topRight: f, bottomLeft: g, bottomRight: p } = gt(o.cornerRadius); e.fillStyle = o.backgroundColor, e.strokeStyle = o.borderColor, e.lineWidth = o.borderWidth, e.beginPath(), e.moveTo(l + u, c), r === "top" && this.drawCaret(t, e, s, o), e.lineTo(l + h - f, c), e.quadraticCurveTo(l + h, c, l + h, c + f), r === "center" && a === "right" && this.drawCaret(t, e, s, o), e.lineTo(l + h, c + d - p), e.quadraticCurveTo(l + h, c + d, l + h - p, c + d), r === "bottom" && this.drawCaret(t, e, s, o), e.lineTo(l + g, c + d), e.quadraticCurveTo(l, c + d, l, c + d - g), r === "center" && a === "left" && this.drawCaret(t, e, s, o), e.lineTo(l, c + u), e.quadraticCurveTo(l, c, l + u, c), e.closePath(), e.fill(), o.borderWidth > 0 && e.stroke(); }
    _updateAnimationTarget(t) { let e = this.chart, s = this.$animations, o = s && s.x, a = s && s.y; if (o || a) {
        let r = Qt[t.position].call(this, this._active, this._eventPosition);
        if (!r)
            return;
        let l = this._size = Js(this, t), c = Object.assign({}, r, this._size), h = Zs(e, t, c), d = Qs(t, c, h, e);
        (o._to !== d.x || a._to !== d.y) && (this.xAlign = h.xAlign, this.yAlign = h.yAlign, this.width = l.width, this.height = l.height, this.caretX = r.x, this.caretY = r.y, this._resolveAnimations().update(this, d));
    } }
    _willRender() { return !!this.opacity; }
    draw(t) { let e = this.options.setContext(this.getContext()), s = this.opacity; if (!s)
        return; this._updateAnimationTarget(e); let o = { width: this.width, height: this.height }, a = { x: this.x, y: this.y }; s = Math.abs(s) < .001 ? 0 : s; let r = j(e.padding), l = this.title.length || this.beforeBody.length || this.body.length || this.afterBody.length || this.footer.length; e.enabled && l && (t.save(), t.globalAlpha = s, this.drawBackground(a, t, o, e), qe(t, e.textDirection), a.y += r.top, this.drawTitle(a, t, e), this.drawBody(a, t, e), this.drawFooter(a, t, e), Je(t, e.textDirection), t.restore()); }
    getActiveElements() { return this._active || []; }
    setActiveElements(t, e) { let s = this._active, o = t.map(({ datasetIndex: l, index: c }) => { let h = this.chart.getDatasetMeta(l); if (!h)
        throw new Error("Cannot find a dataset at index " + l); return { datasetIndex: l, element: h.data[c], index: c }; }), a = !Nt(s, o), r = this._positionChanged(o, e); (a || r) && (this._active = o, this._eventPosition = e, this._ignoreReplayEvents = !0, this.update(!0)); }
    handleEvent(t, e, s = !0) { if (e && this._ignoreReplayEvents)
        return !1; this._ignoreReplayEvents = !1; let o = this.options, a = this._active || [], r = this._getActiveElements(t, a, e, s), l = this._positionChanged(r, t), c = e || !Nt(r, a) || l; return c && (this._active = r, (o.enabled || o.external) && (this._eventPosition = { x: t.x, y: t.y }, this.update(!0, e))), c; }
    _getActiveElements(t, e, s, o) { let a = this.options; if (t.type === "mouseout")
        return []; if (!o)
        return e.filter(l => this.chart.data.datasets[l.datasetIndex] && this.chart.getDatasetMeta(l.datasetIndex).controller.getParsed(l.index) !== void 0); let r = this.chart.getElementsAtEventForMode(t, a.mode, a, s); return a.reverse && r.reverse(), r; }
    _positionChanged(t, e) { let { caretX: s, caretY: o, options: a } = this, r = Qt[a.position].call(this, t, e); return r !== !1 && (s !== r.x || o !== r.y); }
} return n; })(), Tr = { id: "tooltip", _element: sn, positioners: Qt, afterInit(n, i, t) { t && (n.tooltip = new sn({ chart: n, options: t })); }, beforeUpdate(n, i, t) { n.tooltip && n.tooltip.initialize(t); }, reset(n, i, t) { n.tooltip && n.tooltip.initialize(t); }, afterDraw(n) { let i = n.tooltip; if (i && i._willRender()) {
        let t = { tooltip: i };
        if (n.notifyPlugins("beforeTooltipDraw", ae(oe({}, t), { cancelable: !0 })) === !1)
            return;
        i.draw(n.ctx), n.notifyPlugins("afterTooltipDraw", t);
    } }, afterEvent(n, i) { if (n.tooltip) {
        let t = i.replay;
        n.tooltip.handleEvent(i.event, t, i.inChartArea) && (i.changed = !0);
    } }, defaults: { enabled: !0, external: null, position: "average", backgroundColor: "rgba(0,0,0,0.8)", titleColor: "#fff", titleFont: { weight: "bold" }, titleSpacing: 2, titleMarginBottom: 6, titleAlign: "left", bodyColor: "#fff", bodySpacing: 2, bodyFont: {}, bodyAlign: "left", footerColor: "#fff", footerSpacing: 2, footerMarginTop: 6, footerFont: { weight: "bold" }, footerAlign: "left", padding: 6, caretPadding: 2, caretSize: 5, cornerRadius: 6, boxHeight: (n, i) => i.bodyFont.size, boxWidth: (n, i) => i.bodyFont.size, multiKeyBackground: "#fff", displayColors: !0, boxPadding: 0, borderColor: "rgba(0,0,0,0)", borderWidth: 0, animation: { duration: 400, easing: "easeOutQuart" }, animations: { numbers: { type: "number", properties: ["x", "y", "width", "height", "caretX", "caretY"] }, opacity: { easing: "linear", duration: 200 } }, callbacks: En }, defaultRoutes: { bodyFont: "font", footerFont: "font", titleFont: "font" }, descriptors: { _scriptable: n => n !== "filter" && n !== "itemSort" && n !== "external", _indexable: !1, callbacks: { _scriptable: !1, _indexable: !1 }, animation: { _fallback: !1 }, animations: { _fallback: "animation" } }, additionalOptionScopes: ["interaction"] }, Er = Object.freeze({ __proto__: null, Colors: Ya, Decimation: Ga, Filler: pr, Legend: vr, SubTitle: Sr, Title: kr, Tooltip: Tr }), Rr = (n, i, t, e) => (typeof i == "string" ? (t = n.push(i) - 1, e.unshift({ index: t, label: i })) : isNaN(i) && (t = null), t);
function Ir(n, i, t, e) { let s = n.indexOf(i); if (s === -1)
    return Rr(n, i, t, e); let o = n.lastIndexOf(i); return s !== o ? t : s; }
var zr = (n, i) => n === null ? null : U(Math.round(n), 0, i);
function nn(n) { let i = this.getLabels(); return n >= 0 && n < i.length ? i[n] : n; }
var Fr = (() => { class n extends Pt {
    static id = "category";
    static defaults = { ticks: { callback: nn } };
    constructor(t) { super(t), this._startValue = void 0, this._valueRange = 0, this._addedLabels = []; }
    init(t) { let e = this._addedLabels; if (e.length) {
        let s = this.getLabels();
        for (let { index: o, label: a } of e)
            s[o] === a && s.splice(o, 1);
        this._addedLabels = [];
    } super.init(t); }
    parse(t, e) { if (L(t))
        return null; let s = this.getLabels(); return e = isFinite(e) && s[e] === t ? e : Ir(s, t, C(e, t), this._addedLabels), zr(e, s.length - 1); }
    determineDataLimits() { let { minDefined: t, maxDefined: e } = this.getUserBounds(), { min: s, max: o } = this.getMinMax(!0); this.options.bounds === "ticks" && (t || (s = 0), e || (o = this.getLabels().length - 1)), this.min = s, this.max = o; }
    buildTicks() { let t = this.min, e = this.max, s = this.options.offset, o = [], a = this.getLabels(); a = t === 0 && e === a.length - 1 ? a : a.slice(t, e + 1), this._valueRange = Math.max(a.length - (s ? 0 : 1), 1), this._startValue = this.min - (s ? .5 : 0); for (let r = t; r <= e; r++)
        o.push({ value: r }); return o; }
    getLabelForValue(t) { return nn.call(this, t); }
    configure() { super.configure(), this.isHorizontal() || (this._reversePixels = !this._reversePixels); }
    getPixelForValue(t) { return typeof t != "number" && (t = this.parse(t)), t === null ? NaN : this.getPixelForDecimal((t - this._startValue) / this._valueRange); }
    getPixelForTick(t) { let e = this.ticks; return t < 0 || t > e.length - 1 ? null : this.getPixelForValue(e[t].value); }
    getValueForPixel(t) { return Math.round(this._startValue + this.getDecimalForPixel(t) * this._valueRange); }
    getBasePixel() { return this.bottom; }
} return n; })();
function Br(n, i) { let t = [], { bounds: s, step: o, min: a, max: r, precision: l, count: c, maxTicks: h, maxDigits: d, includeBounds: u } = n, f = o || 1, g = h - 1, { min: p, max: m } = i, x = !L(a), b = !L(r), y = !L(c), M = (m - p) / (d + 1), _ = Le((m - p) / g / f) * f, v, S, k, w; if (_ < 1e-14 && !x && !b)
    return [{ value: p }, { value: m }]; w = Math.ceil(m / _) - Math.floor(p / _), w > g && (_ = Le(w * _ / g / f) * f), L(l) || (v = Math.pow(10, l), _ = Math.ceil(_ * v) / v), s === "ticks" ? (S = Math.floor(p / _) * _, k = Math.ceil(m / _) * _) : (S = p, k = m), x && b && o && Ni((r - a) / o, _ / 1e3) ? (w = Math.round(Math.min((r - a) / _, h)), _ = (r - a) / w, S = a, k = r) : y ? (S = x ? a : S, k = b ? r : k, w = c - 1, _ = (k - S) / w) : (w = (k - S) / _, re(w, Math.round(w), _ / 1e3) ? w = Math.round(w) : w = Math.ceil(w)); let P = Math.max(Te(_), Te(S)); v = Math.pow(10, L(l) ? P : l), S = Math.round(S * v) / v, k = Math.round(k * v) / v; let D = 0; for (x && (u && S !== a ? (t.push({ value: a }), S < a && D++, re(Math.round((S + D * _) * v) / v, a, on(a, M, n)) && D++) : S < a && D++); D < w; ++D) {
    let A = Math.round((S + D * _) * v) / v;
    if (b && A > r)
        break;
    t.push({ value: A });
} return b && u && k !== r ? t.length && re(t[t.length - 1].value, r, on(r, M, n)) ? t[t.length - 1].value = r : t.push({ value: r }) : (!b || k === r) && t.push({ value: k }), t; }
function on(n, i, { horizontal: t, minRotation: e }) { let s = tt(e), o = (t ? Math.sin(s) : Math.cos(s)) || .001, a = .75 * i * ("" + n).length; return Math.min(i / o, a); }
var Ft = class extends Pt {
    constructor(i) { super(i), this.start = void 0, this.end = void 0, this._startValue = void 0, this._endValue = void 0, this._valueRange = 0; }
    parse(i, t) { return L(i) || (typeof i == "number" || i instanceof Number) && !isFinite(+i) ? null : +i; }
    handleTickRangeOptions() { let { beginAtZero: i } = this.options, { minDefined: t, maxDefined: e } = this.getUserBounds(), { min: s, max: o } = this, a = l => s = t ? s : l, r = l => o = e ? o : l; if (i) {
        let l = at(s), c = at(o);
        l < 0 && c < 0 ? r(0) : l > 0 && c > 0 && a(0);
    } if (s === o) {
        let l = o === 0 ? 1 : Math.abs(o * .05);
        r(o + l), i || a(s - l);
    } this.min = s, this.max = o; }
    getTickLimit() { let i = this.options.ticks, { maxTicksLimit: t, stepSize: e } = i, s; return e ? (s = Math.ceil(this.max / e) - Math.floor(this.min / e) + 1, s > 1e3 && (console.warn(`scales.${this.id}.ticks.stepSize: ${e} would result generating up to ${s} ticks. Limiting to 1000.`), s = 1e3)) : (s = this.computeTickLimit(), t = t || 11), t && (s = Math.min(t, s)), s; }
    computeTickLimit() { return Number.POSITIVE_INFINITY; }
    buildTicks() { let i = this.options, t = i.ticks, e = this.getTickLimit(); e = Math.max(2, e); let s = { maxTicks: e, bounds: i.bounds, min: i.min, max: i.max, precision: t.precision, step: t.stepSize, count: t.count, maxDigits: this._maxDigits(), horizontal: this.isHorizontal(), minRotation: t.minRotation || 0, includeBounds: t.includeBounds !== !1 }, o = this._range || this, a = Br(s, o); return i.bounds === "ticks" && Oe(a, this, "value"), i.reverse ? (a.reverse(), this.start = this.max, this.end = this.min) : (this.start = this.min, this.end = this.max), a; }
    configure() { let i = this.ticks, t = this.min, e = this.max; if (super.configure(), this.options.offset && i.length) {
        let s = (e - t) / Math.max(i.length - 1, 1) / 2;
        t -= s, e += s;
    } this._startValue = t, this._endValue = e, this._valueRange = e - t; }
    getLabelForValue(i) { return $t(i, this.chart.options.locale, this.options.ticks.format); }
}, Di = class extends Ft {
    static id = "linear";
    static defaults = { ticks: { callback: he.formatters.numeric } };
    determineDataLimits() { let { min: i, max: t } = this.getMinMax(!0); this.min = B(i) ? i : 0, this.max = B(t) ? t : 1, this.handleTickRangeOptions(); }
    computeTickLimit() { let i = this.isHorizontal(), t = i ? this.width : this.height, e = tt(this.options.ticks.minRotation), s = (i ? Math.sin(e) : Math.cos(e)) || .001, o = this._resolveTickFontOptions(0); return Math.ceil(t / Math.min(40, o.lineHeight / s)); }
    getPixelForValue(i) { return i === null ? NaN : this.getPixelForDecimal((i - this._startValue) / this._valueRange); }
    getValueForPixel(i) { return this._startValue + this.getDecimalForPixel(i) * this._valueRange; }
}, ie = n => Math.floor(Ot(n)), Dt = (n, i) => Math.pow(10, ie(n) + i);
function an(n) { return n / Math.pow(10, ie(n)) === 1; }
function rn(n, i, t) { let e = Math.pow(10, t), s = Math.floor(n / e); return Math.ceil(i / e) - s; }
function Vr(n, i) { let t = i - n, e = ie(t); for (; rn(n, i, e) > 10;)
    e++; for (; rn(n, i, e) < 10;)
    e--; return Math.min(e, ie(n)); }
function Nr(n, { min: i, max: t }) { i = G(n.min, i); let e = [], s = ie(i), o = Vr(i, t), a = o < 0 ? Math.pow(10, Math.abs(o)) : 1, r = Math.pow(10, o), l = s > o ? Math.pow(10, s) : 0, c = Math.round((i - l) * a) / a, h = Math.floor((i - l) / r / 10) * r * 10, d = Math.floor((c - h) / Math.pow(10, o)), u = G(n.min, Math.round((l + h + d * Math.pow(10, o)) * a) / a); for (; u < t;)
    e.push({ value: u, major: an(u), significand: d }), d >= 10 ? d = d < 15 ? 15 : 20 : d++, d >= 20 && (o++, d = 2, a = o >= 0 ? 1 : a), u = Math.round((l + h + d * Math.pow(10, o)) * a) / a; let f = G(n.max, u); return e.push({ value: f, major: an(f), significand: d }), e; }
var Pi = class extends Pt {
    static id = "logarithmic";
    static defaults = { ticks: { callback: he.formatters.logarithmic, major: { enabled: !0 } } };
    constructor(i) { super(i), this.start = void 0, this.end = void 0, this._startValue = void 0, this._valueRange = 0; }
    parse(i, t) { let e = Ft.prototype.parse.apply(this, [i, t]); if (e === 0) {
        this._zero = !0;
        return;
    } return B(e) && e > 0 ? e : null; }
    determineDataLimits() { let { min: i, max: t } = this.getMinMax(!0); this.min = B(i) ? Math.max(0, i) : null, this.max = B(t) ? Math.max(0, t) : null, this.options.beginAtZero && (this._zero = !0), this._zero && this.min !== this._suggestedMin && !B(this._userMin) && (this.min = i === Dt(this.min, 0) ? Dt(this.min, -1) : Dt(this.min, 0)), this.handleTickRangeOptions(); }
    handleTickRangeOptions() { let { minDefined: i, maxDefined: t } = this.getUserBounds(), e = this.min, s = this.max, o = r => e = i ? e : r, a = r => s = t ? s : r; e === s && (e <= 0 ? (o(1), a(10)) : (o(Dt(e, -1)), a(Dt(s, 1)))), e <= 0 && o(Dt(s, -1)), s <= 0 && a(Dt(e, 1)), this.min = e, this.max = s; }
    buildTicks() { let i = this.options, t = { min: this._userMin, max: this._userMax }, e = Nr(t, this); return i.bounds === "ticks" && Oe(e, this, "value"), i.reverse ? (e.reverse(), this.start = this.max, this.end = this.min) : (this.start = this.min, this.end = this.max), e; }
    getLabelForValue(i) { return i === void 0 ? "0" : $t(i, this.chart.options.locale, this.options.ticks.format); }
    configure() { let i = this.min; super.configure(), this._startValue = Ot(i), this._valueRange = Ot(this.max) - Ot(i); }
    getPixelForValue(i) { return (i === void 0 || i === 0) && (i = this.min), i === null || isNaN(i) ? NaN : this.getPixelForDecimal(i === this.min ? 0 : (Ot(i) - this._startValue) / this._valueRange); }
    getValueForPixel(i) { let t = this.getDecimalForPixel(i); return Math.pow(10, this._startValue + t * this._valueRange); }
};
function Ci(n) { let i = n.ticks; if (i.display && n.display) {
    let t = j(i.backdropPadding);
    return C(i.font && i.font.size, I.font.size) + t.height;
} return 0; }
function Wr(n, i, t) { return t = K(t) ? t : [t], { w: qi(n, i.string, t), h: t.length * i.lineHeight }; }
function ln(n, i, t, e, s) { return n === e || n === s ? { start: i - t / 2, end: i + t / 2 } : n < e || n > s ? { start: i - t, end: i } : { start: i, end: i + t }; }
function Hr(n) { let i = { l: n.left + n._padding.left, r: n.right - n._padding.right, t: n.top + n._padding.top, b: n.bottom - n._padding.bottom }, t = Object.assign({}, i), e = [], s = [], o = n._pointLabels.length, a = n.options.pointLabels, r = a.centerPointLabels ? W / o : 0; for (let l = 0; l < o; l++) {
    let c = a.setContext(n.getPointLabelContext(l));
    s[l] = c.padding;
    let h = n.getPointPosition(l, n.drawingArea + s[l], r), d = V(c.font), u = Wr(n.ctx, d, n._pointLabels[l]);
    e[l] = u;
    let f = rt(n.getIndexAngle(l) + r), g = Math.round(le(f)), p = ln(g, h.x, u.w, 0, 180), m = ln(g, h.y, u.h, 90, 270);
    jr(t, i, f, p, m);
} n.setCenterPoint(i.l - t.l, t.r - i.r, i.t - t.t, t.b - i.b), n._pointLabelItems = Ur(n, e, s); }
function jr(n, i, t, e, s) { let o = Math.abs(Math.sin(t)), a = Math.abs(Math.cos(t)), r = 0, l = 0; e.start < i.l ? (r = (i.l - e.start) / o, n.l = Math.min(n.l, i.l - r)) : e.end > i.r && (r = (e.end - i.r) / o, n.r = Math.max(n.r, i.r + r)), s.start < i.t ? (l = (i.t - s.start) / a, n.t = Math.min(n.t, i.t - l)) : s.end > i.b && (l = (s.end - i.b) / a, n.b = Math.max(n.b, i.b + l)); }
function $r(n, i, t) { let e = n.drawingArea, { extra: s, additionalAngle: o, padding: a, size: r } = t, l = n.getPointPosition(i, e + s + a, o), c = Math.round(le(rt(l.angle + Q))), h = Gr(l.y, r.h, c), d = Xr(c), u = Kr(l.x, r.w, d); return { visible: !0, x: l.x, y: h, textAlign: d, left: u, top: h, right: u + r.w, bottom: h + r.h }; }
function Yr(n, i) { if (!i)
    return !0; let { left: t, top: e, right: s, bottom: o } = n; return !(ut({ x: t, y: e }, i) || ut({ x: t, y: o }, i) || ut({ x: s, y: e }, i) || ut({ x: s, y: o }, i)); }
function Ur(n, i, t) { let e = [], s = n._pointLabels.length, o = n.options, { centerPointLabels: a, display: r } = o.pointLabels, l = { extra: Ci(o) / 2, additionalAngle: a ? W / s : 0 }, c; for (let h = 0; h < s; h++) {
    l.padding = t[h], l.size = i[h];
    let d = $r(n, h, l);
    e.push(d), r === "auto" && (d.visible = Yr(d, c), d.visible && (c = d));
} return e; }
function Xr(n) { return n === 0 || n === 180 ? "center" : n < 180 ? "left" : "right"; }
function Kr(n, i, t) { return t === "right" ? n -= i : t === "center" && (n -= i / 2), n; }
function Gr(n, i, t) { return t === 90 || t === 270 ? n -= i / 2 : (t > 270 || t < 90) && (n -= i), n; }
function qr(n, i, t) { let { left: e, top: s, right: o, bottom: a } = t, { backdropColor: r } = i; if (!L(r)) {
    let l = gt(i.borderRadius), c = j(i.backdropPadding);
    n.fillStyle = r;
    let h = e - c.left, d = s - c.top, u = o - e + c.width, f = a - s + c.height;
    Object.values(l).some(g => g !== 0) ? (n.beginPath(), Et(n, { x: h, y: d, w: u, h: f, radius: l }), n.fill()) : n.fillRect(h, d, u, f);
} }
function Jr(n, i) { let { ctx: t, options: { pointLabels: e } } = n; for (let s = i - 1; s >= 0; s--) {
    let o = n._pointLabelItems[s];
    if (!o.visible)
        continue;
    let a = e.setContext(n.getPointLabelContext(s));
    qr(t, a, o);
    let r = V(a.font), { x: l, y: c, textAlign: h } = o;
    ft(t, n._pointLabels[s], l, c + r.lineHeight / 2, r, { color: a.color, textAlign: h, textBaseline: "middle" });
} }
function Rn(n, i, t, e) { let { ctx: s } = n; if (t)
    s.arc(n.xCenter, n.yCenter, i, 0, Y);
else {
    let o = n.getPointPosition(0, i);
    s.moveTo(o.x, o.y);
    for (let a = 1; a < e; a++)
        o = n.getPointPosition(a, i), s.lineTo(o.x, o.y);
} }
function Zr(n, i, t, e, s) { let o = n.ctx, a = i.circular, { color: r, lineWidth: l } = i; !a && !e || !r || !l || t < 0 || (o.save(), o.strokeStyle = r, o.lineWidth = l, o.setLineDash(s.dash || []), o.lineDashOffset = s.dashOffset, o.beginPath(), Rn(n, t, a, e), o.closePath(), o.stroke(), o.restore()); }
function Qr(n, i, t) { return pt(n, { label: t, index: i, type: "pointLabel" }); }
var Ai = class extends Ft {
    static id = "radialLinear";
    static defaults = { display: !0, animate: !0, position: "chartArea", angleLines: { display: !0, lineWidth: 1, borderDash: [], borderDashOffset: 0 }, grid: { circular: !1 }, startAngle: 0, ticks: { showLabelBackdrop: !0, callback: he.formatters.numeric }, pointLabels: { backdropColor: void 0, backdropPadding: 2, display: !0, font: { size: 10 }, callback(i) { return i; }, padding: 5, centerPointLabels: !1 } };
    static defaultRoutes = { "angleLines.color": "borderColor", "pointLabels.color": "color", "ticks.color": "color" };
    static descriptors = { angleLines: { _fallback: "grid" } };
    constructor(i) { super(i), this.xCenter = void 0, this.yCenter = void 0, this.drawingArea = void 0, this._pointLabels = [], this._pointLabelItems = []; }
    setDimensions() { let i = this._padding = j(Ci(this.options) / 2), t = this.width = this.maxWidth - i.width, e = this.height = this.maxHeight - i.height; this.xCenter = Math.floor(this.left + t / 2 + i.left), this.yCenter = Math.floor(this.top + e / 2 + i.top), this.drawingArea = Math.floor(Math.min(t, e) / 2); }
    determineDataLimits() { let { min: i, max: t } = this.getMinMax(!1); this.min = B(i) && !isNaN(i) ? i : 0, this.max = B(t) && !isNaN(t) ? t : 0, this.handleTickRangeOptions(); }
    computeTickLimit() { return Math.ceil(this.drawingArea / Ci(this.options)); }
    generateTickLabels(i) { Ft.prototype.generateTickLabels.call(this, i), this._pointLabels = this.getLabels().map((t, e) => { let s = E(this.options.pointLabels.callback, [t, e], this); return s || s === 0 ? s : ""; }).filter((t, e) => this.chart.getDataVisibility(e)); }
    fit() { let i = this.options; i.display && i.pointLabels.display ? Hr(this) : this.setCenterPoint(0, 0, 0, 0); }
    setCenterPoint(i, t, e, s) { this.xCenter += Math.floor((i - t) / 2), this.yCenter += Math.floor((e - s) / 2), this.drawingArea -= Math.min(this.drawingArea / 2, Math.max(i, t, e, s)); }
    getIndexAngle(i) { let t = Y / (this._pointLabels.length || 1), e = this.options.startAngle || 0; return rt(i * t + tt(e)); }
    getDistanceFromCenterForValue(i) { if (L(i))
        return NaN; let t = this.drawingArea / (this.max - this.min); return this.options.reverse ? (this.max - i) * t : (i - this.min) * t; }
    getValueForDistanceFromCenter(i) { if (L(i))
        return NaN; let t = i / (this.drawingArea / (this.max - this.min)); return this.options.reverse ? this.max - t : this.min + t; }
    getPointLabelContext(i) { let t = this._pointLabels || []; if (i >= 0 && i < t.length) {
        let e = t[i];
        return Qr(this.getContext(), i, e);
    } }
    getPointPosition(i, t, e = 0) { let s = this.getIndexAngle(i) - Q + e; return { x: Math.cos(s) * t + this.xCenter, y: Math.sin(s) * t + this.yCenter, angle: s }; }
    getPointPositionForValue(i, t) { return this.getPointPosition(i, this.getDistanceFromCenterForValue(t)); }
    getBasePosition(i) { return this.getPointPositionForValue(i || 0, this.getBaseValue()); }
    getPointLabelPosition(i) { let { left: t, top: e, right: s, bottom: o } = this._pointLabelItems[i]; return { left: t, top: e, right: s, bottom: o }; }
    drawBackground() { let { backgroundColor: i, grid: { circular: t } } = this.options; if (i) {
        let e = this.ctx;
        e.save(), e.beginPath(), Rn(this, this.getDistanceFromCenterForValue(this._endValue), t, this._pointLabels.length), e.closePath(), e.fillStyle = i, e.fill(), e.restore();
    } }
    drawGrid() { let i = this.ctx, t = this.options, { angleLines: e, grid: s, border: o } = t, a = this._pointLabels.length, r, l, c; if (t.pointLabels.display && Jr(this, a), s.display && this.ticks.forEach((h, d) => { if (d !== 0 || d === 0 && this.min < 0) {
        l = this.getDistanceFromCenterForValue(h.value);
        let u = this.getContext(d), f = s.setContext(u), g = o.setContext(u);
        Zr(this, f, l, a, g);
    } }), e.display) {
        for (i.save(), r = a - 1; r >= 0; r--) {
            let h = e.setContext(this.getPointLabelContext(r)), { color: d, lineWidth: u } = h;
            !u || !d || (i.lineWidth = u, i.strokeStyle = d, i.setLineDash(h.borderDash), i.lineDashOffset = h.borderDashOffset, l = this.getDistanceFromCenterForValue(t.reverse ? this.min : this.max), c = this.getPointPosition(r, l), i.beginPath(), i.moveTo(this.xCenter, this.yCenter), i.lineTo(c.x, c.y), i.stroke());
        }
        i.restore();
    } }
    drawBorder() { }
    drawLabels() { let i = this.ctx, t = this.options, e = t.ticks; if (!e.display)
        return; let s = this.getIndexAngle(0), o, a; i.save(), i.translate(this.xCenter, this.yCenter), i.rotate(s), i.textAlign = "center", i.textBaseline = "middle", this.ticks.forEach((r, l) => { if (l === 0 && this.min >= 0 && !t.reverse)
        return; let c = e.setContext(this.getContext(l)), h = V(c.font); if (o = this.getDistanceFromCenterForValue(this.ticks[l].value), c.showLabelBackdrop) {
        i.font = h.string, a = i.measureText(r.label).width, i.fillStyle = c.backdropColor;
        let d = j(c.backdropPadding);
        i.fillRect(-a / 2 - d.left, -o - h.size / 2 - d.top, a + d.width, h.size + d.height);
    } ft(i, r.label, 0, -o, h, { color: c.color, strokeColor: c.textStrokeColor, strokeWidth: c.textStrokeWidth }); }), i.restore(); }
    drawTitle() { }
}, Ce = { millisecond: { common: !0, size: 1, steps: 1e3 }, second: { common: !0, size: 1e3, steps: 60 }, minute: { common: !0, size: 6e4, steps: 60 }, hour: { common: !0, size: 36e5, steps: 24 }, day: { common: !0, size: 864e5, steps: 30 }, week: { common: !1, size: 6048e5, steps: 4 }, month: { common: !0, size: 2628e6, steps: 12 }, quarter: { common: !1, size: 7884e6, steps: 4 }, year: { common: !0, size: 3154e7 } }, J = Object.keys(Ce);
function cn(n, i) { return n - i; }
function hn(n, i) { if (L(i))
    return null; let t = n._adapter, { parser: e, round: s, isoWeekday: o } = n._parseOpts, a = i; return typeof e == "function" && (a = e(a)), B(a) || (a = typeof e == "string" ? t.parse(a, e) : t.parse(a)), a === null ? null : (s && (a = s === "week" && (Mt(o) || o === !0) ? t.startOf(a, "isoWeek", o) : t.startOf(a, s)), +a); }
function dn(n, i, t, e) { let s = J.length; for (let o = J.indexOf(n); o < s - 1; ++o) {
    let a = Ce[J[o]], r = a.steps ? a.steps : Number.MAX_SAFE_INTEGER;
    if (a.common && Math.ceil((t - i) / (r * a.size)) <= e)
        return J[o];
} return J[s - 1]; }
function tl(n, i, t, e, s) { for (let o = J.length - 1; o >= J.indexOf(t); o--) {
    let a = J[o];
    if (Ce[a].common && n._adapter.diff(s, e, a) >= i - 1)
        return a;
} return J[t ? J.indexOf(t) : 0]; }
function el(n) { for (let i = J.indexOf(n) + 1, t = J.length; i < t; ++i)
    if (Ce[J[i]].common)
        return J[i]; }
function un(n, i, t) { if (!t)
    n[i] = !0;
else if (t.length) {
    let { lo: e, hi: s } = ji(t, i), o = t[e] >= i ? t[e] : t[s];
    n[o] = !0;
} }
function il(n, i, t, e) { let s = n._adapter, o = +s.startOf(i[0].value, e), a = i[i.length - 1].value, r, l; for (r = o; r <= a; r = +s.add(r, 1, e))
    l = t[r], l >= 0 && (i[l].major = !0); return i; }
function fn(n, i, t) { let e = [], s = {}, o = i.length, a, r; for (a = 0; a < o; ++a)
    r = i[a], s[r] = a, e.push({ value: r, major: !1 }); return o === 0 || !t ? e : il(n, e, s, t); }
var Li = (() => { class n extends Pt {
    static id = "time";
    static defaults = { bounds: "data", adapters: {}, time: { parser: !1, unit: !1, round: !1, isoWeekday: !1, minUnit: "millisecond", displayFormats: {} }, ticks: { source: "auto", callback: !1, major: { enabled: !1 } } };
    constructor(t) { super(t), this._cache = { data: [], labels: [], all: [] }, this._unit = "day", this._majorUnit = void 0, this._offsets = {}, this._normalized = !1, this._parseOpts = void 0; }
    init(t, e = {}) { let s = t.time || (t.time = {}), o = this._adapter = new uo._date(t.adapters.date); o.init(e), Wt(s.displayFormats, o.formats()), this._parseOpts = { parser: s.parser, round: s.round, isoWeekday: s.isoWeekday }, super.init(t), this._normalized = e.normalized; }
    parse(t, e) { return t === void 0 ? null : hn(this, t); }
    beforeLayout() { super.beforeLayout(), this._cache = { data: [], labels: [], all: [] }; }
    determineDataLimits() { let t = this.options, e = this._adapter, s = t.time.unit || "day", { min: o, max: a, minDefined: r, maxDefined: l } = this.getUserBounds(); function c(h) { !r && !isNaN(h.min) && (o = Math.min(o, h.min)), !l && !isNaN(h.max) && (a = Math.max(a, h.max)); } (!r || !l) && (c(this._getLabelBounds()), (t.bounds !== "ticks" || t.ticks.source !== "labels") && c(this.getMinMax(!1))), o = B(o) && !isNaN(o) ? o : +e.startOf(Date.now(), s), a = B(a) && !isNaN(a) ? a : +e.endOf(Date.now(), s) + 1, this.min = Math.min(o, a - 1), this.max = Math.max(o + 1, a); }
    _getLabelBounds() { let t = this.getLabelTimestamps(), e = Number.POSITIVE_INFINITY, s = Number.NEGATIVE_INFINITY; return t.length && (e = t[0], s = t[t.length - 1]), { min: e, max: s }; }
    buildTicks() { let t = this.options, e = t.time, s = t.ticks, o = s.source === "labels" ? this.getLabelTimestamps() : this._generate(); t.bounds === "ticks" && o.length && (this.min = this._userMin || o[0], this.max = this._userMax || o[o.length - 1]); let a = this.min, r = this.max, l = Yi(o, a, r); return this._unit = e.unit || (s.autoSkip ? dn(e.minUnit, this.min, this.max, this._getLabelCapacity(a)) : tl(this, l.length, e.minUnit, this.min, this.max)), this._majorUnit = !s.major.enabled || this._unit === "year" ? void 0 : el(this._unit), this.initOffsets(o), t.reverse && l.reverse(), fn(this, l, this._majorUnit); }
    afterAutoSkip() { this.options.offsetAfterAutoskip && this.initOffsets(this.ticks.map(t => +t.value)); }
    initOffsets(t = []) { let e = 0, s = 0, o, a; this.options.offset && t.length && (o = this.getDecimalForValue(t[0]), t.length === 1 ? e = 1 - o : e = (this.getDecimalForValue(t[1]) - o) / 2, a = this.getDecimalForValue(t[t.length - 1]), t.length === 1 ? s = a : s = (a - this.getDecimalForValue(t[t.length - 2])) / 2); let r = t.length < 3 ? .5 : .25; e = U(e, 0, r), s = U(s, 0, r), this._offsets = { start: e, end: s, factor: 1 / (e + 1 + s) }; }
    _generate() { let t = this._adapter, e = this.min, s = this.max, o = this.options, a = o.time, r = a.unit || dn(a.minUnit, e, s, this._getLabelCapacity(e)), l = C(o.ticks.stepSize, 1), c = r === "week" ? a.isoWeekday : !1, h = Mt(c) || c === !0, d = {}, u = e, f, g; if (h && (u = +t.startOf(u, "isoWeek", c)), u = +t.startOf(u, h ? "day" : r), t.diff(s, e, r) > 1e5 * l)
        throw new Error(e + " and " + s + " are too far apart with stepSize of " + l + " " + r); let p = o.ticks.source === "data" && this.getDataTimestamps(); for (f = u, g = 0; f < s; f = +t.add(f, l, r), g++)
        un(d, f, p); return (f === s || o.bounds === "ticks" || g === 1) && un(d, f, p), Object.keys(d).sort(cn).map(m => +m); }
    getLabelForValue(t) { let e = this._adapter, s = this.options.time; return s.tooltipFormat ? e.format(t, s.tooltipFormat) : e.format(t, s.displayFormats.datetime); }
    format(t, e) { let o = this.options.time.displayFormats, a = this._unit, r = e || o[a]; return this._adapter.format(t, r); }
    _tickFormatFunction(t, e, s, o) { let a = this.options, r = a.ticks.callback; if (r)
        return E(r, [t, e, s], this); let l = a.time.displayFormats, c = this._unit, h = this._majorUnit, d = c && l[c], u = h && l[h], f = s[e], g = h && u && f && f.major; return this._adapter.format(t, o || (g ? u : d)); }
    generateTickLabels(t) { let e, s, o; for (e = 0, s = t.length; e < s; ++e)
        o = t[e], o.label = this._tickFormatFunction(o.value, e, t); }
    getDecimalForValue(t) { return t === null ? NaN : (t - this.min) / (this.max - this.min); }
    getPixelForValue(t) { let e = this._offsets, s = this.getDecimalForValue(t); return this.getPixelForDecimal((e.start + s) * e.factor); }
    getValueForPixel(t) { let e = this._offsets, s = this.getDecimalForPixel(t) / e.factor - e.end; return this.min + s * (this.max - this.min); }
    _getLabelSize(t) { let e = this.options.ticks, s = this.ctx.measureText(t).width, o = tt(this.isHorizontal() ? e.maxRotation : e.minRotation), a = Math.cos(o), r = Math.sin(o), l = this._resolveTickFontOptions(0).size; return { w: s * a + l * r, h: s * r + l * a }; }
    _getLabelCapacity(t) { let e = this.options.time, s = e.displayFormats, o = s[e.unit] || s.millisecond, a = this._tickFormatFunction(t, 0, fn(this, [t], this._majorUnit), o), r = this._getLabelSize(a), l = Math.floor(this.isHorizontal() ? this.width / r.w : this.height / r.h) - 1; return l > 0 ? l : 1; }
    getDataTimestamps() { let t = this._cache.data || [], e, s; if (t.length)
        return t; let o = this.getMatchingVisibleMetas(); if (this._normalized && o.length)
        return this._cache.data = o[0].controller.getAllParsedValues(this); for (e = 0, s = o.length; e < s; ++e)
        t = t.concat(o[e].controller.getAllParsedValues(this)); return this._cache.data = this.normalize(t); }
    getLabelTimestamps() { let t = this._cache.labels || [], e, s; if (t.length)
        return t; let o = this.getLabels(); for (e = 0, s = o.length; e < s; ++e)
        t.push(hn(this, o[e])); return this._cache.labels = this._normalized ? t : this.normalize(t); }
    normalize(t) { return Ie(t.sort(cn)); }
} return n; })();
function be(n, i, t) { let e = 0, s = n.length - 1, o, a, r, l; t ? (i >= n[e].pos && i <= n[s].pos && ({ lo: e, hi: s } = Tt(n, "pos", i)), { pos: o, time: r } = n[e], { pos: a, time: l } = n[s]) : (i >= n[e].time && i <= n[s].time && ({ lo: e, hi: s } = Tt(n, "time", i)), { time: o, pos: r } = n[e], { time: a, pos: l } = n[s]); let c = a - o; return c ? r + (l - r) * (i - o) / c : r; }
var Oi = class extends Li {
    static id = "timeseries";
    static defaults = Li.defaults;
    constructor(i) { super(i), this._table = [], this._minPos = void 0, this._tableRange = void 0; }
    initOffsets() { let i = this._getTimestampsForTable(), t = this._table = this.buildLookupTable(i); this._minPos = be(t, this.min), this._tableRange = be(t, this.max) - this._minPos, super.initOffsets(i); }
    buildLookupTable(i) { let { min: t, max: e } = this, s = [], o = [], a, r, l, c, h; for (a = 0, r = i.length; a < r; ++a)
        c = i[a], c >= t && c <= e && s.push(c); if (s.length < 2)
        return [{ time: t, pos: 0 }, { time: e, pos: 1 }]; for (a = 0, r = s.length; a < r; ++a)
        h = s[a + 1], l = s[a - 1], c = s[a], Math.round((h + l) / 2) !== c && o.push({ time: c, pos: a / (r - 1) }); return o; }
    _generate() { let i = this.min, t = this.max, e = super.getDataTimestamps(); return (!e.includes(i) || !e.length) && e.splice(0, 0, i), (!e.includes(t) || e.length === 1) && e.push(t), e.sort((s, o) => s - o); }
    _getTimestampsForTable() { let i = this._cache.all || []; if (i.length)
        return i; let t = this.getDataTimestamps(), e = this.getLabelTimestamps(); return t.length && e.length ? i = this.normalize(t.concat(e)) : i = t.length ? t : e, i = this._cache.all = i, i; }
    getDecimalForValue(i) { return (be(this._table, i) - this._minPos) / this._tableRange; }
    getValueForPixel(i) { let t = this._offsets, e = this.getDecimalForPixel(i) / t.factor - t.end; return be(this._table, e * this._tableRange + this._minPos, !0); }
}, sl = Object.freeze({ __proto__: null, CategoryScale: Fr, LinearScale: Di, LogarithmicScale: Pi, RadialLinearScale: Ai, TimeScale: Li, TimeSeriesScale: Oi }), ol = [ho, Ba, Er, sl];
export { ct as a, ui as b, ye as c, xt as d, so as e, no as f, Ti as g, ao as h, mn as i, ro as j, lo as k, co as l, ho as m, uo as n, bo as o, X as p, ve as q, gi as r, pi as s, zo as t, it as u, Pt as v, ot as w, ma as x, vi as y, De as z, Ta as A, ki as B, Ba as C, Ya as D, Ga as E, pr as F, vr as G, kr as H, Sr as I, Tr as J, Er as K, Fr as L, Di as M, Pi as N, Ai as O, Li as P, Oi as Q, sl as R, ol as S };
/*! Bundled license information:

chart.js/dist/chart.js:
  (*!
   * Chart.js v4.5.0
   * https://www.chartjs.org
   * (c) 2025 Chart.js Contributors
   * Released under the MIT License
   *)
*/
