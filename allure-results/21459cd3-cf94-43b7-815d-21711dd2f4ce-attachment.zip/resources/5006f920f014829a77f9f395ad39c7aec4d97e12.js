function c(r) { return Array.isArray(r) ? r : [r]; }
export { c as a };
