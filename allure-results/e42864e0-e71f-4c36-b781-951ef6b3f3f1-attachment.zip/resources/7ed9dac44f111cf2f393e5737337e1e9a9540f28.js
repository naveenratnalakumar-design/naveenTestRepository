import { a as te, b as I, f as re } from "@nf-internal/chunk-6KUZPJZH";
import { D as ie, E as $e, F as qe, G as He, b as m, c as b, d as Oe, g as Se, o as Pe, p as Le, q as Ae, r as oe, u as ke, w as Ve } from "@nf-internal/chunk-L2D3IU5T";
import { a as $, b as q, i as ne } from "@nf-internal/chunk-66YHNWRR";
import { BehaviorSubject as Ln, Observable as An } from "rxjs";
import { setActiveConsumer as T } from "@angular/core/primitives/signals";
import { isNotFound as kn } from "@angular/core/primitives/di";
var pr = "https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss", f = class extends Error {
    code;
    constructor(n, t) { super(Y(n, t)), this.code = n; }
};
function Vn(e) { return `NG0${Math.abs(e)}`; }
function Y(e, n) { return `${Vn(e)}${n ? ": " + n : ""}`; }
var gr = globalThis;
function c(e) {
    for (let n in e)
        if (e[n] === c)
            return n;
    throw Error("");
}
function mr(e, n) {
    for (let t in n)
        n.hasOwnProperty(t) && !e.hasOwnProperty(t) && (e[t] = n[t]);
}
function S(e) {
    if (typeof e == "string")
        return e;
    if (Array.isArray(e))
        return `[${e.map(S).join(", ")}]`;
    if (e == null)
        return "" + e;
    let n = e.overriddenName || e.name;
    if (n)
        return `${n}`;
    let t = e.toString();
    if (t == null)
        return "" + t;
    let r = t.indexOf(`
`);
    return r >= 0 ? t.slice(0, r) : t;
}
function vr(e, n) { return e ? n ? `${e} ${n}` : e : n || ""; }
function yr(e, n = 100) {
    if (!e || n < 1 || e.length <= n)
        return e;
    if (n == 1)
        return e.substring(0, 1) + "...";
    let t = Math.round(n / 2);
    return e.substring(0, t) + "..." + e.substring(e.length - t);
}
var $n = c({ __forward_ref__: c });
function Ke(e) { return e.__forward_ref__ = Ke, e.toString = function () { return S(this()); }, e; }
function v(e) { return qn(e) ? e() : e; }
function qn(e) { return typeof e == "function" && e.hasOwnProperty($n) && e.__forward_ref__ === Ke; }
function Ir(e, n, t) { e != n && J(t, e, n, "=="); }
function Hn(e, n) { e == null && J(n, e, null, "!="); }
function J(e, n, t, r) { throw new Error(`ASSERTION ERROR: ${e}` + (r == null ? "" : ` [Expected=> ${t} ${r} ${n} <=Actual]`)); }
function _(e) { return { token: e.token, providedIn: e.providedIn || null, factory: e.factory, value: void 0 }; }
var Er = _;
function Dr(e) { return { providers: e.providers || [], imports: e.imports || [] }; }
function Z(e) { return Gn(e, Xe); }
function wr(e) { return Z(e) !== null; }
function Gn(e, n) { return e.hasOwnProperty(n) && e[n] || null; }
function Bn(e) { let n = e?.[Xe] ?? null; return n || null; }
function Ge(e) { return e && e.hasOwnProperty(Be) ? e[Be] : null; }
var Xe = c({ \u0275prov: c }), Be = c({ \u0275inj: c }), g = class {
    _desc;
    ngMetadataName = "InjectionToken";
    \u0275prov;
    constructor(n, t) { this._desc = n, this.\u0275prov = void 0, typeof t == "number" ? this.__NG_ELEMENT_ID__ = t : t !== void 0 && (this.\u0275prov = _({ token: this, providedIn: t.providedIn || "root", factory: t.factory })); }
    get multi() { return this; }
    toString() { return `InjectionToken ${this._desc}`; }
}, Ue;
function Tr(e) { J("setInjectorProfilerContext should never be called in production mode"); let n = Ue; return Ue = e, n; }
function en(e) { return e && !!e.\u0275providers; }
var Un = c({ \u0275cmp: c }), Wn = c({ \u0275dir: c }), zn = c({ \u0275pipe: c }), Yn = c({ \u0275mod: c }), We = c({ \u0275fac: c }), Nr = c({ __NG_ELEMENT_ID__: c }), ze = c({ __NG_ENV_ID__: c });
function Jn(e) { return typeof e == "string" ? e : e == null ? "" : String(e); }
function Ye(e) { return typeof e == "function" ? e.name || e.toString() : typeof e == "object" && e != null && typeof e.type == "function" ? e.type.name || e.type.toString() : Jn(e); }
var Ie = c({ ngErrorCode: c }), nn = c({ ngErrorMessage: c }), O = c({ ngTokenPath: c });
function Zn(e, n) { return tn("", -200, n); }
function Qn(e, n) { throw new f(-201, !1); }
function Kn(e, n) { e[O] ??= []; let t = e[O], r; typeof n == "object" && "multi" in n && n?.multi === !0 ? (Hn(n.provide, "Token with multi: true should have a provide property"), r = Ye(n.provide)) : r = Ye(n), t[0] !== r && e[O].unshift(r); }
function Xn(e, n) { let t = e[O], r = e[Ie], o = e[nn] || e.message; return e.message = nt(o, r, t, n), e; }
function tn(e, n, t) { let r = new f(n, e); return r[Ie] = n, r[nn] = e, t && (r[O] = t), r; }
function et(e) { return e[Ie]; }
function nt(e, n, t = [], r = null) { let o = ""; t && t.length > 1 && (o = ` Path: ${t.join(" -> ")}.`); let i = r ? ` Source: ${r}.` : ""; return Y(n, `${e}${i}${o}`); }
var ue;
function rn() { return ue; }
function E(e) { let n = ue; return ue = e, n; }
function tt(e, n, t) {
    let r = Z(e);
    if (r && r.providedIn == "root")
        return r.value === void 0 ? r.value = r.factory() : r.value;
    if (t & 8)
        return null;
    if (n !== void 0)
        return n;
    Qn(e, "Injector");
}
var rt = {}, w = rt, ce = "__NG_DI_FLAG__", ae = class {
    injector;
    constructor(n) { this.injector = n; }
    retrieve(n, t) {
        let r = G(t) || 0;
        try {
            return this.injector.get(n, r & 8 ? null : w, r);
        }
        catch (o) {
            if (re(o))
                return o;
            throw o;
        }
    }
};
function ot(e, n = 0) {
    let t = te();
    if (t === void 0)
        throw new f(-203, !1);
    if (t === null)
        return tt(e, void 0, n);
    {
        let r = it(n), o = t.retrieve(e, r);
        if (re(o)) {
            if (r.optional)
                return null;
            throw o;
        }
        return o;
    }
}
function C(e, n = 0) { return (rn() || ot)(v(e), n); }
function xr(e) { throw new f(202, !1); }
function h(e, n) { return C(e, G(n)); }
function G(e) { return typeof e > "u" || typeof e == "number" ? e : 0 | (e.optional && 8) | (e.host && 1) | (e.self && 2) | (e.skipSelf && 4); }
function it(e) { return { optional: !!(e & 8), host: !!(e & 1), self: !!(e & 2), skipSelf: !!(e & 4) }; }
function de(e) {
    let n = [];
    for (let t = 0; t < e.length; t++) {
        let r = v(e[t]);
        if (Array.isArray(r)) {
            if (r.length === 0)
                throw new f(900, !1);
            let o, i = 0;
            for (let u = 0; u < r.length; u++) {
                let d = r[u], a = st(d);
                typeof a == "number" ? a === -1 ? o = d.token : i |= a : o = d;
            }
            n.push(C(o, i));
        }
        else
            n.push(C(r));
    }
    return n;
}
function Cr(e, n) { return e[ce] = n, e.prototype[ce] = n, e; }
function st(e) { return e[ce]; }
function B(e, n) { let t = e.hasOwnProperty(We); return t ? e[We] : null; }
function Mr(e, n, t) {
    if (e.length !== n.length)
        return !1;
    for (let r = 0; r < e.length; r++) {
        let o = e[r], i = n[r];
        if (t && (o = t(o), i = t(i)), i !== o)
            return !1;
    }
    return !0;
}
function _r(e) { return e.flat(Number.POSITIVE_INFINITY); }
function Ee(e, n) { e.forEach(t => Array.isArray(t) ? Ee(t, n) : n(t)); }
function Fr(e, n, t) { n >= e.length ? e.push(t) : e.splice(n, 0, t); }
function Rr(e, n) { return n >= e.length - 1 ? e.pop() : e.splice(n, 1)[0]; }
function br(e, n) {
    let t = [];
    for (let r = 0; r < e; r++)
        t.push(n);
    return t;
}
function jr(e, n, t) {
    let r = e.length - t;
    for (; n < r;)
        e[n] = e[n + t], n++;
    for (; t--;)
        e.pop();
}
function ut(e, n, t, r) {
    let o = e.length;
    if (o == n)
        e.push(t, r);
    else if (o === 1)
        e.push(r, e[0]), e[0] = t;
    else {
        for (o--, e.push(e[o - 1], e[o]); o > n;) {
            let i = o - 2;
            e[o] = e[i], o--;
        }
        e[n] = t, e[n + 1] = r;
    }
}
function Or(e, n, t) { let r = on(e, n); return r >= 0 ? e[r | 1] = t : (r = ~r, ut(e, r, n, t)), r; }
function Sr(e, n) {
    let t = on(e, n);
    if (t >= 0)
        return e[t | 1];
}
function on(e, n) { return ct(e, n, 1); }
function ct(e, n, t) {
    let r = 0, o = e.length >> t;
    for (; o !== r;) {
        let i = r + (o - r >> 1), u = e[i << t];
        if (n === u)
            return i << t;
        u > n ? o = i : r = i + 1;
    }
    return ~(o << t);
}
var Pr = {}, U = [], Q = new g(""), sn = new g("", -1), un = new g(""), W = class {
    get(n, t = w) {
        if (t === w) {
            let o = tn("", -201);
            throw o.name = "\u0275NotFound", o;
        }
        return t;
    }
};
function at(e) { return e[Yn] || null; }
function Lr(e) {
    let n = at(e);
    if (!n)
        throw new f(915, !1);
    return n;
}
function cn(e) { return e[Un] || null; }
function dt(e) { return e[Wn] || null; }
function lt(e) { return e[zn] || null; }
function Ar(e) { let n = cn(e) || dt(e) || lt(e); return n !== null && n.standalone; }
function an(e) { return { \u0275providers: e }; }
function ft(e) { return an([{ provide: Q, multi: !0, useValue: e }]); }
function ht(...e) { return { \u0275providers: pt(!0, e), \u0275fromNgModule: !0 }; }
function pt(e, ...n) { let t = [], r = new Set, o, i = u => { t.push(u); }; return Ee(n, u => { let d = u; le(d, i, [], r) && (o ||= [], o.push(d)); }), o !== void 0 && dn(o, i), t; }
function dn(e, n) {
    for (let t = 0; t < e.length; t++) {
        let { ngModule: r, providers: o } = e[t];
        De(o, i => { n(i, r); });
    }
}
function le(e, n, t, r) {
    if (e = v(e), !e)
        return !1;
    let o = null, i = Ge(e), u = !i && cn(e);
    if (!i && !u) {
        let a = e.ngModule;
        if (i = Ge(a), i)
            o = a;
        else
            return !1;
    }
    else {
        if (u && !u.standalone)
            return !1;
        o = e;
    }
    let d = r.has(o);
    if (u) {
        if (d)
            return !1;
        if (r.add(o), u.dependencies) {
            let a = typeof u.dependencies == "function" ? u.dependencies() : u.dependencies;
            for (let l of a)
                le(l, n, t, r);
        }
    }
    else if (i) {
        if (i.imports != null && !d) {
            r.add(o);
            let l;
            try {
                Ee(i.imports, D => { le(D, n, t, r) && (l ||= [], l.push(D)); });
            }
            finally { }
            l !== void 0 && dn(l, n);
        }
        if (!d) {
            let l = B(o) || (() => new o);
            n({ provide: o, useFactory: l, deps: U }, o), n({ provide: un, useValue: o, multi: !0 }, o), n({ provide: Q, useValue: () => C(o), multi: !0 }, o);
        }
        let a = i.providers;
        if (a != null && !d) {
            let l = e;
            De(a, D => { n(D, l); });
        }
    }
    else
        return !1;
    return o !== e && e.providers !== void 0;
}
function De(e, n) {
    for (let t of e)
        en(t) && (t = t.\u0275providers), Array.isArray(t) ? De(t, n) : n(t);
}
var gt = c({ provide: String, useValue: c });
function ln(e) { return e !== null && typeof e == "object" && gt in e; }
function mt(e) { return !!(e && e.useExisting); }
function vt(e) { return !!(e && e.useFactory); }
function fe(e) { return typeof e == "function"; }
function kr(e) { return !!e.useClass; }
var yt = new g(""), H = {}, Je = {}, se;
function fn() { return se === void 0 && (se = new W), se; }
var P = class {
}, z = class extends P {
    parent;
    source;
    scopes;
    records = new Map;
    _ngOnDestroyHooks = new Set;
    _onDestroyHooks = [];
    get destroyed() { return this._destroyed; }
    _destroyed = !1;
    injectorDefTypes;
    constructor(n, t, r, o) { super(), this.parent = t, this.source = r, this.scopes = o, pe(n, u => this.processProvider(u)), this.records.set(sn, N(void 0, this)), o.has("environment") && this.records.set(P, N(void 0, this)); let i = this.records.get(yt); i != null && typeof i.value == "string" && this.scopes.add(i.value), this.injectorDefTypes = new Set(this.get(un, U, { self: !0 })); }
    retrieve(n, t) {
        let r = G(t) || 0;
        try {
            return this.get(n, w, r);
        }
        catch (o) {
            if (kn(o))
                return o;
            throw o;
        }
    }
    destroy() {
        j(this), this._destroyed = !0;
        let n = T(null);
        try {
            for (let r of this._ngOnDestroyHooks)
                r.ngOnDestroy();
            let t = this._onDestroyHooks;
            this._onDestroyHooks = [];
            for (let r of t)
                r();
        }
        finally {
            this.records.clear(), this._ngOnDestroyHooks.clear(), this.injectorDefTypes.clear(), T(n);
        }
    }
    onDestroy(n) { return j(this), this._onDestroyHooks.push(n), () => this.removeOnDestroy(n); }
    runInContext(n) {
        j(this);
        let t = I(this), r = E(void 0), o;
        try {
            return n();
        }
        finally {
            I(t), E(r);
        }
    }
    get(n, t = w, r) {
        if (j(this), n.hasOwnProperty(ze))
            return n[ze](this);
        let o = G(r), i, u = I(this), d = E(void 0);
        try {
            if (!(o & 4)) {
                let l = this.records.get(n);
                if (l === void 0) {
                    let D = Nt(n) && Z(n);
                    D && this.injectableDefInScope(D) ? l = N(he(n), H) : l = null, this.records.set(n, l);
                }
                if (l != null)
                    return this.hydrate(n, l, o);
            }
            let a = o & 2 ? fn() : this.parent;
            return t = o & 8 && t === w ? null : t, a.get(n, t);
        }
        catch (a) {
            let l = et(a);
            throw l === -200 || l === -201 ? new f(l, null) : a;
        }
        finally {
            E(d), I(u);
        }
    }
    resolveInjectorInitializers() {
        let n = T(null), t = I(this), r = E(void 0), o;
        try {
            let i = this.get(Q, U, { self: !0 });
            for (let u of i)
                u();
        }
        finally {
            I(t), E(r), T(n);
        }
    }
    toString() {
        let n = [], t = this.records;
        for (let r of t.keys())
            n.push(S(r));
        return `R3Injector[${n.join(", ")}]`;
    }
    processProvider(n) {
        n = v(n);
        let t = fe(n) ? n : v(n && n.provide), r = Et(n);
        if (!fe(n) && n.multi === !0) {
            let o = this.records.get(t);
            o || (o = N(void 0, H, !0), o.factory = () => de(o.multi), this.records.set(t, o)), t = n, o.multi.push(n);
        }
        this.records.set(t, r);
    }
    hydrate(n, t, r) {
        let o = T(null);
        try {
            if (t.value === Je)
                throw Zn(S(n));
            return t.value === H && (t.value = Je, t.value = t.factory(void 0, r)), typeof t.value == "object" && t.value && Tt(t.value) && this._ngOnDestroyHooks.add(t.value), t.value;
        }
        finally {
            T(o);
        }
    }
    injectableDefInScope(n) {
        if (!n.providedIn)
            return !1;
        let t = v(n.providedIn);
        return typeof t == "string" ? t === "any" || this.scopes.has(t) : this.injectorDefTypes.has(t);
    }
    removeOnDestroy(n) { let t = this._onDestroyHooks.indexOf(n); t !== -1 && this._onDestroyHooks.splice(t, 1); }
};
function he(e) {
    let n = Z(e), t = n !== null ? n.factory : B(e);
    if (t !== null)
        return t;
    if (e instanceof g)
        throw new f(204, !1);
    if (e instanceof Function)
        return It(e);
    throw new f(204, !1);
}
function It(e) {
    if (e.length > 0)
        throw new f(204, !1);
    let t = Bn(e);
    return t !== null ? () => t.factory(e) : () => new e;
}
function Et(e) {
    if (ln(e))
        return N(void 0, e.useValue);
    {
        let n = Dt(e);
        return N(n, H);
    }
}
function Dt(e, n, t) {
    let r;
    if (fe(e)) {
        let o = v(e);
        return B(o) || he(o);
    }
    else if (ln(e))
        r = () => v(e.useValue);
    else if (vt(e))
        r = () => e.useFactory(...de(e.deps || []));
    else if (mt(e))
        r = (o, i) => C(v(e.useExisting), i !== void 0 && i & 8 ? 8 : void 0);
    else {
        let o = v(e && (e.useClass || e.provide));
        if (wt(e))
            r = () => new o(...de(e.deps));
        else
            return B(o) || he(o);
    }
    return r;
}
function j(e) {
    if (e.destroyed)
        throw new f(205, !1);
}
function N(e, n, t = !1) { return { factory: e, value: n, multi: t ? [] : void 0 }; }
function wt(e) { return !!e.deps; }
function Tt(e) { return e !== null && typeof e == "object" && typeof e.ngOnDestroy == "function"; }
function Nt(e) { return typeof e == "function" || typeof e == "object" && e.ngMetadataName === "InjectionToken"; }
function pe(e, n) {
    for (let t of e)
        Array.isArray(t) ? pe(t, n) : t && en(t) ? pe(t.\u0275providers, n) : n(t);
}
function Vr(e, n) {
    let t;
    e instanceof z ? (j(e), t = e) : t = new ae(e);
    let r, o = I(t), i = E(void 0);
    try {
        return n();
    }
    finally {
        I(o), E(i);
    }
}
function xt() { return rn() !== void 0 || te() != null; }
function $r(e) {
    if (!xt())
        throw new f(-203, !1);
}
var we = 0, hn = 1, p = 2, ge = 3, qr = 4, Ct = 5, Hr = 6, Mt = 7, pn = 8, Gr = 9, gn = 10, Br = 11, Ur = 12, Wr = 13, mn = 14, zr = 15, Yr = 16, _t = 17, Jr = 18, Zr = 19, Qr = 20, x = 21, Kr = 22, K = 23, Ft = 24, Xr = 25, eo = 26, Te = 1, no = 6, to = 7, ro = 8, oo = 9, io = 10;
function Rt(e) { return Array.isArray(e) && typeof e[Te] == "object"; }
function vn(e) { return Array.isArray(e) && e[Te] === !0; }
function so(e) { return (e.flags & 4) !== 0; }
function uo(e) { return e.componentOffset > -1; }
function co(e) { return (e.flags & 1) === 1; }
function ao(e) { return !!e.template; }
function lo(e) { return (e[p] & 512) !== 0; }
function fo(e) { return (e.type & 16) === 16; }
function ho(e) { return (e[p] & 32) === 32; }
function yn(e) { return (e[p] & 256) === 256; }
var bt = "svg", jt = "math";
function Ne(e) {
    for (; Array.isArray(e);)
        e = e[we];
    return e;
}
function po(e) {
    for (; Array.isArray(e);) {
        if (typeof e[Te] == "object")
            return e;
        e = e[we];
    }
    return null;
}
function go(e, n) { return Ne(n[e]); }
function mo(e, n) { return Ne(n[e.index]); }
function vo(e, n) { let t = e === null ? -1 : e.index; return t !== -1 ? Ne(n[t]) : null; }
function Ot(e, n) { return e.data[n]; }
function yo(e, n) { return e[n]; }
function Io(e, n, t, r) { t >= e.data.length && (e.data[t] = null, e.blueprint[t] = null), n[t] = r; }
function Eo(e, n) { let t = n[e]; return Rt(t) ? t : t[we]; }
function Do(e) { return (e[p] & 4) === 4; }
function In(e) { return (e[p] & 128) === 128; }
function wo(e) { return vn(e[ge]); }
function To(e, n) { return n == null ? null : e[n]; }
function No(e) { e[_t] = 0; }
function xo(e) { e[p] & 1024 || (e[p] |= 1024, In(e) && X(e)); }
function St(e, n) {
    for (; e > 0;)
        n = n[mn], e--;
    return n;
}
function Pt(e) { return !!(e[p] & 9216 || e[Ft]?.dirty); }
function Co(e) { e[gn].changeDetectionScheduler?.notify(8), e[p] & 64 && (e[p] |= 1024), Pt(e) && X(e); }
function X(e) {
    e[gn].changeDetectionScheduler?.notify(0);
    let n = Ze(e);
    for (; n !== null && !(n[p] & 8192 || (n[p] |= 8192, !In(n)));)
        n = Ze(n);
}
function Lt(e, n) {
    if (yn(e))
        throw new f(911, !1);
    e[x] === null && (e[x] = []), e[x].push(n);
}
function At(e, n) {
    if (e[x] === null)
        return;
    let t = e[x].indexOf(n);
    t !== -1 && e[x].splice(t, 1);
}
function Ze(e) { let n = e[ge]; return vn(n) ? n[ge] : n; }
function kt(e) { return e[Mt] ??= []; }
function Vt(e) { return e.cleanup ??= []; }
function Mo(e, n, t, r) { let o = kt(n); o.push(t), e.firstCreatePass && Vt(e).push(r, o.length - 1); }
var s = { lFrame: wn(null), bindingsEnabled: !0, skipHydrationRootTNode: null }, $t = (function (e) { return e[e.Off = 0] = "Off", e[e.Exhaustive = 1] = "Exhaustive", e[e.OnlyDirtyViews = 2] = "OnlyDirtyViews", e; })($t || {}), qt = 0, me = !1;
function _o() { return s.lFrame.elementDepthCount; }
function Fo() { s.lFrame.elementDepthCount++; }
function Ro() { s.lFrame.elementDepthCount--; }
function bo() { return s.bindingsEnabled; }
function jo() { return s.skipHydrationRootTNode !== null; }
function Oo(e) { return s.skipHydrationRootTNode === e; }
function So() { s.bindingsEnabled = !0; }
function Po(e) { s.skipHydrationRootTNode = e; }
function Lo() { s.bindingsEnabled = !1; }
function Ao() { s.skipHydrationRootTNode = null; }
function En() { return s.lFrame.lView; }
function ko() { return s.lFrame.tView; }
function Vo(e) { return s.lFrame.contextLView = e, e[pn]; }
function $o(e) { return s.lFrame.contextLView = null, e; }
function Ht() {
    let e = Gt();
    for (; e !== null && e.type === 64;)
        e = e.parent;
    return e;
}
function Gt() { return s.lFrame.currentTNode; }
function qo() { let e = s.lFrame, n = e.currentTNode; return e.isParent ? n : n.parent; }
function Ho(e, n) { let t = s.lFrame; t.currentTNode = e, t.isParent = n; }
function Go() { return s.lFrame.isParent; }
function Bo() { s.lFrame.isParent = !1; }
function Uo() { return s.lFrame.contextLView; }
function Wo(e) { J("Must never be called in production mode"), qt = e; }
function zo() { return me; }
function xe(e) { let n = me; return me = e, n; }
function Yo() { let e = s.lFrame, n = e.bindingRootIndex; return n === -1 && (n = e.bindingRootIndex = e.tView.bindingStartIndex), n; }
function Jo() { return s.lFrame.bindingIndex; }
function Zo(e) { return s.lFrame.bindingIndex = e; }
function Qo() { return s.lFrame.bindingIndex++; }
function Ko(e) { let n = s.lFrame, t = n.bindingIndex; return n.bindingIndex = n.bindingIndex + e, t; }
function Xo() { return s.lFrame.inI18n; }
function ei(e) { s.lFrame.inI18n = e; }
function ni(e, n) { let t = s.lFrame; t.bindingIndex = t.bindingRootIndex = e, Bt(n); }
function ti() { return s.lFrame.currentDirectiveIndex; }
function Bt(e) { s.lFrame.currentDirectiveIndex = e; }
function ri(e) { let n = s.lFrame.currentDirectiveIndex; return n === -1 ? null : e[n]; }
function oi() { return s.lFrame.currentQueryIndex; }
function ii(e) { s.lFrame.currentQueryIndex = e; }
function Ut(e) { let n = e[hn]; return n.type === 2 ? n.declTNode : n.type === 1 ? e[Ct] : null; }
function si(e, n, t) {
    if (t & 4) {
        let o = n, i = e;
        for (; o = o.parent, o === null && !(t & 1);)
            if (o = Ut(i), o === null || (i = i[mn], o.type & 10))
                break;
        if (o === null)
            return !1;
        n = o, e = i;
    }
    let r = s.lFrame = Dn();
    return r.currentTNode = n, r.lView = e, !0;
}
function ui(e) { let n = Dn(), t = e[hn]; s.lFrame = n, n.currentTNode = t.firstChild, n.lView = e, n.tView = t, n.contextLView = e, n.bindingIndex = t.bindingStartIndex, n.inI18n = !1; }
function Dn() { let e = s.lFrame, n = e === null ? null : e.child; return n === null ? wn(e) : n; }
function wn(e) { let n = { currentTNode: null, isParent: !0, lView: null, tView: null, selectedIndex: -1, contextLView: null, elementDepthCount: 0, currentNamespace: null, currentDirectiveIndex: -1, bindingRootIndex: -1, bindingIndex: -1, currentQueryIndex: 0, parent: e, child: null, inI18n: !1 }; return e !== null && (e.child = n), n; }
function Tn() { let e = s.lFrame; return s.lFrame = e.parent, e.currentTNode = null, e.lView = null, e; }
var ci = Tn;
function ai() { let e = Tn(); e.isParent = !0, e.tView = null, e.selectedIndex = -1, e.contextLView = null, e.elementDepthCount = 0, e.currentDirectiveIndex = -1, e.currentNamespace = null, e.bindingRootIndex = -1, e.bindingIndex = -1, e.currentQueryIndex = 0; }
function di(e) { return (s.lFrame.contextLView = St(e, s.lFrame.contextLView))[pn]; }
function li() { return s.lFrame.selectedIndex; }
function fi(e) { s.lFrame.selectedIndex = e; }
function hi() { let e = s.lFrame; return Ot(e.tView, e.selectedIndex); }
function pi() { s.lFrame.currentNamespace = bt; }
function gi() { s.lFrame.currentNamespace = jt; }
function mi() { Wt(); }
function Wt() { s.lFrame.currentNamespace = null; }
function vi() { return s.lFrame.currentNamespace; }
var Nn = !0;
function yi() { return Nn; }
function Ii(e) { Nn = e; }
var ve = { elements: void 0 };
function Ei(e) { ve.elements === void 0 && (ve.elements = e); }
function Di() { return ve; }
function Qe(e, n = null, t = null, r) { let o = zt(e, n, t, r); return o.resolveInjectorInitializers(), o; }
function zt(e, n = null, t = null, r, o = new Set) { let i = [t || U, ht(e)]; return r = r || (typeof e == "object" ? void 0 : S(e)), new z(i, n || fn(), r || null, o); }
var L = class e {
    static THROW_IF_NOT_FOUND = w;
    static NULL = new W;
    static create(n, t) {
        if (Array.isArray(n))
            return Qe({ name: "" }, t, n, "");
        {
            let r = n.name ?? "";
            return Qe({ name: r }, n.parent, n.providers, r);
        }
    }
    static \u0275prov = _({ token: e, providedIn: "any", factory: () => C(sn) });
    static __NG_ELEMENT_ID__ = -1;
}, Yt = new g(""), F = (() => {
    class e {
        static __NG_ELEMENT_ID__ = Jt;
        static __NG_ENV_ID__ = t => t;
    }
    return e;
})(), A = class extends F {
    _lView;
    constructor(n) { super(), this._lView = n; }
    get destroyed() { return yn(this._lView); }
    onDestroy(n) { let t = this._lView; return Lt(t, n), () => At(t, n); }
};
function Jt() { return new A(En()); }
var M = class {
    _console = console;
    handleError(n) { this._console.error("ERROR", n); }
}, xn = new g("", { providedIn: "root", factory: () => { let e = h(P), n; return t => { e.destroyed && !n ? setTimeout(() => { throw t; }) : (n ??= e.get(M), n.handleError(t)); }; } }), wi = { provide: Q, useValue: () => void h(M), multi: !0 }, Zt = new g("", { providedIn: "root", factory: () => {
        if (typeof ngServerMode < "u" && ngServerMode)
            return;
        let e = h(Yt).defaultView;
        if (!e)
            return;
        let n = h(xn), t = i => { n(i.reason), i.preventDefault(); }, r = i => { i.error ? n(i.error) : n(new Error(i.message, { cause: i })), i.preventDefault(); }, o = () => { e.addEventListener("unhandledrejection", t), e.addEventListener("error", r); };
        typeof Zone < "u" ? Zone.root.run(o) : o(), h(F).onDestroy(() => { e.removeEventListener("error", r), e.removeEventListener("unhandledrejection", t); });
    } });
function Ti() { return an([ft(() => void h(Zt))]); }
function Qt(e) { return typeof e == "function" && e[m] !== void 0; }
function Ni(e) { return null; }
function V(e, n) { let [t, r, o] = Ve(e, n?.equal), i = t, u = i[m]; return i.set = r, i.update = o, i.asReadonly = ee.bind(i), i; }
function ee() {
    let e = this[m];
    if (e.readonlyFn === void 0) {
        let n = () => this();
        n[m] = e, e.readonlyFn = n;
    }
    return e.readonlyFn;
}
function xi(e) { return Qt(e) && typeof e.set == "function"; }
var k = class {
}, Ci = new g("", { providedIn: "root", factory: () => !1 });
var Mi = new g(""), _i = new g("");
function Fi(e, n) {
    if (Oe() !== null)
        throw new f(-602, !1);
}
var Ce = (() => {
    class e {
        view;
        node;
        constructor(t, r) { this.view = t, this.node = r; }
        static __NG_ELEMENT_ID__ = Kt;
    }
    return e;
})();
function Kt() { return new Ce(En(), Ht()); }
var Xt = (() => {
    class e {
        taskId = 0;
        pendingTasks = new Set;
        destroyed = !1;
        pendingTask = new Ln(!1);
        get hasPendingTasks() { return this.destroyed ? !1 : this.pendingTask.value; }
        get hasPendingTasksObservable() { return this.destroyed ? new An(t => { t.next(!1), t.complete(); }) : this.pendingTask; }
        add() { !this.hasPendingTasks && !this.destroyed && this.pendingTask.next(!0); let t = this.taskId++; return this.pendingTasks.add(t), t; }
        has(t) { return this.pendingTasks.has(t); }
        remove(t) { this.pendingTasks.delete(t), this.pendingTasks.size === 0 && this.hasPendingTasks && this.pendingTask.next(!1); }
        ngOnDestroy() { this.pendingTasks.clear(), this.hasPendingTasks && this.pendingTask.next(!1), this.destroyed = !0, this.pendingTask.unsubscribe(); }
        static \u0275prov = _({ token: e, providedIn: "root", factory: () => new e });
    }
    return e;
})(), Cn = (() => {
    class e {
        internalPendingTasks = h(Xt);
        scheduler = h(k);
        errorHandler = h(xn);
        add() { let t = this.internalPendingTasks.add(); return () => { this.internalPendingTasks.has(t) && (this.scheduler.notify(11), this.internalPendingTasks.remove(t)); }; }
        run(t) { let r = this.add(); t().catch(this.errorHandler).finally(r); }
        static \u0275prov = _({ token: e, providedIn: "root", factory: () => new e });
    }
    return e;
})();
function Mn(...e) { }
var _n = (() => {
    class e {
        static \u0275prov = _({ token: e, providedIn: "root", factory: () => new ye });
    }
    return e;
})(), ye = class {
    dirtyEffectCount = 0;
    queues = new Map;
    add(n) { this.enqueue(n), this.schedule(n); }
    schedule(n) { n.dirty && this.dirtyEffectCount++; }
    remove(n) { let t = n.zone, r = this.queues.get(t); r.has(n) && (r.delete(n), n.dirty && this.dirtyEffectCount--); }
    enqueue(n) { let t = n.zone; this.queues.has(t) || this.queues.set(t, new Set); let r = this.queues.get(t); r.has(n) || r.add(n); }
    flush() {
        for (; this.dirtyEffectCount > 0;) {
            let n = !1;
            for (let [t, r] of this.queues)
                t === null ? n ||= this.flushQueue(r) : n ||= t.run(() => this.flushQueue(r));
            n || (this.dirtyEffectCount = 0);
        }
    }
    flushQueue(n) {
        let t = !1;
        for (let r of n)
            r.dirty && (this.dirtyEffectCount--, t = !0, r.run());
        return t;
    }
};
var Fn = class {
    destroyed = !1;
    listeners = null;
    errorHandler = h(M, { optional: !0 });
    destroyRef = h(F);
    constructor() { this.destroyRef.onDestroy(() => { this.destroyed = !0, this.listeners = null; }); }
    subscribe(n) {
        if (this.destroyed)
            throw new f(953, !1);
        return (this.listeners ??= []).push(n), { unsubscribe: () => { let t = this.listeners?.indexOf(n); t !== void 0 && t !== -1 && this.listeners?.splice(t, 1); } };
    }
    emit(n) {
        if (this.destroyed) {
            console.warn(Y(953, !1));
            return;
        }
        if (this.listeners === null)
            return;
        let t = b(null);
        try {
            for (let r of this.listeners)
                try {
                    r(n);
                }
                catch (o) {
                    this.errorHandler?.handleError(o);
                }
        }
        finally {
            b(t);
        }
    }
};
function Vi(e) { return e.destroyRef; }
function y(e) { return He(e); }
function R(e, n) { return ke(e, n?.equal); }
var Me = class {
    [m];
    constructor(n) { this[m] = n; }
    destroy() { this[m].destroy(); }
};
function er(e, n) { let t = n?.injector ?? h(L), r = n?.manualCleanup !== !0 ? t.get(F) : null, o, i = t.get(Ce, null, { optional: !0 }), u = t.get(k); return i !== null ? (o = rr(i.view, u, e), r instanceof A && r._lView === i.view && (r = null)) : o = or(e, t.get(_n), u), o.injector = t, r !== null && (o.onDestroyFn = r.onDestroy(() => o.destroy())), new Me(o); }
var On = q($({}, Se), { consumerIsAlwaysLive: !0, consumerAllowSignalWrites: !0, dirty: !0, hasRun: !1, cleanupFns: void 0, zone: null, kind: "effect", onDestroyFn: Mn, run() {
        if (this.dirty = !1, this.hasRun && !Ae(this))
            return;
        this.hasRun = !0;
        let e = r => (this.cleanupFns ??= []).push(r), n = Pe(this), t = xe(!1);
        try {
            this.maybeCleanup(), this.fn(e);
        }
        finally {
            xe(t), Le(this, n);
        }
    }, maybeCleanup() {
        if (!this.cleanupFns?.length)
            return;
        let e = b(null);
        try {
            for (; this.cleanupFns.length;)
                this.cleanupFns.pop()();
        }
        finally {
            this.cleanupFns = [], b(e);
        }
    } }), nr = q($({}, On), { consumerMarkedDirty() { this.scheduler.schedule(this), this.notifier.notify(12); }, destroy() { oe(this), this.onDestroyFn(), this.maybeCleanup(), this.scheduler.remove(this); } }), tr = q($({}, On), { consumerMarkedDirty() { this.view[p] |= 8192, X(this.view), this.notifier.notify(13); }, destroy() { oe(this), this.onDestroyFn(), this.maybeCleanup(), this.view[K]?.delete(this); } });
function rr(e, n, t) { let r = Object.create(tr); return r.view = e, r.zone = typeof Zone < "u" ? Zone.current : null, r.notifier = n, r.fn = t, e[K] ??= new Set, e[K].add(r), r.consumerMarkedDirty(r), r; }
function or(e, n, t) { let r = Object.create(nr); return r.fn = e, r.scheduler = n, r.notifier = t, r.zone = typeof Zone < "u" ? Zone.current : null, r.scheduler.add(r), r.notifier.notify(12), r; }
var ir = e => e;
function Rn(e, n) {
    if (typeof e == "function") {
        let t = ie(e, ir, n?.equal);
        return bn(t);
    }
    else {
        let t = ie(e.source, e.computation, e.equal);
        return bn(t);
    }
}
function bn(e) { let n = e[m], t = e; return t.set = r => $e(n, r), t.update = r => qe(n, r), t.asReadonly = ee.bind(e), t; }
var Sn = !0;
function $i(e) { let n = e.request, t = e.params ?? n ?? (() => null); return new Fe(t, ur(e), e.defaultValue, e.equal ? sr(e.equal) : void 0, e.injector ?? h(L), Sn); }
var _e = class {
    value;
    constructor(n) { this.value = n, this.value.set = this.set.bind(this), this.value.update = this.update.bind(this), this.value.asReadonly = ee; }
    isError = R(() => this.status() === "error");
    update(n) { this.set(n(y(this.value))); }
    isLoading = R(() => this.status() === "loading" || this.status() === "reloading");
    isValueDefined = R(() => this.isError() ? !1 : this.value() !== void 0);
    hasValue() { return this.isValueDefined(); }
    asReadonly() { return this; }
}, Fe = class extends _e {
    loaderFn;
    equal;
    pendingTasks;
    state;
    extRequest;
    effectRef;
    pendingController;
    resolvePendingTask = void 0;
    destroyed = !1;
    unregisterOnDestroy;
    constructor(n, t, r, o, i, u = Sn) {
        super(R(() => {
            let d = this.state().stream?.();
            if (!d || this.state().status === "loading" && this.error())
                return r;
            if (!Re(d)) {
                if (u)
                    throw new be(this.error());
                return r;
            }
            return d.value;
        }, { equal: o })), this.loaderFn = t, this.equal = o, this.extRequest = Rn({ source: n, computation: d => ({ request: d, reload: 0 }) }), this.state = Rn({ source: this.extRequest, computation: (d, a) => { let l = d.request === void 0 ? "idle" : "loading"; return a ? { extRequest: d, status: l, previousStatus: jn(a.value), stream: a.value.extRequest.request === d.request ? a.value.stream : void 0 } : { extRequest: d, status: l, previousStatus: "idle", stream: void 0 }; } }), this.effectRef = er(this.loadEffect.bind(this), { injector: i, manualCleanup: !0 }), this.pendingTasks = i.get(Cn), this.unregisterOnDestroy = i.get(F).onDestroy(() => this.destroy());
    }
    status = R(() => jn(this.state()));
    error = R(() => { let n = this.state().stream?.(); return n && !Re(n) ? n.error : void 0; });
    set(n) {
        if (this.destroyed)
            return;
        let t = y(this.error), r = y(this.state);
        if (!t) {
            let o = y(this.value);
            if (r.status === "local" && (this.equal ? this.equal(o, n) : o === n))
                return;
        }
        this.state.set({ extRequest: r.extRequest, status: "local", previousStatus: "local", stream: V({ value: n }) }), this.abortInProgressLoad();
    }
    reload() { let { status: n } = y(this.state); return n === "idle" || n === "loading" ? !1 : (this.extRequest.update(({ request: t, reload: r }) => ({ request: t, reload: r + 1 })), !0); }
    destroy() { this.destroyed = !0, this.unregisterOnDestroy(), this.effectRef.destroy(), this.abortInProgressLoad(), this.state.set({ extRequest: { request: void 0, reload: 0 }, status: "idle", previousStatus: "idle", stream: void 0 }); }
    loadEffect() {
        return ne(this, null, function* () {
            let n = this.extRequest(), { status: t, previousStatus: r } = y(this.state);
            if (n.request === void 0)
                return;
            if (t !== "loading")
                return;
            this.abortInProgressLoad();
            let o = this.resolvePendingTask = this.pendingTasks.add(), { signal: i } = this.pendingController = new AbortController;
            try {
                let u = yield y(() => this.loaderFn({ params: n.request, request: n.request, abortSignal: i, previous: { status: r } }));
                if (i.aborted || y(this.extRequest) !== n)
                    return;
                this.state.set({ extRequest: n, status: "resolved", previousStatus: "resolved", stream: u });
            }
            catch (u) {
                if (i.aborted || y(this.extRequest) !== n)
                    return;
                this.state.set({ extRequest: n, status: "resolved", previousStatus: "error", stream: V({ error: Pn(u) }) });
            }
            finally {
                o?.(), o = void 0;
            }
        });
    }
    abortInProgressLoad() { y(() => this.pendingController?.abort()), this.pendingController = void 0, this.resolvePendingTask?.(), this.resolvePendingTask = void 0; }
};
function sr(e) { return (n, t) => n === void 0 || t === void 0 ? n === t : e(n, t); }
function ur(e) {
    return cr(e) ? e.stream : n => ne(null, null, function* () {
        try {
            return V({ value: yield e.loader(n) });
        }
        catch (t) {
            return V({ error: Pn(t) });
        }
    });
}
function cr(e) { return !!e.stream; }
function jn(e) {
    switch (e.status) {
        case "loading": return e.extRequest.reload === 0 ? "loading" : "reloading";
        case "resolved": return Re(e.stream()) ? "resolved" : "error";
        default: return e.status;
    }
}
function Re(e) { return e.error === void 0; }
function Pn(e) { return e instanceof Error ? e : new je(e); }
var be = class extends Error {
    constructor(n) { super(n.message, { cause: n }); }
}, je = class extends Error {
    constructor(n) { super(String(n), { cause: n }); }
};
export { pr as a, f as b, Y as c, gr as d, c as e, mr as f, S as g, vr as h, yr as i, Ke as j, v as k, qn as l, Ir as m, _ as n, Er as o, Dr as p, Z as q, wr as r, Xe as s, Be as t, g as u, Tr as v, en as w, Un as x, Wn as y, zn as z, Yn as A, We as B, Nr as C, Jn as D, Ye as E, Zn as F, Qn as G, E as H, tt as I, C as J, xr as K, h as L, G as M, Cr as N, B as O, Mr as P, _r as Q, Fr as R, Rr as S, br as T, jr as U, ut as V, Or as W, Sr as X, on as Y, Pr as Z, U as _, Q as $, sn as aa, at as ba, Lr as ca, cn as da, dt as ea, lt as fa, Ar as ga, an as ha, ft as ia, ht as ja, pt as ka, fe as la, kr as ma, yt as na, fn as oa, P as pa, z as qa, Dt as ra, Vr as sa, xt as ta, $r as ua, we as va, hn as wa, p as xa, ge as ya, qr as za, Ct as Aa, Hr as Ba, Mt as Ca, pn as Da, Gr as Ea, gn as Fa, Br as Ga, Ur as Ha, Wr as Ia, mn as Ja, zr as Ka, Yr as La, _t as Ma, Jr as Na, Zr as Oa, Qr as Pa, x as Qa, Kr as Ra, K as Sa, Ft as Ta, Xr as Ua, eo as Va, no as Wa, to as Xa, ro as Ya, oo as Za, io as _a, Rt as $a, vn as ab, so as bb, uo as cb, co as db, ao as eb, lo as fb, fo as gb, ho as hb, yn as ib, bt as jb, jt as kb, Ne as lb, po as mb, go as nb, mo as ob, vo as pb, Ot as qb, yo as rb, Io as sb, Eo as tb, Do as ub, In as vb, wo as wb, To as xb, No as yb, xo as zb, St as Ab, Pt as Bb, Co as Cb, X as Db, Lt as Eb, At as Fb, Ze as Gb, kt as Hb, Vt as Ib, Mo as Jb, $t as Kb, _o as Lb, Fo as Mb, Ro as Nb, bo as Ob, jo as Pb, Oo as Qb, So as Rb, Po as Sb, Lo as Tb, Ao as Ub, En as Vb, ko as Wb, Vo as Xb, $o as Yb, Ht as Zb, Gt as _b, qo as $b, Ho as ac, Go as bc, Bo as cc, Uo as dc, Wo as ec, zo as fc, xe as gc, Yo as hc, Jo as ic, Zo as jc, Qo as kc, Ko as lc, Xo as mc, ei as nc, ni as oc, ti as pc, Bt as qc, ri as rc, oi as sc, ii as tc, si as uc, ui as vc, ci as wc, ai as xc, di as yc, li as zc, fi as Ac, hi as Bc, pi as Cc, gi as Dc, mi as Ec, vi as Fc, yi as Gc, Ii as Hc, Ei as Ic, Di as Jc, Qe as Kc, zt as Lc, L as Mc, Yt as Nc, F as Oc, M as Pc, xn as Qc, wi as Rc, Ti as Sc, Qt as Tc, Ni as Uc, V as Vc, ee as Wc, xi as Xc, k as Yc, Ci as Zc, Mi as _c, _i as $c, Fi as ad, Ce as bd, Xt as cd, Cn as dd, Mn as ed, _n as fd, Fn as gd, Vi as hd, y as id, R as jd, er as kd, Rn as ld, $i as md, Fe as nd, Pn as od };
/*! Bundled license information:

@angular/core/fesm2022/root_effect_scheduler.mjs:
@angular/core/fesm2022/resource.mjs:
  (**
   * @license Angular v20.2.1
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)
*/
