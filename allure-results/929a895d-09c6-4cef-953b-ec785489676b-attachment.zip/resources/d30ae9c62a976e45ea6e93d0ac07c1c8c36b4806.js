import { a as ui, c as Kf, d as Jf, e as Xf, g as ep, h as tp, i as np, j as op, l as rp, o as mc } from "@nf-internal/chunk-4TZKTG3W";
import { a as xC } from "@nf-internal/chunk-UNM3RYWE";
import { $ as ft, $a as Y, $b as dn, $c as ci, A as wa, Aa as se, Ab as Lf, Ac as It, B as dt, Ba as te, Bb as To, Bc as Ce, C as kt, Ca as Ot, Cb as Kr, Cc as ic, D as M, Da as P, Db as Jr, Dc as sc, E as Ee, Ea as V, Eb as Xr, Ec as ac, F as Cf, Fa as ze, Fb as Va, Fc as cc, G as _a, Ga as C, Gb as jt, Gc as wo, H as xt, Ha as ht, Hb as Ff, Hc as ke, I as Tf, Ia as yo, Ib as jf, Ic as zf, J as Se, Ja as vo, Jb as Ha, Jc as si, K as Br, Ka as Q, Kb as ei, Kc as EC, L as D, La as gt, Lb as Vf, Lc as Qf, M as ba, Ma as cn, Mb as Hf, Mc as Te, N as sn, Na as je, Nb as Ba, Nc as DC, O as $r, Oa as ln, Ob as ti, Oc as fn, P as Mf, Pa as Oa, Pb as Mo, Pc as ai, Q as Ae, Qa as Pa, Qb as $a, Qc as Et, R as Sa, Ra as Zr, Rb as Ua, Rc as lc, S as po, Sa as Io, Sb as Bf, Sc as CC, T as ho, Ta as we, Tb as Ga, Tc as Zf, U as Aa, Ua as Pt, Ub as Wa, Uc as TC, V as Nf, Va as I, Vb as g, Vc as uc, W as go, Wa as De, Wb as N, Wc as Yf, X as Ur, Xa as Re, Xb as qa, Xc as dc, Y as Gr, Ya as Eo, Yb as za, Yc as Qe, Z as Me, Za as Lt, Zb as T, Zc as pn, _ as O, _a as G, _b as $f, _c as fc, a as Pr, aa as mC, ab as K, ac as He, ad as MC, b as w, ba as an, bb as La, bc as Qa, bd as li, c as If, ca as Wr, cb as me, cc as Za, cd as Dt, d as Ie, da as U, db as un, dc as Ya, dd as pc, e as Ta, ea as Ne, eb as ye, ec as Ka, ed as _o, f as Ef, fa as Fe, fb as Ve, fc as Ja, fd as hc, g as on, ga as mo, gb as Fa, gc as Xa, gd as gc, h as Lr, ha as qe, hb as Sf, hc as ue, hd as NC, i as uC, ia as yC, ib as mt, ic as Be, id as wC, j as Ma, ja as vC, jb as Af, jc as ec, jd as _C, k as $, ka as Ra, kb as Rf, kc as de, kd as bC, l as Fr, la as qr, lb as R, lc as $e, ld as SC, m as Df, ma as wf, mb as Do, mc as Uf, md as AC, n as j, na as _f, nb as Ft, nc as tc, nd as RC, o as dC, oa as zr, ob as ne, oc as Gf, od as kC, p as fo, pa as pt, pb as kf, pc as Wf, q as fC, qa as ka, qb as yt, qc as nc, r as pC, ra as bf, rb as vt, rc as ni, s as jr, sa as Qr, sb as Co, sc as oi, t as Na, ta as xa, tb as le, tc as No, u as _, ua as IC, ub as xf, uc as oc, v as hC, va as F, vb as Of, vc as ri, w as gC, wa as y, wb as Pf, wc as rc, x as rn, xa as b, xb as ae, xc as ii, y as Vr, ya as q, yb as ja, yc as qf, z as Hr, za as ie, zb as Yr, zc as oe } from "@nf-internal/chunk-L5JUMZ3J";
import { b as lC } from "@nf-internal/chunk-6KUZPJZH";
import { C as Ca, b as ut, c as S, d as mf, g as Ea, h as kr, o as lo, p as xr, q as Or, r as uo, u as yf, v as vf, z as Da } from "@nf-internal/chunk-L2D3IU5T";
import { a as W, b as Le, i as co } from "@nf-internal/chunk-66YHNWRR";
import { Subject as Wl, Subscription as ql } from "rxjs";
import { setActiveConsumer as ip } from "@angular/core/primitives/signals";
import { map as OC } from "rxjs/operators";
function Ge(e) { return { toString: e }.toString(); }
var mn = "__annotations__", yn = "__parameters__", vn = "__prop__metadata__";
function sr(e, t, n, o, r) { return Ge(() => { let i = zl(t); function s(...a) { if (this instanceof s)
    return i.call(this, ...a), this; let c = new s(...a); return function (u) { return r && r(u, ...a), (u.hasOwnProperty(mn) ? u[mn] : Object.defineProperty(u, mn, { value: [] })[mn]).push(c), u; }; } return n && (s.prototype = Object.create(n.prototype)), s.prototype.ngMetadataName = e, s.annotationCls = s, s; }); }
function zl(e) { return function (...n) { if (e) {
    let o = e(...n);
    for (let r in o)
        this[r] = o[r];
} }; }
function $n(e, t, n) { return Ge(() => { let o = zl(t); function r(...i) { if (this instanceof r)
    return o.apply(this, i), this; let s = new r(...i); return a.annotation = s, a; function a(c, l, u) { let d = c.hasOwnProperty(yn) ? c[yn] : Object.defineProperty(c, yn, { value: [] })[yn]; for (; d.length <= u;)
    d.push(null); return (d[u] = d[u] || []).push(s), c; } } return r.prototype.ngMetadataName = e, r.annotationCls = r, r; }); }
function tt(e, t, n, o) { return Ge(() => { let r = zl(t); function i(...s) { if (this instanceof i)
    return r.apply(this, s), this; let a = new i(...s); function c(l, u) { if (l === void 0)
    throw new Error("Standard Angular field decorators are not supported in JIT mode."); let d = l.constructor, f = d.hasOwnProperty(vn) ? d[vn] : Object.defineProperty(d, vn, { value: {} })[vn]; f[u] = f.hasOwnProperty(u) && f[u] || [], f[u].unshift(a); } return c; } return n && (i.prototype = Object.create(n.prototype)), i.prototype.ngMetadataName = e, i.annotationCls = i, i; }); }
var mh = sn($n("Inject", e => ({ token: e })), -1), rs = sn($n("Optional"), 8), yh = sn($n("Self"), 2), is = sn($n("SkipSelf"), 4), vh = sn($n("Host"), 1);
function X(e) { let t = Ie.ng; if (t && t.\u0275compilerFacade)
    return t.\u0275compilerFacade; throw new Error("JIT compiler unavailable"); }
var sp = { \u0275\u0275defineInjectable: j, \u0275\u0275defineInjector: fo, \u0275\u0275inject: Se, \u0275\u0275invalidFactoryDep: Br, resolveForwardRef: $ }, Ih = Function;
function So(e) { return typeof e == "function"; }
var PC = /^function\s+\S+\(\)\s*{[\s\S]+\.apply\(this,\s*(arguments|(?:[^()]+\(\[\],)?[^()]+\(arguments\).*)\)/, LC = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{/, FC = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(/, jC = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(\)\s*{[^}]*super\(\.\.\.arguments\)/;
function VC(e) { return PC.test(e) || jC.test(e) || LC.test(e) && !FC.test(e); }
var Si = class {
    _reflect;
    constructor(t) { this._reflect = t || Ie.Reflect; }
    factory(t) { return (...n) => new t(...n); }
    _zipTypesAndAnnotations(t, n) { let o; typeof t > "u" ? o = ho(n.length) : o = ho(t.length); for (let r = 0; r < o.length; r++)
        typeof t > "u" ? o[r] = [] : t[r] && t[r] != Object ? o[r] = [t[r]] : o[r] = [], n && n[r] != null && (o[r] = o[r].concat(n[r])); return o; }
    _ownParameters(t, n) { let o = t.toString(); if (VC(o))
        return null; if (t.parameters && t.parameters !== n.parameters)
        return t.parameters; let r = t.ctorParameters; if (r && r !== n.ctorParameters) {
        let a = typeof r == "function" ? r() : r, c = a.map(u => u && u.type), l = a.map(u => u && yc(u.decorators));
        return this._zipTypesAndAnnotations(c, l);
    } let i = t.hasOwnProperty(yn) && t[yn], s = this._reflect && this._reflect.getOwnMetadata && this._reflect.getOwnMetadata("design:paramtypes", t); return s || i ? this._zipTypesAndAnnotations(s, i) : ho(t.length); }
    parameters(t) { if (!So(t))
        return []; let n = di(t), o = this._ownParameters(t, n); return !o && n !== Object && (o = this.parameters(n)), o || []; }
    _ownAnnotations(t, n) { if (t.annotations && t.annotations !== n.annotations) {
        let o = t.annotations;
        return typeof o == "function" && o.annotations && (o = o.annotations), o;
    } return t.decorators && t.decorators !== n.decorators ? yc(t.decorators) : t.hasOwnProperty(mn) ? t[mn] : null; }
    annotations(t) { if (!So(t))
        return []; let n = di(t), o = this._ownAnnotations(t, n) || []; return (n !== Object ? this.annotations(n) : []).concat(o); }
    _ownPropMetadata(t, n) { if (t.propMetadata && t.propMetadata !== n.propMetadata) {
        let o = t.propMetadata;
        return typeof o == "function" && o.propMetadata && (o = o.propMetadata), o;
    } if (t.propDecorators && t.propDecorators !== n.propDecorators) {
        let o = t.propDecorators, r = {};
        return Object.keys(o).forEach(i => { r[i] = yc(o[i]); }), r;
    } return t.hasOwnProperty(vn) ? t[vn] : null; }
    propMetadata(t) { if (!So(t))
        return {}; let n = di(t), o = {}; if (n !== Object) {
        let i = this.propMetadata(n);
        Object.keys(i).forEach(s => { o[s] = i[s]; });
    } let r = this._ownPropMetadata(t, n); return r && Object.keys(r).forEach(i => { let s = []; o.hasOwnProperty(i) && s.push(...o[i]), s.push(...r[i]), o[i] = s; }), o; }
    ownPropMetadata(t) { return So(t) ? this._ownPropMetadata(t, di(t)) || {} : {}; }
    hasLifecycleHook(t, n) { return t instanceof Ih && n in t.prototype; }
};
function yc(e) { return e ? e.map(t => { let o = t.type.annotationCls, r = t.args ? t.args : []; return new o(...r); }) : []; }
function di(e) { let t = e.prototype ? Object.getPrototypeOf(e.prototype) : null; return (t ? t.constructor : null) || Object; }
var Ai = class {
    previousValue;
    currentValue;
    firstChange;
    constructor(t, n, o) { this.previousValue = t, this.currentValue = n, this.firstChange = o; }
    isFirstChange() { return this.firstChange; }
};
function Eh(e, t, n, o) { t !== null ? t.applyValueToInputSignal(t, o) : e[n] = o; }
var Dh = (() => { let e = () => Ch; return e.ngInherit = !0, e; })();
function Ch(e) { return e.type.prototype.ngOnChanges && (e.setInput = BC), HC; }
function HC() { let e = Mh(this), t = e?.current; if (t) {
    let n = e.previous;
    if (n === Me)
        e.previous = t;
    else
        for (let o in t)
            n[o] = t[o];
    e.current = null, this.ngOnChanges(t);
} }
function BC(e, t, n, o, r) { let i = this.declaredInputs[o], s = Mh(e) || $C(e, { previous: Me, current: null }), a = s.current || (s.current = {}), c = s.previous, l = c[i]; a[i] = new Ai(l && l.currentValue, n, c === Me), Eh(e, t, r, n); }
var Th = "__ngSimpleChanges__";
function Mh(e) { return e[Th] || null; }
function $C(e, t) { return e[Th] = t; }
var ap = [];
var k = function (e, t = null, n) { for (let o = 0; o < ap.length; o++) {
    let r = ap[o];
    r(e, t, n);
} };
function UC(e, t, n) { let { ngOnChanges: o, ngOnInit: r, ngDoCheck: i } = t.type.prototype; if (o) {
    let s = Ch(t);
    (n.preOrderHooks ??= []).push(e, s), (n.preOrderCheckHooks ??= []).push(e, s);
} r && (n.preOrderHooks ??= []).push(0 - e, r), i && ((n.preOrderHooks ??= []).push(e, i), (n.preOrderCheckHooks ??= []).push(e, i)); }
function Nh(e, t) { for (let n = t.directiveStart, o = t.directiveEnd; n < o; n++) {
    let i = e.data[n].type.prototype, { ngAfterContentInit: s, ngAfterContentChecked: a, ngAfterViewInit: c, ngAfterViewChecked: l, ngOnDestroy: u } = i;
    s && (e.contentHooks ??= []).push(-n, s), a && ((e.contentHooks ??= []).push(n, a), (e.contentCheckHooks ??= []).push(n, a)), c && (e.viewHooks ??= []).push(-n, c), l && ((e.viewHooks ??= []).push(n, l), (e.viewCheckHooks ??= []).push(n, l)), u != null && (e.destroyHooks ??= []).push(n, u);
} }
function Ii(e, t, n) { wh(e, t, 3, n); }
function Ei(e, t, n, o) { (e[b] & 3) === n && wh(e, t, n, o); }
function vc(e, t) { let n = e[b]; (n & 3) === t && (n &= 16383, n += 1, e[b] = n); }
function wh(e, t, n, o) { let r = o !== void 0 ? e[cn] & 65535 : 0, i = o ?? -1, s = t.length - 1, a = 0; for (let c = r; c < s; c++)
    if (typeof t[c + 1] == "number") {
        if (a = t[c], o != null && a >= o)
            break;
    }
    else
        t[c] < 0 && (e[cn] += 65536), (a < i || i == -1) && (GC(e, n, t, c), e[cn] = (e[cn] & 4294901760) + c + 2), c++; }
function cp(e, t) { k(4, e, t); let n = S(null); try {
    t.call(e);
}
finally {
    S(n), k(5, e, t);
} }
function GC(e, t, n, o) { let r = n[o] < 0, i = n[o + 1], s = r ? -n[o] : n[o], a = e[s]; r ? e[b] >> 14 < e[cn] >> 16 && (e[b] & 3) === t && (e[b] += 16384, cp(a, i)) : cp(a, i); }
var Tn = -1, Wt = class {
    factory;
    name;
    injectImpl;
    resolving = !1;
    canSeeViewProviders;
    multi;
    componentProviders;
    index;
    providerFactory;
    constructor(t, n, o, r) { this.factory = t, this.name = r, this.canSeeViewProviders = n, this.injectImpl = o; }
};
function ss(e) { return e != null && typeof e == "object" && (e.insertBeforeIndex === null || typeof e.insertBeforeIndex == "number" || Array.isArray(e.insertBeforeIndex)); }
function _h(e) { return !!(e.type & 128); }
function WC(e) { return (e.flags & 8) !== 0; }
function qC(e) { return (e.flags & 16) !== 0; }
function zC(e, t, n) { let o = 0; for (; o < n.length;) {
    let r = n[o];
    if (typeof r == "number") {
        if (r !== 0)
            break;
        o++;
        let i = n[o++], s = n[o++], a = n[o++];
        e.setAttribute(t, s, a, i);
    }
    else {
        let i = r, s = n[++o];
        QC(i) ? e.setProperty(t, i, s) : e.setAttribute(t, i, s), o++;
    }
} return o; }
function bh(e) { return e === 3 || e === 4 || e === 6; }
function QC(e) { return e.charCodeAt(0) === 64; }
function An(e, t) { if (!(t === null || t.length === 0))
    if (e === null || e.length === 0)
        e = t.slice();
    else {
        let n = -1;
        for (let o = 0; o < t.length; o++) {
            let r = t[o];
            typeof r == "number" ? n = r : n === 0 || (n === -1 || n === 2 ? lp(e, n, r, null, t[++o]) : lp(e, n, r, null, null));
        }
    } return e; }
function lp(e, t, n, o, r) { let i = 0, s = e.length; if (t === -1)
    s = -1;
else
    for (; i < e.length;) {
        let a = e[i++];
        if (typeof a == "number") {
            if (a === t) {
                s = -1;
                break;
            }
            else if (a > t) {
                s = i - 1;
                break;
            }
        }
    } for (; i < e.length;) {
    let a = e[i];
    if (typeof a == "number")
        break;
    if (a === n) {
        r !== null && (e[i + 1] = r);
        return;
    }
    i++, r !== null && i++;
} s !== -1 && (e.splice(s, 0, t), i = s + 1), e.splice(i++, 0, n), r !== null && e.splice(i++, 0, r); }
function Sh(e) { return e !== Tn; }
function Ri(e) { return e & 32767; }
function ZC(e) { return e >> 16; }
function ki(e, t) { let n = ZC(e), o = t; for (; n > 0;)
    o = o[vo], n--; return o; }
var Gc = !0;
function xi(e) { let t = Gc; return Gc = e, t; }
var YC = 256, Ah = YC - 1, Rh = 5, KC = 0, Ue = {};
function JC(e, t, n) { let o; typeof n == "string" ? o = n.charCodeAt(0) || 0 : n.hasOwnProperty(kt) && (o = n[kt]), o == null && (o = n[kt] = KC++); let r = o & Ah, i = 1 << r; t.data[e + (r >> Rh)] |= i; }
function Oi(e, t) { let n = kh(e, t); if (n !== -1)
    return n; let o = t[y]; o.firstCreatePass && (e.injectorIndex = t.length, Ic(o.data, e), Ic(t, null), Ic(o.blueprint, null)); let r = Ql(e, t), i = e.injectorIndex; if (Sh(r)) {
    let s = Ri(r), a = ki(r, t), c = a[y].data;
    for (let l = 0; l < 8; l++)
        t[i + l] = a[s + l] | c[s + l];
} return t[i + 8] = r, i; }
function Ic(e, t) { e.push(0, 0, 0, 0, 0, 0, 0, 0, t); }
function kh(e, t) { return e.injectorIndex === -1 || e.parent && e.parent.injectorIndex === e.injectorIndex || t[e.injectorIndex + 8] === null ? -1 : e.injectorIndex; }
function Ql(e, t) { if (e.parent && e.parent.injectorIndex !== -1)
    return e.parent.injectorIndex; let n = 0, o = null, r = t; for (; r !== null;) {
    if (o = jh(r), o === null)
        return Tn;
    if (n++, r = r[vo], o.injectorIndex !== -1)
        return o.injectorIndex | n << 16;
} return Tn; }
function Wc(e, t, n) { JC(e, t, n); }
function XC(e, t) { if (t === "class")
    return e.classes; if (t === "style")
    return e.styles; let n = e.attrs; if (n) {
    let o = n.length, r = 0;
    for (; r < o;) {
        let i = n[r];
        if (bh(i))
            break;
        if (i === 0)
            r = r + 2;
        else if (typeof i == "number")
            for (r++; r < o && typeof n[r] == "string";)
                r++;
        else {
            if (i === t)
                return n[r + 1];
            r = r + 2;
        }
    }
} return null; }
function xh(e, t, n) { if (n & 8 || e !== void 0)
    return e; _a(t, "NodeInjector"); }
function Oh(e, t, n, o) { if (n & 8 && o === void 0 && (o = null), (n & 3) === 0) {
    let r = e[V], i = xt(void 0);
    try {
        return r ? r.get(t, o, n & 8) : Tf(t, o, n & 8);
    }
    finally {
        xt(i);
    }
} return xh(o, t, n); }
function Ph(e, t, n, o = 0, r) { if (e !== null) {
    if (t[b] & 2048 && !(o & 2)) {
        let s = oT(e, t, n, o, Ue);
        if (s !== Ue)
            return s;
    }
    let i = Lh(e, t, n, o, Ue);
    if (i !== Ue)
        return i;
} return Oh(t, n, o, r); }
function Lh(e, t, n, o, r) { let i = tT(n); if (typeof i == "function") {
    if (!oc(t, e, o))
        return o & 1 ? xh(r, n, o) : Oh(t, n, o, r);
    try {
        let s;
        if (s = i(o), s == null && !(o & 8))
            _a(n);
        else
            return s;
    }
    finally {
        rc();
    }
}
else if (typeof i == "number") {
    let s = null, a = kh(e, t), c = Tn, l = o & 1 ? t[Q][se] : null;
    for ((a === -1 || o & 4) && (c = a === -1 ? Ql(e, t) : t[a + 8], c === Tn || !dp(o, !1) ? a = -1 : (s = t[y], a = Ri(c), t = ki(c, t))); a !== -1;) {
        let u = t[y];
        if (up(i, a, u.data)) {
            let d = eT(a, t, n, s, o, l);
            if (d !== Ue)
                return d;
        }
        c = t[a + 8], c !== Tn && dp(o, t[y].data[a + 8] === l) && up(i, a, t) ? (s = u, a = Ri(c), t = ki(c, t)) : a = -1;
    }
} return r; }
function eT(e, t, n, o, r, i) { let s = t[y], a = s.data[e + 8], c = o == null ? me(a) && Gc : o != s && (a.type & 3) !== 0, l = r & 1 && i === a, u = Di(a, s, n, c, l); return u !== null ? Go(t, s, u, a, r) : Ue; }
function Di(e, t, n, o, r) { let i = e.providerIndexes, s = t.data, a = i & 1048575, c = e.directiveStart, l = e.directiveEnd, u = i >> 20, d = o ? a : a + u, f = r ? a + u : l; for (let p = d; p < f; p++) {
    let h = s[p];
    if (p < c && n === h || p >= c && h.type === n)
        return p;
} if (r) {
    let p = s[c];
    if (p && ye(p) && p.type === n)
        return c;
} return null; }
function Go(e, t, n, o, r) { let i = e[n], s = t.data; if (i instanceof Wt) {
    let a = i;
    if (a.resolving) {
        let p = Ee(s[n]);
        throw Cf(p);
    }
    let c = xi(a.canSeeViewProviders);
    a.resolving = !0;
    let l = s[n].type || s[n], u, d = a.injectImpl ? xt(a.injectImpl) : null, f = oc(e, o, 0);
    try {
        i = e[n] = a.factory(void 0, r, s, e, o), t.firstCreatePass && n >= o.directiveStart && UC(n, s[n], t);
    }
    finally {
        d !== null && xt(d), xi(c), a.resolving = !1, rc();
    }
} return i; }
function tT(e) { if (typeof e == "string")
    return e.charCodeAt(0) || 0; let t = e.hasOwnProperty(kt) ? e[kt] : void 0; return typeof t == "number" ? t >= 0 ? t & Ah : nT : t; }
function up(e, t, n) { let o = 1 << e; return !!(n[t + (e >> Rh)] & o); }
function dp(e, t) { return !(e & 2) && !(e & 1 && t); }
var Mt = class {
    _tNode;
    _lView;
    constructor(t, n) { this._tNode = t, this._lView = n; }
    get(t, n, o) { return Ph(this._tNode, this._lView, t, ba(o), n); }
};
function nT() { return new Mt(T(), g()); }
function Fh(e) { return Ge(() => { let t = e.prototype.constructor, n = t[dt] || qc(t), o = Object.prototype, r = Object.getPrototypeOf(e.prototype).constructor; for (; r && r !== o;) {
    let i = r[dt] || qc(r);
    if (i && i !== n)
        return i;
    r = Object.getPrototypeOf(r);
} return i => new i; }); }
function qc(e) { return Fr(e) ? () => { let t = qc($(e)); return t && t(); } : $r(e); }
function oT(e, t, n, o, r) { let i = e, s = t; for (; i !== null && s !== null && s[b] & 2048 && !Ve(s);) {
    let a = Lh(i, s, n, o | 2, Ue);
    if (a !== Ue)
        return a;
    let c = i.parent;
    if (!c) {
        let l = s[Oa];
        if (l) {
            let u = l.get(n, Ue, o);
            if (u !== Ue)
                return u;
        }
        c = jh(s), s = s[vo];
    }
    i = c;
} return r; }
function jh(e) { let t = e[y], n = t.type; return n === 2 ? t.declTNode : n === 1 ? e[se] : null; }
function as(e) { return XC(T(), e); }
var Vh = $n("Attribute", e => ({ attributeName: e, __NG_ELEMENT_ID__: () => as(e) })), fp = null;
function Zl() { return fp = fp || new Si; }
function cs(e) { return Hh(Zl().parameters(e)); }
function Hh(e) { return e.map(t => rT(t)); }
function rT(e) { let t = { token: null, attribute: null, host: !1, optional: !1, self: !1, skipSelf: !1 }; if (Array.isArray(e) && e.length > 0)
    for (let n = 0; n < e.length; n++) {
        let o = e[n];
        if (o === void 0)
            continue;
        let r = Object.getPrototypeOf(o);
        if (o instanceof rs || r.ngMetadataName === "Optional")
            t.optional = !0;
        else if (o instanceof is || r.ngMetadataName === "SkipSelf")
            t.skipSelf = !0;
        else if (o instanceof yh || r.ngMetadataName === "Self")
            t.self = !0;
        else if (o instanceof vh || r.ngMetadataName === "Host")
            t.host = !0;
        else if (o instanceof mh)
            t.token = o.token;
        else if (o instanceof Vh) {
            if (o.attributeName === void 0)
                throw new w(204, !1);
            t.attribute = o.attributeName;
        }
        else
            t.token = o;
    }
else
    e === void 0 || Array.isArray(e) && e.length === 0 ? t.token = null : t.token = e; return t; }
function iT(e, t) { let n = null, o = null; e.hasOwnProperty(jr) || Object.defineProperty(e, jr, { get: () => (n === null && (n = X({ usage: 0, kind: "injectable", type: e }).compileInjectable(sp, `ng:///${e.name}/\u0275prov.js`, lT(e, t))), n) }), e.hasOwnProperty(dt) || Object.defineProperty(e, dt, { get: () => { if (o === null) {
        let r = X({ usage: 0, kind: "injectable", type: e });
        o = r.compileFactory(sp, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, typeArgumentCount: 0, deps: cs(e), target: r.FactoryTarget.Injectable });
    } return o; }, configurable: !0 }); }
var sT = Ta({ provide: String, useValue: Ta });
function pp(e) { return e.useClass !== void 0; }
function aT(e) { return sT in e; }
function hp(e) { return e.useFactory !== void 0; }
function cT(e) { return e.useExisting !== void 0; }
function lT(e, t) { let n = t || { providedIn: null }, o = { name: e.name, type: e, typeArgumentCount: 0, providedIn: n.providedIn }; return (pp(n) || hp(n)) && n.deps !== void 0 && (o.deps = Hh(n.deps)), pp(n) ? o.useClass = n.useClass : aT(n) ? o.useValue = n.useValue : hp(n) ? o.useFactory = n.useFactory : cT(n) && (o.useExisting = n.useExisting), o; }
var uT = sr("Injectable", void 0, void 0, void 0, (e, t) => iT(e, t));
function dT() { return Un(T(), g()); }
function Un(e, t) { return new ar(ne(e, t)); }
var ar = (() => { class e {
    nativeElement;
    constructor(n) { this.nativeElement = n; }
    static __NG_ELEMENT_ID__ = dT;
} return e; })();
function Bh(e) { return e instanceof ar ? e.nativeElement : e; }
function fT() { return this._results[Symbol.iterator](); }
var Pi = class {
    _emitDistinctChangesOnly;
    dirty = !0;
    _onDirty = void 0;
    _results = [];
    _changesDetected = !1;
    _changes = void 0;
    length = 0;
    first = void 0;
    last = void 0;
    get changes() { return this._changes ??= new Wl; }
    constructor(t = !1) { this._emitDistinctChangesOnly = t; }
    get(t) { return this._results[t]; }
    map(t) { return this._results.map(t); }
    filter(t) { return this._results.filter(t); }
    find(t) { return this._results.find(t); }
    reduce(t, n) { return this._results.reduce(t, n); }
    forEach(t) { this._results.forEach(t); }
    some(t) { return this._results.some(t); }
    toArray() { return this._results.slice(); }
    toString() { return this._results.toString(); }
    reset(t, n) { this.dirty = !1; let o = Ae(t); (this._changesDetected = !Mf(this._results, o, n)) && (this._results = o, this.length = o.length, this.last = o[this.length - 1], this.first = o[0]); }
    notifyOnChanges() { this._changes !== void 0 && (this._changesDetected || !this._emitDistinctChangesOnly) && this._changes.next(this); }
    onDirty(t) { this._onDirty = t; }
    setDirty() { this.dirty = !0, this._onDirty?.(); }
    destroy() { this._changes !== void 0 && (this._changes.complete(), this._changes.unsubscribe()); }
    [Symbol.iterator] = fT;
}, Gn = "ngSkipHydration", pT = "ngskiphydration";
function Yl(e) { let t = e.mergedAttrs; if (t === null)
    return !1; for (let n = 0; n < t.length; n += 2) {
    let o = t[n];
    if (typeof o == "number")
        return !1;
    if (typeof o == "string" && o.toLowerCase() === pT)
        return !0;
} return !1; }
function $h(e) { return e.hasAttribute(Gn); }
function Wo(e) { return (e.flags & 128) === 128; }
function Wn(e) { if (Wo(e))
    return !0; let t = e.parent; for (; t;) {
    if (Wo(e) || Yl(t))
        return !0;
    t = t.parent;
} return !1; }
function Uh(e) { return Wo(e) || Yl(e) || Wn(e); }
var ls = (function (e) { return e[e.OnPush = 0] = "OnPush", e[e.Default = 1] = "Default", e; })(ls || {}), us = new Map, hT = 0;
function gT() { return hT++; }
function mT(e) { us.set(e[ln], e); }
function Gh(e) { return us.get(e) || null; }
function zc(e) { us.delete(e[ln]); }
function yT() { return us; }
var Li = class {
    lViewId;
    nodeIndex;
    native;
    component;
    directives;
    localRefs;
    get lView() { return Gh(this.lViewId); }
    constructor(t, n, o) { this.lViewId = t, this.nodeIndex = n, this.native = o; }
};
function ve(e) { let t = Ci(e); if (t) {
    if (Y(t)) {
        let n = t, o, r, i;
        if (qh(e)) {
            if (o = ET(n, e), o == -1)
                throw new Error("The provided component was not found in the application");
            r = e;
        }
        else if (vT(e)) {
            if (o = DT(n, e), o == -1)
                throw new Error("The provided directive was not found in the application");
            i = zh(o, n);
        }
        else if (o = mp(n, e), o == -1)
            return null;
        let s = R(n[o]), a = Ci(s), c = a && !Array.isArray(a) ? a : gp(n, o, s);
        if (r && c.component === void 0 && (c.component = r, _e(c.component, c)), i && c.directives === void 0) {
            c.directives = i;
            for (let l = 0; l < i.length; l++)
                _e(i[l], c);
        }
        _e(c.native, c), t = c;
    }
}
else {
    let n = e, o = n;
    for (; o = o.parentNode;) {
        let r = Ci(o);
        if (r) {
            let i = Array.isArray(r) ? r : r.lView;
            if (!i)
                return null;
            let s = mp(i, n);
            if (s >= 0) {
                let a = R(i[s]), c = gp(i, s, a);
                _e(a, c), t = c;
                break;
            }
        }
    }
} return t || null; }
function gp(e, t, n) { return new Li(e[ln], t, n); }
var Qc = "__ngContext__";
function _e(e, t) { Y(t) ? (e[Qc] = t[ln], mT(t)) : e[Qc] = t; }
function Ci(e) { let t = e[Qc]; return typeof t == "number" ? Gh(t) : t || null; }
function Wh(e) { let t = Ci(e); return t ? Y(t) ? t : t.lView : null; }
function qh(e) { return e && e.constructor && e.constructor.\u0275cmp; }
function vT(e) { return e && e.constructor && e.constructor.\u0275dir; }
function mp(e, t) { let n = e[y]; for (let o = I; o < n.bindingStartIndex; o++)
    if (R(e[o]) === t)
        return o; return -1; }
function IT(e) { if (e.child)
    return e.child; if (e.next)
    return e.next; for (; e.parent && !e.parent.next;)
    e = e.parent; return e.parent && e.parent.next; }
function ET(e, t) { let n = e[y].components; if (n)
    for (let o = 0; o < n.length; o++) {
        let r = n[o];
        if (le(r, e)[P] === t)
            return r;
    }
else if (le(I, e)[P] === t)
    return I; return -1; }
function DT(e, t) { let n = e[y].firstChild; for (; n;) {
    let o = n.directiveStart, r = n.directiveEnd;
    for (let i = o; i < r; i++)
        if (e[i] === t)
            return n.index;
    n = IT(n);
} return -1; }
function zh(e, t) { let n = t[y].data[e]; if (n.directiveStart === 0)
    return O; let o = []; for (let r = n.directiveStart; r < n.directiveEnd; r++) {
    let i = t[r];
    qh(i) || o.push(i);
} return o; }
function CT(e, t) { let n = t[y].data[e]; return me(n) ? t[n.directiveStart + n.componentOffset] : null; }
function TT(e, t) { let n = e[y].data[t]; if (n && n.localNames) {
    let o = {}, r = n.index + 1;
    for (let i = 0; i < n.localNames.length; i += 2)
        o[n.localNames[i]] = e[r], r++;
    return o;
} return null; }
function Qh(e) { return Yh(e[ht]); }
function Zh(e) { return Yh(e[ie]); }
function Yh(e) { for (; e !== null && !K(e);)
    e = e[ie]; return e; }
function yp(e) { let t = ve(e); if (t === null)
    return null; if (t.component === void 0) {
    let n = t.lView;
    if (n === null)
        return null;
    t.component = CT(t.nodeIndex, n);
} return t.component; }
function MT(e) { OT(e); let t = ve(e), n = t ? t.lView : null; return n === null ? null : n[P]; }
function NT(e) { let t = ve(e), n = t ? t.lView : null; if (n === null)
    return null; let o; for (; n[y].type === 2 && (o = jt(n));)
    n = o; return Ve(n) ? null : n[P]; }
function wT(e) { let t = ve(e), n = t ? t.lView : null; if (n === null)
    return Te.NULL; let o = n[y].data[t.nodeIndex]; return new Mt(o, n); }
function _T(e) { let t = ve(e), n = t ? t.lView : null; if (n === null)
    return []; let o = n[y], r = o.data[t.nodeIndex], i = [], s = r.providerIndexes & 1048575, a = r.directiveEnd; for (let c = s; c < a; c++) {
    let l = o.data[c];
    xT(l) && (l = l.type), i.push(l);
} return i; }
function bT(e) { if (e instanceof Text)
    return []; let t = ve(e), n = t ? t.lView : null; if (n === null)
    return []; let o = n[y], r = t.nodeIndex; return o?.data[r] ? (t.directives === void 0 && (t.directives = zh(r, n)), t.directives === null ? [] : [...t.directives]) : []; }
var Kh = (function (e) { return e.Angular = "angular", e.ACX = "acx", e.Wiz = "wiz", e; })(Kh || {}), Jh = (function (e) { return e[e.Default = 0] = "Default", e[e.OnPush = 1] = "OnPush", e; })(Jh || {}), Xh = (function (e) { return e[e.Emulated = 0] = "Emulated", e[e.None = 1] = "None", e; })(Xh || {});
function ST(e) { let t = ve(e); if (t === null)
    return {}; if (t.localRefs === void 0) {
    let n = t.lView;
    if (n === null)
        return {};
    t.localRefs = TT(n, t.nodeIndex);
} return t.localRefs || {}; }
function AT(e) { return ve(e).native; }
function RT(e) { let t = ve(e), n = t === null ? null : t.lView; if (n === null)
    return []; let o = n[y], r = n[Ot], i = o.cleanup, s = []; if (i && r)
    for (let a = 0; a < i.length;) {
        let c = i[a++], l = i[a++];
        if (typeof c == "string") {
            let u = c, d = R(n[l]), f = r[i[a++]], p = i[a++], h = typeof p == "boolean" || p >= 0 ? "dom" : "output", m = typeof p == "boolean" ? p : !1;
            e == d && s.push({ element: e, name: u, callback: f, useCapture: m, type: h });
        }
    } return s.sort(kT), s; }
function kT(e, t) { return e.name == t.name ? 0 : e.name < t.name ? -1 : 1; }
function xT(e) { return e.type !== void 0 && e.declaredInputs !== void 0 && e.resolveHostDirectives !== void 0; }
function OT(e) { if (typeof Element < "u" && !(e instanceof Element))
    throw new Error("Expecting instance of DOM Element"); }
var Zc;
function PT(e) { Zc = e; }
function nt() { if (Zc !== void 0)
    return Zc; if (typeof document < "u")
    return document; throw new w(210, !1); }
var ot = new _("", { providedIn: "root", factory: () => LT }), LT = "ng", Kl = new _(""), FT = new _("", { providedIn: "platform", factory: () => "unknown" }), jT = new _(""), VT = new _(""), HT = new _("", { providedIn: "root", factory: () => nt().body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") || null }), eg = { breakpoints: [16, 32, 48, 64, 96, 128, 256, 384, 640, 750, 828, 1080, 1200, 1920, 2048, 3840], placeholderResolution: 30, disableImageSizeWarning: !1, disableImageLazyLoadWarning: !1 }, BT = new _("", { providedIn: "root", factory: () => eg });
function $T(e) { return e; }
function UT() { let e = new Xt; return (typeof ngServerMode > "u" || !ngServerMode) && (e.store = tg(nt(), D(ot))), e; }
var Xt = (() => { class e {
    static \u0275prov = j({ token: e, providedIn: "root", factory: UT });
    store = {};
    onSerializeCallbacks = {};
    get(n, o) { return this.store[n] !== void 0 ? this.store[n] : o; }
    set(n, o) { this.store[n] = o; }
    remove(n) { delete this.store[n]; }
    hasKey(n) { return this.store.hasOwnProperty(n); }
    get isEmpty() { return Object.keys(this.store).length === 0; }
    onSerialize(n, o) { this.onSerializeCallbacks[n] = o; }
    toJson() { for (let n in this.onSerializeCallbacks)
        if (this.onSerializeCallbacks.hasOwnProperty(n))
            try {
                this.store[n] = this.onSerializeCallbacks[n]();
            }
            catch (o) {
                console.warn("Exception in onSerialize callback: ", o);
            } return JSON.stringify(this.store).replace(/</g, "\\u003C"); }
} return e; })();
function tg(e, t) { let n = e.getElementById(t + "-state"); if (n?.textContent)
    try {
        return JSON.parse(n.textContent);
    }
    catch (o) {
        console.warn("Exception while restoring TransferState for app " + t, o);
    } return {}; }
var Jl = "h", Xl = "b", ng = "f", og = "n", cr = "e", ds = "t", qn = "c", lr = "x", Je = "r", fs = "i", ur = "n", zn = "d", ps = "l", hs = "di", dr = "s", eu = "p", gs = "t", en = new _(""), rg = !1, tu = new _("", { providedIn: "root", factory: () => rg }), nu = new _(""), ms = new _(""), ou = !1, ru = new _(""), fr = new _("", { providedIn: "root", factory: () => new Map }), GT = new _("");
var Fi = { passive: !0, capture: !0 }, Ec = new WeakMap, Dc = new WeakMap, In = new WeakMap, ji = ["click", "keydown"], Vi = ["mouseenter", "mouseover", "focusin"], hn = null, Cc = 0, qo = class {
    callbacks = new Set;
    listener = () => { for (let t of this.callbacks)
        t(); };
};
function ig(e, t) { let n = Dc.get(e); if (!n) {
    n = new qo, Dc.set(e, n);
    for (let o of ji)
        e.addEventListener(o, n.listener, Fi);
} return n.callbacks.add(t), () => { let { callbacks: o, listener: r } = n; if (o.delete(t), o.size === 0) {
    Dc.delete(e);
    for (let i of ji)
        e.removeEventListener(i, r, Fi);
} }; }
function sg(e, t) { let n = Ec.get(e); if (!n) {
    n = new qo, Ec.set(e, n);
    for (let o of Vi)
        e.addEventListener(o, n.listener, Fi);
} return n.callbacks.add(t), () => { let { callbacks: o, listener: r } = n; if (o.delete(t), o.size === 0) {
    for (let i of Vi)
        e.removeEventListener(i, r, Fi);
    Ec.delete(e);
} }; }
function WT() { return new IntersectionObserver(e => { for (let t of e)
    t.isIntersecting && In.has(t.target) && In.get(t.target).listener(); }); }
function qT(e, t, n) { let o = In.get(e); return hn = hn || n(), o || (o = new qo, hn.observe(e), In.set(e, o), Cc++), o.callbacks.add(t), () => { In.has(e) && (o.callbacks.delete(t), o.callbacks.size === 0 && (hn?.unobserve(e), In.delete(e), Cc--), Cc === 0 && (hn?.disconnect(), hn = null)); }; }
var Qn = "ngb";
function iu(e, t, n = null) { if (t.length === 0 || e.nodeType !== Node.ELEMENT_NODE)
    return; let o = e.getAttribute(ui.JSACTION), r = t.reduce((s, a) => (o?.indexOf(a) ?? -1) === -1 ? s + a + ":;" : s, ""); e.setAttribute(ui.JSACTION, `${o ?? ""}${r}`); let i = n ?? ""; i !== "" && r.length > 0 && e.setAttribute(Qn, i); }
var ag = (e, t, n) => { let o = e, r = o.__jsaction_fns ?? new Map, i = r.get(t) ?? []; i.push(n), r.set(t, i), o.__jsaction_fns = r; }, su = (e, t) => { let n = e, o = n.getAttribute(Qn) ?? "", r = t.get(o) ?? new Set; r.has(n) || r.add(n), t.set(o, r); };
function zT(e, t) { if (e.length > 0) {
    let n = [];
    for (let r of e)
        t.has(r) && (n = [...n, ...t.get(r)]);
    new Set(n).forEach(au);
} }
var au = e => { e.removeAttribute(ui.JSACTION), e.removeAttribute(Qn), e.__jsaction_fns = void 0; }, cu = new _("", { providedIn: "root", factory: () => ({}) });
function lu(e, t) { let n = t?.__jsaction_fns?.get(e.type); if (!(!n || !t?.isConnected))
    for (let o of n)
        o(e); }
var Yc = new Map;
function cg(e, t) { return Yc.set(e, t), () => Yc.delete(e); }
var vp = !1, lg = (e, t, n, o) => { };
function QT(e, t, n, o) { lg(e, t, n, o); }
function ug() { vp || (lg = (e, t, n, o) => { let r = e[V].get(ot); Yc.get(r)?.(t, n, o); }, vp = !0); }
var rt = new _(""), dg = (() => { class e {
    registry = new Map;
    cleanupFns = new Map;
    jsActionMap = D(fr);
    contract = D(cu);
    add(n, o) { if (this.registry.set(n, o), this.awaitingCallbacks.has(n)) {
        let r = this.awaitingCallbacks.get(n);
        for (let i of r)
            i();
    } }
    get(n) { return this.registry.get(n) ?? null; }
    has(n) { return this.registry.has(n); }
    cleanup(n) { zT(n, this.jsActionMap); for (let o of n)
        this.registry.delete(o), this.jsActionMap.delete(o), this.invokeTriggerCleanupFns(o), this.hydrating.delete(o), this.awaitingCallbacks.delete(o); this.size === 0 && this.contract.instance?.cleanUp(); }
    get size() { return this.registry.size; }
    addCleanupFn(n, o) { let r = []; this.cleanupFns.has(n) && (r = this.cleanupFns.get(n)), r.push(o), this.cleanupFns.set(n, r); }
    invokeTriggerCleanupFns(n) { let o = this.cleanupFns.get(n) ?? []; for (let r of o)
        r(); this.cleanupFns.delete(n); }
    hydrating = new Map;
    awaitingCallbacks = new Map;
    awaitParentBlock(n, o) { let r = this.awaitingCallbacks.get(n) ?? []; r.push(o), this.awaitingCallbacks.set(n, r); }
    static \u0275prov = j({ token: e, providedIn: null, factory: () => new e });
} return e; })();
function Zn(e) { return (e.flags & 32) === 32; }
var fg = "__nghData__", ys = fg, pg = "__nghDeferData__", vs = pg;
function ZT(e) { return e === fg || e === pg; }
var Mn = "ngh", hg = "nghm", gg = () => null;
function YT(e, t, n = !1) { let o = e.getAttribute(Mn); if (o == null)
    return null; let [r, i] = o.split("|"); if (o = n ? i : r, !o)
    return null; let s = i ? `|${i}` : "", a = n ? r : s, c = {}; if (o !== "") {
    let u = t.get(Xt, null, { optional: !0 });
    u !== null && (c = u.get(ys, [])[Number(o)]);
} let l = { data: c, firstChild: e.firstChild ?? null }; return n && (l.firstChild = e, Is(l, 0, e.nextSibling)), a ? e.setAttribute(Mn, a) : e.removeAttribute(Mn), l; }
function mg() { gg = YT; }
function yg(e, t, n = !1) { return gg(e, t, n); }
function uu(e) { let t = e._lView; return t[y].type === 2 ? null : (Ve(t) && (t = t[I]), t); }
function KT(e) { return e.textContent?.replace(/\s/gm, ""); }
function JT(e) { let t = nt(), n = t.createNodeIterator(e, NodeFilter.SHOW_COMMENT, { acceptNode(i) { let s = KT(i); return s === "ngetn" || s === "ngtns" ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; } }), o, r = []; for (; o = n.nextNode();)
    r.push(o); for (let i of r)
    i.textContent === "ngetn" ? i.replaceWith(t.createTextNode("")) : i.remove(); }
var vg = (function (e) { return e.Hydrated = "hydrated", e.Skipped = "skipped", e.Mismatched = "mismatched", e; })(vg || {}), XT = "__ngDebugHydrationInfo__";
function eM(e) { return e[XT] ?? null; }
function Is(e, t, n) { e.segmentHeads ??= {}, e.segmentHeads[t] = n; }
function Kc(e, t) { return e.segmentHeads?.[t] ?? null; }
function Es(e) { return e.get(ru, !1, { optional: !0 }); }
function Ig(e, t) { let n = e.data, o = n[cr]?.[t] ?? null; return o === null && n[qn]?.[t] && (o = du(e, t)), o; }
function tM(e, t) { return e.data[cr]?.[t] !== void 0; }
function Eg(e, t) { return e.data[qn]?.[t] ?? null; }
function du(e, t) { let n = Eg(e, t) ?? [], o = 0; for (let r of n)
    o += r[Je] * (r[lr] ?? 1); return o; }
function Dg(e) { if (typeof e.disconnectedNodes > "u") {
    let t = e.data[zn];
    e.disconnectedNodes = t ? new Set(t) : null;
} return e.disconnectedNodes; }
function Ds(e, t) { if (typeof e.disconnectedNodes > "u") {
    let n = e.data[zn];
    e.disconnectedNodes = n ? new Set(n) : null;
} return !!Dg(e)?.has(t); }
function Cs(e, t) { let n = e[te]; return n !== null && !Mo() && !Zn(t) && !Ds(n, t.index - I); }
function fu(e, t) { let n = t, o = e.corruptedTextNodes; n.textContent === "" ? o.set(n, "ngetn") : n.nextSibling?.nodeType === Node.TEXT_NODE && o.set(n, "ngtns"); }
function Cg(e) { let t = []; return e !== null && (e.has(4) && t.push(...Vi), e.has(3) && t.push(...ji)), t; }
function nM(e, t) { let n = t.get(rt), r = t.get(Xt).get(vs, {}), i = !1, s = e, a = null, c = []; for (; !i && s;) {
    i = n.has(s);
    let l = n.hydrating.get(s);
    if (a === null && l != null) {
        a = l.promise;
        break;
    }
    c.unshift(s), s = r[s][eu];
} return { parentBlockPromise: a, hydrationQueue: c }; }
function oM(e) { let t = e.body.querySelectorAll("[jsaction]"), n = new Set, o = [Vi.join(":;"), ji.join(":;")].join("|"); for (let r of t) {
    let i = r.getAttribute("jsaction"), s = r.getAttribute("ngb");
    i?.match(o) && s !== null && n.add(r);
} return n; }
function Tg(e, t) { let n = oM(e), o = t.get(fr); for (let r of n)
    su(r, o); }
var Mg = () => ({});
function rM(e) { let t = e.get(Xt, null, { optional: !0 }); return t !== null ? t.get(vs, {}) : {}; }
function Ng() { Mg = rM; }
function iM(e) { return Mg(e); }
function sM(e) { return typeof e == "object" && e.trigger === 5; }
function aM(e) { return e[gs]?.find(n => sM(n))?.delay ?? null; }
function Tc(e, t) { return e[gs]?.includes(t) ?? !1; }
function cM(e) { return { data: e, hydrate: { idle: Tc(e, 0), immediate: Tc(e, 1), timer: aM(e), viewport: Tc(e, 2) } }; }
function wg(e) { let t = iM(e), n = new Map; for (let o in t)
    n.set(o, cM(t[o])); return n; }
function Mc(e) { return !!e && e.nodeType === Node.COMMENT_NODE && e.textContent?.trim() === hg; }
function Ip(e) { for (; e && e.nodeType === Node.TEXT_NODE;)
    e = e.previousSibling; return e; }
function _g(e) { for (let o of e.body.childNodes)
    if (Mc(o))
        return; let t = Ip(e.body.previousSibling); if (Mc(t))
    return; let n = Ip(e.head.lastChild); if (!Mc(n))
    throw new w(-507, !1); }
function bg(e, t) { let n = e.contentQueries; if (n !== null) {
    let o = S(null);
    try {
        for (let r = 0; r < n.length; r += 2) {
            let i = n[r], s = n[r + 1];
            if (s !== -1) {
                let a = e.data[s];
                No(i), a.contentQueries(2, t[s], s);
            }
        }
    }
    finally {
        S(o);
    }
} }
function Jc(e, t, n) { No(0); let o = S(null); try {
    t(e, n);
}
finally {
    S(o);
} }
function pu(e, t, n) { if (La(t)) {
    let o = S(null);
    try {
        let r = t.directiveStart, i = t.directiveEnd;
        for (let s = r; s < i; s++) {
            let a = e.data[s];
            if (a.contentQueries) {
                let c = n[s];
                a.contentQueries(1, c, s);
            }
        }
    }
    finally {
        S(o);
    }
} }
var Xe = (function (e) { return e[e.Emulated = 0] = "Emulated", e[e.None = 2] = "None", e[e.ShadowDom = 3] = "ShadowDom", e; })(Xe || {}), fi;
function Sg() { if (fi === void 0 && (fi = null, Ie.trustedTypes))
    try {
        fi = Ie.trustedTypes.createPolicy("angular", { createHTML: e => e, createScript: e => e, createScriptURL: e => e });
    }
    catch { } return fi; }
function Yn(e) { return Sg()?.createHTML(e) || e; }
function lM(e) { return Sg()?.createScriptURL(e) || e; }
var pi;
function hu() { if (pi === void 0 && (pi = null, Ie.trustedTypes))
    try {
        pi = Ie.trustedTypes.createPolicy("angular#unsafe-bypass", { createHTML: e => e, createScript: e => e, createScriptURL: e => e });
    }
    catch { } return pi; }
function Ep(e) { return hu()?.createHTML(e) || e; }
function Dp(e) { return hu()?.createScript(e) || e; }
function Cp(e) { return hu()?.createScriptURL(e) || e; }
var et = class {
    changingThisBreaksApplicationSecurity;
    constructor(t) { this.changingThisBreaksApplicationSecurity = t; }
    toString() { return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity} (see ${Pr})`; }
}, Xc = class extends et {
    getTypeName() { return "HTML"; }
}, el = class extends et {
    getTypeName() { return "Style"; }
}, tl = class extends et {
    getTypeName() { return "Script"; }
}, nl = class extends et {
    getTypeName() { return "URL"; }
}, ol = class extends et {
    getTypeName() { return "ResourceURL"; }
};
function it(e) { return e instanceof et ? e.changingThisBreaksApplicationSecurity : e; }
function Kn(e, t) { let n = Ag(e); if (n != null && n !== t) {
    if (n === "ResourceURL" && t === "URL")
        return !0;
    throw new Error(`Required a safe ${t}, got a ${n} (see ${Pr})`);
} return n === t; }
function Ag(e) { return e instanceof et && e.getTypeName() || null; }
function uM(e) { return new Xc(e); }
function dM(e) { return new el(e); }
function fM(e) { return new tl(e); }
function pM(e) { return new nl(e); }
function hM(e) { return new ol(e); }
function Rg(e) { let t = new il(e); return gM() ? new rl(t) : t; }
var rl = class {
    inertDocumentHelper;
    constructor(t) { this.inertDocumentHelper = t; }
    getInertBodyElement(t) { t = "<body><remove></remove>" + t; try {
        let n = new window.DOMParser().parseFromString(Yn(t), "text/html").body;
        return n === null ? this.inertDocumentHelper.getInertBodyElement(t) : (n.firstChild?.remove(), n);
    }
    catch {
        return null;
    } }
}, il = class {
    defaultDoc;
    inertDocument;
    constructor(t) { this.defaultDoc = t, this.inertDocument = this.defaultDoc.implementation.createHTMLDocument("sanitization-inert"); }
    getInertBodyElement(t) { let n = this.inertDocument.createElement("template"); return n.innerHTML = Yn(t), n; }
};
function gM() { try {
    return !!new window.DOMParser().parseFromString(Yn(""), "text/html");
}
catch {
    return !1;
} }
var mM = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;
function Ts(e) { return e = String(e), e.match(mM) ? e : "unsafe:" + e; }
function st(e) { let t = {}; for (let n of e.split(","))
    t[n] = !0; return t; }
function pr(...e) { let t = {}; for (let n of e)
    for (let o in n)
        n.hasOwnProperty(o) && (t[o] = !0); return t; }
var kg = st("area,br,col,hr,img,wbr"), xg = st("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr"), Og = st("rp,rt"), yM = pr(Og, xg), vM = pr(xg, st("address,article,aside,blockquote,caption,center,del,details,dialog,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,main,map,menu,nav,ol,pre,section,summary,table,ul")), IM = pr(Og, st("a,abbr,acronym,audio,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,picture,q,ruby,rp,rt,s,samp,small,source,span,strike,strong,sub,sup,time,track,tt,u,var,video")), sl = pr(kg, vM, IM, yM), gu = st("background,cite,href,itemtype,longdesc,poster,src,xlink:href"), EM = st("abbr,accesskey,align,alt,autoplay,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,controls,coords,datetime,default,dir,download,face,headers,height,hidden,hreflang,hspace,ismap,itemscope,itemprop,kind,label,lang,language,loop,media,muted,nohref,nowrap,open,preload,rel,rev,role,rows,rowspan,rules,scope,scrolling,shape,size,sizes,span,srclang,srcset,start,summary,tabindex,target,title,translate,type,usemap,valign,value,vspace,width"), DM = st("aria-activedescendant,aria-atomic,aria-autocomplete,aria-busy,aria-checked,aria-colcount,aria-colindex,aria-colspan,aria-controls,aria-current,aria-describedby,aria-details,aria-disabled,aria-dropeffect,aria-errormessage,aria-expanded,aria-flowto,aria-grabbed,aria-haspopup,aria-hidden,aria-invalid,aria-keyshortcuts,aria-label,aria-labelledby,aria-level,aria-live,aria-modal,aria-multiline,aria-multiselectable,aria-orientation,aria-owns,aria-placeholder,aria-posinset,aria-pressed,aria-readonly,aria-relevant,aria-required,aria-roledescription,aria-rowcount,aria-rowindex,aria-rowspan,aria-selected,aria-setsize,aria-sort,aria-valuemax,aria-valuemin,aria-valuenow,aria-valuetext"), Pg = pr(gu, EM, DM), CM = st("script,style,template"), al = class {
    sanitizedSomething = !1;
    buf = [];
    sanitizeChildren(t) { let n = t.firstChild, o = !0, r = []; for (; n;) {
        if (n.nodeType === Node.ELEMENT_NODE ? o = this.startElement(n) : n.nodeType === Node.TEXT_NODE ? this.chars(n.nodeValue) : this.sanitizedSomething = !0, o && n.firstChild) {
            r.push(n), n = NM(n);
            continue;
        }
        for (; n;) {
            n.nodeType === Node.ELEMENT_NODE && this.endElement(n);
            let i = MM(n);
            if (i) {
                n = i;
                break;
            }
            n = r.pop();
        }
    } return this.buf.join(""); }
    startElement(t) { let n = Tp(t).toLowerCase(); if (!sl.hasOwnProperty(n))
        return this.sanitizedSomething = !0, !CM.hasOwnProperty(n); this.buf.push("<"), this.buf.push(n); let o = t.attributes; for (let r = 0; r < o.length; r++) {
        let i = o.item(r), s = i.name, a = s.toLowerCase();
        if (!Pg.hasOwnProperty(a)) {
            this.sanitizedSomething = !0;
            continue;
        }
        let c = i.value;
        gu[a] && (c = Ts(c)), this.buf.push(" ", s, '="', Mp(c), '"');
    } return this.buf.push(">"), !0; }
    endElement(t) { let n = Tp(t).toLowerCase(); sl.hasOwnProperty(n) && !kg.hasOwnProperty(n) && (this.buf.push("</"), this.buf.push(n), this.buf.push(">")); }
    chars(t) { this.buf.push(Mp(t)); }
};
function TM(e, t) { return (e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY) !== Node.DOCUMENT_POSITION_CONTAINED_BY; }
function MM(e) { let t = e.nextSibling; if (t && e !== t.previousSibling)
    throw Lg(t); return t; }
function NM(e) { let t = e.firstChild; if (t && TM(e, t))
    throw Lg(t); return t; }
function Tp(e) { let t = e.nodeName; return typeof t == "string" ? t : "FORM"; }
function Lg(e) { return new Error(`Failed to sanitize html because the element is clobbered: ${e.outerHTML}`); }
var wM = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g, _M = /([^\#-~ |!])/g;
function Mp(e) { return e.replace(/&/g, "&amp;").replace(wM, function (t) { let n = t.charCodeAt(0), o = t.charCodeAt(1); return "&#" + ((n - 55296) * 1024 + (o - 56320) + 65536) + ";"; }).replace(_M, function (t) { return "&#" + t.charCodeAt(0) + ";"; }).replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
var hi;
function Fg(e, t) { let n = null; try {
    hi = hi || Rg(e);
    let o = t ? String(t) : "";
    n = hi.getInertBodyElement(o);
    let r = 5, i = o;
    do {
        if (r === 0)
            throw new Error("Failed to sanitize html because the input is unstable");
        r--, o = i, i = n.innerHTML, n = hi.getInertBodyElement(o);
    } while (o !== i);
    let a = new al().sanitizeChildren(cl(n) || n);
    return Yn(a);
}
finally {
    if (n) {
        let o = cl(n) || n;
        for (; o.firstChild;)
            o.firstChild.remove();
    }
} }
function cl(e) { return "content" in e && bM(e) ? e.content : null; }
function bM(e) { return e.nodeType === Node.ELEMENT_NODE && e.nodeName === "TEMPLATE"; }
var tn = (function (e) { return e[e.NONE = 0] = "NONE", e[e.HTML = 1] = "HTML", e[e.STYLE = 2] = "STYLE", e[e.SCRIPT = 3] = "SCRIPT", e[e.URL = 4] = "URL", e[e.RESOURCE_URL = 5] = "RESOURCE_URL", e; })(tn || {});
function jg(e) { let t = hr(); return t ? Ep(t.sanitize(tn.HTML, e) || "") : Kn(e, "HTML") ? Ep(it(e)) : Fg(nt(), M(e)); }
function Vg(e) { let t = hr(); return t ? t.sanitize(tn.STYLE, e) || "" : Kn(e, "Style") ? it(e) : M(e); }
function mu(e) { let t = hr(); return t ? t.sanitize(tn.URL, e) || "" : Kn(e, "URL") ? it(e) : Ts(M(e)); }
function yu(e) { let t = hr(); if (t)
    return Cp(t.sanitize(tn.RESOURCE_URL, e) || ""); if (Kn(e, "ResourceURL"))
    return Cp(it(e)); throw new w(904, !1); }
function Hg(e) { let t = hr(); if (t)
    return Dp(t.sanitize(tn.SCRIPT, e) || ""); if (Kn(e, "Script"))
    return Dp(it(e)); throw new w(905, !1); }
function Bg(e) { return Yn(e[0]); }
function $g(e) { return lM(e[0]); }
function SM(e, t) { return t === "src" && (e === "embed" || e === "frame" || e === "iframe" || e === "media" || e === "script") || t === "href" && (e === "base" || e === "link") ? yu : mu; }
function Ug(e, t, n) { return SM(t, n)(e); }
function hr() { let e = g(); return e && e[ze].sanitizer; }
var AM = /^>|^->|<!--|-->|--!>|<!-$/g, RM = /(<|>)/g, kM = "\u200B$1\u200B";
function xM(e) { return e.replace(AM, t => t.replace(RM, kM)); }
function OM() { return qe([]); }
var PM = { name: "custom-elements" }, LM = { name: "no-errors-schema" }, Gg = !1;
function FM(e) { Gg = e; }
function jM() { return Gg; }
var Wg = !1;
function VM(e) { Wg = e; }
function HM() { return Wg; }
function qg(e) { return e.ownerDocument.defaultView; }
function zg(e) { return e.ownerDocument; }
function vu(e) { return e.ownerDocument.body; }
var BM = "\uFFFD";
function En(e) { return e instanceof Function ? e() : e; }
function $M(e, t, n) { let o = e.length; for (;;) {
    let r = e.indexOf(t, n);
    if (r === -1)
        return r;
    if (r === 0 || e.charCodeAt(r - 1) <= 32) {
        let i = t.length;
        if (r + i === o || e.charCodeAt(r + i) <= 32)
            return r;
    }
    n = r + 1;
} }
var Qg = "ng-template";
function UM(e, t, n, o) { let r = 0; if (o) {
    for (; r < t.length && typeof t[r] == "string"; r += 2)
        if (t[r] === "class" && $M(t[r + 1].toLowerCase(), n, 0) !== -1)
            return !0;
}
else if (Iu(e))
    return !1; if (r = t.indexOf(1, r), r > -1) {
    let i;
    for (; ++r < t.length && typeof (i = t[r]) == "string";)
        if (i.toLowerCase() === n)
            return !0;
} return !1; }
function Iu(e) { return e.type === 4 && e.value !== Qg; }
function GM(e, t, n) { let o = e.type === 4 && !n ? Qg : e.value; return t === o; }
function WM(e, t, n) { let o = 4, r = e.attrs, i = r !== null ? QM(r) : 0, s = !1; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "number") {
        if (!s && !xe(o) && !xe(c))
            return !1;
        if (s && xe(c))
            continue;
        s = !1, o = c | o & 1;
        continue;
    }
    if (!s)
        if (o & 4) {
            if (o = 2 | o & 1, c !== "" && !GM(e, c, n) || c === "" && t.length === 1) {
                if (xe(o))
                    return !1;
                s = !0;
            }
        }
        else if (o & 8) {
            if (r === null || !UM(e, r, c, n)) {
                if (xe(o))
                    return !1;
                s = !0;
            }
        }
        else {
            let l = t[++a], u = qM(c, r, Iu(e), n);
            if (u === -1) {
                if (xe(o))
                    return !1;
                s = !0;
                continue;
            }
            if (l !== "") {
                let d;
                if (u > i ? d = "" : d = r[u + 1].toLowerCase(), o & 2 && l !== d) {
                    if (xe(o))
                        return !1;
                    s = !0;
                }
            }
        }
} return xe(o) || s; }
function xe(e) { return (e & 1) === 0; }
function qM(e, t, n, o) { if (t === null)
    return -1; let r = 0; if (o || !n) {
    let i = !1;
    for (; r < t.length;) {
        let s = t[r];
        if (s === e)
            return r;
        if (s === 3 || s === 6)
            i = !0;
        else if (s === 1 || s === 2) {
            let a = t[++r];
            for (; typeof a == "string";)
                a = t[++r];
            continue;
        }
        else {
            if (s === 4)
                break;
            if (s === 0) {
                r += 4;
                continue;
            }
        }
        r += i ? 1 : 2;
    }
    return -1;
}
else
    return ZM(t, e); }
function Zg(e, t, n = !1) { for (let o = 0; o < t.length; o++)
    if (WM(e, t[o], n))
        return !0; return !1; }
function zM(e) { let t = e.attrs; if (t != null) {
    let n = t.indexOf(5);
    if ((n & 1) === 0)
        return t[n + 1];
} return null; }
function QM(e) { for (let t = 0; t < e.length; t++) {
    let n = e[t];
    if (bh(n))
        return t;
} return e.length; }
function ZM(e, t) { let n = e.indexOf(4); if (n > -1)
    for (n++; n < e.length;) {
        let o = e[n];
        if (typeof o == "number")
            return -1;
        if (o === t)
            return n;
        n++;
    } return -1; }
function YM(e, t) { e: for (let n = 0; n < t.length; n++) {
    let o = t[n];
    if (e.length === o.length) {
        for (let r = 0; r < e.length; r++)
            if (e[r] !== o[r])
                continue e;
        return !0;
    }
} return !1; }
function Np(e, t) { return e ? ":not(" + t.trim() + ")" : t; }
function KM(e) { let t = e[0], n = 1, o = 2, r = "", i = !1; for (; n < e.length;) {
    let s = e[n];
    if (typeof s == "string")
        if (o & 2) {
            let a = e[++n];
            r += "[" + s + (a.length > 0 ? '="' + a + '"' : "") + "]";
        }
        else
            o & 8 ? r += "." + s : o & 4 && (r += " " + s);
    else
        r !== "" && !xe(s) && (t += Np(i, r), r = ""), o = s, i = i || !xe(o);
    n++;
} return r !== "" && (t += Np(i, r)), t; }
function JM(e) { return e.map(KM).join(","); }
function XM(e) { let t = [], n = [], o = 1, r = 2; for (; o < e.length;) {
    let i = e[o];
    if (typeof i == "string")
        r === 2 ? i !== "" && t.push(i, e[++o]) : r === 8 && n.push(i);
    else {
        if (!xe(r))
            break;
        r = i;
    }
    o++;
} return n.length && t.push(1, ...n), t; }
var x = {};
function Eu(e, t) { return e.createText(t); }
function Yg(e, t, n) { e.setValue(t, n); }
function Du(e, t) { return e.createComment(xM(t)); }
function Ms(e, t, n) { return e.createElement(t, n); }
function qt(e, t, n, o, r) { e.insertBefore(t, n, o, r); }
function Kg(e, t, n) { e.appendChild(t, n); }
function wp(e, t, n, o, r) { o !== null ? qt(e, t, n, o, r) : Kg(e, t, n); }
function gr(e, t, n) { e.removeChild(null, t, n); }
function Jg(e) { e.textContent = ""; }
function eN(e, t, n) { e.setAttribute(t, "style", n); }
function tN(e, t, n) { n === "" ? e.removeAttribute(t, "class") : e.setAttribute(t, "class", n); }
function Xg(e, t, n) { let { mergedAttrs: o, classes: r, styles: i } = n; o !== null && zC(e, t, o), r !== null && tN(e, t, r), i !== null && eN(e, t, i); }
function Cu(e, t, n, o, r, i, s, a, c, l, u) { let d = I + o, f = d + r, p = nN(d, f), h = typeof l == "function" ? l() : l; return p[y] = { type: e, blueprint: p, template: n, queries: null, viewQuery: a, declTNode: t, data: p.slice().fill(null, d), bindingStartIndex: d, expandoStartIndex: f, hostBindingOpCodes: null, firstCreatePass: !0, firstUpdatePass: !0, staticViewQueries: !1, staticContentQueries: !1, preOrderHooks: null, preOrderCheckHooks: null, contentHooks: null, contentCheckHooks: null, viewHooks: null, viewCheckHooks: null, destroyHooks: null, cleanup: null, contentQueries: null, components: null, directiveRegistry: typeof i == "function" ? i() : i, pipeRegistry: typeof s == "function" ? s() : s, firstChild: null, schemas: c, consts: h, incompleteFirstPass: !1, ssrId: u }; }
function nN(e, t) { let n = []; for (let o = 0; o < t; o++)
    n.push(o < e ? null : x); return n; }
function em(e) { let t = e.tView; return t === null || t.incompleteFirstPass ? e.tView = Cu(1, null, e.template, e.decls, e.vars, e.directiveDefs, e.pipeDefs, e.viewQuery, e.schemas, e.consts, e.id) : t; }
function Ns(e, t, n, o, r, i, s, a, c, l, u) { let d = t.blueprint.slice(); return d[F] = r, d[b] = o | 4 | 128 | 8 | 64 | 1024, (l !== null || e && e[b] & 2048) && (d[b] |= 2048), ja(d), d[q] = d[vo] = e, d[P] = n, d[ze] = s || e && e[ze], d[C] = a || e && e[C], d[V] = c || e && e[V] || null, d[se] = i, d[ln] = gT(), d[te] = u, d[Oa] = l, d[Q] = t.type == 2 ? e[Q] : d, d; }
function oN(e, t, n) { let o = ne(t, e), r = em(n), i = e[ze].rendererFactory, s = Mu(e, Ns(e, r, null, Tu(n), o, t, null, i.createRenderer(o, n), null, null, null)); return e[t.index] = s; }
function Tu(e) { let t = 16; return e.signals ? t = 4096 : e.onPush && (t = 64), t; }
function mr(e, t, n, o) { if (n === 0)
    return -1; let r = t.length; for (let i = 0; i < n; i++)
    t.push(o), e.blueprint.push(o), e.data.push(null); return r; }
function Mu(e, t) { return e[ht] ? e[yo][ie] = t : e[ht] = t, e[yo] = t, t; }
function tm(e = 1) { nm(N(), g(), oe() + e, !1); }
function nm(e, t, n, o) { if (!o)
    if ((t[b] & 3) === 3) {
        let i = e.preOrderCheckHooks;
        i !== null && Ii(t, i, n);
    }
    else {
        let i = e.preOrderHooks;
        i !== null && Ei(t, i, 0, n);
    } It(n); }
var ws = (function (e) { return e[e.None = 0] = "None", e[e.SignalBased = 1] = "SignalBased", e[e.HasDecoratorInputTransform = 2] = "HasDecoratorInputTransform", e; })(ws || {});
function zo(e, t, n, o) { let r = S(null); try {
    let [i, s, a] = e.inputs[n], c = null;
    (s & ws.SignalBased) !== 0 && (c = t[i][ut]), c !== null && c.transformFn !== void 0 ? o = c.transformFn(o) : a !== null && (o = a.call(t, o)), e.setInput !== null ? e.setInput(t, c, o, n, i) : Eh(t, c, i, o);
}
finally {
    S(r);
} }
var Hi = (function (e) { return e[e.Important = 1] = "Important", e[e.DashCase = 2] = "DashCase", e; })(Hi || {}), ll;
function Nu(e, t) { return ll(e, t); }
function rN(e) { ll === void 0 && (ll = e()); }
function Dn(e, t, n, o, r) { if (o != null) {
    let i, s = !1;
    K(o) ? i = o : Y(o) && (s = !0, o = o[F]);
    let a = R(o);
    e === 0 && n !== null ? r == null ? Kg(t, n, a) : qt(t, n, a, r || null, !0) : e === 1 && n !== null ? qt(t, n, a, r || null, !0) : e === 2 ? gr(t, a, s) : e === 3 && t.destroyNode(a), i != null && uN(t, e, i, n, r);
} }
function om(e, t) { rm(e, t), t[F] = null, t[se] = null; }
function iN(e, t, n, o, r, i) { o[F] = r, o[se] = t, _s(e, o, n, 1, r, i); }
function rm(e, t) { t[ze].changeDetectionScheduler?.notify(9), _s(e, t, t[C], 2, null, null); }
function sN(e) { let t = e[ht]; if (!t)
    return Nc(e[y], e); for (; t;) {
    let n = null;
    if (Y(t))
        n = t[ht];
    else {
        let o = t[G];
        o && (n = o);
    }
    if (!n) {
        for (; t && !t[ie] && t !== e;)
            Y(t) && Nc(t[y], t), t = t[q];
        t === null && (t = e), Y(t) && Nc(t[y], t), n = t && t[ie];
    }
    t = n;
} }
function wu(e, t) { let n = e[Lt], o = n.indexOf(t); n.splice(o, 1); }
function yr(e, t) { if (mt(t))
    return; let n = t[C]; n.destroyNode && _s(e, t, n, 3, null, null), sN(t); }
function Nc(e, t) { if (mt(t))
    return; let n = S(null); try {
    t[b] &= -129, t[b] |= 256, t[we] && uo(t[we]), cN(e, t), aN(e, t), t[y].type === 1 && t[C].destroy();
    let o = t[gt];
    if (o !== null && K(t[q])) {
        o !== t[q] && wu(o, t);
        let r = t[je];
        r !== null && r.detachView(e);
    }
    zc(t);
}
finally {
    S(n);
} }
function aN(e, t) { let n = e.cleanup, o = t[Ot]; if (n !== null)
    for (let s = 0; s < n.length - 1; s += 2)
        if (typeof n[s] == "string") {
            let a = n[s + 3];
            a >= 0 ? o[a]() : o[-a].unsubscribe(), s += 2;
        }
        else {
            let a = o[n[s + 1]];
            n[s].call(a);
        } o !== null && (t[Ot] = null); let r = t[Pa]; if (r !== null) {
    t[Pa] = null;
    for (let s = 0; s < r.length; s++) {
        let a = r[s];
        a();
    }
} let i = t[Io]; if (i !== null) {
    t[Io] = null;
    for (let s of i)
        s.destroy();
} }
function cN(e, t) { let n; if (e != null && (n = e.destroyHooks) != null)
    for (let o = 0; o < n.length; o += 2) {
        let r = t[n[o]];
        if (!(r instanceof Wt)) {
            let i = n[o + 1];
            if (Array.isArray(i))
                for (let s = 0; s < i.length; s += 2) {
                    let a = r[i[s]], c = i[s + 1];
                    k(4, a, c);
                    try {
                        c.call(a);
                    }
                    finally {
                        k(5, a, c);
                    }
                }
            else {
                k(4, r, i);
                try {
                    i.call(r);
                }
                finally {
                    k(5, r, i);
                }
            }
        }
    } }
function _u(e, t, n) { return im(e, t.parent, n); }
function im(e, t, n) { let o = t; for (; o !== null && o.type & 168;)
    t = o, o = t.parent; if (o === null)
    return n[F]; if (me(o)) {
    let { encapsulation: r } = e.data[o.directiveStart + o.componentOffset];
    if (r === Xe.None || r === Xe.Emulated)
        return null;
} return ne(o, n); }
function sm(e, t, n) { return cm(e, t, n); }
function am(e, t, n) { return e.type & 40 ? ne(e, n) : null; }
var cm = am, ul;
function lm(e, t) { cm = e, ul = t; }
function bu(e, t, n, o) { let r = _u(e, o, t), i = t[C], s = o.parent || t[se], a = sm(s, o, t); if (r != null)
    if (Array.isArray(n))
        for (let c = 0; c < n.length; c++)
            wp(i, r, n[c], a, !1);
    else
        wp(i, r, n, a, !1); ul !== void 0 && ul(i, o, t, n, r); }
function Ut(e, t) { if (t !== null) {
    let n = t.type;
    if (n & 3)
        return ne(t, e);
    if (n & 4)
        return dl(-1, e[t.index]);
    if (n & 8) {
        let o = t.child;
        if (o !== null)
            return Ut(e, o);
        {
            let r = e[t.index];
            return K(r) ? dl(-1, r) : R(r);
        }
    }
    else {
        if (n & 128)
            return Ut(e, t.next);
        if (n & 32)
            return Nu(t, e)() || R(e[t.index]);
        {
            let o = um(e, t);
            if (o !== null) {
                if (Array.isArray(o))
                    return o[0];
                let r = jt(e[Q]);
                return Ut(r, o);
            }
            else
                return Ut(e, t.next);
        }
    }
} return null; }
function um(e, t) { if (t !== null) {
    let o = e[Q][se], r = t.projection;
    return o.projection[r];
} return null; }
function dl(e, t) { let n = G + e + 1; if (n < t.length) {
    let o = t[n], r = o[y].firstChild;
    if (r !== null)
        return Ut(o, r);
} return t[Re]; }
function Su(e, t, n, o, r, i, s) { for (; n != null;) {
    if (n.type === 128) {
        n = n.next;
        continue;
    }
    let a = o[n.index], c = n.type;
    if (s && t === 0 && (a && _e(R(a), o), n.flags |= 2), !Zn(n))
        if (c & 8)
            Su(e, t, n.child, o, r, i, !1), Dn(t, e, r, a, i);
        else if (c & 32) {
            let l = Nu(n, o), u;
            for (; u = l();)
                Dn(t, e, r, u, i);
            Dn(t, e, r, a, i);
        }
        else
            c & 16 ? dm(e, t, o, n, r, i) : Dn(t, e, r, a, i);
    n = s ? n.projectionNext : n.next;
} }
function _s(e, t, n, o, r, i) { Su(n, o, e.firstChild, t, r, i, !1); }
function lN(e, t, n) { let o = t[C], r = _u(e, n, t), i = n.parent || t[se], s = sm(i, n, t); dm(o, 0, t, n, r, s); }
function dm(e, t, n, o, r, i) { let s = n[Q], c = s[se].projection[o.projection]; if (Array.isArray(c))
    for (let l = 0; l < c.length; l++) {
        let u = c[l];
        Dn(t, e, r, u, i);
    }
else {
    let l = c, u = s[q];
    Wo(o) && (l.flags |= 128), Su(e, t, l, u, r, i, !0);
} }
function uN(e, t, n, o, r) { let i = n[Re], s = R(n); i !== s && Dn(t, e, o, i, r); for (let a = G; a < n.length; a++) {
    let c = n[a];
    _s(c[y], c, e, t, o, i);
} }
function dN(e, t, n, o, r) { if (t)
    r ? e.addClass(n, o) : e.removeClass(n, o);
else {
    let i = o.indexOf("-") === -1 ? void 0 : Hi.DashCase;
    r == null ? e.removeStyle(n, o, i) : (typeof r == "string" && r.endsWith("!important") && (r = r.slice(0, -10), i |= Hi.Important), e.setStyle(n, o, r, i));
} }
function fm(e, t, n, o, r) { let i = oe(), s = o & 2; try {
    It(-1), s && t.length > I && nm(e, t, I, !1), k(s ? 2 : 0, r, n), n(o, r);
}
finally {
    It(i), k(s ? 3 : 1, r, n);
} }
function bs(e, t, n) { mN(e, t, n), (n.flags & 64) === 64 && yN(e, t, n); }
function Jn(e, t, n = ne) { let o = t.localNames; if (o !== null) {
    let r = t.index + 1;
    for (let i = 0; i < o.length; i += 2) {
        let s = o[i + 1], a = s === -1 ? n(t, e) : e[s];
        e[r++] = a;
    }
} }
function fN(e, t, n, o) { let i = o.get(tu, rg) || n === Xe.ShadowDom, s = e.selectRootElement(t, i); return pN(s), s; }
function pN(e) { pm(e); }
var pm = () => null;
function hN(e) { $h(e) ? Jg(e) : JT(e); }
function hm() { pm = hN; }
function gN(e) { return e === "class" ? "className" : e === "for" ? "htmlFor" : e === "formaction" ? "formAction" : e === "innerHtml" ? "innerHTML" : e === "readonly" ? "readOnly" : e === "tabindex" ? "tabIndex" : e; }
function Au(e, t, n, o, r, i) { let s = t[y]; if (ks(e, s, t, n, o)) {
    me(e) && gm(t, e.index);
    return;
} e.type & 3 && (n = gN(n)), Ru(e, t, n, o, r, i); }
function Ru(e, t, n, o, r, i) { if (e.type & 3) {
    let s = ne(e, t);
    o = i != null ? i(o, e.value || "", n) : o, r.setProperty(s, n, o);
}
else
    e.type & 12; }
function gm(e, t) { let n = le(t, e); n[b] & 16 || (n[b] |= 64); }
function mN(e, t, n) { let o = n.directiveStart, r = n.directiveEnd; me(n) && oN(t, n, e.data[o + n.componentOffset]), e.firstCreatePass || Oi(n, t); let i = n.initialInputs; for (let s = o; s < r; s++) {
    let a = e.data[s], c = Go(t, e, s, n);
    if (_e(c, t), i !== null && EN(t, s - o, c, a, n, i), ye(a)) {
        let l = le(n.index, t);
        l[P] = Go(t, e, s, n);
    }
} }
function yN(e, t, n) { let o = n.directiveStart, r = n.directiveEnd, i = n.index, s = Wf(); try {
    It(i);
    for (let a = o; a < r; a++) {
        let c = e.data[a], l = t[a];
        nc(a), (c.hostBindings !== null || c.hostVars !== 0 || c.hostAttrs !== null) && vN(c, l);
    }
}
finally {
    It(-1), nc(s);
} }
function vN(e, t) { e.hostBindings !== null && e.hostBindings(1, t); }
function ku(e, t) { let n = e.directiveRegistry, o = null; if (n)
    for (let r = 0; r < n.length; r++) {
        let i = n[r];
        Zg(t, i.selectors, !1) && (o ??= [], ye(i) ? o.unshift(i) : o.push(i));
    } return o; }
function IN(e, t, n, o, r, i) { let s = ne(e, t); Ss(t[C], s, i, e.value, n, o, r); }
function Ss(e, t, n, o, r, i, s) { if (i == null)
    e.removeAttribute(t, r, n);
else {
    let a = s == null ? M(i) : s(i, o || "", r);
    e.setAttribute(t, r, a, n);
} }
function EN(e, t, n, o, r, i) { let s = i[t]; if (s !== null)
    for (let a = 0; a < s.length; a += 2) {
        let c = s[a], l = s[a + 1];
        zo(o, n, c, l);
    } }
function As(e, t, n, o, r) { let i = I + n, s = t[y], a = r(s, t, e, o, n); t[i] = a, He(e, !0); let c = e.type === 2; return c ? (Xg(t[C], a, e), (Vf() === 0 || un(e)) && _e(a, t), Hf()) : _e(a, t), wo() && (!c || !Zn(e)) && bu(s, t, a, e), e; }
function Rs(e) { let t = e; return Qa() ? Za() : (t = t.parent, He(t, !1)), t; }
function mm(e, t, n) { return (e === null || ye(e)) && (n = Do(n[t.index])), n[C]; }
function xu(e, t) { let n = e[V]; if (!n)
    return; n.get(Et, null)?.(t); }
function ks(e, t, n, o, r) { let i = e.inputs?.[o], s = e.hostDirectiveInputs?.[o], a = !1; if (s)
    for (let c = 0; c < s.length; c += 2) {
        let l = s[c], u = s[c + 1], d = t.data[l];
        zo(d, n[l], u, r), a = !0;
    } if (i)
    for (let c of i) {
        let l = n[c], u = t.data[c];
        zo(u, l, o, r), a = !0;
    } return a; }
function DN(e, t, n, o, r, i) { let s = null, a = null, c = null, l = !1, u = e.directiveToIndex.get(o.type); if (typeof u == "number" ? s = u : [s, a, c] = u, a !== null && c !== null && e.hostDirectiveInputs?.hasOwnProperty(r)) {
    let d = e.hostDirectiveInputs[r];
    for (let f = 0; f < d.length; f += 2) {
        let p = d[f];
        if (p >= a && p <= c) {
            let h = t.data[p], m = d[f + 1];
            zo(h, n[p], m, i), l = !0;
        }
        else if (p > c)
            break;
    }
} return s !== null && o.inputs.hasOwnProperty(r) && (zo(o, n[s], r, i), l = !0), l; }
function CN(e, t) { let n = le(t, e), o = n[y]; TN(o, n); let r = n[F]; r !== null && n[te] === null && (n[te] = yg(r, n[V])), k(18), xs(o, n, n[P]), k(19, n[P]); }
function TN(e, t) { for (let n = t.length; n < e.blueprint.length; n++)
    t.push(e.blueprint[n]); }
function xs(e, t, n) { ri(t); try {
    let o = e.viewQuery;
    o !== null && Jc(1, o, n);
    let r = e.template;
    r !== null && fm(e, t, r, 1, n), e.firstCreatePass && (e.firstCreatePass = !1), t[je]?.finishViewCreation(e), e.staticContentQueries && bg(e, t), e.staticViewQueries && Jc(2, e.viewQuery, n);
    let i = e.components;
    i !== null && MN(t, i);
}
catch (o) {
    throw e.firstCreatePass && (e.incompleteFirstPass = !0, e.firstCreatePass = !1), o;
}
finally {
    t[b] &= -5, ii();
} }
function MN(e, t) { for (let n = 0; n < t.length; n++)
    CN(e, t[n]); }
function Xn(e, t, n, o) { let r = S(null); try {
    let i = t.tView, a = e[b] & 4096 ? 4096 : 16, c = Ns(e, i, n, a, null, t, null, null, o?.injector ?? null, o?.embeddedViewInjector ?? null, o?.dehydratedView ?? null), l = e[t.index];
    c[gt] = l;
    let u = e[je];
    return u !== null && (c[je] = u.createEmbeddedView(i)), xs(i, c, n), c;
}
finally {
    S(r);
} }
function zt(e, t) { return !t || t.firstChild === null || Wo(e); }
var _p = !1, NN = new _("");
function Rn(e, t, n, o, r = !1) { for (; n !== null;) {
    if (n.type === 128) {
        n = r ? n.projectionNext : n.next;
        continue;
    }
    let i = t[n.index];
    i !== null && o.push(R(i)), K(i) && Os(i, o);
    let s = n.type;
    if (s & 8)
        Rn(e, t, n.child, o);
    else if (s & 32) {
        let a = Nu(n, t), c;
        for (; c = a();)
            o.push(c);
    }
    else if (s & 16) {
        let a = um(t, n);
        if (Array.isArray(a))
            o.push(...a);
        else {
            let c = jt(t[Q]);
            Rn(c[y], c, a, o, !0);
        }
    }
    n = r ? n.projectionNext : n.next;
} return o; }
function Os(e, t) { for (let n = G; n < e.length; n++) {
    let o = e[n], r = o[y].firstChild;
    r !== null && Rn(o[y], o, r, t);
} e[Re] !== e[F] && t.push(e[Re]); }
function ym(e) { if (e[Pt] !== null) {
    for (let t of e[Pt])
        t.impl.addSequence(t);
    e[Pt].length = 0;
} }
var vm = [];
function wN(e) { return e[we] ?? _N(e); }
function _N(e) { let t = vm.pop() ?? Object.create(SN); return t.lView = e, t; }
function bN(e) { e.lView[we] !== e && (e.lView = null, vm.push(e)); }
var SN = Le(W({}, Ea), { consumerIsAlwaysLive: !0, kind: "template", consumerMarkedDirty: e => { Jr(e.lView); }, consumerOnSignalRead() { this.lView[we] = this; } });
function AN(e) { let t = e[we] ?? Object.create(RN); return t.lView = e, t; }
var RN = Le(W({}, Ea), { consumerIsAlwaysLive: !0, kind: "template", consumerMarkedDirty: e => { let t = jt(e.lView); for (; t && !Im(t[y]);)
        t = jt(t); t && Yr(t); }, consumerOnSignalRead() { this.lView[we] = this; } });
function Im(e) { return e.type !== 2; }
function Em(e) { if (e[Io] === null)
    return; let t = !0; for (; t;) {
    let n = !1;
    for (let o of e[Io])
        o.dirty && (n = !0, o.zone === null || Zone.current === o.zone ? o.run() : o.zone.run(() => o.run()));
    t = n && !!(e[b] & 8192);
} }
var kN = 100;
function Ou(e, t = 0) { let o = e[ze].rendererFactory, r = !1; r || o.begin?.(); try {
    xN(e, t);
}
finally {
    r || o.end?.();
} }
function xN(e, t) { let n = Ja(); try {
    Xa(!0), fl(e, t);
    let o = 0;
    for (; To(e);) {
        if (o === kN)
            throw new w(103, !1);
        o++, fl(e, 1);
    }
}
finally {
    Xa(n);
} }
function Dm(e, t) { Ka(t ? ei.Exhaustive : ei.OnlyDirtyViews); try {
    Ou(e);
}
finally {
    Ka(ei.Off);
} }
function Cm(e, t, n, o) { if (mt(t))
    return; let r = t[b], i = !1, s = !1; ri(t); let a = !0, c = null, l = null; i || (Im(e) ? (l = wN(t), c = lo(l)) : mf() === null ? (a = !1, l = AN(t), c = lo(l)) : t[we] && (uo(t[we]), t[we] = null)); try {
    ja(t), ec(e.bindingStartIndex), n !== null && fm(e, t, n, 2, o);
    let u = (r & 3) === 3;
    if (!i)
        if (u) {
            let p = e.preOrderCheckHooks;
            p !== null && Ii(t, p, null);
        }
        else {
            let p = e.preOrderHooks;
            p !== null && Ei(t, p, 0, null), vc(t, 0);
        }
    if (s || ON(t), Em(t), Tm(t, 0), e.contentQueries !== null && bg(e, t), !i)
        if (u) {
            let p = e.contentCheckHooks;
            p !== null && Ii(t, p);
        }
        else {
            let p = e.contentHooks;
            p !== null && Ei(t, p, 1), vc(t, 1);
        }
    LN(e, t);
    let d = e.components;
    d !== null && Nm(t, d, 0);
    let f = e.viewQuery;
    if (f !== null && Jc(2, f, o), !i)
        if (u) {
            let p = e.viewCheckHooks;
            p !== null && Ii(t, p);
        }
        else {
            let p = e.viewHooks;
            p !== null && Ei(t, p, 2), vc(t, 2);
        }
    if (e.firstUpdatePass === !0 && (e.firstUpdatePass = !1), t[Zr]) {
        for (let p of t[Zr])
            p();
        t[Zr] = null;
    }
    i || (ym(t), t[b] &= -73);
}
catch (u) {
    throw i || Jr(t), u;
}
finally {
    l !== null && (xr(l, c), a && bN(l)), ii();
} }
function Tm(e, t) { for (let n = Qh(e); n !== null; n = Zh(n))
    for (let o = G; o < n.length; o++) {
        let r = n[o];
        Mm(r, t);
    } }
function ON(e) { for (let t = Qh(e); t !== null; t = Zh(t)) {
    if (!(t[b] & 2))
        continue;
    let n = t[Lt];
    for (let o = 0; o < n.length; o++) {
        let r = n[o];
        Yr(r);
    }
} }
function PN(e, t, n) { k(18); let o = le(t, e); Mm(o, n), k(19, o[P]); }
function Mm(e, t) { Of(e) && fl(e, t); }
function fl(e, t) { let o = e[y], r = e[b], i = e[we], s = !!(t === 0 && r & 16); if (s ||= !!(r & 64 && t === 0), s ||= !!(r & 1024), s ||= !!(i?.dirty && Or(i)), s ||= !1, i && (i.dirty = !1), e[b] &= -9217, s)
    Cm(o, e, o.template, e[P]);
else if (r & 8192) {
    let a = S(null);
    try {
        Em(e), Tm(e, 1);
        let c = o.components;
        c !== null && Nm(e, c, 1), ym(e);
    }
    finally {
        S(a);
    }
} }
function Nm(e, t, n) { for (let o = 0; o < t.length; o++)
    PN(e, t[o], n); }
function LN(e, t) { let n = e.hostBindingOpCodes; if (n !== null)
    try {
        for (let o = 0; o < n.length; o++) {
            let r = n[o];
            if (r < 0)
                It(~r);
            else {
                let i = r, s = n[++o], a = n[++o];
                Gf(s, i);
                let c = t[i];
                k(24, c), a(2, c), k(25, c);
            }
        }
    }
    finally {
        It(-1);
    } }
function vr(e, t) { let n = Ja() ? 64 : 1088; for (e[ze].changeDetectionScheduler?.notify(t); e;) {
    e[b] |= n;
    let o = jt(e);
    if (Ve(e) && !o)
        return e;
    e = o;
} return null; }
function wm(e, t, n, o) { return [e, !0, 0, t, null, o, null, n, null, null]; }
function _m(e, t) { let n = G + t; if (n < e.length)
    return e[n]; }
function eo(e, t, n, o = !0) { let r = t[y]; if (FN(r, t, e, n), o) {
    let s = dl(n, e), a = t[C], c = a.parentNode(e[Re]);
    c !== null && iN(r, e[se], a, t, c, s);
} let i = t[te]; i !== null && i.firstChild !== null && (i.firstChild = null); }
function Pu(e, t) { let n = Qo(e, t); return n !== void 0 && yr(n[y], n), n; }
function Qo(e, t) { if (e.length <= G)
    return; let n = G + t, o = e[n]; if (o) {
    let r = o[gt];
    r !== null && r !== e && wu(r, o), t > 0 && (e[n - 1][ie] = o[ie]);
    let i = po(e, G + t);
    om(o[y], o);
    let s = i[je];
    s !== null && s.detachView(i[y]), o[q] = null, o[ie] = null, o[b] &= -129;
} return o; }
function FN(e, t, n, o) { let r = G + o, i = n.length; o > 0 && (n[r - 1][ie] = t), o < i - G ? (t[ie] = n[r], Sa(n, G + o, t)) : (n.push(t), t[ie] = null), t[q] = n; let s = t[gt]; s !== null && n !== s && bm(s, t); let a = t[je]; a !== null && a.insertView(e), Kr(t), t[b] |= 128; }
function bm(e, t) { let n = e[Lt], o = t[q]; if (Y(o))
    e[b] |= 2;
else {
    let r = o[q][Q];
    t[Q] !== r && (e[b] |= 2);
} n === null ? e[Lt] = [t] : n.push(t); }
var wt = class {
    _lView;
    _cdRefInjectingView;
    _appRef = null;
    _attachedToViewContainer = !1;
    exhaustive;
    get rootNodes() { let t = this._lView, n = t[y]; return Rn(n, t, n.firstChild, []); }
    constructor(t, n) { this._lView = t, this._cdRefInjectingView = n; }
    get context() { return this._lView[P]; }
    set context(t) { this._lView[P] = t; }
    get destroyed() { return mt(this._lView); }
    destroy() { if (this._appRef)
        this._appRef.detachView(this);
    else if (this._attachedToViewContainer) {
        let t = this._lView[q];
        if (K(t)) {
            let n = t[Eo], o = n ? n.indexOf(this) : -1;
            o > -1 && (Qo(t, o), po(n, o));
        }
        this._attachedToViewContainer = !1;
    } yr(this._lView[y], this._lView); }
    onDestroy(t) { Xr(this._lView, t); }
    markForCheck() { vr(this._cdRefInjectingView || this._lView, 4); }
    detach() { this._lView[b] &= -129; }
    reattach() { Kr(this._lView), this._lView[b] |= 128; }
    detectChanges() { this._lView[b] |= 1024, Ou(this._lView); }
    checkNoChanges() { }
    attachToViewContainerRef() { if (this._appRef)
        throw new w(902, !1); this._attachedToViewContainer = !0; }
    detachFromAppRef() { this._appRef = null; let t = Ve(this._lView), n = this._lView[gt]; n !== null && !t && wu(n, this._lView), rm(this._lView[y], this._lView); }
    attachToAppRef(t) { if (this._attachedToViewContainer)
        throw new w(902, !1); this._appRef = t; let n = Ve(this._lView), o = this._lView[gt]; o !== null && !n && bm(o, this._lView), Kr(this._lView); }
};
function jN(e) { return To(e._lView) || !!(e._lView[b] & 64); }
function VN(e) { Yr(e._lView); }
var Zo = (() => { class e {
    _declarationLView;
    _declarationTContainer;
    elementRef;
    static __NG_ELEMENT_ID__ = HN;
    constructor(n, o, r) { this._declarationLView = n, this._declarationTContainer = o, this.elementRef = r; }
    get ssrId() { return this._declarationTContainer.tView?.ssrId || null; }
    createEmbeddedView(n, o) { return this.createEmbeddedViewImpl(n, o); }
    createEmbeddedViewImpl(n, o, r) { let i = Xn(this._declarationLView, this._declarationTContainer, n, { embeddedViewInjector: o, dehydratedView: r }); return new wt(i); }
} return e; })();
function HN() { return Ps(T(), g()); }
function Ps(e, t) { return e.type & 4 ? new Zo(t, e, Un(e, t)) : null; }
var pl = "<-- AT THIS LOCATION";
function BN(e) { switch (e) {
    case 4: return "view container";
    case 2: return "element";
    case 8: return "ng-container";
    case 32: return "icu";
    case 64: return "i18n";
    case 16: return "projection";
    case 1: return "text";
    case 128: return "@let";
    default: return "<unknown>";
} }
function $N(e, t) {
    let n = `During serialization, Angular was unable to find an element in the DOM:

`, o = `${qN(e, t, !1)}

`, r = QN();
    throw new w(-502, n + o + r);
}
function Sm(e) {
    let t = "During serialization, Angular detected DOM nodes that were created outside of Angular context and provided as projectable nodes (likely via `ViewContainerRef.createComponent` or `createComponent` APIs). Hydration is not supported for such cases, consider refactoring the code to avoid this pattern or using `ngSkipHydration` on the host element of the component.\n\n", n = `${zN(e)}

`, o = t + n + ZN();
    return new w(-503, o);
}
function UN(e) { let t = []; if (e.attrs)
    for (let n = 0; n < e.attrs.length;) {
        let o = e.attrs[n++];
        if (typeof o == "number")
            break;
        let r = e.attrs[n++];
        t.push(`${o}="${Bi(r)}"`);
    } return t.join(" "); }
var GN = new Set(["ngh", "ng-version", "ng-server-context"]);
function WN(e) { let t = []; for (let n = 0; n < e.attributes.length; n++) {
    let o = e.attributes[n];
    GN.has(o.name) || t.push(`${o.name}="${Bi(o.value)}"`);
} return t.join(" "); }
function wc(e, t = "\u2026") { switch (e.type) {
    case 1: return `#text${e.value ? `(${e.value})` : ""}`;
    case 2:
        let o = UN(e), r = e.value.toLowerCase();
        return `<${r}${o ? " " + o : ""}>${t}</${r}>`;
    case 8: return "<!-- ng-container -->";
    case 4: return "<!-- container -->";
    default: return `#node(${BN(e.type)})`;
} }
function Ti(e, t = "\u2026") { let n = e; switch (n.nodeType) {
    case Node.ELEMENT_NODE:
        let o = n.tagName.toLowerCase(), r = WN(n);
        return `<${o}${r ? " " + r : ""}>${t}</${o}>`;
    case Node.TEXT_NODE:
        let i = n.textContent ? Bi(n.textContent) : "";
        return `#text${i ? `(${i})` : ""}`;
    case Node.COMMENT_NODE: return `<!-- ${Bi(n.textContent ?? "")} -->`;
    default: return `#node(${n.nodeType})`;
} }
function qN(e, t, n) {
    let r = "";
    t.prev ? (r += `  \u2026
`, r += "  " + wc(t.prev) + `
`) : t.type && t.type & 12 && (r += `  \u2026
`), n ? (r += "  " + wc(t) + `
`, r += `  <!-- container -->  ${pl}
`) : r += "  " + wc(t) + `  ${pl}
`, r += `  \u2026
`;
    let i = t.type ? _u(e[y], t, e) : null;
    return i && (r = Ti(i, `
` + r)), r;
}
function zN(e) {
    let n = "", o = e;
    return o.previousSibling && (n += `  \u2026
`, n += "  " + Ti(o.previousSibling) + `
`), n += "  " + Ti(o) + `  ${pl}
`, e.nextSibling && (n += `  \u2026
`), e.parentNode && (n = Ti(o.parentNode, `
` + n)), n;
}
function QN(e) {
    return `To fix this problem:
  * check ${e ? `the "${e}"` : "corresponding"} component for hydration-related issues
  * check to see if your template has valid HTML structure
  * or skip hydration by adding the \`ngSkipHydration\` attribute to its host node in a template

`;
}
function ZN() {
    return `Note: attributes are only displayed to better represent the DOM but have no effect on hydration mismatches.

`;
}
function YN(e) { return e.replace(/\s+/gm, ""); }
function Bi(e, t = 50) { return e ? (e = YN(e), e.length > t ? `${e.substring(0, t - 1)}\u2026` : e) : ""; }
function Am(e, t, n) { let o = t.insertBeforeIndex, r = Array.isArray(o) ? o[0] : o; return r === null ? am(e, t, n) : R(n[r]); }
function Rm(e, t, n, o, r) { let i = t.insertBeforeIndex; if (Array.isArray(i)) {
    let s = o, a = null;
    if (t.type & 3 || (a = s, s = r), s !== null && t.componentOffset === -1)
        for (let c = 1; c < i.length; c++) {
            let l = n[i[c]];
            qt(e, s, l, a, !1);
        }
} }
function nn(e, t, n, o, r) { let i = e.data[t]; if (i === null)
    i = Lu(e, t, n, o, r), Uf() && (i.flags |= 32);
else if (i.type & 64) {
    i.type = n, i.value = o, i.attrs = r;
    let s = dn();
    i.injectorIndex = s === null ? -1 : s.injectorIndex;
} return He(i, !0), i; }
function Lu(e, t, n, o, r) { let i = $f(), s = Qa(), a = s ? i : i && i.parent, c = e.data[t] = JN(e, a, n, t, o, r); return KN(e, c, i, s), c; }
function KN(e, t, n, o) { e.firstChild === null && (e.firstChild = t), n !== null && (o ? n.child == null && t.parent !== null && (n.child = t) : n.next === null && (n.next = t, t.prev = n)); }
function JN(e, t, n, o, r, i) { let s = t ? t.injectorIndex : -1, a = 0; return Mo() && (a |= 128), { type: n, index: o, insertBeforeIndex: null, injectorIndex: s, directiveStart: -1, directiveEnd: -1, directiveStylingLast: -1, componentOffset: -1, propertyBindings: null, flags: a, providerIndexes: 0, value: r, attrs: i, mergedAttrs: null, localNames: null, initialInputs: null, inputs: null, hostDirectiveInputs: null, outputs: null, hostDirectiveOutputs: null, directiveToIndex: null, tView: null, next: null, prev: null, projectionNext: null, child: null, parent: t, projection: null, styles: null, stylesWithoutHost: null, residualStyles: void 0, classes: null, classesWithoutHost: null, residualClasses: void 0, classBindings: 0, styleBindings: 0 }; }
function km(e, t) { if (e.push(t), e.length > 1)
    for (let n = e.length - 2; n >= 0; n--) {
        let o = e[n];
        xm(o) || XN(o, t) && ew(o) === null && tw(o, t.index);
    } }
function xm(e) { return !(e.type & 64); }
function XN(e, t) { return xm(t) || e.index > t.index; }
function ew(e) { let t = e.insertBeforeIndex; return Array.isArray(t) ? t[0] : t; }
function tw(e, t) { let n = e.insertBeforeIndex; Array.isArray(n) ? n[0] = t : (lm(Am, Rm), e.insertBeforeIndex = t); }
function Ro(e, t) { let n = e.data[t]; return n === null || typeof n == "string" ? null : n.hasOwnProperty("currentCaseLViewIndex") ? n : n.value; }
function nw(e, t, n) { let o = e.data[t]; o === null ? e.data[t] = n : o.value = n; }
function ow(e, t) { let n = e.insertBeforeIndex; n === null ? (lm(Am, Rm), n = e.insertBeforeIndex = [null, t]) : (Df(Array.isArray(n), !0, "Expecting array here"), n.push(t)); }
function rw(e, t, n) { let o = Lu(e, n, 64, null, null); return km(t, o), o; }
function Ls(e, t) { let n = t[e.currentCaseLViewIndex]; return n === null ? n : n < 0 ? ~n : n; }
function iw(e) { return e >>> 17; }
function sw(e) { return (e & 131070) >>> 1; }
function aw(e, t, n) { return e | t << 17 | n << 1; }
function Om(e) { return e === -1; }
function Fu(e, t, n) { e.index = 0; let o = Ls(t, n); o !== null ? e.removes = t.remove[o] : e.removes = O; }
function $i(e) { if (e.index < e.removes.length) {
    let t = e.removes[e.index++];
    if (t > 0)
        return e.lView[t];
    {
        e.stack.push(e.index, e.removes);
        let n = ~t, o = e.lView[y].data[n];
        return Fu(e, o, e.lView), $i(e);
    }
}
else
    return e.stack.length === 0 ? null : (e.removes = e.stack.pop(), e.index = e.stack.pop(), $i(e)); }
function cw() { let e = { stack: [], index: -1 }; function t(n, o) { for (e.lView = o; e.stack.length;)
    e.stack.pop(); return Fu(e, n.value, o), $i.bind(null, e); } return t; }
function lw(e, t) { let n = { stack: [], index: -1, lView: t }; return Fu(n, e, t), $i.bind(null, n); }
var uw = new RegExp(`^(\\d+)*(${Xl}|${Jl})*(.*)`);
function dw(e, t) { let n = [e]; for (let o of t) {
    let r = n.length - 1;
    if (r > 0 && n[r - 1] === o) {
        let i = n[r] || 1;
        n[r] = i + 1;
    }
    else
        n.push(o, "");
} return n.join(""); }
function fw(e) { let t = e.match(uw), [n, o, r, i] = t, s = o ? parseInt(o, 10) : r, a = []; for (let [c, l, u] of i.matchAll(/(f|n)(\d*)/g)) {
    let d = parseInt(u, 10) || 1;
    a.push(l, d);
} return [s, ...a]; }
function pw(e) { return !e.prev && e.parent?.type === 8; }
function _c(e) { return e.index - I; }
function to(e, t) { return !(e.type & 144) && !!t[e.index] && Pm(R(t[e.index])); }
function Pm(e) { return !!e && !e.isConnected; }
function Lm(e, t) { let n = e.i18nNodes; if (n)
    return n.get(t); }
function hw(e, t, n) { let r = e.data[ur]?.[n]; return r ? Fm(r, t) : null; }
function Ir(e, t, n, o) { let r = _c(o), i = Lm(e, r); if (i === void 0) {
    let s = e.data[ur];
    if (s?.[r])
        i = Fm(s[r], n);
    else if (t.firstChild === o)
        i = e.firstChild;
    else {
        let a = o.prev === null, c = o.prev ?? o.parent;
        if (pw(o)) {
            let l = _c(o.parent);
            i = Kc(e, l);
        }
        else {
            let l = ne(c, n);
            if (a)
                i = l.firstChild;
            else {
                let u = _c(c), d = Kc(e, u);
                if (c.type === 2 && d) {
                    let p = du(e, u) + 1;
                    i = Fs(p, d);
                }
                else
                    i = l.nextSibling;
            }
        }
    }
} return i; }
function Fs(e, t) { let n = t; for (let o = 0; o < e; o++)
    n = n.nextSibling; return n; }
function gw(e, t) { let n = e; for (let o = 0; o < t.length; o += 2) {
    let r = t[o], i = t[o + 1];
    for (let s = 0; s < i; s++)
        switch (r) {
            case ng:
                n = n.firstChild;
                break;
            case og:
                n = n.nextSibling;
                break;
        }
} return n; }
function Fm(e, t) { let [n, ...o] = fw(e), r; if (n === Jl)
    r = t[Q][F];
else if (n === Xl)
    r = vu(t[Q][F]);
else {
    let i = Number(n);
    r = R(t[i + I]);
} return gw(r, o); }
function hl(e, t) { if (e === t)
    return []; if (e.parentElement == null || t.parentElement == null)
    return null; if (e.parentElement === t.parentElement)
    return mw(e, t); {
    let n = t.parentElement, o = hl(e, n), r = hl(n.firstChild, t);
    return !o || !r ? null : [...o, ng, ...r];
} }
function mw(e, t) { let n = [], o = null; for (o = e; o != null && o !== t; o = o.nextSibling)
    n.push(og); return o == null ? null : n; }
function bp(e, t, n) { let o = hl(e, t); return o === null ? null : dw(n, o); }
function jm(e, t, n) { let o = e.parent, r, i, s; for (; o !== null && (to(o, t) || n?.has(o.index));)
    o = o.parent; o === null || !(o.type & 3) ? (r = s = Jl, i = t[Q][F]) : (r = o.index, i = R(t[r]), s = M(r - I)); let a = R(t[e.index]); if (e.type & 44) {
    let l = Ut(t, e);
    l && (a = l);
} let c = bp(i, a, s); if (c === null && i !== a) {
    let l = i.ownerDocument.body;
    if (c = bp(l, a, Xl), c === null)
        throw $N(t, e);
} return c; }
function Vm(e, t) { let n = e.createNodeIterator(t, NodeFilter.SHOW_COMMENT, { acceptNode: yw }), o, r = new Map; for (; o = n.nextNode();) {
    let i = "ngh=", s = o?.textContent, a = s?.indexOf(i) ?? -1;
    if (a > -1) {
        let c = s.substring(a + i.length).trim();
        r.set(c, o);
    }
} return r; }
function yw(e) { return e.textContent?.trimStart().startsWith("ngh=") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; }
var Hm = !1, Bm = () => { };
function ju(e) { Hm = e; }
function js() { return Hm; }
function vw(e, t, n, o) { Bm(e, t, n, o); }
function $m() { Bm = Tw; }
function Um(e) { return e = e ?? D(Te), e.get(nu, !1); }
function Gm(e, t) { let n = t.i18nChildren.get(e); return n === void 0 && (n = Iw(e), t.i18nChildren.set(e, n)), n; }
function Iw(e) { let t = new Set; function n(o) { switch (t.add(o.index), o.kind) {
    case 1:
    case 2: {
        for (let r of o.children)
            n(r);
        break;
    }
    case 3: {
        for (let r of o.cases)
            for (let i of r)
                n(i);
        break;
    }
} } for (let o = I; o < e.bindingStartIndex; o++) {
    let r = e.data[o];
    if (!(!r || !r.ast))
        for (let i of r.ast)
            n(i);
} return t.size === 0 ? null : t; }
function Wm(e, t, n) { if (!n.isI18nHydrationEnabled)
    return null; let o = e[y], r = o.data[t]; if (!r || !r.ast)
    return null; let i = o.data[r.parentTNodeIndex]; if (i && Uh(i))
    return null; let s = { caseQueue: [], disconnectedNodes: new Set, disjointNodes: new Set }; return gl(e, s, n, r.ast), s.caseQueue.length === 0 && s.disconnectedNodes.size === 0 && s.disjointNodes.size === 0 ? null : s; }
function gl(e, t, n, o) { let r = null; for (let i of o) {
    let s = Dw(e, t, n, i);
    s && (Ew(r, s) && t.disjointNodes.add(i.index - I), r = s);
} return r; }
function Ew(e, t) { return e && e.nextSibling !== t; }
function Dw(e, t, n, o) { let r = R(e[o.index]); if (!r || Pm(r))
    return t.disconnectedNodes.add(o.index - I), null; let i = r; switch (o.kind) {
    case 0: {
        fu(n, i);
        break;
    }
    case 1:
    case 2: {
        gl(e, t, n, o.children);
        break;
    }
    case 3: {
        let s = e[o.currentCaseLViewIndex];
        if (s != null) {
            let a = s < 0 ? ~s : s;
            t.caseQueue.push(a), gl(e, t, n, o.cases[a]);
        }
        break;
    }
} return Cw(e, o); }
function Cw(e, t) { let o = e[y].data[t.index]; return ss(o) ? Ut(e, o) : t.kind === 3 ? lw(o, e)() ?? R(e[t.index]) : R(e[t.index]) ?? null; }
function Vt(e, t) { e.currentNode = t; }
function bo(e, t, n) { let o = n.index - I, { disconnectedNodes: r } = e, i = t.currentNode; return t.isConnected ? (e.i18nNodes.set(o, i), r.delete(o)) : r.add(o), i; }
function bc(e, t) { let n = e.currentNode; for (let o = 0; o < t && n; o++)
    n = n?.nextSibling ?? null; return n; }
function Sc(e, t) { return { currentNode: t, isConnected: e.isConnected }; }
function Tw(e, t, n, o) { let r = e[te]; if (!r || !js() || n && (Uh(n) || Ds(r, n.index - I)))
    return; let i = e[y], s = i.data[t]; function a() { if (Om(o)) {
    let p = Ir(r, i, e, n);
    return n.type & 8 ? p : p.firstChild;
} return r?.firstChild; } let c = a(), l = Dg(r) ?? new Set, u = r.i18nNodes ??= new Map, d = r.data[ps]?.[t - I] ?? [], f = r.dehydratedIcuData ??= new Map; gn({ hydrationInfo: r, lView: e, i18nNodes: u, disconnectedNodes: l, caseQueue: d, dehydratedIcuData: f }, { currentNode: c, isConnected: !0 }, s.ast), r.disconnectedNodes = l.size === 0 ? null : l; }
function gn(e, t, n) { if (Array.isArray(n)) {
    let o = t;
    for (let r of n) {
        let i = hw(e.hydrationInfo, e.lView, r.index - I);
        i && (o = Sc(t, i)), gn(e, o, r);
    }
}
else {
    if (e.disconnectedNodes.has(n.index - I))
        return;
    switch (n.kind) {
        case 0: {
            let o = bo(e, t, n);
            Vt(t, o?.nextSibling ?? null);
            break;
        }
        case 1: {
            gn(e, Sc(t, t.currentNode?.firstChild ?? null), n.children);
            let o = bo(e, t, n);
            Vt(t, o?.nextSibling ?? null);
            break;
        }
        case 2: {
            let o = n.index - I, { hydrationInfo: r } = e, i = Ig(r, o);
            switch (n.type) {
                case 0: {
                    let s = bo(e, t, n);
                    if (tM(r, o)) {
                        gn(e, t, n.children);
                        let a = bc(t, 1);
                        Vt(t, a);
                    }
                    else if (gn(e, Sc(t, t.currentNode?.firstChild ?? null), n.children), Vt(t, s?.nextSibling ?? null), i !== null) {
                        let a = bc(t, i + 1);
                        Vt(t, a);
                    }
                    break;
                }
                case 1: {
                    bo(e, t, n);
                    let s = bc(t, i + 1);
                    Vt(t, s);
                    break;
                }
            }
            break;
        }
        case 3: {
            let o = t.isConnected ? e.caseQueue.shift() : null, r = { currentNode: null, isConnected: !1 };
            for (let s = 0; s < n.cases.length; s++)
                gn(e, s === o ? t : r, n.cases[s]);
            o !== null && e.dehydratedIcuData.set(n.index, { case: o, node: n });
            let i = bo(e, t, n);
            Vt(t, i?.nextSibling ?? null);
            break;
        }
    }
} }
var qm = () => { };
function Mw(e, t, n) { qm(e, t, n); }
function zm() { qm = Nw; }
function Nw(e, t, n) { let o = e[te]?.dehydratedIcuData; o && o.get(t)?.case === n && o.delete(t); }
function ww(e) { let t = e[te]; if (t) {
    let { i18nNodes: n, dehydratedIcuData: o } = t;
    if (n && o) {
        let r = e[C];
        for (let i of o.values())
            _w(r, n, i);
    }
    t.i18nNodes = void 0, t.dehydratedIcuData = void 0;
} }
function _w(e, t, n) { for (let o of n.node.cases[n.case]) {
    let r = t.get(o.index - I);
    r && gr(e, r, !1);
} }
function Vs(e) { let t = e[De] ?? [], o = e[q][C], r = []; for (let i of t)
    i.data[hs] !== void 0 ? r.push(i) : Qm(i, o); e[De] = r; }
function bw(e) { let { lContainer: t } = e, n = t[De]; if (n === null)
    return; let r = t[q][C]; for (let i of n)
    Qm(i, r); }
function Qm(e, t) { let n = 0, o = e.firstChild; if (o) {
    let r = e.data[Je];
    for (; n < r;) {
        let i = o.nextSibling;
        gr(t, o, !1), o = i, n++;
    }
} }
function Hs(e) { Vs(e); let t = e[F]; Y(t) && Ui(t); for (let n = G; n < e.length; n++)
    Ui(e[n]); }
function Ui(e) { ww(e); let t = e[y]; for (let n = I; n < t.bindingStartIndex; n++)
    if (K(e[n])) {
        let o = e[n];
        Hs(o);
    }
    else
        Y(e[n]) && Ui(e[n]); }
function Vu(e) { let t = e._views; for (let n of t) {
    let o = uu(n);
    o !== null && o[F] !== null && (Y(o) ? Ui(o) : Hs(o));
} }
function Sw(e, t, n, o) { e !== null && (n.cleanup(t), Hs(e.lContainer), Vu(o)); }
function Aw(e, t) { let n = []; for (let o of t)
    for (let r = 0; r < (o[lr] ?? 1); r++) {
        let i = { data: o, firstChild: null };
        o[Je] > 0 && (i.firstChild = e, e = Fs(o[Je], e)), n.push(i);
    } return [e, n]; }
var Zm = () => null, Ym = () => null;
function Km() { Zm = Rw, Ym = kw; }
function Rw(e, t) { return Xm(e, t) ? e[De].shift() : (Vs(e), null); }
function Yo(e, t) { return Zm(e, t); }
function kw(e, t, n) { if (t.tView.ssrId === null)
    return null; let o = Yo(e, t.tView.ssrId); return n[y].firstUpdatePass && o === null && xw(n, t), o; }
function Jm(e, t, n) { return Ym(e, t, n); }
function xw(e, t) { let n = t; for (; n;) {
    if (Sp(e, n))
        return;
    if ((n.flags & 256) === 256)
        break;
    n = n.prev;
} for (n = t.next; n && (n.flags & 512) === 512;) {
    if (Sp(e, n))
        return;
    n = n.next;
} }
function Xm(e, t) { let n = e[De]; return !t || n === null || n.length === 0 ? !1 : n[0].data[fs] === t; }
function Sp(e, t) { let n = t.tView?.ssrId; if (n == null)
    return !1; let o = e[t.index]; return K(o) && Xm(o, n) ? (Vs(o), !0) : !1; }
var ey = class {
}, Bs = class {
}, ml = class {
    resolveComponentFactory(t) { throw new w(917, !1); }
}, Er = class {
    static NULL = new ml;
}, Ko = class {
}, Ow = (() => { class e {
    destroyNode = null;
    static __NG_ELEMENT_ID__ = () => Pw();
} return e; })();
function Pw() { let e = g(), t = T(), n = le(t.index, e); return (Y(n) ? n : e)[C]; }
var ty = (() => { class e {
    static \u0275prov = j({ token: e, providedIn: "root", factory: () => null });
} return e; })();
function Hu(e) { return e.ngModule !== void 0; }
function Bt(e) { return !!an(e); }
function gi(e) { return !!Fe(e); }
function Ap(e) { return !!Ne(e); }
function ko(e) { return !!U(e); }
function Lw(e) { return U(e) ? "component" : Ne(e) ? "directive" : Fe(e) ? "pipe" : "type"; }
function Fw(e, t) { if (Fr(e) && (e = $(e), !e))
    throw new Error(`Expected forwardRef function, imported from "${Ee(t)}", to return a standalone entity or NgModule but got "${Ee(e) || e}".`); if (an(e) == null) {
    let n = U(e) || Ne(e) || Fe(e);
    if (n != null) {
        if (!n.standalone)
            throw new Error(`The "${Ee(e)}" ${Lw(e)}, imported from "${Ee(t)}", is not standalone. Did you forget to add the standalone: true flag?`);
    }
    else
        throw Hu(e) ? new Error(`A module with providers was imported from "${Ee(t)}". Modules with providers are not supported in standalone components imports.`) : new Error(`The "${Ee(e)}" type, imported from "${Ee(t)}", must be a standalone component / directive / pipe or an NgModule. Did you forget to add the required @Component / @Directive / @Pipe or @NgModule annotation?`);
} }
var yl = class {
    ownerNgModule = new Map;
    ngModulesWithSomeUnresolvedDecls = new Set;
    ngModulesScopeCache = new Map;
    standaloneComponentsScopeCache = new Map;
    resolveNgModulesDecls() { if (this.ngModulesWithSomeUnresolvedDecls.size !== 0) {
        for (let t of this.ngModulesWithSomeUnresolvedDecls) {
            let n = an(t);
            if (n?.declarations)
                for (let o of En(n.declarations))
                    ko(o) && this.ownerNgModule.set(o, t);
        }
        this.ngModulesWithSomeUnresolvedDecls.clear();
    } }
    getComponentDependencies(t, n) { this.resolveNgModulesDecls(); let o = U(t); if (o === null)
        throw new Error(`Attempting to get component dependencies for a type that is not a component: ${t}`); if (o.standalone) {
        let r = this.getStandaloneComponentScope(t, n);
        return r.compilation.isPoisoned ? { dependencies: [] } : { dependencies: [...r.compilation.directives, ...r.compilation.pipes, ...r.compilation.ngModules] };
    }
    else {
        if (!this.ownerNgModule.has(t))
            return { dependencies: [] };
        let r = this.getNgModuleScope(this.ownerNgModule.get(t));
        return r.compilation.isPoisoned ? { dependencies: [] } : { dependencies: [...r.compilation.directives, ...r.compilation.pipes] };
    } }
    registerNgModule(t, n) { if (!Bt(t))
        throw new Error(`Attempting to register a Type which is not NgModule as NgModule: ${t}`); this.ngModulesWithSomeUnresolvedDecls.add(t); }
    clearScopeCacheFor(t) { this.ngModulesScopeCache.delete(t), this.standaloneComponentsScopeCache.delete(t); }
    getNgModuleScope(t) { if (this.ngModulesScopeCache.has(t))
        return this.ngModulesScopeCache.get(t); let n = this.computeNgModuleScope(t); return this.ngModulesScopeCache.set(t, n), n; }
    computeNgModuleScope(t) { let n = Wr(t), o = { exported: { directives: new Set, pipes: new Set }, compilation: { directives: new Set, pipes: new Set } }; for (let r of En(n.imports))
        if (Bt(r)) {
            let i = this.getNgModuleScope(r);
            Ct(i.exported.directives, o.compilation.directives), Ct(i.exported.pipes, o.compilation.pipes);
        }
        else if (mo(r))
            if (Ap(r) || ko(r))
                o.compilation.directives.add(r);
            else if (gi(r))
                o.compilation.pipes.add(r);
            else
                throw new w(980, "The standalone imported type is neither a component nor a directive nor a pipe");
        else {
            o.compilation.isPoisoned = !0;
            break;
        } if (!o.compilation.isPoisoned)
        for (let r of En(n.declarations)) {
            if (Bt(r) || mo(r)) {
                o.compilation.isPoisoned = !0;
                break;
            }
            gi(r) ? o.compilation.pipes.add(r) : o.compilation.directives.add(r);
        } for (let r of En(n.exports))
        if (Bt(r)) {
            let i = this.getNgModuleScope(r);
            Ct(i.exported.directives, o.exported.directives), Ct(i.exported.pipes, o.exported.pipes), Ct(i.exported.directives, o.compilation.directives), Ct(i.exported.pipes, o.compilation.pipes);
        }
        else
            gi(r) ? o.exported.pipes.add(r) : o.exported.directives.add(r); return o; }
    getStandaloneComponentScope(t, n) { if (this.standaloneComponentsScopeCache.has(t))
        return this.standaloneComponentsScopeCache.get(t); let o = this.computeStandaloneComponentScope(t, n); return this.standaloneComponentsScopeCache.set(t, o), o; }
    computeStandaloneComponentScope(t, n) { let o = { compilation: { directives: new Set([t]), pipes: new Set, ngModules: new Set } }; for (let r of Ae(n ?? [])) {
        let i = $(r);
        try {
            Fw(i, t);
        }
        catch {
            return o.compilation.isPoisoned = !0, o;
        }
        if (Bt(i)) {
            o.compilation.ngModules.add(i);
            let s = this.getNgModuleScope(i);
            if (s.exported.isPoisoned)
                return o.compilation.isPoisoned = !0, o;
            Ct(s.exported.directives, o.compilation.directives), Ct(s.exported.pipes, o.compilation.pipes);
        }
        else if (gi(i))
            o.compilation.pipes.add(i);
        else if (Ap(i) || ko(i))
            o.compilation.directives.add(i);
        else
            return o.compilation.isPoisoned = !0, o;
    } return o; }
    isOrphanComponent(t) { let n = U(t); return !n || n.standalone ? !1 : (this.resolveNgModulesDecls(), !this.ownerNgModule.has(t)); }
};
function Ct(e, t) { for (let n of e)
    t.add(n); }
var kn = new yl, Mi = {}, Nn = class {
    injector;
    parentInjector;
    constructor(t, n) { this.injector = t, this.parentInjector = n; }
    get(t, n, o) { let r = this.injector.get(t, Mi, o); return r !== Mi || n === Mi ? r : this.parentInjector.get(t, n, o); }
};
function Gi(e, t, n) { let o = n ? e.styles : null, r = n ? e.classes : null, i = 0; if (t !== null)
    for (let s = 0; s < t.length; s++) {
        let a = t[s];
        if (typeof a == "number")
            i = a;
        else if (i == 1)
            r = Lr(r, a);
        else if (i == 2) {
            let c = a, l = t[++s];
            o = Lr(o, c + ": " + l + ";");
        }
    } n ? e.styles = o : e.stylesWithoutHost = o, n ? e.classes = r : e.classesWithoutHost = r; }
function no(e, t = 0) { let n = g(); if (n === null)
    return Se(e, t); let o = T(); return Ph(o, n, $(e), t); }
function ny() { let e = "invalid"; throw new Error(e); }
function oy(e, t, n, o, r) { let i = o === null ? null : { "": -1 }, s = r(e, n); if (s !== null) {
    let a = s, c = null, l = null;
    for (let u of s)
        if (u.resolveHostDirectives !== null) {
            [a, c, l] = u.resolveHostDirectives(s);
            break;
        }
    Hw(e, t, n, a, i, c, l);
} i !== null && o !== null && jw(n, o, i); }
function jw(e, t, n) { let o = e.localNames = []; for (let r = 0; r < t.length; r += 2) {
    let i = n[t[r + 1]];
    if (i == null)
        throw new w(-301, !1);
    o.push(t[r], i);
} }
function Vw(e, t, n) { t.componentOffset = n, (e.components ??= []).push(t.index); }
function Hw(e, t, n, o, r, i, s) { let a = o.length, c = !1; for (let f = 0; f < a; f++) {
    let p = o[f];
    !c && ye(p) && (c = !0, Vw(e, n, f)), Wc(Oi(n, t), e, p.type);
} qw(n, e.data.length, a); for (let f = 0; f < a; f++) {
    let p = o[f];
    p.providersResolver && p.providersResolver(p);
} let l = !1, u = !1, d = mr(e, t, a, null); a > 0 && (n.directiveToIndex = new Map); for (let f = 0; f < a; f++) {
    let p = o[f];
    if (n.mergedAttrs = An(n.mergedAttrs, p.hostAttrs), $w(e, n, t, d, p), Ww(d, p, r), s !== null && s.has(p)) {
        let [m, v] = s.get(p);
        n.directiveToIndex.set(p.type, [d, m + n.directiveStart, v + n.directiveStart]);
    }
    else
        (i === null || !i.has(p)) && n.directiveToIndex.set(p.type, d);
    p.contentQueries !== null && (n.flags |= 4), (p.hostBindings !== null || p.hostAttrs !== null || p.hostVars !== 0) && (n.flags |= 64);
    let h = p.type.prototype;
    !l && (h.ngOnChanges || h.ngOnInit || h.ngDoCheck) && ((e.preOrderHooks ??= []).push(n.index), l = !0), !u && (h.ngOnChanges || h.ngDoCheck) && ((e.preOrderCheckHooks ??= []).push(n.index), u = !0), d++;
} Bw(e, n, i); }
function Bw(e, t, n) { for (let o = t.directiveStart; o < t.directiveEnd; o++) {
    let r = e.data[o];
    if (n === null || !n.has(r))
        Rp(0, t, r, o), Rp(1, t, r, o), xp(t, o, !1);
    else {
        let i = n.get(r);
        kp(0, t, i, o), kp(1, t, i, o), xp(t, o, !0);
    }
} }
function Rp(e, t, n, o) { let r = e === 0 ? n.inputs : n.outputs; for (let i in r)
    if (r.hasOwnProperty(i)) {
        let s;
        e === 0 ? s = t.inputs ??= {} : s = t.outputs ??= {}, s[i] ??= [], s[i].push(o), ry(t, i);
    } }
function kp(e, t, n, o) { let r = e === 0 ? n.inputs : n.outputs; for (let i in r)
    if (r.hasOwnProperty(i)) {
        let s = r[i], a;
        e === 0 ? a = t.hostDirectiveInputs ??= {} : a = t.hostDirectiveOutputs ??= {}, a[s] ??= [], a[s].push(o, i), ry(t, s);
    } }
function ry(e, t) { t === "class" ? e.flags |= 8 : t === "style" && (e.flags |= 16); }
function xp(e, t, n) { let { attrs: o, inputs: r, hostDirectiveInputs: i } = e; if (o === null || !n && r === null || n && i === null || Iu(e)) {
    e.initialInputs ??= [], e.initialInputs.push(null);
    return;
} let s = null, a = 0; for (; a < o.length;) {
    let c = o[a];
    if (c === 0) {
        a += 4;
        continue;
    }
    else if (c === 5) {
        a += 2;
        continue;
    }
    else if (typeof c == "number")
        break;
    if (!n && r.hasOwnProperty(c)) {
        let l = r[c];
        for (let u of l)
            if (u === t) {
                s ??= [], s.push(c, o[a + 1]);
                break;
            }
    }
    else if (n && i.hasOwnProperty(c)) {
        let l = i[c];
        for (let u = 0; u < l.length; u += 2)
            if (l[u] === t) {
                s ??= [], s.push(l[u + 1], o[a + 1]);
                break;
            }
    }
    a += 2;
} e.initialInputs ??= [], e.initialInputs.push(s); }
function $w(e, t, n, o, r) { e.data[o] = r; let i = r.factory || (r.factory = $r(r.type, !0)), s = new Wt(i, ye(r), no, null); e.blueprint[o] = s, n[o] = s, Uw(e, t, o, mr(e, n, r.hostVars, x), r); }
function Uw(e, t, n, o, r) { let i = r.hostBindings; if (i) {
    let s = e.hostBindingOpCodes;
    s === null && (s = e.hostBindingOpCodes = []);
    let a = ~t.index;
    Gw(s) != a && s.push(a), s.push(n, o, i);
} }
function Gw(e) { let t = e.length; for (; t > 0;) {
    let n = e[--t];
    if (typeof n == "number" && n < 0)
        return n;
} return 0; }
function Ww(e, t, n) { if (n) {
    if (t.exportAs)
        for (let o = 0; o < t.exportAs.length; o++)
            n[t.exportAs[o]] = e;
    ye(t) && (n[""] = e);
} }
function qw(e, t, n) { e.flags |= 1, e.directiveStart = t, e.directiveEnd = t + n, e.providerIndexes = t; }
function Bu(e, t, n, o, r, i, s, a) { let c = t[y], l = c.consts, u = ae(l, s), d = nn(c, e, n, o, u); return i && oy(c, t, d, ae(l, a), r), d.mergedAttrs = An(d.mergedAttrs, d.attrs), d.attrs !== null && Gi(d, d.attrs, !1), d.mergedAttrs !== null && Gi(d, d.mergedAttrs, !0), c.queries !== null && c.queries.elementStart(c, d), d; }
function $u(e, t) { Nh(e, t), La(t) && e.queries.elementEnd(t); }
function iy(e, t, n, o, r, i) { let s = t.consts, a = ae(s, r), c = nn(t, e, n, o, a); if (c.mergedAttrs = An(c.mergedAttrs, c.attrs), i != null) {
    let l = ae(s, i);
    c.localNames = [];
    for (let u = 0; u < l.length; u += 2)
        c.localNames.push(l[u], -1);
} return c.attrs !== null && Gi(c, c.attrs, !1), c.mergedAttrs !== null && Gi(c, c.mergedAttrs, !0), t.queries !== null && t.queries.elementStart(t, c), c; }
function Jo(e) { return $s(e) ? Array.isArray(e) || !(e instanceof Map) && Symbol.iterator in e : !1; }
function zw(e, t, n) { let o = e[Symbol.iterator](), r = t[Symbol.iterator](); for (;;) {
    let i = o.next(), s = r.next();
    if (i.done && s.done)
        return !0;
    if (i.done || s.done || !n(i.value, s.value))
        return !1;
} }
function sy(e, t) { if (Array.isArray(e))
    for (let n = 0; n < e.length; n++)
        t(e[n]);
else {
    let n = e[Symbol.iterator](), o;
    for (; !(o = n.next()).done;)
        t(o.value);
} }
function $s(e) { return e !== null && (typeof e == "function" || typeof e == "object"); }
function ay(e, t) { let n = Jo(e), o = Jo(t); return n && o ? zw(e, t, ay) : !n && (e && (typeof e == "object" || typeof e == "function")) && !o && (t && (typeof t == "object" || typeof t == "function")) ? !0 : Object.is(e, t); }
function We(e, t, n) { return e[t] = n; }
function Dr(e, t) { return e[t]; }
function B(e, t, n) { if (n === x)
    return !1; let o = e[t]; return Object.is(o, n) ? !1 : (e[t] = n, !0); }
function Qt(e, t, n, o) { let r = B(e, t, n); return B(e, t + 1, o) || r; }
function Us(e, t, n, o, r) { let i = Qt(e, t, n, o); return B(e, t + 2, r) || i; }
function be(e, t, n, o, r, i) { let s = Qt(e, t, n, o); return Qt(e, t + 2, r, i) || s; }
function xo(e, t, n) { return function o(r) { let i = me(e) ? le(e.index, t) : t; vr(i, 5); let s = t[P], a = Op(t, s, n, r), c = o.__ngNextListenerFn__; for (; c;)
    a = Op(t, s, c, r) && a, c = c.__ngNextListenerFn__; return a; }; }
function Op(e, t, n, o) { let r = ip(null); try {
    return k(6, t, n), n(o) !== !1;
}
catch (i) {
    return xu(e, i), !1;
}
finally {
    k(7, t, n), ip(r);
} }
function cy(e, t, n, o, r, i, s, a) { let c = un(e), l = !1, u = null; if (!o && c && (u = Qw(t, n, i, e.index)), u !== null) {
    let d = u.__ngLastListenerFn__ || u;
    d.__ngNextListenerFn__ = s, u.__ngLastListenerFn__ = s, l = !0;
}
else {
    let d = ne(e, n), f = o ? o(d) : d;
    QT(n, f, i, a);
    let p = r.listen(f, i, a), h = o ? m => o(R(m[e.index])) : e.index;
    ly(h, t, n, i, a, p, !1);
} return l; }
function Qw(e, t, n, o) { let r = e.cleanup; if (r != null)
    for (let i = 0; i < r.length - 1; i += 2) {
        let s = r[i];
        if (s === n && r[i + 1] === o) {
            let a = t[Ot], c = r[i + 2];
            return a && a.length > c ? a[c] : null;
        }
        typeof s == "string" && (i += 2);
    } return null; }
function ly(e, t, n, o, r, i, s) { let a = t.firstCreatePass ? jf(t) : null, c = Ff(n), l = c.length; c.push(r, i), a && a.push(o, e, l, (l + 1) * (s ? -1 : 1)); }
function Zw(e, t, n, o, r) { let i = xo(e, t, n), s = Yw(e, t, o, r, i); }
function Yw(e, t, n, o, r) { let i = null, s = null, a = null, c = !1, l = e.directiveToIndex.get(n.type); if (typeof l == "number" ? i = l : [i, s, a] = l, s !== null && a !== null && e.hostDirectiveOutputs?.hasOwnProperty(o)) {
    let u = e.hostDirectiveOutputs[o];
    for (let d = 0; d < u.length; d += 2) {
        let f = u[d];
        if (f >= s && f <= a)
            c = !0, Wi(e, t, f, u[d + 1], o, r);
        else if (f > a)
            break;
    }
} return n.outputs.hasOwnProperty(o) && (c = !0, Wi(e, t, i, o, o, r)), c; }
function Wi(e, t, n, o, r, i) { let s = t[n], a = t[y], l = a.data[n].outputs[o], d = s[l].subscribe(i); ly(e.index, a, t, r, i, d, !0); }
var Nt = Symbol("BINDING"), Kw = { kind: "input", requiredVars: 1 }, Jw = { kind: "output", requiredVars: 0 };
function Xw(e, t, n) { let o = g(), r = de(); if (B(o, r, n)) {
    let i = o[y], s = Ce(), a = le(s.index, o);
    vr(a, 1);
    let c = i.directiveRegistry[e], l = DN(s, i, o, c, t, n);
} }
function uy(e, t) { let n = { [Nt]: Kw, update: () => Xw(n.targetIdx, e, t()) }; return n; }
function dy(e, t) { let n = { [Nt]: Jw, create: () => { let o = g(), r = T(), s = o[y].directiveRegistry[n.targetIdx]; Zw(r, o, t, s, e); } }; return n; }
function e_(e, t) { let n = uy(e, t), o = dy(e + "Change", i => t.set(i)); return { [Nt]: { kind: "twoWay", requiredVars: n[Nt].requiredVars + o[Nt].requiredVars }, set targetIdx(i) { n.targetIdx = i, o.targetIdx = i; }, create: o.create, update: n.update }; }
var qi = class extends Er {
    ngModule;
    constructor(t) { super(), this.ngModule = t; }
    resolveComponentFactory(t) { let n = U(t); return new _t(n, this.ngModule); }
};
function t_(e) { return Object.keys(e).map(t => { let [n, o, r] = e[t], i = { propName: n, templateName: t, isSignal: (o & ws.SignalBased) !== 0 }; return r && (i.transform = r), i; }); }
function n_(e) { return Object.keys(e).map(t => ({ propName: e[t], templateName: t })); }
function o_(e, t, n) { let o = t instanceof pt ? t : t?.injector; return o && e.getStandaloneInjector !== null && (o = e.getStandaloneInjector(o) || o), o ? new Nn(n, o) : n; }
function r_(e) { let t = e.get(Ko, null); if (t === null)
    throw new w(407, !1); let n = e.get(ty, null), o = e.get(Qe, null); return { rendererFactory: t, sanitizer: n, changeDetectionScheduler: o, ngReflect: !1 }; }
function i_(e, t) { let n = fy(e); return Ms(t, n, n === "svg" ? Af : n === "math" ? Rf : null); }
function fy(e) { return (e.selectors[0][0] || "div").toLowerCase(); }
var _t = class extends Bs {
    componentDef;
    ngModule;
    selector;
    componentType;
    ngContentSelectors;
    isBoundToModule;
    cachedInputs = null;
    cachedOutputs = null;
    get inputs() { return this.cachedInputs ??= t_(this.componentDef.inputs), this.cachedInputs; }
    get outputs() { return this.cachedOutputs ??= n_(this.componentDef.outputs), this.cachedOutputs; }
    constructor(t, n) { super(), this.componentDef = t, this.ngModule = n, this.componentType = t.type, this.selector = JM(t.selectors), this.ngContentSelectors = t.ngContentSelectors ?? [], this.isBoundToModule = !!n; }
    create(t, n, o, r, i, s) { k(22); let a = S(null); try {
        let c = this.componentDef, l = s_(o, c, s, i), u = o_(c, r || this.ngModule, t), d = r_(u), f = d.rendererFactory.createRenderer(null, c), p = o ? fN(f, o, c.encapsulation, u) : i_(c, f), h = s?.some(Pp) || i?.some(E => typeof E != "function" && E.bindings.some(Pp)), m = Ns(null, l, null, 512 | Tu(c), null, null, d, f, u, null, yg(p, u, !0));
        m[I] = p, ri(m);
        let v = null;
        try {
            let E = Bu(I, m, 2, "#host", () => l.directiveRegistry, !0, 0);
            p && (Xg(f, p, E), _e(p, m)), bs(l, m, E), pu(l, E, m), $u(l, E), n !== void 0 && c_(E, this.ngContentSelectors, n), v = le(E.index, m), m[P] = v[P], xs(l, m, null);
        }
        catch (E) {
            throw v !== null && zc(v), zc(m), E;
        }
        finally {
            k(23), ii();
        }
        return new zi(this.componentType, m, !!h);
    }
    finally {
        S(a);
    } }
};
function s_(e, t, n, o) { let r = e ? ["ng-version", "20.2.1"] : XM(t.selectors[0]), i = null, s = null, a = 0; if (n)
    for (let u of n)
        a += u[Nt].requiredVars, u.create && (u.targetIdx = 0, (i ??= []).push(u)), u.update && (u.targetIdx = 0, (s ??= []).push(u)); if (o)
    for (let u = 0; u < o.length; u++) {
        let d = o[u];
        if (typeof d != "function")
            for (let f of d.bindings) {
                a += f[Nt].requiredVars;
                let p = u + 1;
                f.create && (f.targetIdx = p, (i ??= []).push(f)), f.update && (f.targetIdx = p, (s ??= []).push(f));
            }
    } let c = [t]; if (o)
    for (let u of o) {
        let d = typeof u == "function" ? u : u.type, f = Ne(d);
        c.push(f);
    } return Cu(0, null, a_(i, s), 1, a, c, null, null, null, [r], null); }
function a_(e, t) { return !e && !t ? null : n => { if (n & 1 && e)
    for (let o of e)
        o.create(); if (n & 2 && t)
    for (let o of t)
        o.update(); }; }
function Pp(e) { let t = e[Nt].kind; return t === "input" || t === "twoWay"; }
var zi = class extends ey {
    _rootLView;
    _hasInputBindings;
    instance;
    hostView;
    changeDetectorRef;
    componentType;
    location;
    previousInputValues = null;
    _tNode;
    constructor(t, n, o) { super(), this._rootLView = n, this._hasInputBindings = o, this._tNode = yt(n[y], I), this.location = Un(this._tNode, n), this.instance = le(this._tNode.index, n)[P], this.hostView = this.changeDetectorRef = new wt(n, void 0), this.componentType = t; }
    setInput(t, n) { this._hasInputBindings; let o = this._tNode; if (this.previousInputValues ??= new Map, this.previousInputValues.has(t) && Object.is(this.previousInputValues.get(t), n))
        return; let r = this._rootLView, i = ks(o, r[y], r, t, n); this.previousInputValues.set(t, n); let s = le(o.index, r); vr(s, 1); }
    get injector() { return new Mt(this._tNode, this._rootLView); }
    destroy() { this.hostView.destroy(); }
    onDestroy(t) { this.hostView.onDestroy(t); }
};
function c_(e, t, n) { let o = e.projection = []; for (let r = 0; r < t.length; r++) {
    let i = n[r];
    o.push(i != null && i.length ? Array.from(i) : null);
} }
var Gs = (() => { class e {
    static __NG_ELEMENT_ID__ = l_;
} return e; })();
function l_() { let e = T(); return hy(e, g()); }
var u_ = Gs, py = class extends u_ {
    _lContainer;
    _hostTNode;
    _hostLView;
    constructor(t, n, o) { super(), this._lContainer = t, this._hostTNode = n, this._hostLView = o; }
    get element() { return Un(this._hostTNode, this._hostLView); }
    get injector() { return new Mt(this._hostTNode, this._hostLView); }
    get parentInjector() { let t = Ql(this._hostTNode, this._hostLView); if (Sh(t)) {
        let n = ki(t, this._hostLView), o = Ri(t), r = n[y].data[o + 8];
        return new Mt(r, n);
    }
    else
        return new Mt(null, this._hostLView); }
    clear() { for (; this.length > 0;)
        this.remove(this.length - 1); }
    get(t) { let n = Lp(this._lContainer); return n !== null && n[t] || null; }
    get length() { return this._lContainer.length - G; }
    createEmbeddedView(t, n, o) { let r, i; typeof o == "number" ? r = o : o != null && (r = o.index, i = o.injector); let s = Yo(this._lContainer, t.ssrId), a = t.createEmbeddedViewImpl(n || {}, i, s); return this.insertImpl(a, r, zt(this._hostTNode, s)), a; }
    createComponent(t, n, o, r, i, s, a) { let c = t && !So(t), l; if (c)
        l = n;
    else {
        let v = n || {};
        l = v.index, o = v.injector, r = v.projectableNodes, i = v.environmentInjector || v.ngModuleRef, s = v.directives, a = v.bindings;
    } let u = c ? t : new _t(U(t)), d = o || this.parentInjector; if (!i && u.ngModule == null) {
        let E = (c ? d : this.parentInjector).get(pt, null);
        E && (i = E);
    } let f = U(u.componentType ?? {}), p = Yo(this._lContainer, f?.id ?? null), h = p?.firstChild ?? null, m = u.create(d, r, h, i, s, a); return this.insertImpl(m.hostView, l, zt(this._hostTNode, p)), m; }
    insert(t, n) { return this.insertImpl(t, n, !0); }
    insertImpl(t, n, o) { let r = t._lView; if (Pf(r)) {
        let a = this.indexOf(t);
        if (a !== -1)
            this.detach(a);
        else {
            let c = r[q], l = new py(c, c[se], c[q]);
            l.detach(l.indexOf(t));
        }
    } let i = this._adjustIndex(n), s = this._lContainer; return eo(s, r, i, o), t.attachToViewContainerRef(), Sa(Ac(s), i, t), t; }
    move(t, n) { return this.insert(t, n); }
    indexOf(t) { let n = Lp(this._lContainer); return n !== null ? n.indexOf(t) : -1; }
    remove(t) { let n = this._adjustIndex(t, -1), o = Qo(this._lContainer, n); o && (po(Ac(this._lContainer), n), yr(o[y], o)); }
    detach(t) { let n = this._adjustIndex(t, -1), o = Qo(this._lContainer, n); return o && po(Ac(this._lContainer), n) != null ? new wt(o) : null; }
    _adjustIndex(t, n = 0) { return t ?? this.length + n; }
};
function Lp(e) { return e[Eo]; }
function Ac(e) { return e[Eo] || (e[Eo] = []); }
function hy(e, t) { let n, o = t[e.index]; return K(o) ? n = o : (n = wm(o, t, null, e), t[e.index] = n, Mu(t, n)), gy(n, t, e, o), new py(n, e, t); }
function d_(e, t) { let n = e[C], o = n.createComment(""), r = ne(t, e), i = n.parentNode(r); return qt(n, i, o, n.nextSibling(r), !1), o; }
var gy = yy, Uu = () => !1;
function my(e, t, n) { return Uu(e, t, n); }
function yy(e, t, n, o) { if (e[Re])
    return; let r; n.type & 8 ? r = R(o) : r = d_(t, n), e[Re] = r; }
function f_(e, t, n) { if (e[Re] && e[De])
    return !0; let o = n[te], r = t.index - I; if (!o || Wn(t) || Ds(o, r))
    return !1; let s = Kc(o, r), a = o.data[qn]?.[r], [c, l] = Aw(s, a); return e[Re] = c, e[De] = l, !0; }
function p_(e, t, n, o) { Uu(e, n, t) || yy(e, t, n, o); }
function vy() { gy = p_, Uu = f_; }
var vl = class e {
    queryList;
    matches = null;
    constructor(t) { this.queryList = t; }
    clone() { return new e(this.queryList); }
    setDirty() { this.queryList.setDirty(); }
}, Il = class e {
    queries;
    constructor(t = []) { this.queries = t; }
    createEmbeddedView(t) { let n = t.queries; if (n !== null) {
        let o = t.contentQueries !== null ? t.contentQueries[0] : n.length, r = [];
        for (let i = 0; i < o; i++) {
            let s = n.getByIndex(i), a = this.queries[s.indexInDeclarationView];
            r.push(a.clone());
        }
        return new e(r);
    } return null; }
    insertView(t) { this.dirtyQueriesWithMatches(t); }
    detachView(t) { this.dirtyQueriesWithMatches(t); }
    finishViewCreation(t) { this.dirtyQueriesWithMatches(t); }
    dirtyQueriesWithMatches(t) { for (let n = 0; n < this.queries.length; n++)
        Wu(t, n).matches !== null && this.queries[n].setDirty(); }
}, Qi = class {
    flags;
    read;
    predicate;
    constructor(t, n, o = null) { this.flags = n, this.read = o, typeof t == "string" ? this.predicate = v_(t) : this.predicate = t; }
}, El = class e {
    queries;
    constructor(t = []) { this.queries = t; }
    elementStart(t, n) { for (let o = 0; o < this.queries.length; o++)
        this.queries[o].elementStart(t, n); }
    elementEnd(t) { for (let n = 0; n < this.queries.length; n++)
        this.queries[n].elementEnd(t); }
    embeddedTView(t) { let n = null; for (let o = 0; o < this.length; o++) {
        let r = n !== null ? n.length : 0, i = this.getByIndex(o).embeddedTView(t, r);
        i && (i.indexInDeclarationView = o, n !== null ? n.push(i) : n = [i]);
    } return n !== null ? new e(n) : null; }
    template(t, n) { for (let o = 0; o < this.queries.length; o++)
        this.queries[o].template(t, n); }
    getByIndex(t) { return this.queries[t]; }
    get length() { return this.queries.length; }
    track(t) { this.queries.push(t); }
}, Dl = class e {
    metadata;
    matches = null;
    indexInDeclarationView = -1;
    crossesNgTemplate = !1;
    _declarationNodeIndex;
    _appliesToNextNode = !0;
    constructor(t, n = -1) { this.metadata = t, this._declarationNodeIndex = n; }
    elementStart(t, n) { this.isApplyingToNode(n) && this.matchTNode(t, n); }
    elementEnd(t) { this._declarationNodeIndex === t.index && (this._appliesToNextNode = !1); }
    template(t, n) { this.elementStart(t, n); }
    embeddedTView(t, n) { return this.isApplyingToNode(t) ? (this.crossesNgTemplate = !0, this.addMatch(-t.index, n), new e(this.metadata)) : null; }
    isApplyingToNode(t) { if (this._appliesToNextNode && (this.metadata.flags & 1) !== 1) {
        let n = this._declarationNodeIndex, o = t.parent;
        for (; o !== null && o.type & 8 && o.index !== n;)
            o = o.parent;
        return n === (o !== null ? o.index : -1);
    } return this._appliesToNextNode; }
    matchTNode(t, n) { let o = this.metadata.predicate; if (Array.isArray(o))
        for (let r = 0; r < o.length; r++) {
            let i = o[r];
            this.matchTNodeWithReadOption(t, n, h_(n, i)), this.matchTNodeWithReadOption(t, n, Di(n, t, i, !1, !1));
        }
    else
        o === Zo ? n.type & 4 && this.matchTNodeWithReadOption(t, n, -1) : this.matchTNodeWithReadOption(t, n, Di(n, t, o, !1, !1)); }
    matchTNodeWithReadOption(t, n, o) { if (o !== null) {
        let r = this.metadata.read;
        if (r !== null)
            if (r === ar || r === Gs || r === Zo && n.type & 4)
                this.addMatch(n.index, -2);
            else {
                let i = Di(n, t, r, !1, !1);
                i !== null && this.addMatch(n.index, i);
            }
        else
            this.addMatch(n.index, o);
    } }
    addMatch(t, n) { this.matches === null ? this.matches = [t, n] : this.matches.push(t, n); }
};
function h_(e, t) { let n = e.localNames; if (n !== null) {
    for (let o = 0; o < n.length; o += 2)
        if (n[o] === t)
            return n[o + 1];
} return null; }
function g_(e, t) { return e.type & 11 ? Un(e, t) : e.type & 4 ? Ps(e, t) : null; }
function m_(e, t, n, o) { return n === -1 ? g_(t, e) : n === -2 ? y_(e, t, o) : Go(e, e[y], n, t); }
function y_(e, t, n) { if (n === ar)
    return Un(t, e); if (n === Zo)
    return Ps(t, e); if (n === Gs)
    return hy(t, e); }
function Iy(e, t, n, o) { let r = t[je].queries[o]; if (r.matches === null) {
    let i = e.data, s = n.matches, a = [];
    for (let c = 0; s !== null && c < s.length; c += 2) {
        let l = s[c];
        if (l < 0)
            a.push(null);
        else {
            let u = i[l];
            a.push(m_(t, u, s[c + 1], n.metadata.read));
        }
    }
    r.matches = a;
} return r.matches; }
function Cl(e, t, n, o) { let r = e.queries.getByIndex(n), i = r.matches; if (i !== null) {
    let s = Iy(e, t, r, n);
    for (let a = 0; a < i.length; a += 2) {
        let c = i[a];
        if (c > 0)
            o.push(s[a / 2]);
        else {
            let l = i[a + 1], u = t[-c];
            for (let d = G; d < u.length; d++) {
                let f = u[d];
                f[gt] === f[q] && Cl(f[y], f, l, o);
            }
            if (u[Lt] !== null) {
                let d = u[Lt];
                for (let f = 0; f < d.length; f++) {
                    let p = d[f];
                    Cl(p[y], p, l, o);
                }
            }
        }
    }
} return o; }
function Gu(e, t) { return e[je].queries[t].queryList; }
function Ey(e, t, n) { let o = new Pi((n & 4) === 4); return Ha(e, t, o, o.destroy), (t[je] ??= new Il).queries.push(new vl(o)) - 1; }
function Dy(e, t, n) { let o = N(); return o.firstCreatePass && (Ty(o, new Qi(e, t, n), -1), (t & 2) === 2 && (o.staticViewQueries = !0)), Ey(o, g(), t); }
function Cy(e, t, n, o) { let r = N(); if (r.firstCreatePass) {
    let i = T();
    Ty(r, new Qi(t, n, o), i.index), I_(r, e), (n & 2) === 2 && (r.staticContentQueries = !0);
} return Ey(r, g(), n); }
function v_(e) { return e.split(",").map(t => t.trim()); }
function Ty(e, t, n) { e.queries === null && (e.queries = new El), e.queries.track(new Dl(t, n)); }
function I_(e, t) { let n = e.contentQueries || (e.contentQueries = []), o = n.length ? n[n.length - 1] : -1; t !== o && n.push(e.queries.length - 1, t); }
function Wu(e, t) { return e.queries.getByIndex(t); }
function My(e, t) { let n = e[y], o = Wu(n, t); return o.crossesNgTemplate ? Cl(n, e, t, []) : Iy(n, e, o, t); }
function qu(e, t, n) { let o, r = yf(() => { o._dirtyCounter(); let i = E_(o, e); if (t && i === void 0)
    throw new w(-951, !1); return i; }); return o = r[ut], o._dirtyCounter = uc(0), o._flatValue = void 0, r; }
function zu(e) { return qu(!0, !1, e); }
function Qu(e) { return qu(!0, !0, e); }
function Zu(e) { return qu(!1, !1, e); }
function Ny(e, t) { let n = e[ut]; n._lView = g(), n._queryIndex = t, n._queryList = Gu(n._lView, t), n._queryList.onDirty(() => n._dirtyCounter.update(o => o + 1)); }
function E_(e, t) { let n = e._lView, o = e._queryIndex; if (n === void 0 || o === void 0 || n[b] & 4)
    return t ? void 0 : O; let r = Gu(n, o), i = My(n, o); return r.reset(i, Bh), t ? r.first : r._changesDetected || e._flatValue === void 0 ? e._flatValue = r.toArray() : e._flatValue; }
function wy(e) { let t = [], n = new Map; function o(r) { let i = n.get(r); if (!i) {
    let s = e(r);
    n.set(r, i = s.then(a => M_(r, a)));
} return i; } return xn.forEach((r, i) => { let s = []; r.templateUrl && s.push(o(r.templateUrl).then(l => { r.template = l; })); let a = typeof r.styles == "string" ? [r.styles] : r.styles || []; if (r.styles = a, r.styleUrl && r.styleUrls?.length)
    throw new Error("@Component cannot define both `styleUrl` and `styleUrls`. Use `styleUrl` if the component has one stylesheet, or `styleUrls` if it has multiple"); if (r.styleUrls?.length) {
    let l = r.styles.length, u = r.styleUrls;
    r.styleUrls.forEach((d, f) => { a.push(""), s.push(o(d).then(p => { a[l + f] = p, u.splice(u.indexOf(d), 1), u.length == 0 && (r.styleUrls = void 0); })); });
}
else
    r.styleUrl && s.push(o(r.styleUrl).then(l => { a.push(l), r.styleUrl = void 0; })); let c = Promise.all(s).then(() => N_(i)); t.push(c); }), by(), Promise.all(t).then(() => { }); }
var xn = new Map, Xo = new Set;
function D_(e, t) { _y(t) && (xn.set(e, t), Xo.add(e)); }
function C_(e) { return Xo.has(e); }
function _y(e) { return !!(e.templateUrl && !e.hasOwnProperty("template") || e.styleUrls && e.styleUrls.length || e.styleUrl); }
function by() { let e = xn; return xn = new Map, e; }
function T_(e) { Xo.clear(), e.forEach((t, n) => Xo.add(n)), xn = e; }
function Sy() { return xn.size === 0; }
function M_(e, t) { return typeof t == "string" ? t : t.status !== void 0 && t.status !== 200 ? Promise.reject(new w(918, !1)) : t.text(); }
function N_(e) { Xo.delete(e); }
var Tl = new Map, Ay = !0;
function w_(e, t, n) { if (t && t !== n && Ay)
    throw new Error(`Duplicate module registered for ${e} - ${on(t)} vs ${on(t.name)}`); }
function Yu(e, t) { let n = Tl.get(t) || null; w_(t, n, e), Tl.set(t, e); }
function Ku(e) { return Tl.get(e); }
function __(e) { Ay = !e; }
function Ry(e, t, n) { let o = g(), r = Ce(), i = ne(r, o); if (r.type === 2 && t.toLowerCase() === "iframe") {
    let s = i;
    s.src = "", s.srcdoc = Yn(""), gr(o[C], s);
    let a = !1;
    throw new w(-910, a);
} return e; }
var Fp = new Set;
function Z(e) { Fp.has(e) || (Fp.add(e), performance?.mark?.("mark_feature_usage", { detail: { feature: e } })); }
var On = class {
}, ky = class {
};
function xy(e, t) { return new Pn(e, t ?? null, []); }
var b_ = xy, Pn = class extends On {
    ngModuleType;
    _parent;
    _bootstrapComponents = [];
    _r3Injector;
    instance;
    destroyCbs = [];
    componentFactoryResolver = new qi(this);
    constructor(t, n, o, r = !0) { super(), this.ngModuleType = t, this._parent = n; let i = an(t); this._bootstrapComponents = En(i.bootstrap), this._r3Injector = Qf(t, n, [{ provide: On, useValue: this }, { provide: Er, useValue: this.componentFactoryResolver }, ...o], on(t), new Set(["environment"])), r && this.resolveInjectorInitializers(); }
    resolveInjectorInitializers() { this._r3Injector.resolveInjectorInitializers(), this.instance = this._r3Injector.get(this.ngModuleType); }
    get injector() { return this._r3Injector; }
    destroy() { let t = this._r3Injector; !t.destroyed && t.destroy(), this.destroyCbs.forEach(n => n()), this.destroyCbs = null; }
    onDestroy(t) { this.destroyCbs.push(t); }
}, Ln = class extends ky {
    moduleType;
    constructor(t) { super(), this.moduleType = t; }
    create(t) { return new Pn(this.moduleType, t, []); }
};
function Oy(e, t, n) { return new Pn(e, t, n, !1); }
var er = class extends On {
    injector;
    componentFactoryResolver = new qi(this);
    instance = null;
    constructor(t) { super(); let n = new ka([...t.providers, { provide: On, useValue: this }, { provide: Er, useValue: this.componentFactoryResolver }], t.parent || zr(), t.debugName, new Set(["environment"])); this.injector = n, t.runEnvironmentInitializers && n.resolveInjectorInitializers(); }
    destroy() { this.injector.destroy(); }
    onDestroy(t) { this.injector.onDestroy(t); }
};
function Ju(e, t, n = null) { return new er({ providers: e, parent: t, debugName: n, runEnvironmentInitializers: !0 }).injector; }
var S_ = (() => { class e {
    _injector;
    cachedInjectors = new Map;
    constructor(n) { this._injector = n; }
    getOrCreateStandaloneInjector(n) { if (!n.standalone)
        return null; if (!this.cachedInjectors.has(n)) {
        let o = Ra(!1, n.type), r = o.length > 0 ? Ju([o], this._injector, `Standalone[${n.type.name}]`) : null;
        this.cachedInjectors.set(n, r);
    } return this.cachedInjectors.get(n); }
    ngOnDestroy() { try {
        for (let n of this.cachedInjectors.values())
            n !== null && n.destroy();
    }
    finally {
        this.cachedInjectors.clear();
    } }
    static \u0275prov = j({ token: e, providedIn: "environment", factory: () => new e(Se(pt)) });
} return e; })();
function Py(e) { return Ge(() => { let t = Vy(e), n = Le(W({}, t), { decls: e.decls, vars: e.vars, template: e.template, consts: e.consts || null, ngContentSelectors: e.ngContentSelectors, onPush: e.changeDetection === ls.OnPush, directiveDefs: null, pipeDefs: null, dependencies: t.standalone && e.dependencies || null, getStandaloneInjector: t.standalone ? r => r.get(S_).getOrCreateStandaloneInjector(n) : null, getExternalStyles: null, signals: e.signals ?? !1, data: e.data || {}, encapsulation: e.encapsulation || Xe.Emulated, styles: e.styles || O, _: null, schemas: e.schemas || null, tView: null, id: "" }); t.standalone && Z("NgStandalone"), Hy(n); let o = e.dependencies; return n.directiveDefs = Zi(o, Ly), n.pipeDefs = Zi(o, Fe), n.id = x_(n), n; }); }
function Ly(e) { return U(e) || Ne(e); }
function Xu(e) { return Ge(() => ({ type: e.type, bootstrap: e.bootstrap || O, declarations: e.declarations || O, imports: e.imports || O, exports: e.exports || O, transitiveCompileScopes: null, schemas: e.schemas || null, id: e.id || null })); }
function A_(e, t) { if (e == null)
    return Me; let n = {}; for (let o in e)
    if (e.hasOwnProperty(o)) {
        let r = e[o], i, s, a, c;
        Array.isArray(r) ? (a = r[0], i = r[1], s = r[2] ?? i, c = r[3] || null) : (i = r, s = r, a = ws.None, c = null), n[i] = [o, a, c], t[i] = s;
    } return n; }
function R_(e) { if (e == null)
    return Me; let t = {}; for (let n in e)
    e.hasOwnProperty(n) && (t[e[n]] = n); return t; }
function Fy(e) { return Ge(() => { let t = Vy(e); return Hy(t), t; }); }
function jy(e) { return { type: e.type, name: e.name, factory: null, pure: e.pure !== !1, standalone: e.standalone ?? !0, onDestroy: e.type.prototype.ngOnDestroy || null }; }
function Vy(e) { let t = {}; return { type: e.type, providersResolver: null, factory: null, hostBindings: e.hostBindings || null, hostVars: e.hostVars || 0, hostAttrs: e.hostAttrs || null, contentQueries: e.contentQueries || null, declaredInputs: t, inputConfig: e.inputs || Me, exportAs: e.exportAs || null, standalone: e.standalone ?? !0, signals: e.signals === !0, selectors: e.selectors || O, viewQuery: e.viewQuery || null, features: e.features || null, setInput: null, resolveHostDirectives: null, hostDirectives: null, inputs: A_(e.inputs, t), outputs: R_(e.outputs), debugInfo: null }; }
function Hy(e) { e.features?.forEach(t => t(e)); }
function Zi(e, t) { return e ? () => { let n = typeof e == "function" ? e() : e, o = []; for (let r of n) {
    let i = t(r);
    i !== null && o.push(i);
} return o; } : null; }
var k_ = new Map;
function x_(e) { let t = 0, n = typeof e.consts == "function" ? "" : e.consts, o = [e.selectors, e.ngContentSelectors, e.hostVars, e.hostAttrs, n, e.vars, e.decls, e.encapsulation, e.standalone, e.signals, e.exportAs, JSON.stringify(e.inputs), JSON.stringify(e.outputs), Object.getOwnPropertyNames(e.type.prototype), !!e.contentQueries, !!e.viewQuery]; for (let i of o.join("|"))
    t = Math.imul(31, t) + i.charCodeAt(0) << 0; return t += 2147483648, "c" + t; }
function By(e) { return Object.getPrototypeOf(e.prototype).constructor; }
function ed(e) { let t = By(e.type), n = !0, o = [e]; for (; t;) {
    let r;
    if (ye(e))
        r = t.\u0275cmp || t.\u0275dir;
    else {
        if (t.\u0275cmp)
            throw new w(903, !1);
        r = t.\u0275dir;
    }
    if (r) {
        if (n) {
            o.push(r);
            let s = e;
            s.inputs = Rc(e.inputs), s.declaredInputs = Rc(e.declaredInputs), s.outputs = Rc(e.outputs);
            let a = r.hostBindings;
            a && j_(e, a);
            let c = r.viewQuery, l = r.contentQueries;
            if (c && L_(e, c), l && F_(e, l), O_(e, r), Ef(e.outputs, r.outputs), ye(r) && r.data.animation) {
                let u = e.data;
                u.animation = (u.animation || []).concat(r.data.animation);
            }
        }
        let i = r.features;
        if (i)
            for (let s = 0; s < i.length; s++) {
                let a = i[s];
                a && a.ngInherit && a(e), a === ed && (n = !1);
            }
    }
    t = Object.getPrototypeOf(t);
} P_(o); }
function O_(e, t) { for (let n in t.inputs) {
    if (!t.inputs.hasOwnProperty(n) || e.inputs.hasOwnProperty(n))
        continue;
    let o = t.inputs[n];
    o !== void 0 && (e.inputs[n] = o, e.declaredInputs[n] = t.declaredInputs[n]);
} }
function P_(e) { let t = 0, n = null; for (let o = e.length - 1; o >= 0; o--) {
    let r = e[o];
    r.hostVars = t += r.hostVars, r.hostAttrs = An(r.hostAttrs, n = An(n, r.hostAttrs));
} }
function Rc(e) { return e === Me ? {} : e === O ? [] : e; }
function L_(e, t) { let n = e.viewQuery; n ? e.viewQuery = (o, r) => { t(o, r), n(o, r); } : e.viewQuery = t; }
function F_(e, t) { let n = e.contentQueries; n ? e.contentQueries = (o, r, i) => { t(o, r, i), n(o, r, i); } : e.contentQueries = t; }
function j_(e, t) { let n = e.hostBindings; n ? e.hostBindings = (o, r) => { t(o, r), n(o, r); } : e.hostBindings = t; }
var V_ = ["providersResolver"], H_ = ["template", "decls", "consts", "vars", "onPush", "ngContentSelectors", "styles", "encapsulation", "schemas"];
function $y(e) { let t = By(e.type), n; ye(e) ? n = t.\u0275cmp : n = t.\u0275dir; let o = e; for (let r of V_)
    o[r] = n[r]; if (ye(n))
    for (let r of H_)
        o[r] = n[r]; }
function Uy(e) { let t = n => { let o = Array.isArray(e); n.hostDirectives === null ? (n.resolveHostDirectives = B_, n.hostDirectives = o ? e.map(Ml) : [e]) : o ? n.hostDirectives.unshift(...e.map(Ml)) : n.hostDirectives.unshift(e); }; return t.ngInherit = !0, t; }
function B_(e) { let t = [], n = !1, o = null, r = null; for (let i = 0; i < e.length; i++) {
    let s = e[i];
    if (s.hostDirectives !== null) {
        let a = t.length;
        o ??= new Map, r ??= new Map, Gy(s, t, o), r.set(s, [a, t.length - 1]);
    }
    i === 0 && ye(s) && (n = !0, t.push(s));
} for (let i = n ? 1 : 0; i < e.length; i++)
    t.push(e[i]); return [t, o, r]; }
function Gy(e, t, n) { if (e.hostDirectives !== null)
    for (let o of e.hostDirectives)
        if (typeof o == "function") {
            let r = o();
            for (let i of r)
                jp(Ml(i), t, n);
        }
        else
            jp(o, t, n); }
function jp(e, t, n) { let o = Ne(e.directive); $_(o.declaredInputs, e.inputs), Gy(o, t, n), n.set(o, e), t.push(o); }
function Ml(e) { return typeof e == "function" ? { directive: $(e), inputs: Me, outputs: Me } : { directive: $(e.directive), inputs: Vp(e.inputs), outputs: Vp(e.outputs) }; }
function Vp(e) { if (e === void 0 || e.length === 0)
    return Me; let t = {}; for (let n = 0; n < e.length; n += 2)
    t[e[n]] = e[n + 1]; return t; }
function $_(e, t) { for (let n in t)
    if (t.hasOwnProperty(n)) {
        let o = t[n], r = e[n];
        e[o] = r;
    } }
function Wy(e, t, n, o, r, i, s, a) { if (n.firstCreatePass) {
    e.mergedAttrs = An(e.mergedAttrs, e.attrs);
    let u = e.tView = Cu(2, e, r, i, s, n.directiveRegistry, n.pipeRegistry, null, n.schemas, n.consts, null);
    n.queries !== null && (n.queries.template(n, e), u.queries = n.queries.embeddedTView(e));
} a && (e.flags |= a), He(e, !1); let c = qy(n, t, e, o); wo() && bu(n, t, c, e), _e(c, t); let l = wm(c, t, c, e); t[o + I] = l, Mu(t, l), my(l, e, t); }
function U_(e, t, n, o, r, i, s, a, c, l, u) { let d = n + I, f; return t.firstCreatePass ? (f = nn(t, d, 4, s || null, a || null), ti() && oy(t, e, f, ae(t.consts, l), ku), Nh(t, f)) : f = t.data[d], Wy(f, e, t, n, o, r, i, c), un(f) && bs(t, e, f), l != null && Jn(e, f, u), f; }
function Zt(e, t, n, o, r, i, s, a, c, l, u) { let d = n + I, f; if (t.firstCreatePass) {
    if (f = nn(t, d, 4, s || null, a || null), l != null) {
        let p = ae(t.consts, l);
        f.localNames = [];
        for (let h = 0; h < p.length; h += 2)
            f.localNames.push(p[h], -1);
    }
}
else
    f = t.data[d]; return Wy(f, e, t, n, o, r, i, c), l != null && Jn(e, f, u), f; }
function td(e, t, n, o, r, i, s, a) { let c = g(), l = N(), u = ae(l.consts, i); return U_(c, l, e, t, n, o, r, u, void 0, s, a), td; }
function nd(e, t, n, o, r, i, s, a) { let c = g(), l = N(), u = ae(l.consts, i); return Zt(c, l, e, t, n, o, r, u, void 0, s, a), nd; }
var qy = zy;
function zy(e, t, n, o) { return ke(!0), t[C].createComment(""); }
function G_(e, t, n, o) { let r = !Cs(t, n); ke(r); let i = t[te]?.data[ds]?.[o] ?? null; if (i !== null && n.tView !== null && n.tView.ssrId === null && (n.tView.ssrId = i), r)
    return zy(e, t); let s = t[te], a = Ir(s, e, t, n); Is(s, o, a); let c = du(s, o); return Fs(c, a); }
function Qy() { qy = G_; }
var J = (function (e) { return e[e.NOT_STARTED = 0] = "NOT_STARTED", e[e.IN_PROGRESS = 1] = "IN_PROGRESS", e[e.COMPLETE = 2] = "COMPLETE", e[e.FAILED = 3] = "FAILED", e; })(J || {}), Hp = 0, W_ = 1, H = (function (e) { return e[e.Placeholder = 0] = "Placeholder", e[e.Loading = 1] = "Loading", e[e.Complete = 2] = "Complete", e[e.Error = 3] = "Error", e; })(H || {}), tr = (function (e) { return e[e.Initial = -1] = "Initial", e; })(tr || {}), wn = 0, at = 1, Ao = 2, mi = 3, q_ = 4, z_ = 5, Ws = 6, Q_ = 7, _n = 8, Z_ = 9, od = (function (e) { return e[e.Manual = 0] = "Manual", e[e.Playthrough = 1] = "Playthrough", e; })(od || {});
function Cr(e, t, n) { let o = Yy(e); t[o] === null && (t[o] = []), t[o].push(n); }
function Ni(e, t) { let n = Yy(e), o = t[n]; if (o !== null) {
    for (let r of o)
        r();
    t[n] = null;
} }
function Zy(e) { Ni(1, e), Ni(0, e), Ni(2, e); }
function Yy(e) { let t = q_; return e === 1 ? t = z_ : e === 2 && (t = Z_), t; }
var qs = (function (e) { return e[e.CHANGE_DETECTION = 0] = "CHANGE_DETECTION", e[e.AFTER_NEXT_RENDER = 1] = "AFTER_NEXT_RENDER", e; })(qs || {}), oo = new _(""), Ky = !1, Nl = class extends Wl {
    __isAsync;
    destroyRef = void 0;
    pendingTasks = void 0;
    constructor(t = !1) { super(), this.__isAsync = t, xa() && (this.destroyRef = D(fn, { optional: !0 }) ?? void 0, this.pendingTasks = D(Dt, { optional: !0 }) ?? void 0); }
    emit(t) { let n = S(null); try {
        super.next(t);
    }
    finally {
        S(n);
    } }
    subscribe(t, n, o) { let r = t, i = n || (() => null), s = o; if (t && typeof t == "object") {
        let c = t;
        r = c.next?.bind(c), i = c.error?.bind(c), s = c.complete?.bind(c);
    } this.__isAsync && (i = this.wrapInTimeout(i), r && (r = this.wrapInTimeout(r)), s && (s = this.wrapInTimeout(s))); let a = super.subscribe({ next: r, error: i, complete: s }); return t instanceof ql && t.add(a), a; }
    wrapInTimeout(t) { return n => { let o = this.pendingTasks?.add(); setTimeout(() => { try {
        t(n);
    }
    finally {
        o !== void 0 && this.pendingTasks?.remove(o);
    } }); }; }
}, Ye = Nl;
function Jy(e) { let t, n; function o() { e = _o; try {
    n !== void 0 && typeof cancelAnimationFrame == "function" && cancelAnimationFrame(n), t !== void 0 && clearTimeout(t);
}
catch { } } return t = setTimeout(() => { e(), o(); }), typeof requestAnimationFrame == "function" && (n = requestAnimationFrame(() => { e(), o(); })), () => o(); }
function Bp(e) { return queueMicrotask(() => e()), () => { e = _o; }; }
var rd = "isAngularZone", Yi = rd + "_ID", Y_ = 0, L = class e {
    hasPendingMacrotasks = !1;
    hasPendingMicrotasks = !1;
    isStable = !0;
    onUnstable = new Ye(!1);
    onMicrotaskEmpty = new Ye(!1);
    onStable = new Ye(!1);
    onError = new Ye(!1);
    constructor(t) { let { enableLongStackTrace: n = !1, shouldCoalesceEventChangeDetection: o = !1, shouldCoalesceRunChangeDetection: r = !1, scheduleInRootZone: i = Ky } = t; if (typeof Zone > "u")
        throw new w(908, !1); Zone.assertZonePatched(); let s = this; s._nesting = 0, s._outer = s._inner = Zone.current, Zone.TaskTrackingZoneSpec && (s._inner = s._inner.fork(new Zone.TaskTrackingZoneSpec)), n && Zone.longStackTraceZoneSpec && (s._inner = s._inner.fork(Zone.longStackTraceZoneSpec)), s.shouldCoalesceEventChangeDetection = !r && o, s.shouldCoalesceRunChangeDetection = r, s.callbackScheduled = !1, s.scheduleInRootZone = i, X_(s); }
    static isInAngularZone() { return typeof Zone < "u" && Zone.current.get(rd) === !0; }
    static assertInAngularZone() { if (!e.isInAngularZone())
        throw new w(909, !1); }
    static assertNotInAngularZone() { if (e.isInAngularZone())
        throw new w(909, !1); }
    run(t, n, o) { return this._inner.run(t, n, o); }
    runTask(t, n, o, r) { let i = this._inner, s = i.scheduleEventTask("NgZoneEvent: " + r, t, K_, _o, _o); try {
        return i.runTask(s, n, o);
    }
    finally {
        i.cancelTask(s);
    } }
    runGuarded(t, n, o) { return this._inner.runGuarded(t, n, o); }
    runOutsideAngular(t) { return this._outer.run(t); }
}, K_ = {};
function id(e) { if (e._nesting == 0 && !e.hasPendingMicrotasks && !e.isStable)
    try {
        e._nesting++, e.onMicrotaskEmpty.emit(null);
    }
    finally {
        if (e._nesting--, !e.hasPendingMicrotasks)
            try {
                e.runOutsideAngular(() => e.onStable.emit(null));
            }
            finally {
                e.isStable = !0;
            }
    } }
function J_(e) { if (e.isCheckStableRunning || e.callbackScheduled)
    return; e.callbackScheduled = !0; function t() { Jy(() => { e.callbackScheduled = !1, wl(e), e.isCheckStableRunning = !0, id(e), e.isCheckStableRunning = !1; }); } e.scheduleInRootZone ? Zone.root.run(() => { t(); }) : e._outer.run(() => { t(); }), wl(e); }
function X_(e) { let t = () => { J_(e); }, n = Y_++; e._inner = e._inner.fork({ name: "angular", properties: { [rd]: !0, [Yi]: n, [Yi + n]: !0 }, onInvokeTask: (o, r, i, s, a, c) => { if (eb(c))
        return o.invokeTask(i, s, a, c); try {
        return $p(e), o.invokeTask(i, s, a, c);
    }
    finally {
        (e.shouldCoalesceEventChangeDetection && s.type === "eventTask" || e.shouldCoalesceRunChangeDetection) && t(), Up(e);
    } }, onInvoke: (o, r, i, s, a, c, l) => { try {
        return $p(e), o.invoke(i, s, a, c, l);
    }
    finally {
        e.shouldCoalesceRunChangeDetection && !e.callbackScheduled && !tb(c) && t(), Up(e);
    } }, onHasTask: (o, r, i, s) => { o.hasTask(i, s), r === i && (s.change == "microTask" ? (e._hasPendingMicrotasks = s.microTask, wl(e), id(e)) : s.change == "macroTask" && (e.hasPendingMacrotasks = s.macroTask)); }, onHandleError: (o, r, i, s) => (o.handleError(i, s), e.runOutsideAngular(() => e.onError.emit(s)), !1) }); }
function wl(e) { e._hasPendingMicrotasks || (e.shouldCoalesceEventChangeDetection || e.shouldCoalesceRunChangeDetection) && e.callbackScheduled === !0 ? e.hasPendingMicrotasks = !0 : e.hasPendingMicrotasks = !1; }
function $p(e) { e._nesting++, e.isStable && (e.isStable = !1, e.onUnstable.emit(null)); }
function Up(e) { e._nesting--, id(e); }
var Fn = class {
    hasPendingMicrotasks = !1;
    hasPendingMacrotasks = !1;
    isStable = !0;
    onUnstable = new Ye;
    onMicrotaskEmpty = new Ye;
    onStable = new Ye;
    onError = new Ye;
    run(t, n, o) { return t.apply(n, o); }
    runGuarded(t, n, o) { return t.apply(n, o); }
    runOutsideAngular(t) { return t(); }
    runTask(t, n, o, r) { return t.apply(n, o); }
};
function eb(e) { return Xy(e, "__ignore_ng_zone__"); }
function tb(e) { return Xy(e, "__scheduler_tick__"); }
function Xy(e, t) { return !Array.isArray(e) || e.length !== 1 ? !1 : e[0]?.data?.[t] === !0; }
function ev(e = "zone.js", t) { return e === "noop" ? new Fn : e === "zone.js" ? new L(t) : e; }
var zs = (() => { class e {
    impl = null;
    execute() { this.impl?.execute(); }
    static \u0275prov = j({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), sd = [0, 1, 2, 3], ad = (() => { class e {
    ngZone = D(L);
    scheduler = D(Qe);
    errorHandler = D(ai, { optional: !0 });
    sequences = new Set;
    deferredRegistrations = new Set;
    executing = !1;
    constructor() { D(oo, { optional: !0 }); }
    execute() { let n = this.sequences.size > 0; n && k(16), this.executing = !0; for (let o of sd)
        for (let r of this.sequences)
            if (!(r.erroredOrDestroyed || !r.hooks[o]))
                try {
                    r.pipelinedValue = this.ngZone.runOutsideAngular(() => this.maybeTrace(() => { let i = r.hooks[o]; return i(r.pipelinedValue); }, r.snapshot));
                }
                catch (i) {
                    r.erroredOrDestroyed = !0, this.errorHandler?.handleError(i);
                } this.executing = !1; for (let o of this.sequences)
        o.afterRun(), o.once && (this.sequences.delete(o), o.destroy()); for (let o of this.deferredRegistrations)
        this.sequences.add(o); this.deferredRegistrations.size > 0 && this.scheduler.notify(7), this.deferredRegistrations.clear(), n && k(17); }
    register(n) { let { view: o } = n; o !== void 0 ? ((o[Pt] ??= []).push(n), Jr(o), o[b] |= 8192) : this.executing ? this.deferredRegistrations.add(n) : this.addSequence(n); }
    addSequence(n) { this.sequences.add(n), this.scheduler.notify(7); }
    unregister(n) { this.executing && this.sequences.has(n) ? (n.erroredOrDestroyed = !0, n.pipelinedValue = void 0, n.once = !0) : (this.sequences.delete(n), this.deferredRegistrations.delete(n)); }
    maybeTrace(n, o) { return o ? o.run(qs.AFTER_NEXT_RENDER, n) : n(); }
    static \u0275prov = j({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), nr = class {
    impl;
    hooks;
    view;
    once;
    snapshot;
    erroredOrDestroyed = !1;
    pipelinedValue = void 0;
    unregisterOnDestroy;
    constructor(t, n, o, r, i, s = null) { this.impl = t, this.hooks = n, this.view = o, this.once = r, this.snapshot = s, this.unregisterOnDestroy = i?.onDestroy(() => this.destroy()); }
    afterRun() { this.erroredOrDestroyed = !1, this.pipelinedValue = void 0, this.snapshot?.dispose(), this.snapshot = null; }
    destroy() { this.impl.unregister(this), this.unregisterOnDestroy?.(); let t = this.view?.[Pt]; t && (this.view[Pt] = t.filter(n => n !== this)); }
};
function tv(e, t) { let n = t?.injector ?? D(Te); return typeof ngServerMode < "u" && ngServerMode ? Qs : (Z("NgAfterRender"), ov(e, n, t, !1)); }
function nv(e, t) { let n = t?.injector ?? D(Te); return typeof ngServerMode < "u" && ngServerMode ? Qs : (Z("NgAfterNextRender"), ov(e, n, t, !0)); }
function nb(e) { return e instanceof Function ? [void 0, void 0, e, void 0] : [e.earlyRead, e.write, e.mixedReadWrite, e.read]; }
function ov(e, t, n, o) { let r = t.get(zs); r.impl ??= t.get(ad); let i = t.get(oo, null, { optional: !0 }), s = n?.manualCleanup !== !0 ? t.get(fn) : null, a = t.get(li, null, { optional: !0 }), c = new nr(r.impl, nb(e), a?.view, o, s, i?.snapshot(null)); return r.impl.register(c), c; }
var Qs = { destroy() { } };
function Tr(e) { return e + 1; }
function he(e, t) { let n = e[y], o = Tr(t.index); return e[o]; }
function ob(e, t, n) { let o = e[y], r = Tr(t); e[r] = n; }
function re(e, t) { let n = Tr(t.index); return e.data[n]; }
function rb(e, t, n) { let o = Tr(t); e.data[o] = n; }
function ib(e, t, n) { let o = t[y], r = re(o, n); switch (e) {
    case H.Complete: return r.primaryTmplIndex;
    case H.Loading: return r.loadingTmplIndex;
    case H.Error: return r.errorTmplIndex;
    case H.Placeholder: return r.placeholderTmplIndex;
    default: return null;
} }
function _l(e, t) { return t === H.Placeholder ? e.placeholderBlockConfig?.[Hp] ?? null : t === H.Loading ? e.loadingBlockConfig?.[Hp] ?? null : null; }
function rv(e) { return e.loadingBlockConfig?.[W_] ?? null; }
function Gp(e, t) { if (!e || e.length === 0)
    return t; let n = new Set(e); for (let o of t)
    n.add(o); return e.length === n.size ? e : Array.from(n); }
function sb(e, t) { let n = t.primaryTmplIndex + I; return yt(e, n); }
function iv(e) { return e !== null && typeof e == "object" && typeof e.primaryTmplIndex == "number"; }
function sv(e, t) { let n = null, o = Tr(t.index); return I < o && o < e.bindingStartIndex && (n = re(e, t)), !!n && iv(n); }
function cd(e, t, n) { let o = n.get(L); return qT(e, () => o.run(t), () => o.runOutsideAngular(() => WT())); }
function ab(e, t, n) { return n == null ? e : n >= 0 ? Lf(n, e) : e[t.index][G] ?? null; }
function cb(e, t) { return Ft(I + t, e); }
function ro(e, t, n, o, r, i, s) { let a = e[V], c = a.get(L), l; function u() { if (mt(e)) {
    l.destroy();
    return;
} let d = he(e, t), f = d[at]; if (f !== tr.Initial && f !== H.Placeholder) {
    l.destroy();
    return;
} let p = ab(e, t, o); if (!p || (l.destroy(), mt(p)))
    return; let h = cb(p, n), m = r(h, () => { c.run(() => { e !== p && Va(p, m), i(); }); }, a); e !== p && Xr(p, m), Cr(s, d, m); } l = tv({ read: u }, { injector: a }); }
function Zs(e, t) { let n = t.get(db), o = () => n.remove(e); return n.add(e), o; }
var lb = () => typeof requestIdleCallback < "u" ? requestIdleCallback : setTimeout, ub = () => typeof requestIdleCallback < "u" ? cancelIdleCallback : clearTimeout, db = (() => { class e {
    executingCallbacks = !1;
    idleId = null;
    current = new Set;
    deferred = new Set;
    ngZone = D(L);
    requestIdleCallbackFn = lb().bind(globalThis);
    cancelIdleCallbackFn = ub().bind(globalThis);
    add(n) { (this.executingCallbacks ? this.deferred : this.current).add(n), this.idleId === null && this.scheduleIdleCallback(); }
    remove(n) { let { current: o, deferred: r } = this; o.delete(n), r.delete(n), o.size === 0 && r.size === 0 && this.cancelIdleCallback(); }
    scheduleIdleCallback() { let n = () => { this.cancelIdleCallback(), this.executingCallbacks = !0; for (let o of this.current)
        o(); if (this.current.clear(), this.executingCallbacks = !1, this.deferred.size > 0) {
        for (let o of this.deferred)
            this.current.add(o);
        this.deferred.clear(), this.scheduleIdleCallback();
    } }; this.idleId = this.requestIdleCallbackFn(() => this.ngZone.run(n)); }
    cancelIdleCallback() { this.idleId !== null && (this.cancelIdleCallbackFn(this.idleId), this.idleId = null); }
    ngOnDestroy() { this.cancelIdleCallback(), this.current.clear(), this.deferred.clear(); }
    static \u0275prov = j({ token: e, providedIn: "root", factory: () => new e });
} return e; })();
function Ys(e) { return (t, n) => av(e, t, n); }
function av(e, t, n) { let o = n.get(cv), r = n.get(L), i = () => o.remove(t); return o.add(e, t, r), i; }
var cv = (() => { class e {
    executingCallbacks = !1;
    timeoutId = null;
    invokeTimerAt = null;
    current = [];
    deferred = [];
    add(n, o, r) { let i = this.executingCallbacks ? this.deferred : this.current; this.addToQueue(i, Date.now() + n, o), this.scheduleTimer(r); }
    remove(n) { let { current: o, deferred: r } = this; this.removeFromQueue(o, n) === -1 && this.removeFromQueue(r, n), o.length === 0 && r.length === 0 && this.clearTimeout(); }
    addToQueue(n, o, r) { let i = n.length; for (let s = 0; s < n.length; s += 2)
        if (n[s] > o) {
            i = s;
            break;
        } Nf(n, i, o, r); }
    removeFromQueue(n, o) { let r = -1; for (let i = 0; i < n.length; i += 2)
        if (n[i + 1] === o) {
            r = i;
            break;
        } return r > -1 && Aa(n, r, 2), r; }
    scheduleTimer(n) { let o = () => { this.clearTimeout(), this.executingCallbacks = !0; let i = [...this.current], s = Date.now(); for (let c = 0; c < i.length; c += 2) {
        let l = i[c], u = i[c + 1];
        if (l <= s)
            u();
        else
            break;
    } let a = -1; for (let c = 0; c < this.current.length && this.current[c] <= s; c += 2)
        a = c + 1; if (a >= 0 && Aa(this.current, 0, a + 1), this.executingCallbacks = !1, this.deferred.length > 0) {
        for (let c = 0; c < this.deferred.length; c += 2) {
            let l = this.deferred[c], u = this.deferred[c + 1];
            this.addToQueue(this.current, l, u);
        }
        this.deferred.length = 0;
    } this.scheduleTimer(n); }; if (this.current.length > 0) {
        let i = Date.now(), s = this.current[0];
        if (this.timeoutId === null || this.invokeTimerAt && this.invokeTimerAt - s > 16) {
            this.clearTimeout();
            let a = Math.max(s - i, 16);
            this.invokeTimerAt = s, this.timeoutId = n.runOutsideAngular(() => setTimeout(() => n.run(o), a));
        }
    } }
    clearTimeout() { this.timeoutId !== null && (clearTimeout(this.timeoutId), this.timeoutId = null); }
    ngOnDestroy() { this.clearTimeout(), this.current.length = 0, this.deferred.length = 0; }
    static \u0275prov = j({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), fb = (() => { class e {
    cachedInjectors = new Map;
    getOrCreateInjector(n, o, r, i) { if (!this.cachedInjectors.has(n)) {
        let s = r.length > 0 ? Ju(r, o, i) : null;
        this.cachedInjectors.set(n, s);
    } return this.cachedInjectors.get(n); }
    ngOnDestroy() { try {
        for (let n of this.cachedInjectors.values())
            n !== null && n.destroy();
    }
    finally {
        this.cachedInjectors.clear();
    } }
    static \u0275prov = j({ token: e, providedIn: "environment", factory: () => new e });
} return e; })(), pb = new _("DEFER_BLOCK_DEPENDENCY_INTERCEPTOR"), lv = new _("");
function kc(e, t, n) { return e.get(fb).getOrCreateInjector(t, e, n, ""); }
function hb(e, t, n) { if (e instanceof Nn) {
    let r = e.injector, i = e.parentInjector, s = kc(i, t, n);
    return new Nn(r, s);
} let o = e.get(pt); if (o !== e) {
    let r = kc(o, t, n);
    return new Nn(e, r);
} return kc(e, t, n); }
function Ke(e, t, n, o = !1) { let r = n[q], i = r[y]; if (mt(r))
    return; let s = he(r, t), a = s[at], c = s[Q_]; if (!(c !== null && e < c) && qp(a, e) && qp(s[wn] ?? -1, e)) {
    let l = re(i, t), d = !o && (typeof ngServerMode > "u" || !ngServerMode) && (rv(l) !== null || _l(l, H.Loading) !== null || _l(l, H.Placeholder)) ? bl : uv;
    try {
        d(e, s, n, t, r);
    }
    catch (f) {
        xu(r, f);
    }
} }
function gb(e, t) { let n = e[De]?.findIndex(r => r.data[dr] === t[at]) ?? -1; return { dehydratedView: n > -1 ? e[De][n] : null, dehydratedViewIx: n }; }
function uv(e, t, n, o, r) { k(20); let i = ib(e, r, o); if (i !== null) {
    t[at] = e;
    let s = r[y], a = i + I, c = yt(s, a), l = 0;
    Pu(n, l);
    let u;
    if (e === H.Complete) {
        let h = re(s, o), m = h.providers;
        m && m.length > 0 && (u = hb(r[V], h, m));
    }
    let { dehydratedView: d, dehydratedViewIx: f } = gb(n, t), p = Xn(r, c, null, { injector: u, dehydratedView: d });
    if (eo(n, p, l, zt(c, d)), vr(p, 2), f > -1 && n[De]?.splice(f, 1), (e === H.Complete || e === H.Error) && Array.isArray(t[_n])) {
        for (let h of t[_n])
            h();
        t[_n] = null;
    }
} k(21); }
function mb(e, t, n, o, r) { let i = Date.now(), s = r[y], a = re(s, o); if (t[Ao] === null || t[Ao] <= i) {
    t[Ao] = null;
    let c = rv(a), l = t[mi] !== null;
    if (e === H.Loading && c !== null && !l) {
        t[wn] = e;
        let u = Wp(c, t, o, n, r);
        t[mi] = u;
    }
    else {
        e > H.Loading && l && (t[mi](), t[mi] = null, t[wn] = null), uv(e, t, n, o, r);
        let u = _l(a, e);
        u !== null && (t[Ao] = i + u, Wp(u, t, o, n, r));
    }
}
else
    t[wn] = e; }
function Wp(e, t, n, o, r) { return av(e, () => { let s = t[wn]; t[Ao] = null, t[wn] = null, s !== null && Ke(s, n, o); }, r[V]); }
function qp(e, t) { return e < t; }
function io(e, t) { let n = e[t.index]; Ke(H.Placeholder, t, n); }
function zp(e, t, n) { e.loadingPromise.then(() => { e.loadingState === J.COMPLETE ? Ke(H.Complete, t, n) : e.loadingState === J.FAILED && Ke(H.Error, t, n); }); }
var bl = null;
function dv(e, t, n, o) { let r = e.consts; n != null && (t.placeholderBlockConfig = ae(r, n)), o != null && (t.loadingBlockConfig = ae(r, o)), bl === null && (bl = mb); }
var wi = "__ngAsyncComponentMetadataFn__";
function yb(e) { return e[wi] ?? null; }
function fv(e, t, n) { let o = e; return o[wi] = () => Promise.all(t()).then(r => (n(...r), o[wi] = null, r)), o[wi]; }
function ld(e, t, n, o) { return Ge(() => { let r = e; t !== null && (r.hasOwnProperty("decorators") && r.decorators !== void 0 ? r.decorators.push(...t) : r.decorators = t), n !== null && (r.ctorParameters = n), o !== null && (r.hasOwnProperty("propDecorators") && r.propDecorators !== void 0 ? r.propDecorators = W(W({}, r.propDecorators), o) : r.propDecorators = o); }); }
var vb = (() => { class e {
    log(n) { console.log(n); }
    warn(n) { console.warn(n); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })();
function _i(e, t) { let n = e[y]; for (let o = I; o < n.bindingStartIndex; o++)
    if (K(e[o])) {
        let r = e[o];
        if (!(o === n.bindingStartIndex - 1)) {
            let s = n.data[o], a = re(n, s);
            if (iv(a)) {
                t.push({ lContainer: r, lView: e, tNode: s, tDetails: a });
                continue;
            }
        }
        Y(r[F]) && _i(r[F], t);
        for (let s = G; s < r.length; s++)
            _i(r[s], t);
    }
    else
        Y(e[o]) && _i(e[o], t); }
function Ib() { return Z("Chrome DevTools profiling"), () => { }; }
function Eb(e) { let t = nt(), n = e.get(ot), o = tg(t, n), r = {}; for (let [i, s] of Object.entries(o))
    ZT(i) || (r[i] = s); return r; }
var Qp = "ng";
function Db(e, t) { Cb(e, t); }
function Cb(e, t) { if (typeof COMPILED > "u" || !COMPILED) {
    let n = Ie;
    n[Qp] ??= {}, n[Qp][e] = t;
} }
var pv = new _(""), hv = new _(""), Tb = (() => { class e {
    _ngZone;
    registry;
    _isZoneStable = !0;
    _callbacks = [];
    _taskTrackingZone = null;
    _destroyRef;
    constructor(n, o, r) { this._ngZone = n, this.registry = o, xa() && (this._destroyRef = D(fn, { optional: !0 }) ?? void 0), ud || (mv(r), r.addToWindow(o)), this._watchAngularEvents(), n.run(() => { this._taskTrackingZone = typeof Zone > "u" ? null : Zone.current.get("TaskTrackingZone"); }); }
    _watchAngularEvents() { let n = this._ngZone.onUnstable.subscribe({ next: () => { this._isZoneStable = !1; } }), o = this._ngZone.runOutsideAngular(() => this._ngZone.onStable.subscribe({ next: () => { L.assertNotInAngularZone(), queueMicrotask(() => { this._isZoneStable = !0, this._runCallbacksIfReady(); }); } })); this._destroyRef?.onDestroy(() => { n.unsubscribe(), o.unsubscribe(); }); }
    isStable() { return this._isZoneStable && !this._ngZone.hasPendingMacrotasks; }
    _runCallbacksIfReady() { if (this.isStable())
        queueMicrotask(() => { for (; this._callbacks.length !== 0;) {
            let n = this._callbacks.pop();
            clearTimeout(n.timeoutId), n.doneCb();
        } });
    else {
        let n = this.getPendingTasks();
        this._callbacks = this._callbacks.filter(o => o.updateCb && o.updateCb(n) ? (clearTimeout(o.timeoutId), !1) : !0);
    } }
    getPendingTasks() { return this._taskTrackingZone ? this._taskTrackingZone.macroTasks.map(n => ({ source: n.source, creationLocation: n.creationLocation, data: n.data })) : []; }
    addCallback(n, o, r) { let i = -1; o && o > 0 && (i = setTimeout(() => { this._callbacks = this._callbacks.filter(s => s.timeoutId !== i), n(); }, o)), this._callbacks.push({ doneCb: n, timeoutId: i, updateCb: r }); }
    whenStable(n, o, r) { if (r && !this._taskTrackingZone)
        throw new Error('Task tracking zone is required when passing an update callback to whenStable(). Is "zone.js/plugins/task-tracking" loaded?'); this.addCallback(n, o, r), this._runCallbacksIfReady(); }
    registerApplication(n) { this.registry.registerApplication(n, this); }
    unregisterApplication(n) { this.registry.unregisterApplication(n); }
    findProviders(n, o, r) { return []; }
    static \u0275fac = function (o) { return new (o || e)(Se(L), Se(gv), Se(hv)); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac });
} return e; })(), gv = (() => { class e {
    _applications = new Map;
    registerApplication(n, o) { this._applications.set(n, o); }
    unregisterApplication(n) { this._applications.delete(n); }
    unregisterAllApplications() { this._applications.clear(); }
    getTestability(n) { return this._applications.get(n) || null; }
    getAllTestabilities() { return Array.from(this._applications.values()); }
    getAllRootElements() { return Array.from(this._applications.keys()); }
    findTestabilityInTree(n, o = !0) { return ud?.findTestabilityInTree(this, n, o) ?? null; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })();
function mv(e) { ud = e; }
var ud;
function dd(e) { return !!e && typeof e.then == "function"; }
function yv(e) { return !!e && typeof e.subscribe == "function"; }
var fd = new _("");
function Mb(e) { return qe([{ provide: fd, multi: !0, useValue: e }]); }
var pd = (() => { class e {
    resolve;
    reject;
    initialized = !1;
    done = !1;
    donePromise = new Promise((n, o) => { this.resolve = n, this.reject = o; });
    appInits = D(fd, { optional: !0 }) ?? [];
    injector = D(Te);
    constructor() { }
    runInitializers() { if (this.initialized)
        return; let n = []; for (let r of this.appInits) {
        let i = Qr(this.injector, r);
        if (dd(i))
            n.push(i);
        else if (yv(i)) {
            let s = new Promise((a, c) => { i.subscribe({ complete: a, error: c }); });
            n.push(s);
        }
    } let o = () => { this.done = !0, this.resolve(); }; Promise.all(n).then(() => { o(); }).catch(r => { this.reject(r); }), n.length === 0 && o(), this.initialized = !0; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), Mr = new _("");
function hd() { vf(() => { let e = ""; throw new w(600, e); }); }
function vv(e) { return e.isBoundToModule; }
var Sl = class {
    name;
    token;
    constructor(t, n) { this.name = t, this.token = n; }
}, Nb = 10;
function gd(e, t) { return Array.isArray(t) ? t.reduce(gd, e) : W(W({}, e), t); }
var Oe = (() => { class e {
    _runningTick = !1;
    _destroyed = !1;
    _destroyListeners = [];
    _views = [];
    internalErrorHandler = D(Et);
    afterRenderManager = D(zs);
    zonelessEnabled = D(pn);
    rootEffectScheduler = D(hc);
    dirtyFlags = 0;
    tracingSnapshot = null;
    allTestViews = new Set;
    autoDetectTestViews = new Set;
    includeAllTestViews = !1;
    afterTick = new Wl;
    get allViews() { return [...(this.includeAllTestViews ? this.allTestViews : this.autoDetectTestViews).keys(), ...this._views]; }
    get destroyed() { return this._destroyed; }
    componentTypes = [];
    components = [];
    internalPendingTask = D(Dt);
    get isStable() { return this.internalPendingTask.hasPendingTasksObservable.pipe(OC(n => !n)); }
    constructor() { D(oo, { optional: !0 }); }
    whenStable() { let n; return new Promise(o => { n = this.isStable.subscribe({ next: r => { r && o(); } }); }).finally(() => { n.unsubscribe(); }); }
    _injector = D(pt);
    _rendererFactory = null;
    get injector() { return this._injector; }
    bootstrap(n, o) { return this.bootstrapImpl(n, o); }
    bootstrapImpl(n, o, r = Te.NULL) { return this._injector.get(L).run(() => { k(10); let s = n instanceof Bs; if (!this._injector.get(pd).done) {
        let h = "";
        throw new w(405, h);
    } let c; s ? c = n : c = this._injector.get(Er).resolveComponentFactory(n), this.componentTypes.push(c.componentType); let l = vv(c) ? void 0 : this._injector.get(On), u = o || c.selector, d = c.create(r, [], u, l), f = d.location.nativeElement, p = d.injector.get(pv, null); return p?.registerApplication(f), d.onDestroy(() => { this.detachView(d.hostView), Oo(this.components, d), p?.unregisterApplication(f); }), this._loadComponent(d), k(11, d), d; }); }
    tick() { this.zonelessEnabled || (this.dirtyFlags |= 1), this._tick(); }
    _tick() { k(12), this.tracingSnapshot !== null ? this.tracingSnapshot.run(qs.CHANGE_DETECTION, this.tickImpl) : this.tickImpl(); }
    tickImpl = () => { if (this._runningTick)
        throw new w(101, !1); let n = S(null); try {
        this._runningTick = !0, this.synchronize();
    }
    finally {
        this._runningTick = !1, this.tracingSnapshot?.dispose(), this.tracingSnapshot = null, S(n), this.afterTick.next(), k(13);
    } };
    synchronize() { this._rendererFactory === null && !this._injector.destroyed && (this._rendererFactory = this._injector.get(Ko, null, { optional: !0 })); let n = 0; for (; this.dirtyFlags !== 0 && n++ < Nb;)
        k(14), this.synchronizeOnce(), k(15); }
    synchronizeOnce() { this.dirtyFlags & 16 && (this.dirtyFlags &= -17, this.rootEffectScheduler.flush()); let n = !1; if (this.dirtyFlags & 7) {
        let o = !!(this.dirtyFlags & 1);
        this.dirtyFlags &= -8, this.dirtyFlags |= 8;
        for (let { _lView: r } of this.allViews) {
            if (!o && !To(r))
                continue;
            let i = o && !this.zonelessEnabled ? 0 : 1;
            Ou(r, i), n = !0;
        }
        if (this.dirtyFlags &= -5, this.syncDirtyFlagsWithViews(), this.dirtyFlags & 23)
            return;
    } n || (this._rendererFactory?.begin?.(), this._rendererFactory?.end?.()), this.dirtyFlags & 8 && (this.dirtyFlags &= -9, this.afterRenderManager.execute()), this.syncDirtyFlagsWithViews(); }
    syncDirtyFlagsWithViews() { if (this.allViews.some(({ _lView: n }) => To(n))) {
        this.dirtyFlags |= 2;
        return;
    }
    else
        this.dirtyFlags &= -8; }
    attachView(n) { let o = n; this._views.push(o), o.attachToAppRef(this); }
    detachView(n) { let o = n; Oo(this._views, o), o.detachFromAppRef(); }
    _loadComponent(n) { this.attachView(n.hostView); try {
        this.tick();
    }
    catch (r) {
        this.internalErrorHandler(r);
    } this.components.push(n), this._injector.get(Mr, []).forEach(r => r(n)); }
    ngOnDestroy() { if (!this._destroyed)
        try {
            this._destroyListeners.forEach(n => n()), this._views.slice().forEach(n => n.destroy());
        }
        finally {
            this._destroyed = !0, this._views = [], this._destroyListeners = [];
        } }
    onDestroy(n) { return this._destroyListeners.push(n), () => Oo(this._destroyListeners, n); }
    destroy() { if (this._destroyed)
        throw new w(406, !1); let n = this._injector; n.destroy && !n.destroyed && n.destroy(); }
    get viewCount() { return this._views.length; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function Oo(e, t) { let n = e.indexOf(t); n > -1 && e.splice(n, 1); }
function Iv(e) { let t = g(), n = T(); if (io(t, n), !Cv(0, t))
    return; let o = t[V], r = he(t, n), i = e(() => ge(0, t, n), o); Cr(0, r, i); }
function Ev(e, t) { if (typeof ngServerMode < "u" && ngServerMode)
    return; let n = g(), o = n[V], r = T(), i = n[y], s = re(i, r); if (s.loadingState === J.NOT_STARTED) {
    let a = he(n, r), l = e(() => Nr(s, n, r), o);
    Cr(1, a, l);
} }
function Dv(e, t, n) { if (typeof ngServerMode < "u" && ngServerMode)
    return; let o = t[V], r = he(t, n), i = r[Ws], s = e(() => ct(o, i), o); Cr(2, r, s); }
function Nr(e, t, n) { Ks(e, t, n); }
function Ks(e, t, n) { let o = t[V], r = t[y]; if (e.loadingState !== J.NOT_STARTED)
    return e.loadingPromise ?? Promise.resolve(); let i = he(t, n), s = sb(r, e); e.loadingState = J.IN_PROGRESS, Ni(1, i); let a = e.dependencyResolverFn, c = o.get(pc).add(); return a ? (e.loadingPromise = Promise.allSettled(a()).then(l => { let u = !1, d = [], f = []; for (let p of l)
    if (p.status === "fulfilled") {
        let h = p.value, m = U(h) || Ne(h);
        if (m)
            d.push(m);
        else {
            let v = Fe(h);
            v && f.push(v);
        }
    }
    else {
        u = !0;
        break;
    } if (u) {
    if (e.loadingState = J.FAILED, e.errorTmplIndex === null) {
        let h = new w(-750, !1);
        xu(t, h);
    }
}
else {
    e.loadingState = J.COMPLETE;
    let p = s.tView;
    if (d.length > 0) {
        p.directiveRegistry = Gp(p.directiveRegistry, d);
        let h = d.map(v => v.type), m = Ra(!1, ...h);
        e.providers = m;
    }
    f.length > 0 && (p.pipeRegistry = Gp(p.pipeRegistry, f));
} }), e.loadingPromise.finally(() => { e.loadingPromise = null, c(); })) : (e.loadingPromise = Promise.resolve().then(() => { e.loadingPromise = null, e.loadingState = J.COMPLETE, c(); }), e.loadingPromise); }
function Cv(e, t) { return !(e === 0 && typeof ngServerMode < "u" && ngServerMode || t[V].get(lv, null, { optional: !0 })?.behavior === od.Manual); }
function ge(e, t, n) { let o = t[y], r = t[n.index]; if (!Cv(e, t))
    return; let i = he(t, n), s = re(o, n); switch (Zy(i), s.loadingState) {
    case J.NOT_STARTED:
        Ke(H.Loading, n, r), Ks(s, t, n), s.loadingState === J.IN_PROGRESS && zp(s, n, r);
        break;
    case J.IN_PROGRESS:
        Ke(H.Loading, n, r), zp(s, n, r);
        break;
    case J.COMPLETE:
        Ke(H.Complete, n, r);
        break;
    case J.FAILED:
        Ke(H.Error, n, r);
        break;
    default:
} }
function ct(e, t, n) { return co(this, null, function* () { let o = e.get(rt); if (o.hydrating.has(t))
    return; let { parentBlockPromise: i, hydrationQueue: s } = nM(t, e); if (s.length === 0)
    return; i !== null && s.shift(), bb(o, s), i !== null && (yield i); let a = s[0]; o.has(a) ? yield Zp(e, s, n) : o.awaitParentBlock(a, () => co(null, null, function* () { return yield Zp(e, s, n); })); }); }
function Zp(e, t, n) { return co(this, null, function* () { let o = e.get(rt), r = o.hydrating, i = e.get(Dt), s = i.add(); for (let c = 0; c < t.length; c++) {
    let l = t[c], u = o.get(l);
    if (u != null) {
        if (yield Ab(u), yield Sb(e), wb(u)) {
            bw(u), Yp(t.slice(c), o);
            break;
        }
        r.get(l).resolve();
    }
    else {
        _b(c, t, o), Yp(t.slice(c), o);
        break;
    }
} let a = t[t.length - 1]; yield r.get(a)?.promise, i.remove(s), n && n(t), Sw(o.get(a), t, o, e.get(Oe)); }); }
function wb(e) { return he(e.lView, e.tNode)[at] === H.Error; }
function _b(e, t, n) { let o = e - 1, r = o > -1 ? n.get(t[o]) : null; r && Hs(r.lContainer); }
function Yp(e, t) { let n = t.hydrating; for (let o in e)
    n.get(o)?.reject(); t.cleanup(e); }
function bb(e, t) { for (let n of t)
    e.hydrating.set(n, Promise.withResolvers()); }
function Sb(e) { return new Promise(t => nv(t, { injector: e })); }
function Ab(e) { return co(this, null, function* () { let { tNode: t, lView: n } = e, o = he(n, t); return new Promise(r => { Rb(o, r), ge(2, n, t); }); }); }
function Rb(e, t) { Array.isArray(e[_n]) || (e[_n] = []), e[_n].push(t); }
function z(e, t, n) { return e === 0 ? Kp(t, n) : e === 2 ? !Kp(t, n) : !(typeof ngServerMode < "u" && ngServerMode); }
function kb(e) { return e != null && (e & 1) === 1; }
function Kp(e, t) { let n = e[V], o = re(e[y], t), r = Es(n), i = kb(o.flags); if (typeof ngServerMode < "u" && ngServerMode)
    return !r || !i; let a = he(e, t)[Ws] !== null; return !(i && a && r); }
function St(e, t) { let n = re(e, t); return n.hydrateTriggers ??= new Map; }
function Tv(e, t, n) { let o = [], r = [], i = [], s = []; for (let [a, c] of t) {
    let l = n.get(a);
    if (l !== void 0) {
        let u = c.data[Je], d = l;
        for (let f = 0; f < u; f++) {
            if (d = d.previousSibling, d.nodeType !== Node.ELEMENT_NODE)
                continue;
            let p = { el: d, blockName: a };
            c.hydrate.idle && o.push(p), c.hydrate.immediate && s.push(p), c.hydrate.timer !== null && (p.delay = c.hydrate.timer, r.push(p)), c.hydrate.viewport && i.push(p);
        }
    }
} xb(e, o), Lb(e, s), Ob(e, i), Pb(e, r); }
function xb(e, t) { for (let n of t) {
    let o = e.get(rt), i = Zs(() => ct(e, n.blockName), e);
    o.addCleanupFn(n.blockName, i);
} }
function Ob(e, t) { if (t.length > 0) {
    let n = e.get(rt);
    for (let o of t) {
        let r = cd(o.el, () => ct(e, o.blockName), e);
        n.addCleanupFn(o.blockName, r);
    }
} }
function Pb(e, t) { for (let n of t) {
    let o = e.get(rt), r = () => ct(e, n.blockName), s = Ys(n.delay)(r, e);
    o.addCleanupFn(n.blockName, s);
} }
function Lb(e, t) { for (let n of t)
    ct(e, n.blockName); }
function Mv(e, t, n, o, r, i, s, a, c, l) { let u = g(), d = N(), f = e + I, p = Zt(u, d, e, null, 0, 0), h = u[V]; if (d.firstCreatePass) {
    Z("NgDefer");
    let pe = { primaryTmplIndex: t, loadingTmplIndex: o ?? null, placeholderTmplIndex: r ?? null, errorTmplIndex: i ?? null, placeholderBlockConfig: null, loadingBlockConfig: null, dependencyResolverFn: n ?? null, loadingState: J.NOT_STARTED, loadingPromise: null, providers: null, hydrateTriggers: null, debug: null, flags: l ?? 0 };
    c?.(d, pe, a, s), rb(d, f, pe);
} let m = u[f]; my(m, p, u); let v = null, E = null; if (m[De]?.length > 0) {
    let pe = m[De][0].data;
    E = pe[hs] ?? null, v = pe[dr];
} let A = [null, tr.Initial, null, null, null, null, E, v, null, null]; ob(u, f, A); let ce = null; E !== null && (ce = h.get(rt), ce.add(E, { lView: u, tNode: p, lContainer: m })); let Pe = () => { Zy(A), E !== null && ce?.cleanup([E]); }; Cr(0, A, () => Va(u, Pe)), Xr(u, Pe); }
function Nv(e) { let t = g(), n = Ce(); if (!z(0, t, n))
    return; let o = de(); if (B(t, o, e)) {
    let r = S(null);
    try {
        let i = !!e, a = he(t, n)[at];
        i === !1 && a === tr.Initial ? io(t, n) : i === !0 && (a === tr.Initial || a === H.Placeholder) && ge(0, t, n);
    }
    finally {
        S(r);
    }
} }
function wv(e) { let t = g(), n = Ce(); if (!z(1, t, n))
    return; let o = de(); if (B(t, o, e)) {
    let r = S(null);
    try {
        let i = !!e, s = t[y], a = Ce(), c = re(s, a);
        i === !0 && c.loadingState === J.NOT_STARTED && Nr(c, t, a);
    }
    finally {
        S(r);
    }
} }
function _v(e) { let t = g(), n = Ce(); if (!z(2, t, n))
    return; let o = de(), r = N(); if (St(r, n).set(6, null), B(t, o, e))
    if (typeof ngServerMode < "u" && ngServerMode)
        ge(2, t, n);
    else {
        let s = t[V], a = S(null);
        try {
            if (!!e === !0) {
                let u = he(t, n)[Ws];
                ct(s, u);
            }
        }
        finally {
            S(a);
        }
    } }
function bv() { let e = g(), t = T(); if (!z(2, e, t))
    return; St(N(), t).set(7, null), typeof ngServerMode < "u" && ngServerMode && ge(2, e, t); }
function Sv() { let e = g(), t = T(); z(0, e, t) && Iv(Zs); }
function Av() { let e = g(), t = T(); z(1, e, t) && Ev(Zs); }
function Rv() { let e = g(), t = T(); if (!z(2, e, t))
    return; St(N(), t).set(0, null), typeof ngServerMode < "u" && ngServerMode ? ge(2, e, t) : Dv(Zs, e, t); }
function kv() { let e = g(), t = T(); if (!z(0, e, t))
    return; re(e[y], t).loadingTmplIndex === null && io(e, t), ge(0, e, t); }
function xv() { let e = g(), t = T(); if (!z(1, e, t))
    return; let n = e[y], o = re(n, t); o.loadingState === J.NOT_STARTED && Ks(o, e, t); }
function Ov() { let e = g(), t = T(); if (!z(2, e, t))
    return; if (St(N(), t).set(1, null), typeof ngServerMode < "u" && ngServerMode)
    ge(2, e, t);
else {
    let o = e[V], i = he(e, t)[Ws];
    ct(o, i);
} }
function Pv(e) { let t = g(), n = T(); z(0, t, n) && Iv(Ys(e)); }
function Lv(e) { let t = g(), n = T(); z(1, t, n) && Ev(Ys(e)); }
function Fv(e) { let t = g(), n = T(); if (!z(2, t, n))
    return; St(N(), n).set(5, { delay: e }), typeof ngServerMode < "u" && ngServerMode ? ge(2, t, n) : Dv(Ys(e), t, n); }
function jv(e, t) { let n = g(), o = T(); z(0, n, o) && (io(n, o), typeof ngServerMode < "u" && ngServerMode || ro(n, o, e, t, sg, () => ge(0, n, o), 0)); }
function Vv(e, t) { let n = g(), o = T(); if (!z(1, n, o))
    return; let r = n[y], i = re(r, o); i.loadingState === J.NOT_STARTED && ro(n, o, e, t, sg, () => Nr(i, n, o), 1); }
function Hv() { let e = g(), t = T(); if (!z(2, e, t))
    return; St(N(), t).set(4, null), typeof ngServerMode < "u" && ngServerMode && ge(2, e, t); }
function Bv(e, t) { let n = g(), o = T(); z(0, n, o) && (io(n, o), typeof ngServerMode < "u" && ngServerMode || ro(n, o, e, t, ig, () => ge(0, n, o), 0)); }
function $v(e, t) { let n = g(), o = T(); if (!z(1, n, o))
    return; let r = n[y], i = re(r, o); i.loadingState === J.NOT_STARTED && ro(n, o, e, t, ig, () => Nr(i, n, o), 1); }
function Uv() { let e = g(), t = T(); if (!z(2, e, t))
    return; St(N(), t).set(3, null), typeof ngServerMode < "u" && ngServerMode && ge(2, e, t); }
function Gv(e, t) { let n = g(), o = T(); z(0, n, o) && (io(n, o), typeof ngServerMode < "u" && ngServerMode || ro(n, o, e, t, cd, () => ge(0, n, o), 0)); }
function Wv(e, t) { let n = g(), o = T(); if (!z(1, n, o))
    return; let r = n[y], i = re(r, o); i.loadingState === J.NOT_STARTED && ro(n, o, e, t, cd, () => Nr(i, n, o), 1); }
function qv() { let e = g(), t = T(); if (!z(2, e, t))
    return; St(N(), t).set(2, null), typeof ngServerMode < "u" && ngServerMode && ge(2, e, t); }
var xc = "aria";
function md(e, t) { let n = g(), o = de(); if (B(n, o, t)) {
    let r = N(), i = Ce();
    if (ks(i, r, n, e, t))
        me(i) && gm(n, i.index);
    else {
        let a = ne(i, n), c = Fb(e);
        Ss(n[C], a, null, i.value, c, t, null);
    }
} return md; }
function Fb(e) { return e.charAt(xc.length) !== "-" ? xc + "-" + e.slice(xc.length).toLowerCase() : e; }
function yd(e, t, n, o) { let r = g(), i = de(); if (B(r, i, t)) {
    let s = N(), a = Ce();
    IN(a, r, e, t, n, o);
} return yd; }
var zv = new _("", { providedIn: "root", factory: () => !1 }), jb = new _("", { providedIn: "root", factory: () => Vb }), Vb = 4e3, Ki = class {
    outElements = new WeakMap;
    remove(t) { this.outElements.delete(t); }
    trackClasses(t, n) { let o = Qv(n); if (o)
        for (let r of o)
            t.classes?.add(r); }
    trackResolver(t, n) { t.classFns ? t.classFns.push(n) : t.classFns = [n]; }
    addCallback(t, n, o) { let r = this.outElements.get(t) ?? { classes: null, animateFn: () => { } }; r.animateFn = o(t, n), this.outElements.set(t, r); }
    add(t, n, o) { let r = this.outElements.get(t) ?? { classes: new Set, animateFn: () => { } }; typeof n == "function" ? this.trackResolver(r, n) : this.trackClasses(r, n), r.animateFn = o(t, r.classes, r.classFns), this.outElements.set(t, r); }
    has(t) { return this.outElements.has(t); }
    animate(t, n, o) { if (!this.outElements.has(t))
        return n(); let r = this.outElements.get(t), i, s = !1, a = () => { s || (s = !0, clearTimeout(i), this.remove(t), n()); }; i = setTimeout(a, o), r.animateFn(a); }
};
function Qv(e) { let t = typeof e == "function" ? e() : e, n = Array.isArray(t) ? t : null; return typeof t == "string" && (n = t.trim().split(/\s+/).filter(o => o)), n; }
function Ji(e) { let t = e.toLowerCase().indexOf("ms") > -1 ? 1 : 1e3; return parseFloat(e) * t; }
function bn(e, t) { return e.getPropertyValue(t).split(",").map(o => o.trim()); }
function Hb(e) { let t = bn(e, "transition-property"), n = bn(e, "transition-duration"), o = bn(e, "transition-delay"), r = { propertyName: "", duration: 0, animationName: void 0 }; for (let i = 0; i < t.length; i++) {
    let s = Ji(o[i]) + Ji(n[i]);
    s > r.duration && (r.propertyName = t[i], r.duration = s);
} return r; }
function Bb(e) { let t = bn(e, "animation-name"), n = bn(e, "animation-delay"), o = bn(e, "animation-duration"), r = { animationName: "", propertyName: void 0, duration: 0 }; for (let i = 0; i < t.length; i++) {
    let s = Ji(n[i]) + Ji(o[i]);
    s > r.duration && (r.animationName = t[i], r.duration = s);
} return r; }
function Zv(e, t) { return e !== void 0 && e.duration > t.duration; }
function Yv(e) { return (e.animationName != null || e.propertyName != null) && e.duration > 0; }
function $b(e, t) { let n = getComputedStyle(e), o = Bb(n), r = Hb(n), i = o.duration > r.duration ? o : r; Zv(t.get(e), i) || Yv(i) && t.set(e, i); }
function Kv(e, t, n) { if (!n)
    return; let o = e.getAnimations(); return o.length === 0 ? $b(e, t) : Ub(e, t, o); }
function Ub(e, t, n) { let o = { animationName: void 0, propertyName: void 0, duration: 0 }; for (let r of n) {
    let i = r.effect?.getTiming(), s = typeof i?.duration == "number" ? i.duration : 0, a = (i?.delay ?? 0) + s, c, l;
    r.animationName ? l = r.animationName : c = r.transitionProperty, a >= o.duration && (o = { animationName: l, propertyName: c, duration: a });
} Zv(t.get(e), o) || Yv(o) && t.set(e, o); }
var Gb = !1, bt = (typeof ngServerMode > "u" || !ngServerMode) && typeof document < "u" && typeof document?.documentElement?.getAnimations == "function";
function Js(e) { return e[V].get(zv, Gb); }
function Jv(e, t, n, o) { t[b] & 8 && Ha(n, t, o, r => { e.elements.remove(r); }); }
function vd(e) { let t = Yt.get(e); if (t) {
    for (let n of t.cleanupFns)
        n();
    Yt.delete(e);
} Tt.delete(e); }
var Wb = () => { }, Yt = new WeakMap, Tt = new WeakMap, Gt = new WeakMap;
function Al(e) { Gt.get(e)?.length === 0 && Gt.delete(e); }
function Xv(e, t) { Gt.has(e) ? Gt.get(e)?.push(t) : Gt.set(e, [t]); }
function Po(e) { if (Z("NgAnimateEnter"), typeof ngServerMode < "u" && ngServerMode || !bt)
    return Po; let t = g(); if (Js(t))
    return Po; let n = T(), o = ne(n, t), r = t[C], i = t[V].get(L), s = Qv(e), a = [], c = u => { Zb(u, r); let d = u instanceof AnimationEvent ? "animationend" : "transitionend"; i.runOutsideAngular(() => { a.push(r.listen(o, d, l)); }); }, l = u => { Yb(u, o, r); }; if (s && s.length > 0) {
    i.runOutsideAngular(() => { a.push(r.listen(o, "animationstart", c)), a.push(r.listen(o, "transitionstart", c)); }), Gt.get(n)?.pop()?.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } })), qb(o, s, a);
    for (let u of s)
        r.addClass(o, u);
    i.runOutsideAngular(() => { requestAnimationFrame(() => { if (Kv(o, Tt, bt), !Tt.has(o)) {
        for (let u of s)
            r.removeClass(o, u);
        vd(o);
    } }); });
} return Po; }
function qb(e, t, n) { let o = Yt.get(e); if (o) {
    for (let r of t)
        o.classList.push(r);
    for (let r of n)
        o.cleanupFns.push(r);
}
else
    Yt.set(e, { classList: t, cleanupFns: n }); }
function Lo(e) { if (Z("NgAnimateEnter"), typeof ngServerMode < "u" && ngServerMode || !bt)
    return Lo; let t = g(); if (Js(t))
    return Lo; let n = T(), o = ne(n, t); return Gt.get(n)?.pop()?.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } })), e.call(t[P], { target: o, animationComplete: Wb }), Lo; }
function Fo(e) { if (Z("NgAnimateLeave"), typeof ngServerMode < "u" && ngServerMode || !bt)
    return Fo; let t = g(), n = Js(t); if (n)
    return Fo; let o = N(), r = T(), i = ne(r, t), s = t[C], a = si(), c = t[V].get(L), l = (u, d, f) => p => { Kb(u, r, zb(d, f), p, s, n, c); }; return Jv(a, t, o, i), a.elements.add(i, e, l), Fo; }
function jo(e) { if (Z("NgAnimateLeave"), typeof ngServerMode < "u" && ngServerMode || !bt)
    return jo; let t = g(), n = T(), o = N(), r = ne(n, t); if (r.nodeType !== Node.ELEMENT_NODE)
    return jo; let i = si(), s = t[C], a = Js(t), c = t[V].get(L), l = (u, d) => f => { if (a)
    f();
else {
    let p = { target: r, animationComplete: () => { Al(n), f(); } };
    Xv(n, u), c.runOutsideAngular(() => { s.listen(u, "animationend", () => f(), { once: !0 }); }), d.call(t[P], p);
} }; return Jv(i, t, o, r), i.elements.addCallback(r, e, l), jo; }
function zb(e, t) { let n = new Set(e); if (t && t.length)
    for (let o of t) {
        let r = o();
        if (r instanceof Array)
            for (let i of r)
                n.add(i);
        else
            n.add(r);
    } return n; }
function Qb(e, t) { if (!bt)
    return; let n = Yt.get(e); if (e.getAnimations().length > 0)
    for (let o of e.getAnimations())
        o.playState === "running" && o.cancel();
else if (n)
    for (let o of n.classList)
        t.removeClass(e, o); vd(e); }
function Zb(e, t) { if (!(e.target instanceof Element))
    return; let n = e.target; if (bt) {
    let o = Yt.get(n), r = n.getAnimations();
    if (r.length === 0)
        return;
    for (let i of r)
        i.addEventListener("cancel", s => { if (n === s.target && o?.classList)
            for (let a of o.classList)
                t.removeClass(n, a); });
} }
function eI(e, t) { let n = Tt.get(t); return t === e.target && n !== void 0 && (n.animationName !== void 0 && e.animationName === n.animationName || n.propertyName !== void 0 && e.propertyName === n.propertyName); }
function Yb(e, t, n) { let o = Yt.get(t); if (o && eI(e, t)) {
    e.stopImmediatePropagation();
    for (let r of o.classList)
        n.removeClass(t, r);
    vd(t);
} }
function Kb(e, t, n, o, r, i, s) { if (i) {
    Tt.delete(e), o();
    return;
} Qb(e, r); let a = c => { (c instanceof CustomEvent || eI(c, e)) && (c.stopImmediatePropagation(), Tt.delete(e), Al(t), o()); }; s.runOutsideAngular(() => { r.listen(e, "animationend", a), r.listen(e, "transitionend", a); }), Xv(t, e); for (let c of n)
    r.addClass(e, c); s.runOutsideAngular(() => { requestAnimationFrame(() => { Kv(e, Tt, bt), Tt.has(e) || (Al(t), o()); }); }); }
function tI() { return g()[Q][P]; }
var Rl = class {
    destroy(t) { }
    updateValue(t, n) { }
    swap(t, n) { let o = Math.min(t, n), r = Math.max(t, n), i = this.detach(r); if (r - o > 1) {
        let s = this.detach(o);
        this.attach(o, i), this.attach(r, s);
    }
    else
        this.attach(o, i); }
    move(t, n) { this.attach(n, this.detach(t)); }
};
function Oc(e, t, n, o, r) { return e === n && Object.is(t, o) ? 1 : Object.is(r(e, t), r(n, o)) ? -1 : 0; }
function Jb(e, t, n) { let o, r, i = 0, s = e.length - 1, a = void 0; if (Array.isArray(t)) {
    let c = t.length - 1;
    for (; i <= s && i <= c;) {
        let l = e.at(i), u = t[i], d = Oc(i, l, i, u, n);
        if (d !== 0) {
            d < 0 && e.updateValue(i, u), i++;
            continue;
        }
        let f = e.at(s), p = t[c], h = Oc(s, f, c, p, n);
        if (h !== 0) {
            h < 0 && e.updateValue(s, p), s--, c--;
            continue;
        }
        let m = n(i, l), v = n(s, f), E = n(i, u);
        if (Object.is(E, v)) {
            let A = n(c, p);
            Object.is(A, m) ? (e.swap(i, s), e.updateValue(s, p), c--, s--) : e.move(s, i), e.updateValue(i, u), i++;
            continue;
        }
        if (o ??= new Xi, r ??= Xp(e, i, s, n), kl(e, o, i, E))
            e.updateValue(i, u), i++, s++;
        else if (r.has(E))
            o.set(m, e.detach(i)), s--;
        else {
            let A = e.create(i, t[i]);
            e.attach(i, A), i++, s++;
        }
    }
    for (; i <= c;)
        Jp(e, o, n, i, t[i]), i++;
}
else if (t != null) {
    let c = t[Symbol.iterator](), l = c.next();
    for (; !l.done && i <= s;) {
        let u = e.at(i), d = l.value, f = Oc(i, u, i, d, n);
        if (f !== 0)
            f < 0 && e.updateValue(i, d), i++, l = c.next();
        else {
            o ??= new Xi, r ??= Xp(e, i, s, n);
            let p = n(i, d);
            if (kl(e, o, i, p))
                e.updateValue(i, d), i++, s++, l = c.next();
            else if (!r.has(p))
                e.attach(i, e.create(i, d)), i++, s++, l = c.next();
            else {
                let h = n(i, u);
                o.set(h, e.detach(i)), s--;
            }
        }
    }
    for (; !l.done;)
        Jp(e, o, n, e.length, l.value), l = c.next();
} for (; i <= s;)
    e.destroy(e.detach(s--)); o?.forEach(c => { e.destroy(c); }); }
function kl(e, t, n, o) { return t !== void 0 && t.has(o) ? (e.attach(n, t.get(o)), t.delete(o), !0) : !1; }
function Jp(e, t, n, o, r) { if (kl(e, t, o, n(o, r)))
    e.updateValue(o, r);
else {
    let i = e.create(o, r);
    e.attach(o, i);
} }
function Xp(e, t, n, o) { let r = new Set; for (let i = t; i <= n; i++)
    r.add(o(i, e.at(i))); return r; }
var Xi = class {
    kvMap = new Map;
    _vMap = void 0;
    has(t) { return this.kvMap.has(t); }
    delete(t) { if (!this.has(t))
        return !1; let n = this.kvMap.get(t); return this._vMap !== void 0 && this._vMap.has(n) ? (this.kvMap.set(t, this._vMap.get(n)), this._vMap.delete(n)) : this.kvMap.delete(t), !0; }
    get(t) { return this.kvMap.get(t); }
    set(t, n) { if (this.kvMap.has(t)) {
        let o = this.kvMap.get(t);
        this._vMap === void 0 && (this._vMap = new Map);
        let r = this._vMap;
        for (; r.has(o);)
            o = r.get(o);
        r.set(o, n);
    }
    else
        this.kvMap.set(t, n); }
    forEach(t) { for (let [n, o] of this.kvMap)
        if (t(o, n), this._vMap !== void 0) {
            let r = this._vMap;
            for (; r.has(o);)
                o = r.get(o), t(o, n);
        } }
};
function nI(e, t, n, o, r, i, s, a) { Z("NgControlFlow"); let c = g(), l = N(), u = ae(l.consts, i); return Zt(c, l, e, t, n, o, r, u, 256, s, a), Xs; }
function Xs(e, t, n, o, r, i, s, a) { Z("NgControlFlow"); let c = g(), l = N(), u = ae(l.consts, i); return Zt(c, l, e, t, n, o, r, u, 512, s, a), Xs; }
function oI(e, t) { Z("NgControlFlow"); let n = g(), o = de(), r = n[o] !== x ? n[o] : -1, i = r !== -1 ? es(n, I + r) : void 0, s = 0; if (B(n, o, e)) {
    let a = S(null);
    try {
        if (i !== void 0 && Pu(i, s), e !== -1) {
            let c = I + e, l = es(n, c), u = Ll(n[y], c), d = Jm(l, u, n), f = Xn(n, u, t, { dehydratedView: d });
            eo(l, f, s, zt(u, d));
        }
    }
    finally {
        S(a);
    }
}
else if (i !== void 0) {
    let a = _m(i, s);
    a !== void 0 && (a[P] = t);
} }
var xl = class {
    lContainer;
    $implicit;
    $index;
    constructor(t, n, o) { this.lContainer = t, this.$implicit = n, this.$index = o; }
    get $count() { return this.lContainer.length - G; }
};
function rI(e) { return e; }
function iI(e, t) { return t; }
var Ol = class {
    hasEmptyBlock;
    trackByFn;
    liveCollection;
    constructor(t, n, o) { this.hasEmptyBlock = t, this.trackByFn = n, this.liveCollection = o; }
};
function sI(e, t, n, o, r, i, s, a, c, l, u, d, f) { Z("NgControlFlow"); let p = g(), h = N(), m = c !== void 0, v = g(), E = a ? s.bind(v[Q][P]) : s, A = new Ol(m, E); v[I + e] = A, Zt(p, h, e + 1, t, n, o, r, ae(h.consts, i), 256), m && Zt(p, h, e + 2, c, l, u, d, ae(h.consts, f), 512); }
var Pl = class extends Rl {
    lContainer;
    hostLView;
    templateTNode;
    operationsCounter = void 0;
    needsIndexUpdate = !1;
    constructor(t, n, o) { super(), this.lContainer = t, this.hostLView = n, this.templateTNode = o; }
    get length() { return this.lContainer.length - G; }
    at(t) { return this.getLView(t)[P].$implicit; }
    attach(t, n) { let o = n[te]; this.needsIndexUpdate ||= t !== this.length, eo(this.lContainer, n, t, zt(this.templateTNode, o)); }
    detach(t) { return this.needsIndexUpdate ||= t !== this.length - 1, Xb(this.lContainer, t); }
    create(t, n) { let o = Yo(this.lContainer, this.templateTNode.tView.ssrId), r = Xn(this.hostLView, this.templateTNode, new xl(this.lContainer, n, t), { dehydratedView: o }); return this.operationsCounter?.recordCreate(), r; }
    destroy(t) { yr(t[y], t), this.operationsCounter?.recordDestroy(); }
    updateValue(t, n) { this.getLView(t)[P].$implicit = n; }
    reset() { this.needsIndexUpdate = !1, this.operationsCounter?.reset(); }
    updateIndexes() { if (this.needsIndexUpdate)
        for (let t = 0; t < this.length; t++)
            this.getLView(t)[P].$index = t; }
    getLView(t) { return eS(this.lContainer, t); }
};
function aI(e) { let t = S(null), n = oe(); try {
    let o = g(), r = o[y], i = o[n], s = n + 1, a = es(o, s);
    if (i.liveCollection === void 0) {
        let l = Ll(r, s);
        i.liveCollection = new Pl(a, o, l);
    }
    else
        i.liveCollection.reset();
    let c = i.liveCollection;
    if (Jb(c, e, i.trackByFn), c.updateIndexes(), i.hasEmptyBlock) {
        let l = de(), u = c.length === 0;
        if (B(o, l, u)) {
            let d = n + 2, f = es(o, d);
            if (u) {
                let p = Ll(r, d), h = Jm(f, p, o), m = Xn(o, p, void 0, { dehydratedView: h });
                eo(f, m, 0, zt(p, h));
            }
            else
                r.firstUpdatePass && Vs(f), Pu(f, 0);
        }
    }
}
finally {
    S(t);
} }
function es(e, t) { return e[t]; }
function Xb(e, t) { return Qo(e, t); }
function eS(e, t) { return _m(e, t); }
function Ll(e, t) { return yt(e, t); }
function Id(e, t, n) { let o = g(), r = de(); if (B(o, r, t)) {
    let i = N(), s = Ce();
    Au(s, o, e, t, o[C], n);
} return Id; }
function Fl(e, t, n, o, r) { ks(t, e, n, r ? "class" : "style", o); }
function ea(e, t, n, o) { let r = g(), i = r[y], s = e + I, a = i.firstCreatePass ? Bu(s, r, 2, t, ku, ti(), n, o) : i.data[s]; if (As(a, r, e, t, Cd), un(a)) {
    let c = r[y];
    bs(c, r, a), pu(c, a, r);
} return o != null && Jn(r, a), ea; }
function ta() { let e = N(), t = T(), n = Rs(t); return e.firstCreatePass && $u(e, n), $a(n) && Wa(), Ba(), n.classesWithoutHost != null && WC(n) && Fl(e, n, g(), n.classesWithoutHost, !0), n.stylesWithoutHost != null && qC(n) && Fl(e, n, g(), n.stylesWithoutHost, !1), ta; }
function Ed(e, t, n, o) { return ea(e, t, n, o), ta(), Ed; }
function na(e, t, n, o) { let r = g(), i = r[y], s = e + I, a = i.firstCreatePass ? iy(s, i, 2, t, n, o) : i.data[s]; return As(a, r, e, t, Cd), o != null && Jn(r, a), na; }
function oa() { let e = T(), t = Rs(e); return $a(t) && Wa(), Ba(), oa; }
function Dd(e, t, n, o) { return na(e, t, n, o), oa(), Dd; }
var Cd = (e, t, n, o, r) => (ke(!0), Ms(t[C], o, cc()));
function tS(e, t, n, o, r) { let i = !Cs(t, n); if (ke(i), i)
    return Ms(t[C], o, cc()); let s = t[te], a = Ir(s, e, t, n); return Eg(s, r) && Is(s, r, a.nextSibling), s && (Yl(n) || $h(a)) && me(n) && (Bf(n), Jg(a)), a; }
function cI() { Cd = tS; }
function ra(e, t, n) { let o = g(), r = o[y], i = e + I, s = r.firstCreatePass ? Bu(i, o, 8, "ng-container", ku, ti(), t, n) : r.data[i]; if (As(s, o, e, "ng-container", wd), un(s)) {
    let a = o[y];
    bs(a, o, s), pu(a, s, o);
} return n != null && Jn(o, s), ra; }
function wr() { let e = N(), t = T(), n = Rs(t); return e.firstCreatePass && $u(e, n), wr; }
function Td(e, t, n) { return ra(e, t, n), wr(), Td; }
function ia(e, t, n) { let o = g(), r = o[y], i = e + I, s = r.firstCreatePass ? iy(i, r, 8, "ng-container", t, n) : r.data[i]; return As(s, o, e, "ng-container", wd), n != null && Jn(o, s), ia; }
function Md() { let e = T(), t = Rs(e); return wr; }
function Nd(e, t, n) { return ia(e, t, n), Md(), Nd; }
var wd = (e, t, n, o, r) => (ke(!0), Du(t[C], ""));
function nS(e, t, n, o, r) { let i, s = !Cs(t, n); if (ke(s), s)
    return Du(t[C], ""); let a = t[te], c = Ir(a, e, t, n), l = Ig(a, r); return Is(a, r, c), i = Fs(l, c), i; }
function lI() { wd = nS; }
function uI() { return g(); }
function _d(e, t, n) { let o = g(), r = de(); if (B(o, r, t)) {
    let i = N(), s = Ce();
    Ru(s, o, e, t, o[C], n);
} return _d; }
function bd(e, t, n) { let o = g(), r = de(); if (B(o, r, t)) {
    let i = N(), s = Ce(), a = ni(i.data), c = mm(a, s, o);
    Ru(s, o, e, t, c, n);
} return bd; }
var Ht = void 0;
function oS(e) { let t = Math.floor(Math.abs(e)), n = e.toString().replace(/^[^.]*\.?/, "").length; return t === 1 && n === 0 ? 1 : 5; }
var rS = ["en", [["a", "p"], ["AM", "PM"], Ht], [["AM", "PM"], Ht, Ht], [["S", "M", "T", "W", "T", "F", "S"], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]], Ht, [["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]], Ht, [["B", "A"], ["BC", "AD"], ["Before Christ", "Anno Domini"]], 0, [6, 0], ["M/d/yy", "MMM d, y", "MMMM d, y", "EEEE, MMMM d, y"], ["h:mm a", "h:mm:ss a", "h:mm:ss a z", "h:mm:ss a zzzz"], ["{1}, {0}", Ht, "{1} 'at' {0}", Ht], [".", ",", ";", "%", "+", "-", "E", "\xD7", "\u2030", "\u221E", "NaN", ":"], ["#,##0.###", "#,##0%", "\xA4#,##0.00", "#E0"], "USD", "$", "US Dollar", {}, "ltr", oS], Sn = {};
function iS(e, t, n) { typeof t != "string" && (n = t, t = e[jn.LocaleId]), t = t.toLowerCase().replace(/_/g, "-"), Sn[t] = e, n && (Sn[t][jn.ExtraData] = n); }
function Sd(e) { let t = cS(e), n = eh(t); if (n)
    return n; let o = t.split("-")[0]; if (n = eh(o), n)
    return n; if (o === "en")
    return rS; throw new w(701, !1); }
function sS(e) { return Sd(e)[jn.CurrencyCode] || null; }
function dI(e) { return Sd(e)[jn.PluralCase]; }
function eh(e) { return e in Sn || (Sn[e] = Ie.ng && Ie.ng.common && Ie.ng.common.locales && Ie.ng.common.locales[e]), Sn[e]; }
function aS() { Sn = {}; }
var jn = (function (e) { return e[e.LocaleId = 0] = "LocaleId", e[e.DayPeriodsFormat = 1] = "DayPeriodsFormat", e[e.DayPeriodsStandalone = 2] = "DayPeriodsStandalone", e[e.DaysFormat = 3] = "DaysFormat", e[e.DaysStandalone = 4] = "DaysStandalone", e[e.MonthsFormat = 5] = "MonthsFormat", e[e.MonthsStandalone = 6] = "MonthsStandalone", e[e.Eras = 7] = "Eras", e[e.FirstDayOfWeek = 8] = "FirstDayOfWeek", e[e.WeekendRange = 9] = "WeekendRange", e[e.DateFormat = 10] = "DateFormat", e[e.TimeFormat = 11] = "TimeFormat", e[e.DateTimeFormat = 12] = "DateTimeFormat", e[e.NumberSymbols = 13] = "NumberSymbols", e[e.NumberFormats = 14] = "NumberFormats", e[e.CurrencyCode = 15] = "CurrencyCode", e[e.CurrencySymbol = 16] = "CurrencySymbol", e[e.CurrencyName = 17] = "CurrencyName", e[e.Currencies = 18] = "Currencies", e[e.Directionality = 19] = "Directionality", e[e.PluralCase = 20] = "PluralCase", e[e.ExtraData = 21] = "ExtraData", e; })(jn || {});
function cS(e) { return e.toLowerCase().replace(/_/g, "-"); }
var lS = ["zero", "one", "two", "few", "many"];
function uS(e, t) { let n = dI(t)(parseInt(e, 10)), o = lS[n]; return o !== void 0 ? o : "other"; }
var _r = "en-US", dS = "USD", fI = { marker: "element" }, pI = { marker: "ICU" }, Ze = (function (e) { return e[e.SHIFT = 2] = "SHIFT", e[e.APPEND_EAGERLY = 1] = "APPEND_EAGERLY", e[e.COMMENT = 2] = "COMMENT", e; })(Ze || {}), hI = _r;
function gI(e) { typeof e == "string" && (hI = e.toLowerCase().replace(/_/g, "-")); }
function fS() { return hI; }
var or = 0, Vo = 0;
function pS(e) { e && (or = or | 1 << Math.min(Vo, 31)), Vo++; }
function hS(e, t, n) { if (Vo > 0) {
    let o = e.data[n], r = Array.isArray(o) ? o : o.update, i = Be() - Vo - 1;
    II(e, t, r, i, or);
} or = 0, Vo = 0; }
function mI(e, t, n) { let o = e[C]; switch (n) {
    case Node.COMMENT_NODE: return Du(o, t);
    case Node.TEXT_NODE: return Eu(o, t);
    case Node.ELEMENT_NODE: return Ms(o, t, null);
} }
var Ho = (e, t, n, o) => (ke(!0), mI(e, n, o));
function gS(e, t, n, o) { let r = e[te], i = t - I, s = !js() || !r || Mo() || Ds(r, i); return ke(s), s ? mI(e, n, o) : Lm(r, i); }
function yI() { Ho = gS; }
function mS(e, t, n, o) { let r = e[C]; for (let i = 0; i < t.length; i++) {
    let s = t[i++], a = t[i], c = (s & Ze.COMMENT) === Ze.COMMENT, l = (s & Ze.APPEND_EAGERLY) === Ze.APPEND_EAGERLY, u = s >>> Ze.SHIFT, d = e[u], f = !1;
    d === null && (d = e[u] = Ho(e, u, a, c ? Node.COMMENT_NODE : Node.TEXT_NODE), f = wo()), l && n !== null && f && qt(r, n, d, o, !1);
} }
function vI(e, t, n, o) { let r = n[C], i = null, s; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "string") {
        let l = t[++a];
        n[l] === null && (n[l] = Ho(n, l, c, Node.TEXT_NODE));
    }
    else if (typeof c == "number")
        switch (c & 1) {
            case 0:
                let l = iw(c);
                i === null && (i = l, s = r.parentNode(o));
                let u, d;
                if (l === i ? (u = o, d = s) : (u = null, d = R(n[l])), d !== null) {
                    let m = sw(c), v = n[m];
                    qt(r, d, v, u, !1);
                    let E = Ro(e, m);
                    if (E !== null && typeof E == "object") {
                        let A = Ls(E, n);
                        A !== null && vI(e, E.create[A], n, n[E.anchorIdx]);
                    }
                }
                break;
            case 1:
                let f = c >>> 1, p = t[++a], h = t[++a];
                Ss(r, Ft(f, n), null, null, p, h, null);
                break;
            default:
        }
    else
        switch (c) {
            case pI:
                let l = t[++a], u = t[++a];
                if (n[u] === null) {
                    let p = n[u] = Ho(n, u, l, Node.COMMENT_NODE);
                    _e(p, n);
                }
                break;
            case fI:
                let d = t[++a], f = t[++a];
                if (n[f] === null) {
                    let p = n[f] = Ho(n, f, d, Node.ELEMENT_NODE);
                    _e(p, n);
                }
                break;
            default:
        }
} }
function II(e, t, n, o, r) { for (let i = 0; i < n.length; i++) {
    let s = n[i], a = n[++i];
    if (s & r) {
        let c = "";
        for (let l = i + 1; l <= i + a; l++) {
            let u = n[l];
            if (typeof u == "string")
                c += u;
            else if (typeof u == "number")
                if (u < 0)
                    c += M(t[o - u]);
                else {
                    let d = u >>> 2;
                    switch (u & 3) {
                        case 1:
                            let f = n[++l], p = n[++l], h = e.data[d];
                            typeof h == "string" ? Ss(t[C], t[d], null, h, f, c, p) : Au(h, t, f, c, t[C], p);
                            break;
                        case 0:
                            let m = t[d];
                            m !== null && Yg(t[C], m, c);
                            break;
                        case 2:
                            yS(e, Ro(e, d), t, c);
                            break;
                        case 3:
                            th(e, Ro(e, d), o, t);
                            break;
                    }
                }
        }
    }
    else {
        let c = n[i + 1];
        if (c > 0 && (c & 3) === 3) {
            let l = c >>> 2, u = Ro(e, l);
            t[u.currentCaseLViewIndex] < 0 && th(e, u, o, t);
        }
    }
    i += a;
} }
function th(e, t, n, o) { let r = o[t.currentCaseLViewIndex]; if (r !== null) {
    let i = or;
    r < 0 && (r = o[t.currentCaseLViewIndex] = ~r, i = -1), II(e, o, t.update[r], n, i);
} }
function yS(e, t, n, o) { let r = vS(t, o); if (Ls(t, n) !== r && (EI(e, t, n), n[t.currentCaseLViewIndex] = r === null ? null : ~r, r !== null)) {
    let s = n[t.anchorIdx];
    s && vI(e, t.create[r], n, s), Mw(n, t.anchorIdx, r);
} }
function EI(e, t, n) { let o = Ls(t, n); if (o !== null) {
    let r = t.remove[o];
    for (let i = 0; i < r.length; i++) {
        let s = r[i];
        if (s > 0) {
            let a = Ft(s, n);
            a !== null && gr(n[C], a);
        }
        else
            EI(e, Ro(e, ~s), n);
    }
} }
function vS(e, t) { let n = e.cases.indexOf(t); if (n === -1)
    switch (e.type) {
        case 1: {
            let o = uS(t, fS());
            n = e.cases.indexOf(o), n === -1 && o !== "other" && (n = e.cases.indexOf("other"));
            break;
        }
        case 0: {
            n = e.cases.indexOf("other");
            break;
        }
    } return n === -1 ? null : n; }
var ts = /�(\d+):?\d*�/gi, IS = /({\s*�\d+:?\d*�\s*,\s*\S{6}\s*,[\s\S]*})/gi, ES = /�(\d+)�/, DI = /^\s*(�\d+:?\d*�)\s*,\s*(select|plural)\s*,/, Bo = "\uFFFD", DS = /�\/?\*(\d+:\d+)�/gi, CS = /�(\/?[#*]\d+):?\d*�/gi, TS = /\uE500/g;
function MS(e) { return e.replace(TS, " "); }
function NS(e, t, n, o, r, i) { let s = dn(), a = [], c = [], l = [[]], u = [[]]; r = SS(r, i); let d = MS(r).split(CS); for (let f = 0; f < d.length; f++) {
    let p = d[f];
    if ((f & 1) === 0) {
        let h = jl(p);
        for (let m = 0; m < h.length; m++) {
            let v = h[m];
            if ((m & 1) === 0) {
                let E = v;
                E !== "" && wS(u[0], e, s, l[0], a, c, n, E);
            }
            else {
                let E = v;
                if (typeof E != "object")
                    throw new Error(`Unable to parse ICU expression in "${r}" message.`);
                let ce = CI(e, s, l[0], n, a, "", !0).index;
                MI(u[0], e, n, c, t, E, ce);
            }
        }
    }
    else {
        let h = p.charCodeAt(0) === 47, m = p.charCodeAt(h ? 1 : 0), v = I + Number.parseInt(p.substring(h ? 2 : 1));
        if (h)
            l.shift(), u.shift(), He(dn(), !1);
        else {
            let E = rw(e, l[0], v);
            l.unshift([]), He(E, !0);
            let A = { kind: 2, index: v, children: [], type: m === 35 ? 0 : 1 };
            u[0].push(A), u.unshift(A.children);
        }
    }
} e.data[o] = { create: a, update: c, ast: u[0], parentTNodeIndex: t }; }
function CI(e, t, n, o, r, i, s) { let a = mr(e, o, 1, null), c = a << Ze.SHIFT, l = dn(); t === l && (l = null), l === null && (c |= Ze.APPEND_EAGERLY), s && (c |= Ze.COMMENT, rN(cw)), r.push(c, i === null ? "" : i); let u = Lu(e, a, s ? 32 : 1, i === null ? "" : i, null); km(n, u); let d = u.index; return He(u, !1), l !== null && t !== l && ow(l, d), u; }
function wS(e, t, n, o, r, i, s, a) { let c = a.match(ts), u = CI(t, n, o, s, r, c ? null : a, !1).index; c && $o(i, a, u, null, 0, null), e.push({ kind: 0, index: u }); }
function _S(e, t, n) { let r = T().index, i = []; if (e.firstCreatePass && e.data[t] === null) {
    for (let s = 0; s < n.length; s += 2) {
        let a = n[s], c = n[s + 1];
        if (c !== "") {
            if (IS.test(c))
                throw new Error(`ICU expressions are not supported in attributes. Message: "${c}".`);
            $o(i, c, r, a, bS(i), null);
        }
    }
    e.data[t] = i;
} }
function $o(e, t, n, o, r, i) { let s = e.length, a = s + 1; e.push(null, null); let c = s + 2, l = t.split(ts), u = 0; for (let d = 0; d < l.length; d++) {
    let f = l[d];
    if (d & 1) {
        let p = r + parseInt(f, 10);
        e.push(-1 - p), u = u | TI(p);
    }
    else
        f !== "" && e.push(f);
} return e.push(n << 2 | (o ? 1 : 0)), o && e.push(o, i), e[s] = u, e[a] = e.length - c, u; }
function bS(e) { let t = 0; for (let n = 0; n < e.length; n++) {
    let o = e[n];
    typeof o == "number" && o < 0 && t++;
} return t; }
function TI(e) { return 1 << Math.min(e, 31); }
function nh(e) { let t, n = "", o = 0, r = !1, i; for (; (t = DS.exec(e)) !== null;)
    r ? t[0] === `${Bo}/*${i}${Bo}` && (o = t.index, r = !1) : (n += e.substring(o, t.index + t[0].length), i = t[1], r = !0); return n += e.slice(o), n; }
function SS(e, t) { if (Om(t))
    return nh(e); {
    let n = e.indexOf(`:${t}${Bo}`) + 2 + t.toString().length, o = e.search(new RegExp(`${Bo}\\/\\*\\d+:${t}${Bo}`));
    return nh(e.substring(n, o));
} }
function MI(e, t, n, o, r, i, s) { let a = 0, c = { type: i.type, currentCaseLViewIndex: mr(t, n, 1, null), anchorIdx: s, cases: [], create: [], remove: [], update: [] }; xS(o, i, s), nw(t, s, c); let l = i.values, u = []; for (let d = 0; d < l.length; d++) {
    let f = l[d], p = [];
    for (let m = 0; m < f.length; m++) {
        let v = f[m];
        if (typeof v != "string") {
            let E = p.push(v) - 1;
            f[m] = `<!--\uFFFD${E}\uFFFD-->`;
        }
    }
    let h = [];
    u.push(h), a = RS(h, t, c, n, o, r, i.cases[d], f.join(""), p) | a;
} a && OS(o, a, s), e.push({ kind: 3, index: s, cases: u, currentCaseLViewIndex: c.currentCaseLViewIndex }); }
function AS(e) { let t = [], n = [], o = 1, r = 0; e = e.replace(DI, function (s, a, c) { return c === "select" ? o = 0 : o = 1, r = parseInt(a.slice(1), 10), ""; }); let i = jl(e); for (let s = 0; s < i.length;) {
    let a = i[s++].trim();
    o === 1 && (a = a.replace(/\s*(?:=)?(\w+)\s*/, "$1")), a.length && t.push(a);
    let c = jl(i[s++]);
    t.length > n.length && n.push(c);
} return { type: o, mainBinding: r, cases: t, values: n }; }
function jl(e) { if (!e)
    return []; let t = 0, n = [], o = [], r = /[{}]/g; r.lastIndex = 0; let i; for (; i = r.exec(e);) {
    let a = i.index;
    if (i[0] == "}") {
        if (n.pop(), n.length == 0) {
            let c = e.substring(t, a);
            DI.test(c) ? o.push(AS(c)) : o.push(c), t = a + 1;
        }
    }
    else {
        if (n.length == 0) {
            let c = e.substring(t, a);
            o.push(c), t = a + 1;
        }
        n.push("{");
    }
} let s = e.substring(t); return o.push(s), o; }
function RS(e, t, n, o, r, i, s, a, c) { let l = [], u = [], d = []; n.cases.push(s), n.create.push(l), n.remove.push(u), n.update.push(d); let p = Rg(nt()).getInertBodyElement(a), h = cl(p) || p; return h ? NI(e, t, n, o, r, l, u, d, h, i, c, 0) : 0; }
function NI(e, t, n, o, r, i, s, a, c, l, u, d) { let f = 0, p = c.firstChild; for (; p;) {
    let h = mr(t, o, 1, null);
    switch (p.nodeType) {
        case Node.ELEMENT_NODE:
            let m = p, v = m.tagName.toLowerCase();
            if (sl.hasOwnProperty(v)) {
                Pc(i, fI, v, l, h), t.data[h] = v;
                let Pe = m.attributes;
                for (let Ia = 0; Ia < Pe.length; Ia++) {
                    let Rt = Pe.item(Ia), gf = Rt.name.toLowerCase();
                    !!Rt.value.match(ts) ? Pg.hasOwnProperty(gf) && (gu[gf] ? $o(a, Rt.value, h, Rt.name, 0, Ts) : $o(a, Rt.value, h, Rt.name, 0, null)) : PS(i, h, Rt);
                }
                let pe = { kind: 1, index: h, children: [] };
                e.push(pe), f = NI(pe.children, t, n, o, r, i, s, a, p, h, u, d + 1) | f, oh(s, h, d);
            }
            break;
        case Node.TEXT_NODE:
            let E = p.textContent || "", A = E.match(ts);
            Pc(i, null, A ? "" : E, l, h), oh(s, h, d), A && (f = $o(a, E, h, null, 0, null) | f), e.push({ kind: 0, index: h });
            break;
        case Node.COMMENT_NODE:
            let ce = ES.exec(p.textContent || "");
            if (ce) {
                let Pe = parseInt(ce[1], 10), pe = u[Pe];
                Pc(i, pI, "", l, h), MI(e, t, o, r, l, pe, h), kS(s, h, d);
            }
            break;
    }
    p = p.nextSibling;
} return f; }
function oh(e, t, n) { n === 0 && e.push(t); }
function kS(e, t, n) { n === 0 && (e.push(~t), e.push(t)); }
function xS(e, t, n) { e.push(TI(t.mainBinding), 2, -1 - t.mainBinding, n << 2 | 2); }
function OS(e, t, n) { e.push(t, 1, n << 2 | 3); }
function Pc(e, t, n, o, r) { t !== null && e.push(t), e.push(n, r, aw(0, o, r)); }
function PS(e, t, n) { e.push(t << 1 | 1, n.name, n.value); }
var rh = 0, LS = /\[(�.+?�?)\]/, FS = /\[(�.+?�?)\]|(�\/?\*\d+:\d+�)/g, jS = /({\s*)(VAR_(PLURAL|SELECT)(_\d+)?)(\s*,)/g, VS = /{([A-Z0-9_]+)}/g, HS = /�I18N_EXP_(ICU(_\d+)?)�/g, BS = /\/\*/, $S = /\d+\:(\d+)/;
function US(e, t = {}) { let n = e; if (LS.test(e)) {
    let o = {}, r = [rh];
    n = n.replace(FS, (i, s, a) => { let c = s || a, l = o[c] || []; if (l.length || (c.split("|").forEach(m => { let v = m.match($S), E = v ? parseInt(v[1], 10) : rh, A = BS.test(m); l.push([E, A, m]); }), o[c] = l), !l.length)
        throw new Error(`i18n postprocess: unmatched placeholder - ${c}`); let u = r[r.length - 1], d = 0; for (let m = 0; m < l.length; m++)
        if (l[m][0] === u) {
            d = m;
            break;
        } let [f, p, h] = l[d]; return p ? r.pop() : u !== f && r.push(f), l.splice(d, 1), h; });
} return Object.keys(t).length && (n = n.replace(jS, (o, r, i, s, a, c) => t.hasOwnProperty(i) ? `${r}${t[i]}${c}` : o), n = n.replace(VS, (o, r) => t.hasOwnProperty(r) ? t[r] : o), n = n.replace(HS, (o, r) => { if (t.hasOwnProperty(r)) {
    let i = t[r];
    if (!i.length)
        throw new Error(`i18n postprocess: unmatched ICU - ${o} with key: ${r}`);
    return i.shift();
} return o; })), n; }
function Ad(e, t, n = -1) { let o = N(), r = g(), i = I + e, s = ae(o.consts, t), a = dn(); if (o.firstCreatePass && NS(o, a === null ? 0 : a.index, r, i, s, n), o.type === 2) {
    let f = r[Q];
    f[b] |= 32;
}
else
    r[b] |= 32; let c = o.data[i], l = a === r[se] ? null : a, u = im(o, l, r), d = a && a.type & 8 ? r[a.index] : null; vw(r, i, a, n), mS(r, c.create, u, d), tc(!0); }
function Rd() { tc(!1); }
function wI(e, t, n) { Ad(e, t, n), Rd(); }
function _I(e, t) { let n = N(), o = ae(n.consts, t); _S(n, e + I, o); }
function kd(e) { let t = g(); return pS(B(t, de(), e)), kd; }
function bI(e) { hS(N(), g(), e + I); }
function SI(e, t = {}) { return US(e, t); }
function xd(e, t, n) { let o = g(), r = N(), i = T(); return Ld(r, o, o[C], i, e, t, n), xd; }
function Od(e, t) { let n = T(), o = g(), r = N(), i = ni(r.data), s = mm(i, n, o); return Ld(r, o, s, n, e, t), Od; }
function Pd(e, t, n) { let o = g(), r = N(), i = T(); return (i.type & 3 || n) && cy(i, r, o, n, o[C], e, t, xo(i, o, t)), Pd; }
function Ld(e, t, n, o, r, i, s) { let a = !0, c = null; if ((o.type & 3 || s) && (c ??= xo(o, t, i), cy(o, e, t, s, n, r, i, c) && (a = !1)), a) {
    let l = o.outputs?.[r], u = o.hostDirectiveOutputs?.[r];
    if (u && u.length)
        for (let d = 0; d < u.length; d += 2) {
            let f = u[d], p = u[d + 1];
            c ??= xo(o, t, i), Wi(o, t, f, p, r, c);
        }
    if (l && l.length)
        for (let d of l)
            c ??= xo(o, t, i), Wi(o, t, d, r, r, c);
} }
function AI(e = 1) { return qf(e); }
function GS(e, t) { let n = null, o = zM(e); for (let r = 0; r < t.length; r++) {
    let i = t[r];
    if (i === "*") {
        n = r;
        continue;
    }
    if (o === null ? Zg(e, i, !0) : YM(o, i))
        return r;
} return n; }
function RI(e) { let t = g()[Q][se]; if (!t.projection) {
    let n = e ? e.length : 1, o = t.projection = ho(n, null), r = o.slice(), i = t.child;
    for (; i !== null;) {
        if (i.type !== 128) {
            let s = e ? GS(i, e) : 0;
            s !== null && (r[s] ? r[s].projectionNext = i : o[s] = i, r[s] = i);
        }
        i = i.next;
    }
} }
function kI(e, t = 0, n, o, r, i) { let s = g(), a = N(), c = o ? e + 1 : null; c !== null && Zt(s, a, c, o, r, i, null, n); let l = nn(a, I + e, 16, null, n || null); l.projection === null && (l.projection = t), Za(); let d = !s[te] || Mo(); s[Q][se].projection[l.projection] === null && c !== null ? WS(s, a, c) : d && !Zn(l) && lN(a, s, l); }
function WS(e, t, n) { let o = I + n, r = t.data[o], i = e[o], s = Yo(i, r.tView.ssrId), a = Xn(e, r, void 0, { dehydratedView: s }); eo(i, a, 0, zt(r, s)); }
function xI(e, t, n, o) { Cy(e, t, n, o); }
function OI(e, t, n) { Dy(e, t, n); }
function PI(e) { let t = g(), n = N(), o = oi(); No(o + 1); let r = Wu(n, o); if (e.dirty && xf(t) === ((r.metadata.flags & 2) === 2)) {
    if (r.matches === null)
        e.reset([]);
    else {
        let i = My(t, o);
        e.reset(i, Bh), e.notifyOnChanges();
    }
    return !0;
} return !1; }
function LI() { return Gu(g(), oi()); }
function FI(e, t, n, o, r) { Ny(t, Cy(e, n, o, r)); }
function jI(e, t, n, o) { Ny(e, Dy(t, n, o)); }
function VI(e = 1) { No(oi() + e); }
function HI(e) { let t = Ya(); return vt(t, I + e); }
function yi(e, t) { return e << 17 | t << 2; }
function Kt(e) { return e >> 17 & 32767; }
function qS(e) { return (e & 2) == 2; }
function zS(e, t) { return e & 131071 | t << 17; }
function Vl(e) { return e | 2; }
function Vn(e) { return (e & 131068) >> 2; }
function Lc(e, t) { return e & -131069 | t << 2; }
function QS(e) { return (e & 1) === 1; }
function Hl(e) { return e | 1; }
function ZS(e, t, n, o, r, i) { let s = i ? t.classBindings : t.styleBindings, a = Kt(s), c = Vn(s); e[o] = n; let l = !1, u; if (Array.isArray(n)) {
    let d = n;
    u = d[1], (u === null || Gr(d, u) > 0) && (l = !0);
}
else
    u = n; if (r)
    if (c !== 0) {
        let f = Kt(e[a + 1]);
        e[o + 1] = yi(f, a), f !== 0 && (e[f + 1] = Lc(e[f + 1], o)), e[a + 1] = zS(e[a + 1], o);
    }
    else
        e[o + 1] = yi(a, 0), a !== 0 && (e[a + 1] = Lc(e[a + 1], o)), a = o;
else
    e[o + 1] = yi(c, 0), a === 0 ? a = o : e[c + 1] = Lc(e[c + 1], o), c = o; l && (e[o + 1] = Vl(e[o + 1])), ih(e, u, o, !0), ih(e, u, o, !1), YS(t, u, e, o, i), s = yi(a, c), i ? t.classBindings = s : t.styleBindings = s; }
function YS(e, t, n, o, r) { let i = r ? e.residualClasses : e.residualStyles; i != null && typeof t == "string" && Gr(i, t) >= 0 && (n[o + 1] = Hl(n[o + 1])); }
function ih(e, t, n, o) { let r = e[n + 1], i = t === null, s = o ? Kt(r) : Vn(r), a = !1; for (; s !== 0 && (a === !1 || i);) {
    let c = e[s], l = e[s + 1];
    KS(c, t) && (a = !0, e[s + 1] = o ? Hl(l) : Vl(l)), s = o ? Kt(l) : Vn(l);
} a && (e[n + 1] = o ? Vl(r) : Hl(r)); }
function KS(e, t) { return e === null || t == null || (Array.isArray(e) ? e[1] : e) === t ? !0 : Array.isArray(e) && typeof t == "string" ? Gr(e, t) >= 0 : !1; }
var ee = { textEnd: 0, key: 0, keyEnd: 0, value: 0, valueEnd: 0 };
function BI(e) { return e.substring(ee.key, ee.keyEnd); }
function JS(e) { return e.substring(ee.value, ee.valueEnd); }
function XS(e) { return GI(e), $I(e, Hn(e, 0, ee.textEnd)); }
function $I(e, t) { let n = ee.textEnd; return n === t ? -1 : (t = ee.keyEnd = tA(e, ee.key = t, n), Hn(e, t, n)); }
function eA(e) { return GI(e), UI(e, Hn(e, 0, ee.textEnd)); }
function UI(e, t) { let n = ee.textEnd, o = ee.key = Hn(e, t, n); return n === o ? -1 : (o = ee.keyEnd = nA(e, o, n), o = sh(e, o, n, 58), o = ee.value = Hn(e, o, n), o = ee.valueEnd = oA(e, o, n), sh(e, o, n, 59)); }
function GI(e) { ee.key = 0, ee.keyEnd = 0, ee.value = 0, ee.valueEnd = 0, ee.textEnd = e.length; }
function Hn(e, t, n) { for (; t < n && e.charCodeAt(t) <= 32;)
    t++; return t; }
function tA(e, t, n) { for (; t < n && e.charCodeAt(t) > 32;)
    t++; return t; }
function nA(e, t, n) { let o; for (; t < n && ((o = e.charCodeAt(t)) === 45 || o === 95 || (o & -33) >= 65 && (o & -33) <= 90 || o >= 48 && o <= 57);)
    t++; return t; }
function sh(e, t, n, o) { return t = Hn(e, t, n), t < n && t++, t; }
function oA(e, t, n) { let o = -1, r = -1, i = -1, s = t, a = s; for (; s < n;) {
    let c = e.charCodeAt(s++);
    if (c === 59)
        return a;
    c === 34 || c === 39 ? a = s = ah(e, c, s, n) : t === s - 4 && i === 85 && r === 82 && o === 76 && c === 40 ? a = s = ah(e, 41, s, n) : c > 32 && (a = s), i = r, r = o, o = c & -33;
} return a; }
function ah(e, t, n, o) { let r = -1, i = n; for (; i < o;) {
    let s = e.charCodeAt(i++);
    if (s == t && r !== 92)
        return i;
    s == 92 && r === 92 ? r = 0 : r = s;
} throw new Error; }
function Fd(e, t, n) { return zI(e, t, n, !1), Fd; }
function jd(e, t) { return zI(e, t, null, !0), jd; }
function WI(e) { QI(KI, rA, e, !1); }
function rA(e, t) { for (let n = eA(t); n >= 0; n = UI(t, n))
    KI(e, BI(t), JS(t)); }
function qI(e) { QI(dA, iA, e, !0); }
function iA(e, t) { for (let n = XS(t); n >= 0; n = $I(t, n))
    go(e, BI(t), !0); }
function zI(e, t, n, o) { let r = g(), i = N(), s = $e(2); if (i.firstUpdatePass && YI(i, e, s, o), t !== x && B(r, s, t)) {
    let a = i.data[oe()];
    JI(i, a, r, r[C], e, r[s + 1] = pA(t, n), o, s);
} }
function QI(e, t, n, o) { let r = N(), i = $e(2); r.firstUpdatePass && YI(r, null, i, o); let s = g(); if (n !== x && B(s, i, n)) {
    let a = r.data[oe()];
    if (XI(a, o) && !ZI(r, i)) {
        let c = o ? a.classesWithoutHost : a.stylesWithoutHost;
        c !== null && (n = Lr(c, n || "")), Fl(r, a, s, n, o);
    }
    else
        fA(r, a, s, s[C], s[i + 1], s[i + 1] = uA(e, t, n), o, i);
} }
function ZI(e, t) { return t >= e.expandoStartIndex; }
function YI(e, t, n, o) { let r = e.data; if (r[n + 1] === null) {
    let i = r[oe()], s = ZI(e, n);
    XI(i, o) && t === null && !s && (t = !1), t = sA(r, i, t, o), ZS(r, i, t, n, s, o);
} }
function sA(e, t, n, o) { let r = ni(e), i = o ? t.residualClasses : t.residualStyles; if (r === null)
    (o ? t.classBindings : t.styleBindings) === 0 && (n = Fc(null, e, t, n, o), n = rr(n, t.attrs, o), i = null);
else {
    let s = t.directiveStylingLast;
    if (s === -1 || e[s] !== r)
        if (n = Fc(r, e, t, n, o), i === null) {
            let c = aA(e, t, o);
            c !== void 0 && Array.isArray(c) && (c = Fc(null, e, t, c[1], o), c = rr(c, t.attrs, o), cA(e, t, o, c));
        }
        else
            i = lA(e, t, o);
} return i !== void 0 && (o ? t.residualClasses = i : t.residualStyles = i), n; }
function aA(e, t, n) { let o = n ? t.classBindings : t.styleBindings; if (Vn(o) !== 0)
    return e[Kt(o)]; }
function cA(e, t, n, o) { let r = n ? t.classBindings : t.styleBindings; e[Kt(r)] = o; }
function lA(e, t, n) { let o, r = t.directiveEnd; for (let i = 1 + t.directiveStylingLast; i < r; i++) {
    let s = e[i].hostAttrs;
    o = rr(o, s, n);
} return rr(o, t.attrs, n); }
function Fc(e, t, n, o, r) { let i = null, s = n.directiveEnd, a = n.directiveStylingLast; for (a === -1 ? a = n.directiveStart : a++; a < s && (i = t[a], o = rr(o, i.hostAttrs, r), i !== e);)
    a++; return e !== null && (n.directiveStylingLast = a), o; }
function rr(e, t, n) { let o = n ? 1 : 2, r = -1; if (t !== null)
    for (let i = 0; i < t.length; i++) {
        let s = t[i];
        typeof s == "number" ? r = s : r === o && (Array.isArray(e) || (e = e === void 0 ? [] : ["", e]), go(e, s, n ? !0 : t[++i]));
    } return e === void 0 ? null : e; }
function uA(e, t, n) { if (n == null || n === "")
    return O; let o = [], r = it(n); if (Array.isArray(r))
    for (let i = 0; i < r.length; i++)
        e(o, r[i], !0);
else if (typeof r == "object")
    for (let i in r)
        r.hasOwnProperty(i) && e(o, i, r[i]);
else
    typeof r == "string" && t(o, r); return o; }
function KI(e, t, n) { go(e, t, it(n)); }
function dA(e, t, n) { let o = String(t); o !== "" && !o.includes(" ") && go(e, o, n); }
function fA(e, t, n, o, r, i, s, a) { r === x && (r = O); let c = 0, l = 0, u = 0 < r.length ? r[0] : null, d = 0 < i.length ? i[0] : null; for (; u !== null || d !== null;) {
    let f = c < r.length ? r[c + 1] : void 0, p = l < i.length ? i[l + 1] : void 0, h = null, m;
    u === d ? (c += 2, l += 2, f !== p && (h = d, m = p)) : d === null || u !== null && u < d ? (c += 2, h = u) : (l += 2, h = d, m = p), h !== null && JI(e, t, n, o, h, m, s, a), u = c < r.length ? r[c] : null, d = l < i.length ? i[l] : null;
} }
function JI(e, t, n, o, r, i, s, a) { if (!(t.type & 3))
    return; let c = e.data, l = c[a + 1], u = QS(l) ? ch(c, t, n, r, Vn(l), s) : void 0; if (!ns(u)) {
    ns(i) || qS(l) && (i = ch(c, null, n, r, a, s));
    let d = Ft(oe(), n);
    dN(o, s, d, r, i);
} }
function ch(e, t, n, o, r, i) { let s = t === null, a; for (; r > 0;) {
    let c = e[r], l = Array.isArray(c), u = l ? c[1] : c, d = u === null, f = n[r + 1];
    f === x && (f = d ? O : void 0);
    let p = d ? Ur(f, o) : u === o ? f : void 0;
    if (l && !ns(p) && (p = Ur(c, o)), ns(p) && (a = p, s))
        return a;
    let h = e[r + 1];
    r = s ? Kt(h) : Vn(h);
} if (t !== null) {
    let c = i ? t.residualClasses : t.residualStyles;
    c != null && (a = Ur(c, o));
} return a; }
function ns(e) { return e !== void 0; }
function pA(e, t) { return e == null || e === "" || (typeof t == "string" ? e = e + t : typeof e == "object" && (e = on(it(e)))), e; }
function XI(e, t) { return (e.flags & (t ? 8 : 16)) !== 0; }
function eE(e, t = "") { let n = g(), o = N(), r = e + I, i = o.firstCreatePass ? nn(o, r, 1, t, null) : o.data[r], s = tE(o, n, i, t, e); n[r] = s, wo() && bu(o, n, s, i), He(i, !1); }
var tE = (e, t, n, o, r) => (ke(!0), Eu(t[C], o));
function hA(e, t, n, o, r) { let i = !Cs(t, n); if (ke(i), i)
    return Eu(t[C], o); let s = t[te]; return Ir(s, e, t, n); }
function nE() { tE = hA; }
function oE(e, t) { let n = !1, o = Be(); for (let i = 1; i < t.length; i += 2)
    n = B(e, o++, t[i]) || n; if (ec(o), !n)
    return x; let r = t[0]; for (let i = 1; i < t.length; i += 2)
    r += M(t[i]) + (i + 1 !== t.length ? t[i + 1] : ""); return r; }
function rE(e, t, n, o = "") { return B(e, de(), n) ? t + M(n) + o : x; }
function iE(e, t, n, o, r, i = "") { let s = Be(), a = Qt(e, s, n, r); return $e(2), a ? t + M(n) + o + M(r) + i : x; }
function sE(e, t, n, o, r, i, s, a = "") { let c = Be(), l = Us(e, c, n, r, s); return $e(3), l ? t + M(n) + o + M(r) + i + M(s) + a : x; }
function aE(e, t, n, o, r, i, s, a, c, l = "") { let u = Be(), d = be(e, u, n, r, s, c); return $e(4), d ? t + M(n) + o + M(r) + i + M(s) + a + M(c) + l : x; }
function cE(e, t, n, o, r, i, s, a, c, l, u, d = "") { let f = Be(), p = be(e, f, n, r, s, c); return p = B(e, f + 4, u) || p, $e(5), p ? t + M(n) + o + M(r) + i + M(s) + a + M(c) + l + M(u) + d : x; }
function lE(e, t, n, o, r, i, s, a, c, l, u, d, f, p = "") { let h = Be(), m = be(e, h, n, r, s, c); return m = Qt(e, h + 4, u, f) || m, $e(6), m ? t + M(n) + o + M(r) + i + M(s) + a + M(c) + l + M(u) + d + M(f) + p : x; }
function uE(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, m = "") { let v = Be(), E = be(e, v, n, r, s, c); return E = Us(e, v + 4, u, f, h) || E, $e(7), E ? t + M(n) + o + M(r) + i + M(s) + a + M(c) + l + M(u) + d + M(f) + p + M(h) + m : x; }
function dE(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, m, v, E = "") { let A = Be(), ce = be(e, A, n, r, s, c); return ce = be(e, A + 4, u, f, h, v) || ce, $e(8), ce ? t + M(n) + o + M(r) + i + M(s) + a + M(c) + l + M(u) + d + M(f) + p + M(h) + m + M(v) + E : x; }
function Vd(e) { return sa("", e), Vd; }
function sa(e, t, n) { let o = g(), r = rE(o, e, t, n); return r !== x && lt(o, oe(), r), sa; }
function Hd(e, t, n, o, r) { let i = g(), s = iE(i, e, t, n, o, r); return s !== x && lt(i, oe(), s), Hd; }
function Bd(e, t, n, o, r, i, s) { let a = g(), c = sE(a, e, t, n, o, r, i, s); return c !== x && lt(a, oe(), c), Bd; }
function $d(e, t, n, o, r, i, s, a, c) { let l = g(), u = aE(l, e, t, n, o, r, i, s, a, c); return u !== x && lt(l, oe(), u), $d; }
function Ud(e, t, n, o, r, i, s, a, c, l, u) { let d = g(), f = cE(d, e, t, n, o, r, i, s, a, c, l, u); return f !== x && lt(d, oe(), f), Ud; }
function Gd(e, t, n, o, r, i, s, a, c, l, u, d, f) { let p = g(), h = lE(p, e, t, n, o, r, i, s, a, c, l, u, d, f); return h !== x && lt(p, oe(), h), Gd; }
function Wd(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h) { let m = g(), v = uE(m, e, t, n, o, r, i, s, a, c, l, u, d, f, p, h); return v !== x && lt(m, oe(), v), Wd; }
function qd(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, m, v) { let E = g(), A = dE(E, e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, m, v); return A !== x && lt(E, oe(), A), qd; }
function zd(e) { let t = g(), n = oE(t, e); return n !== x && lt(t, oe(), n), zd; }
function lt(e, t, n) { let o = Ft(t, e); Yg(e[C], o, n); }
function Qd(e, t, n) { dc(t) && (t = t()); let o = g(), r = de(); if (B(o, r, t)) {
    let i = N(), s = Ce();
    Au(s, o, e, t, o[C], n);
} return Qd; }
function fE(e, t) { let n = dc(e); return n && e.set(t), n; }
function Zd(e, t) { let n = g(), o = N(), r = T(); return Ld(o, n, n[C], r, e, t), Zd; }
var pE = {};
function Yd(e) { let t = N(), n = g(), o = e + I, r = nn(t, o, 128, null, null); return He(r, !1), Co(t, n, o, pE), Yd; }
function hE(e) { Z("NgLet"); let t = N(), n = g(), o = oe(); return Co(t, n, o, e), e; }
function gE(e) { let t = Ya(), n = vt(t, I + e); if (n === pE)
    throw new w(314, !1); return n; }
function mE(e, t) { let n = N(), o = g(), r = o[C], i = "data-ng-source-location"; for (let [s, a, c, l] of t) {
    let u = yt(n, s + I), d = Ft(s + I, o);
    if (!d.hasAttribute(i)) {
        let f = `${e}@o:${a},l:${c},c:${l}`;
        r.setAttribute(d, i, f);
    }
} }
function yE(e) { return B(g(), de(), e) ? M(e) : x; }
function vE(e, t, n = "") { return rE(g(), e, t, n); }
function IE(e, t, n, o, r = "") { return iE(g(), e, t, n, o, r); }
function EE(e, t, n, o, r, i, s = "") { return sE(g(), e, t, n, o, r, i, s); }
function DE(e, t, n, o, r, i, s, a, c = "") { return aE(g(), e, t, n, o, r, i, s, a, c); }
function CE(e, t, n, o, r, i, s, a, c, l, u = "") { return cE(g(), e, t, n, o, r, i, s, a, c, l, u); }
function TE(e, t, n, o, r, i, s, a, c, l, u, d, f = "") { return lE(g(), e, t, n, o, r, i, s, a, c, l, u, d, f); }
function ME(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h = "") { return uE(g(), e, t, n, o, r, i, s, a, c, l, u, d, f, p, h); }
function NE(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, m, v = "") { return dE(g(), e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, m, v); }
function wE(e) { return oE(g(), e); }
function gA(e, t, n) { let o = N(); if (o.firstCreatePass) {
    let r = ye(e);
    Bl(n, o.data, o.blueprint, r, !0), Bl(t, o.data, o.blueprint, r, !1);
} }
function Bl(e, t, n, o, r) { if (e = $(e), Array.isArray(e))
    for (let i = 0; i < e.length; i++)
        Bl(e[i], t, n, o, r);
else {
    let i = N(), s = g(), a = T(), c = qr(e) ? e : $(e.provide), l = bf(e), u = a.providerIndexes & 1048575, d = a.directiveStart, f = a.providerIndexes >> 20;
    if (qr(e) || !e.multi) {
        let p = new Wt(l, r, no, null), h = Vc(c, t, r ? u : u + f, d);
        h === -1 ? (Wc(Oi(a, s), i, c), jc(i, e, t.length), t.push(c), a.directiveStart++, a.directiveEnd++, r && (a.providerIndexes += 1048576), n.push(p), s.push(p)) : (n[h] = p, s[h] = p);
    }
    else {
        let p = Vc(c, t, u + f, d), h = Vc(c, t, u, u + f), m = p >= 0 && n[p], v = h >= 0 && n[h];
        if (r && !v || !r && !m) {
            Wc(Oi(a, s), i, c);
            let E = vA(r ? yA : mA, n.length, r, o, l, e);
            !r && v && (n[h].providerFactory = E), jc(i, e, t.length, 0), t.push(c), a.directiveStart++, a.directiveEnd++, r && (a.providerIndexes += 1048576), n.push(E), s.push(E);
        }
        else {
            let E = _E(n[r ? h : p], l, !r && o);
            jc(i, e, p > -1 ? p : h, E);
        }
        !r && o && v && n[h].componentProviders++;
    }
} }
function jc(e, t, n, o) { let r = qr(t), i = wf(t); if (r || i) {
    let c = (i ? $(t.useClass) : t).prototype.ngOnDestroy;
    if (c) {
        let l = e.destroyHooks || (e.destroyHooks = []);
        if (!r && t.multi) {
            let u = l.indexOf(n);
            u === -1 ? l.push(n, [o, c]) : l[u + 1].push(o, c);
        }
        else
            l.push(n, c);
    }
} }
function _E(e, t, n) { return n && e.componentProviders++, e.multi.push(t) - 1; }
function Vc(e, t, n, o) { for (let r = n; r < o; r++)
    if (t[r] === e)
        return r; return -1; }
function mA(e, t, n, o, r) { return $l(this.multi, []); }
function yA(e, t, n, o, r) { let i = this.multi, s; if (this.providerFactory) {
    let a = this.providerFactory.componentProviders, c = Go(o, o[y], this.providerFactory.index, r);
    s = c.slice(0, a), $l(i, s);
    for (let l = a; l < c.length; l++)
        s.push(c[l]);
}
else
    s = [], $l(i, s); return s; }
function $l(e, t) { for (let n = 0; n < e.length; n++) {
    let o = e[n];
    t.push(o());
} return t; }
function vA(e, t, n, o, r, i) { let s = new Wt(e, n, no, null); return s.multi = [], s.index = t, s.componentProviders = 0, _E(s, r, o && !n), s; }
function bE(e, t = []) { return n => { n.providersResolver = (o, r) => gA(o, r ? r(e) : e, t); }; }
function SE(e) { return t => { e.length < 1 || (t.getExternalStyles = n => e.map(r => r + "?ngcomp" + (n ? "=" + encodeURIComponent(n) : "") + "&e=" + t.encapsulation)); }; }
function AE() { return () => { zf(new Ki); }; }
function RE(e, t, n) { let o = e.\u0275cmp; o.directiveDefs = Zi(t, Ly), o.pipeDefs = Zi(n, Fe); }
function kE(e, t) { return Ge(() => { let n = Wr(e); n.declarations = vi(t.declarations || O), n.imports = vi(t.imports || O), n.exports = vi(t.exports || O), t.bootstrap && (n.bootstrap = vi(t.bootstrap)), kn.registerNgModule(e, t); }); }
function vi(e) { if (typeof e == "function")
    return e; let t = Ae(e); return t.some(Fr) ? () => t.map($).map(lh) : t.map(lh); }
function lh(e) { return Hu(e) ? e.ngModule : e; }
function xE(e, t, n) { let o = ue() + e, r = g(); return r[o] === x ? We(r, o, n ? t.call(n) : t()) : Dr(r, o); }
function OE(e, t, n, o) { return UE(g(), ue(), e, t, n, o); }
function PE(e, t, n, o, r) { return GE(g(), ue(), e, t, n, o, r); }
function LE(e, t, n, o, r, i) { return WE(g(), ue(), e, t, n, o, r, i); }
function FE(e, t, n, o, r, i, s) { return qE(g(), ue(), e, t, n, o, r, i, s); }
function jE(e, t, n, o, r, i, s, a) { let c = ue() + e, l = g(), u = be(l, c, n, o, r, i); return B(l, c + 4, s) || u ? We(l, c + 5, a ? t.call(a, n, o, r, i, s) : t(n, o, r, i, s)) : Dr(l, c + 5); }
function VE(e, t, n, o, r, i, s, a, c) { let l = ue() + e, u = g(), d = be(u, l, n, o, r, i); return Qt(u, l + 4, s, a) || d ? We(u, l + 6, c ? t.call(c, n, o, r, i, s, a) : t(n, o, r, i, s, a)) : Dr(u, l + 6); }
function HE(e, t, n, o, r, i, s, a, c, l) { let u = ue() + e, d = g(), f = be(d, u, n, o, r, i); return Us(d, u + 4, s, a, c) || f ? We(d, u + 7, l ? t.call(l, n, o, r, i, s, a, c) : t(n, o, r, i, s, a, c)) : Dr(d, u + 7); }
function BE(e, t, n, o, r, i, s, a, c, l, u) { let d = ue() + e, f = g(), p = be(f, d, n, o, r, i); return be(f, d + 4, s, a, c, l) || p ? We(f, d + 8, u ? t.call(u, n, o, r, i, s, a, c, l) : t(n, o, r, i, s, a, c, l)) : Dr(f, d + 8); }
function $E(e, t, n, o) { return zE(g(), ue(), e, t, n, o); }
function br(e, t) { let n = e[t]; return n === x ? void 0 : n; }
function UE(e, t, n, o, r, i) { let s = t + n; return B(e, s, r) ? We(e, s + 1, i ? o.call(i, r) : o(r)) : br(e, s + 1); }
function GE(e, t, n, o, r, i, s) { let a = t + n; return Qt(e, a, r, i) ? We(e, a + 2, s ? o.call(s, r, i) : o(r, i)) : br(e, a + 2); }
function WE(e, t, n, o, r, i, s, a) { let c = t + n; return Us(e, c, r, i, s) ? We(e, c + 3, a ? o.call(a, r, i, s) : o(r, i, s)) : br(e, c + 3); }
function qE(e, t, n, o, r, i, s, a, c) { let l = t + n; return be(e, l, r, i, s, a) ? We(e, l + 4, c ? o.call(c, r, i, s, a) : o(r, i, s, a)) : br(e, l + 4); }
function zE(e, t, n, o, r, i) { let s = t + n, a = !1; for (let c = 0; c < r.length; c++)
    B(e, s++, r[c]) && (a = !0); return a ? We(e, s, o.apply(i, r)) : br(e, s); }
function QE(e, t) { let n = N(), o, r = e + I; n.firstCreatePass ? (o = IA(t, n.pipeRegistry), n.data[r] = o, o.onDestroy && (n.destroyHooks ??= []).push(r, o.onDestroy)) : o = n.data[r]; let i = o.factory || (o.factory = $r(o.type, !0)), s, a = xt(no); try {
    let c = xi(!1), l = i();
    return xi(c), Co(n, g(), r, l), l;
}
finally {
    xt(a);
} }
function IA(e, t) { if (t)
    for (let n = t.length - 1; n >= 0; n--) {
        let o = t[n];
        if (e === o.name)
            return o;
    } }
function ZE(e, t, n) { let o = e + I, r = g(), i = vt(r, o); return Sr(r, o) ? UE(r, ue(), t, i.transform, n, i) : i.transform(n); }
function YE(e, t, n, o) { let r = e + I, i = g(), s = vt(i, r); return Sr(i, r) ? GE(i, ue(), t, s.transform, n, o, s) : s.transform(n, o); }
function KE(e, t, n, o, r) { let i = e + I, s = g(), a = vt(s, i); return Sr(s, i) ? WE(s, ue(), t, a.transform, n, o, r, a) : a.transform(n, o, r); }
function JE(e, t, n, o, r, i) { let s = e + I, a = g(), c = vt(a, s); return Sr(a, s) ? qE(a, ue(), t, c.transform, n, o, r, i, c) : c.transform(n, o, r, i); }
function XE(e, t, n) { let o = e + I, r = g(), i = vt(r, o); return Sr(r, o) ? zE(r, ue(), t, i.transform, n, i) : i.transform.apply(i, n); }
function Sr(e, t) { return e[y].data[t].pure; }
function eD(e, t) { return Ps(e, t); }
function tD(e, t) { return () => { try {
    return kn.getComponentDependencies(e, t).dependencies;
}
catch (n) {
    throw console.error(`Computing dependencies in local compilation mode for the component "${e.name}" failed with the exception:`, n), n;
} }; }
function nD(e, t) { let n = U(e); n !== null && (n.debugInfo = t); }
function oD(e, t, n) { let o = `./@ng/component?c=${e}&t=${encodeURIComponent(t)}`; return new URL(o, n).href; }
function rD(e, t, n, o, r = null, i = null) { let s = U(e); t.apply(null, [e, n, ...o]); let { newDef: a, oldDef: c } = EA(s, U(e)); if (e[rn] = a, c.tView) {
    let l = yT().values();
    for (let u of l)
        Ve(u) && u[q] === null && bi(r, i, a, c, u);
} }
function EA(e, t) { let n = W({}, e); return { newDef: Object.assign(e, t, { directiveDefs: n.directiveDefs, pipeDefs: n.pipeDefs, setInput: n.setInput, type: n.type }), oldDef: n }; }
function bi(e, t, n, o, r) { let i = r[y]; if (i === o.tView) {
    CA(e, t, n, o, r);
    return;
} for (let s = I; s < i.bindingStartIndex; s++) {
    let a = r[s];
    if (K(a)) {
        Y(a[F]) && bi(e, t, n, o, a[F]);
        for (let c = G; c < a.length; c++)
            bi(e, t, n, o, a[c]);
    }
    else
        Y(a) && bi(e, t, n, o, a);
} }
function DA(e, t) { e.componentReplaced?.(t.id); }
function CA(e, t, n, o, r) { let i = r[P], s = r[F], a = r[q], c = r[se], l = r[V].get(L, null), u = () => { if (o.encapsulation === Xe.ShadowDom) {
    let h = s.cloneNode(!1);
    s.replaceWith(h), s = h;
} let d = em(n), f = Ns(a, d, i, Tu(n), s, c, null, null, null, null, null); TA(a, r, f, c.index), yr(r[y], r); let p = r[ze].rendererFactory; DA(p, o), f[C] = p.createRenderer(s, n), om(r[y], r), MA(c), xs(d, f, i), Cm(d, f, d.template, i); }; l === null ? uh(e, t, u) : l.run(() => uh(e, t, u)); }
function uh(e, t, n) {
    try {
        n();
    }
    catch (o) {
        let r = o;
        if (t !== null && r.message) {
            let i = r.message + (r.stack ? `
` + r.stack : "");
            e?.hot?.send?.("angular:invalidate", { id: t, message: i, error: !0 });
        }
        throw o;
    }
}
function TA(e, t, n, o) { for (let r = I; r < e[y].bindingStartIndex; r++) {
    let i = e[r];
    if ((Y(i) || K(i)) && i[ie] === t) {
        i[ie] = n;
        break;
    }
} e[ht] === t && (e[ht] = n), e[yo] === t && (e[yo] = n), n[ie] = t[ie], t[ie] = null, e[o] = n; }
function MA(e) { if (e.projection !== null) {
    for (let t of e.projection)
        ss(t) && (t.projectionNext = null, t.flags &= -3);
    e.projection = null;
} }
var fe = { \u0275\u0275animateEnter: Po, \u0275\u0275animateEnterListener: Lo, \u0275\u0275animateLeave: Fo, \u0275\u0275animateLeaveListener: jo, \u0275\u0275attribute: yd, \u0275\u0275defineComponent: Py, \u0275\u0275defineDirective: Fy, \u0275\u0275defineInjectable: j, \u0275\u0275defineInjector: fo, \u0275\u0275defineNgModule: Xu, \u0275\u0275definePipe: jy, \u0275\u0275directiveInject: no, \u0275\u0275getInheritedFactory: Fh, \u0275\u0275inject: Se, \u0275\u0275injectAttribute: as, \u0275\u0275invalidFactory: ny, \u0275\u0275invalidFactoryDep: Br, \u0275\u0275templateRefExtractor: eD, \u0275\u0275resetView: za, \u0275\u0275HostDirectivesFeature: Uy, \u0275\u0275NgOnChangesFeature: Dh, \u0275\u0275ProvidersFeature: bE, \u0275\u0275CopyDefinitionFeature: $y, \u0275\u0275InheritDefinitionFeature: ed, \u0275\u0275ExternalStylesFeature: SE, \u0275\u0275AnimationsFeature: AE, \u0275\u0275nextContext: AI, \u0275\u0275namespaceHTML: ac, \u0275\u0275namespaceMathML: sc, \u0275\u0275namespaceSVG: ic, \u0275\u0275enableBindings: Ua, \u0275\u0275disableBindings: Ga, \u0275\u0275elementStart: ea, \u0275\u0275elementEnd: ta, \u0275\u0275element: Ed, \u0275\u0275elementContainerStart: ra, \u0275\u0275elementContainerEnd: wr, \u0275\u0275domElement: Dd, \u0275\u0275domElementStart: na, \u0275\u0275domElementEnd: oa, \u0275\u0275domElementContainer: Nd, \u0275\u0275domElementContainerStart: ia, \u0275\u0275domElementContainerEnd: Md, \u0275\u0275domTemplate: nd, \u0275\u0275domListener: Pd, \u0275\u0275elementContainer: Td, \u0275\u0275pureFunction0: xE, \u0275\u0275pureFunction1: OE, \u0275\u0275pureFunction2: PE, \u0275\u0275pureFunction3: LE, \u0275\u0275pureFunction4: FE, \u0275\u0275pureFunction5: jE, \u0275\u0275pureFunction6: VE, \u0275\u0275pureFunction7: HE, \u0275\u0275pureFunction8: BE, \u0275\u0275pureFunctionV: $E, \u0275\u0275getCurrentView: uI, \u0275\u0275restoreView: qa, \u0275\u0275listener: xd, \u0275\u0275projection: kI, \u0275\u0275syntheticHostProperty: bd, \u0275\u0275syntheticHostListener: Od, \u0275\u0275pipeBind1: ZE, \u0275\u0275pipeBind2: YE, \u0275\u0275pipeBind3: KE, \u0275\u0275pipeBind4: JE, \u0275\u0275pipeBindV: XE, \u0275\u0275projectionDef: RI, \u0275\u0275domProperty: _d, \u0275\u0275ariaProperty: md, \u0275\u0275property: Id, \u0275\u0275pipe: QE, \u0275\u0275queryRefresh: PI, \u0275\u0275queryAdvance: VI, \u0275\u0275viewQuery: OI, \u0275\u0275viewQuerySignal: jI, \u0275\u0275loadQuery: LI, \u0275\u0275contentQuery: xI, \u0275\u0275contentQuerySignal: FI, \u0275\u0275reference: HI, \u0275\u0275classMap: qI, \u0275\u0275styleMap: WI, \u0275\u0275styleProp: Fd, \u0275\u0275classProp: jd, \u0275\u0275advance: tm, \u0275\u0275template: td, \u0275\u0275conditional: oI, \u0275\u0275conditionalCreate: nI, \u0275\u0275conditionalBranchCreate: Xs, \u0275\u0275defer: Mv, \u0275\u0275deferWhen: Nv, \u0275\u0275deferOnIdle: Sv, \u0275\u0275deferOnImmediate: kv, \u0275\u0275deferOnTimer: Pv, \u0275\u0275deferOnHover: jv, \u0275\u0275deferOnInteraction: Bv, \u0275\u0275deferOnViewport: Gv, \u0275\u0275deferPrefetchWhen: wv, \u0275\u0275deferPrefetchOnIdle: Av, \u0275\u0275deferPrefetchOnImmediate: xv, \u0275\u0275deferPrefetchOnTimer: Lv, \u0275\u0275deferPrefetchOnHover: Vv, \u0275\u0275deferPrefetchOnInteraction: $v, \u0275\u0275deferPrefetchOnViewport: Wv, \u0275\u0275deferHydrateWhen: _v, \u0275\u0275deferHydrateNever: bv, \u0275\u0275deferHydrateOnIdle: Rv, \u0275\u0275deferHydrateOnImmediate: Ov, \u0275\u0275deferHydrateOnTimer: Fv, \u0275\u0275deferHydrateOnHover: Hv, \u0275\u0275deferHydrateOnInteraction: Uv, \u0275\u0275deferHydrateOnViewport: qv, \u0275\u0275deferEnableTimerScheduling: dv, \u0275\u0275repeater: aI, \u0275\u0275repeaterCreate: sI, \u0275\u0275repeaterTrackByIndex: rI, \u0275\u0275repeaterTrackByIdentity: iI, \u0275\u0275componentInstance: tI, \u0275\u0275text: eE, \u0275\u0275textInterpolate: Vd, \u0275\u0275textInterpolate1: sa, \u0275\u0275textInterpolate2: Hd, \u0275\u0275textInterpolate3: Bd, \u0275\u0275textInterpolate4: $d, \u0275\u0275textInterpolate5: Ud, \u0275\u0275textInterpolate6: Gd, \u0275\u0275textInterpolate7: Wd, \u0275\u0275textInterpolate8: qd, \u0275\u0275textInterpolateV: zd, \u0275\u0275i18n: wI, \u0275\u0275i18nAttributes: _I, \u0275\u0275i18nExp: kd, \u0275\u0275i18nStart: Ad, \u0275\u0275i18nEnd: Rd, \u0275\u0275i18nApply: bI, \u0275\u0275i18nPostprocess: SI, \u0275\u0275resolveWindow: qg, \u0275\u0275resolveDocument: zg, \u0275\u0275resolveBody: vu, \u0275\u0275setComponentScope: RE, \u0275\u0275setNgModuleScope: kE, \u0275\u0275registerNgModuleType: Yu, \u0275\u0275getComponentDepsFactory: tD, \u0275setClassDebugInfo: nD, \u0275\u0275declareLet: Yd, \u0275\u0275storeLet: hE, \u0275\u0275readContextLet: gE, \u0275\u0275attachSourceLocations: mE, \u0275\u0275interpolate: yE, \u0275\u0275interpolate1: vE, \u0275\u0275interpolate2: IE, \u0275\u0275interpolate3: EE, \u0275\u0275interpolate4: DE, \u0275\u0275interpolate5: CE, \u0275\u0275interpolate6: TE, \u0275\u0275interpolate7: ME, \u0275\u0275interpolate8: NE, \u0275\u0275interpolateV: wE, \u0275\u0275sanitizeHtml: jg, \u0275\u0275sanitizeStyle: Vg, \u0275\u0275sanitizeResourceUrl: yu, \u0275\u0275sanitizeScript: Hg, \u0275\u0275sanitizeUrl: mu, \u0275\u0275sanitizeUrlOrResourceUrl: Ug, \u0275\u0275trustConstantHtml: Bg, \u0275\u0275trustConstantResourceUrl: $g, \u0275\u0275validateIframeAttribute: Ry, forwardRef: Ma, resolveForwardRef: $, \u0275\u0275twoWayProperty: Qd, \u0275\u0275twoWayBindingSet: fE, \u0275\u0275twoWayListener: Zd, \u0275\u0275replaceMetadata: rD, \u0275\u0275getReplaceMetadataURL: oD }, Cn = null;
function iD(e) { Cn !== null && (e.defaultEncapsulation !== Cn.defaultEncapsulation || e.preserveWhitespaces !== Cn.preserveWhitespaces) || (Cn = e); }
function NA() { return Cn; }
function wA() { Cn = null; }
var Uo = [];
function _A(e, t) { Uo.push({ moduleType: e, ngModule: t }); }
var Hc = !1;
function sD() { if (!Hc) {
    Hc = !0;
    try {
        for (let e = Uo.length - 1; e >= 0; e--) {
            let { moduleType: t, ngModule: n } = Uo[e];
            n.declarations && n.declarations.every(aD) && (Uo.splice(e, 1), kA(t, n));
        }
    }
    finally {
        Hc = !1;
    }
} }
function aD(e) { return Array.isArray(e) ? e.every(aD) : !!$(e); }
function cD(e, t = {}) { lD(e, t), t.id !== void 0 && Yu(e, t.id), _A(e, t); }
function lD(e, t, n = !1) { let o = Ae(t.declarations || O), r = null; Object.defineProperty(e, wa, { configurable: !0, get: () => (r === null && (r = X({ usage: 0, kind: "NgModule", type: e }).compileNgModule(fe, `ng:///${e.name}/\u0275mod.js`, { type: e, bootstrap: Ae(t.bootstrap || O).map($), declarations: o.map($), imports: Ae(t.imports || O).map($).map(dh), exports: Ae(t.exports || O).map($).map(dh), schemas: t.schemas ? Ae(t.schemas) : null, id: t.id || null }), r.schemas || (r.schemas = [])), r) }); let i = null; Object.defineProperty(e, dt, { get: () => { if (i === null) {
        let a = X({ usage: 0, kind: "NgModule", type: e });
        i = a.compileFactory(fe, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, deps: cs(e), target: a.FactoryTarget.NgModule, typeArgumentCount: 0 });
    } return i; }, configurable: !1 }); let s = null; Object.defineProperty(e, Na, { get: () => { if (s === null) {
        let a = { name: e.name, type: e, providers: t.providers || O, imports: [(t.imports || O).map($), (t.exports || O).map($)] };
        s = X({ usage: 0, kind: "NgModule", type: e }).compileInjector(fe, `ng:///${e.name}/\u0275inj.js`, a);
    } return s; }, configurable: !1 }); }
function bA(e, t) { let n = `Unexpected "${Ee(e)}" found in the "declarations" array of the`, o = `"${Ee(e)}" is marked as standalone and can't be declared in any NgModule - did you intend to import it instead (by adding it to the "imports" array)?`; return `${n} ${t}, ${o}`; }
var SA = new WeakMap, AA = new WeakMap;
function RA() { SA = new WeakMap, AA = new WeakMap, Uo.length = 0, k_.clear(); }
function kA(e, t) { let n = Ae(t.declarations || O), o = Jd(e); n.forEach(r => { if (r = $(r), r.hasOwnProperty(rn)) {
    let s = U(r);
    Kd(s, o);
}
else
    !r.hasOwnProperty(Vr) && !r.hasOwnProperty(Hr) && (r.ngSelectorScope = e); }); }
function Kd(e, t) { e.directiveDefs = () => Array.from(t.compilation.directives).map(n => n.hasOwnProperty(rn) ? U(n) : Ne(n)).filter(n => !!n), e.pipeDefs = () => Array.from(t.compilation.pipes).map(n => Fe(n)), e.schemas = t.schemas, e.tView = null; }
function Jd(e) { if (Bt(e)) {
    let t = kn.getNgModuleScope(e), n = Wr(e);
    return W({ schemas: n.schemas || null }, t);
}
else if (mo(e)) {
    if ((U(e) || Ne(e)) !== null)
        return { schemas: null, compilation: { directives: new Set, pipes: new Set }, exported: { directives: new Set([e]), pipes: new Set } };
    if (Fe(e) !== null)
        return { schemas: null, compilation: { directives: new Set, pipes: new Set }, exported: { directives: new Set, pipes: new Set([e]) } };
} throw new Error(`${e.name} does not have a module def (\u0275mod property)`); }
function dh(e) { return Hu(e) ? e.ngModule : e; }
var Bc = 0;
function uD(e, t) {
    let n = null;
    D_(e, t), fD(e, t), Object.defineProperty(e, rn, { get: () => {
            if (n === null) {
                let o = X({ usage: 0, kind: "component", type: e });
                if (_y(t)) {
                    let u = [`Component '${e.name}' is not resolved:`];
                    throw t.templateUrl && u.push(` - templateUrl: ${t.templateUrl}`), t.styleUrls && t.styleUrls.length && u.push(` - styleUrls: ${JSON.stringify(t.styleUrls)}`), t.styleUrl && u.push(` - styleUrl: ${t.styleUrl}`), u.push("Did you run and wait for 'resolveComponentResources()'?"), new Error(u.join(`
`));
                }
                let r = NA(), i = t.preserveWhitespaces;
                i === void 0 && (r !== null && r.preserveWhitespaces !== void 0 ? i = r.preserveWhitespaces : i = !1);
                let s = t.encapsulation;
                s === void 0 && (r !== null && r.defaultEncapsulation !== void 0 ? s = r.defaultEncapsulation : s = Xe.Emulated);
                let a = t.templateUrl || `ng:///${e.name}/template.html`, c = pD(e, t), l = Le(W({}, c), { typeSourceSpan: o.createParseSourceSpan("Component", e.name, a), template: t.template || "", preserveWhitespaces: i, styles: typeof t.styles == "string" ? [t.styles] : t.styles || O, animations: t.animations, declarations: [], changeDetection: t.changeDetection, encapsulation: s, interpolation: t.interpolation, viewProviders: t.viewProviders || null, hasDirectiveDependencies: !c.isStandalone || t.imports != null && t.imports.length > 0 });
                Bc++;
                try {
                    if (l.usesInheritance && hD(e), n = o.compileComponent(fe, a, l), l.isStandalone) {
                        let u = Ae(t.imports || O), { directiveDefs: d, pipeDefs: f } = xA(e, u);
                        n.directiveDefs = d, n.pipeDefs = f, n.dependencies = () => u.map($);
                    }
                }
                finally {
                    Bc--;
                }
                if (Bc === 0 && sD(), OA(e)) {
                    let u = Jd(e.ngSelectorScope);
                    Kd(n, u);
                }
                if (t.schemas)
                    if (l.isStandalone)
                        n.schemas = t.schemas;
                    else
                        throw new Error(`The 'schemas' was specified for the ${Ee(e)} but is only valid on a component that is standalone.`);
                else
                    l.isStandalone && (n.schemas = []);
            }
            return n;
        }, set: o => { n = o; }, configurable: !1 });
}
function xA(e, t) { return { directiveDefs: () => ko(e) ? [...kn.getStandaloneComponentScope(e, t).compilation.directives].map(i => U(i) || Ne(i)).filter(i => i !== null) : [], pipeDefs: () => ko(e) ? [...kn.getStandaloneComponentScope(e, t).compilation.pipes].map(i => Fe(i)).filter(i => i !== null) : [] }; }
function OA(e) { return e.ngSelectorScope !== void 0; }
function Xd(e, t) { let n = null; fD(e, t || {}), Object.defineProperty(e, Vr, { get: () => { if (n === null) {
        let o = dD(e, t || {});
        n = X({ usage: 0, kind: "directive", type: e }).compileDirective(fe, o.sourceMapUrl, o.metadata);
    } return n; }, configurable: !1 }); }
function dD(e, t) { let n = e && e.name, o = `ng:///${n}/\u0275dir.js`, r = X({ usage: 0, kind: "directive", type: e }), i = pD(e, t); return i.typeSourceSpan = r.createParseSourceSpan("Directive", n, o), i.usesInheritance && hD(e), { metadata: i, sourceMapUrl: o }; }
function fD(e, t) { let n = null; Object.defineProperty(e, dt, { get: () => { if (n === null) {
        let o = dD(e, t), r = X({ usage: 0, kind: "directive", type: e });
        n = r.compileFactory(fe, `ng:///${e.name}/\u0275fac.js`, { name: o.metadata.name, type: o.metadata.type, typeArgumentCount: 0, deps: cs(e), target: r.FactoryTarget.Directive });
    } return n; }, configurable: !1 }); }
function PA(e) { return Object.getPrototypeOf(e.prototype) === Object.prototype; }
function pD(e, t) { let n = Zl(), o = n.ownPropMetadata(e); return { name: e.name, type: e, selector: t.selector !== void 0 ? t.selector : null, host: t.host || Me, propMetadata: o, inputs: t.inputs || O, outputs: t.outputs || O, queries: fh(e, o, gD), lifecycle: { usesOnChanges: n.hasLifecycleHook(e, "ngOnChanges") }, typeSourceSpan: null, usesInheritance: !PA(e), exportAs: jA(t.exportAs), providers: t.providers || null, viewQueries: fh(e, o, mD), isStandalone: t.standalone === void 0 ? !0 : !!t.standalone, isSignal: !!t.signals, hostDirectives: t.hostDirectives?.map(r => typeof r == "function" ? { directive: r } : r) || null }; }
function hD(e) { let t = Object.prototype, n = Object.getPrototypeOf(e.prototype).constructor; for (; n && n !== t;)
    !Ne(n) && !U(n) && HA(n) && Xd(n, null), n = Object.getPrototypeOf(n); }
function LA(e) { return typeof e == "string" ? vD(e) : $(e); }
function FA(e, t) { return { propertyName: e, predicate: LA(t.selector), descendants: t.descendants, first: t.first, read: t.read ? t.read : null, static: !!t.static, emitDistinctChangesOnly: !!t.emitDistinctChangesOnly, isSignal: !!t.isSignal }; }
function fh(e, t, n) { let o = []; for (let r in t)
    if (t.hasOwnProperty(r)) {
        let i = t[r];
        i.forEach(s => { if (n(s)) {
            if (!s.selector)
                throw new Error(`Can't construct a query for the property "${r}" of "${Ee(e)}" since the query selector wasn't defined.`);
            if (i.some(yD))
                throw new Error("Cannot combine @Input decorators with query decorators");
            o.push(FA(r, s));
        } });
    } return o; }
function jA(e) { return e === void 0 ? null : vD(e); }
function gD(e) { let t = e.ngMetadataName; return t === "ContentChild" || t === "ContentChildren"; }
function mD(e) { let t = e.ngMetadataName; return t === "ViewChild" || t === "ViewChildren"; }
function yD(e) { return e.ngMetadataName === "Input"; }
function vD(e) { return e.split(",").map(t => t.trim()); }
var VA = ["ngOnChanges", "ngOnInit", "ngOnDestroy", "ngDoCheck", "ngAfterViewInit", "ngAfterViewChecked", "ngAfterContentInit", "ngAfterContentChecked"];
function HA(e) { let t = Zl(); if (VA.some(o => t.hasLifecycleHook(e, o)))
    return !0; let n = t.propMetadata(e); for (let o in n) {
    let r = n[o];
    for (let i = 0; i < r.length; i++) {
        let s = r[i], a = s.ngMetadataName;
        if (yD(s) || gD(s) || mD(s) || a === "Output" || a === "HostBinding" || a === "HostListener")
            return !0;
    }
} return !1; }
function ID(e, t) { let n = null, o = null; Object.defineProperty(e, dt, { get: () => { if (o === null) {
        let r = ph(e, t), i = X({ usage: 0, kind: "pipe", type: r.type });
        o = i.compileFactory(fe, `ng:///${r.name}/\u0275fac.js`, { name: r.name, type: r.type, typeArgumentCount: 0, deps: cs(e), target: i.FactoryTarget.Pipe });
    } return o; }, configurable: !1 }), Object.defineProperty(e, Hr, { get: () => { if (n === null) {
        let r = ph(e, t);
        n = X({ usage: 0, kind: "pipe", type: r.type }).compilePipe(fe, `ng:///${r.name}/\u0275pipe.js`, r);
    } return n; }, configurable: !1 }); }
function ph(e, t) { return { type: e, name: e.name, pipeName: t.name, pure: t.pure !== void 0 ? t.pure : !0, isStandalone: t.standalone === void 0 ? !0 : !!t.standalone }; }
var ED = sr("Directive", (e = {}) => e, void 0, void 0, (e, t) => Xd(e, t)), BA = sr("Component", (e = {}) => W({ changeDetection: ls.Default }, e), ED, void 0, (e, t) => uD(e, t)), $A = sr("Pipe", e => W({ pure: !0 }, e), void 0, void 0, (e, t) => ID(e, t)), UA = tt("Input", e => e ? typeof e == "string" ? { alias: e } : e : {}), GA = tt("Output", e => ({ alias: e })), WA = tt("HostBinding", e => ({ hostPropertyName: e })), qA = tt("HostListener", (e, t) => ({ eventName: e, args: t })), zA = sr("NgModule", e => e, void 0, void 0, (e, t) => cD(e, t)), os = class {
    ngModuleFactory;
    componentFactories;
    constructor(t, n) { this.ngModuleFactory = t, this.componentFactories = n; }
}, QA = (() => { class e {
    compileModuleSync(n) { return new Ln(n); }
    compileModuleAsync(n) { return Promise.resolve(this.compileModuleSync(n)); }
    compileModuleAndAllComponentsSync(n) { let o = this.compileModuleSync(n), r = an(n), i = En(r.declarations).reduce((s, a) => { let c = U(a); return c && s.push(new _t(c)), s; }, []); return new os(o, i); }
    compileModuleAndAllComponentsAsync(n) { return Promise.resolve(this.compileModuleAndAllComponentsSync(n)); }
    clearCache() { }
    clearCacheFor(n) { }
    getModuleId(n) { }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), DD = new _(""), Ul = class {
}, ZA = (() => { class e {
    zone = D(L);
    changeDetectionScheduler = D(Qe);
    applicationRef = D(Oe);
    applicationErrorHandler = D(Et);
    _onMicrotaskEmptySubscription;
    initialize() { this._onMicrotaskEmptySubscription || (this._onMicrotaskEmptySubscription = this.zone.onMicrotaskEmpty.subscribe({ next: () => { this.changeDetectionScheduler.runningTick || this.zone.run(() => { try {
            this.applicationRef.dirtyFlags |= 1, this.applicationRef._tick();
        }
        catch (n) {
            this.applicationErrorHandler(n);
        } }); } })); }
    ngOnDestroy() { this._onMicrotaskEmptySubscription?.unsubscribe(); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), CD = new _("", { factory: () => !1 });
function aa({ ngZoneFactory: e, ignoreChangesOutsideZone: t, scheduleInRootZone: n }) { return e ??= () => new L(Le(W({}, ca()), { scheduleInRootZone: n })), [{ provide: L, useFactory: e }, { provide: ft, multi: !0, useFactory: () => { let o = D(ZA, { optional: !0 }); return () => o.initialize(); } }, { provide: ft, multi: !0, useFactory: () => { let o = D(KA); return () => { o.initialize(); }; } }, t === !0 ? { provide: fc, useValue: !0 } : [], { provide: ci, useValue: n ?? Ky }, { provide: Et, useFactory: () => { let o = D(L), r = D(pt), i; return s => { o.runOutsideAngular(() => { r.destroyed && !i ? setTimeout(() => { throw s; }) : (i ??= r.get(ai), i.handleError(s)); }); }; } }]; }
function YA(e) { let t = e?.ignoreChangesOutsideZone, n = e?.scheduleInRootZone, o = aa({ ngZoneFactory: () => { let r = ca(e); return r.scheduleInRootZone = n, r.shouldCoalesceEventChangeDetection && Z("NgZone_CoalesceEvent"), new L(r); }, ignoreChangesOutsideZone: t, scheduleInRootZone: n }); return qe([{ provide: CD, useValue: !0 }, { provide: pn, useValue: !1 }, o]); }
function ca(e) { return { enableLongStackTrace: !1, shouldCoalesceEventChangeDetection: e?.eventCoalescing ?? !1, shouldCoalesceRunChangeDetection: e?.runCoalescing ?? !1 }; }
var KA = (() => { class e {
    subscription = new ql;
    initialized = !1;
    zone = D(L);
    pendingTasks = D(Dt);
    initialize() { if (this.initialized)
        return; this.initialized = !0; let n = null; !this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (n = this.pendingTasks.add()), this.zone.runOutsideAngular(() => { this.subscription.add(this.zone.onStable.subscribe(() => { L.assertNotInAngularZone(), queueMicrotask(() => { n !== null && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (this.pendingTasks.remove(n), n = null); }); })); }), this.subscription.add(this.zone.onUnstable.subscribe(() => { L.assertInAngularZone(), n ??= this.pendingTasks.add(); })); }
    ngOnDestroy() { this.subscription.unsubscribe(); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
var la = (() => { class e {
    applicationErrorHandler = D(Et);
    appRef = D(Oe);
    taskService = D(Dt);
    ngZone = D(L);
    zonelessEnabled = D(pn);
    tracing = D(oo, { optional: !0 });
    disableScheduling = D(fc, { optional: !0 }) ?? !1;
    zoneIsDefined = typeof Zone < "u" && !!Zone.root.run;
    schedulerTickApplyArgs = [{ data: { __scheduler_tick__: !0 } }];
    subscriptions = new ql;
    angularZoneId = this.zoneIsDefined ? this.ngZone._inner?.get(Yi) : null;
    scheduleInRootZone = !this.zonelessEnabled && this.zoneIsDefined && (D(ci, { optional: !0 }) ?? !1);
    cancelScheduledCallback = null;
    useMicrotaskScheduler = !1;
    runningTick = !1;
    pendingRenderTaskId = null;
    constructor() { this.subscriptions.add(this.appRef.afterTick.subscribe(() => { this.runningTick || this.cleanup(); })), this.subscriptions.add(this.ngZone.onUnstable.subscribe(() => { this.runningTick || this.cleanup(); })), this.disableScheduling ||= !this.zonelessEnabled && (this.ngZone instanceof Fn || !this.zoneIsDefined); }
    notify(n) { if (!this.zonelessEnabled && n === 5)
        return; let o = !1; switch (n) {
        case 0: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 3:
        case 2:
        case 4:
        case 5:
        case 1: {
            this.appRef.dirtyFlags |= 4;
            break;
        }
        case 6: {
            this.appRef.dirtyFlags |= 2, o = !0;
            break;
        }
        case 12: {
            this.appRef.dirtyFlags |= 16, o = !0;
            break;
        }
        case 13: {
            this.appRef.dirtyFlags |= 2, o = !0;
            break;
        }
        case 11: {
            o = !0;
            break;
        }
        case 9:
        case 8:
        case 7:
        case 10:
        default: this.appRef.dirtyFlags |= 8;
    } if (this.appRef.tracingSnapshot = this.tracing?.snapshot(this.appRef.tracingSnapshot) ?? null, !this.shouldScheduleTick(o))
        return; let r = this.useMicrotaskScheduler ? Bp : Jy; this.pendingRenderTaskId = this.taskService.add(), this.scheduleInRootZone ? this.cancelScheduledCallback = Zone.root.run(() => r(() => this.tick())) : this.cancelScheduledCallback = this.ngZone.runOutsideAngular(() => r(() => this.tick())); }
    shouldScheduleTick(n) { return !(this.disableScheduling && !n || this.appRef.destroyed || this.pendingRenderTaskId !== null || this.runningTick || this.appRef._runningTick || !this.zonelessEnabled && this.zoneIsDefined && Zone.current.get(Yi + this.angularZoneId)); }
    tick() { if (this.runningTick || this.appRef.destroyed)
        return; if (this.appRef.dirtyFlags === 0) {
        this.cleanup();
        return;
    } !this.zonelessEnabled && this.appRef.dirtyFlags & 7 && (this.appRef.dirtyFlags |= 1); let n = this.taskService.add(); try {
        this.ngZone.run(() => { this.runningTick = !0, this.appRef._tick(); }, void 0, this.schedulerTickApplyArgs);
    }
    catch (o) {
        this.taskService.remove(n), this.applicationErrorHandler(o);
    }
    finally {
        this.cleanup();
    } this.useMicrotaskScheduler = !0, Bp(() => { this.useMicrotaskScheduler = !1, this.taskService.remove(n); }); }
    ngOnDestroy() { this.subscriptions.unsubscribe(), this.cleanup(); }
    cleanup() { if (this.runningTick = !1, this.cancelScheduledCallback?.(), this.cancelScheduledCallback = null, this.pendingRenderTaskId !== null) {
        let n = this.pendingRenderTaskId;
        this.pendingRenderTaskId = null, this.taskService.remove(n);
    } }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function JA() { return Z("NgZoneless"), qe([{ provide: Qe, useExisting: la }, { provide: L, useClass: Fn }, { provide: pn, useValue: !0 }, { provide: ci, useValue: !1 }, []]); }
function XA() { return typeof $localize < "u" && $localize.locale || _r; }
var ef = new _("", { providedIn: "root", factory: () => D(ef, { optional: !0, skipSelf: !0 }) || XA() }), eR = new _("", { providedIn: "root", factory: () => dS }), tR = new _(""), nR = new _(""), TD = (function (e) { return e[e.Error = 0] = "Error", e[e.Warning = 1] = "Warning", e[e.Ignore = 2] = "Ignore", e; })(TD || {}), Gl = class {
    name;
    callback;
    constructor(t, n) { this.name = t, this.callback = n; }
};
function oR(e) { return e.map(t => t.nativeElement); }
var ir = class {
    nativeNode;
    constructor(t) { this.nativeNode = t; }
    get parent() { let t = this.nativeNode.parentNode; return t ? new Jt(t) : null; }
    get injector() { return wT(this.nativeNode); }
    get componentInstance() { let t = this.nativeNode; return t && (yp(t) || NT(t)); }
    get context() { return yp(this.nativeNode) || MT(this.nativeNode); }
    get listeners() { return RT(this.nativeNode).filter(t => t.type === "dom"); }
    get references() { return ST(this.nativeNode); }
    get providerTokens() { return _T(this.nativeNode); }
}, Jt = class extends ir {
    constructor(t) { super(t); }
    get nativeElement() { return this.nativeNode.nodeType == Node.ELEMENT_NODE ? this.nativeNode : null; }
    get name() { let t = ve(this.nativeNode), n = t ? t.lView : null; return n !== null ? n[y].data[t.nodeIndex].value : this.nativeNode.nodeName; }
    get properties() { let t = ve(this.nativeNode), n = t ? t.lView : null; if (n === null)
        return {}; let o = n[y].data, r = o[t.nodeIndex], i = {}; return rR(this.nativeElement, i), sR(i, r, n, o), i; }
    get attributes() { let t = {}, n = this.nativeElement; if (!n)
        return t; let o = ve(n), r = o ? o.lView : null; if (r === null)
        return {}; let i = r[y].data[o.nodeIndex].attrs, s = []; if (i) {
        let a = 0;
        for (; a < i.length;) {
            let c = i[a];
            if (typeof c != "string")
                break;
            let l = i[a + 1];
            t[c] = l, s.push(c.toLowerCase()), a += 2;
        }
    } for (let a of n.attributes)
        s.includes(a.name) || (t[a.name] = a.value); return t; }
    get styles() { return this.nativeElement?.style ?? {}; }
    get classes() { let t = {}, o = this.nativeElement.className; return (typeof o != "string" ? o.baseVal.split(" ") : o.split(" ")).forEach(i => t[i] = !0), t; }
    get childNodes() { let t = this.nativeNode.childNodes, n = []; for (let o = 0; o < t.length; o++) {
        let r = t[o];
        n.push(Bn(r));
    } return n; }
    get children() { let t = this.nativeElement; if (!t)
        return []; let n = t.children, o = []; for (let r = 0; r < n.length; r++) {
        let i = n[r];
        o.push(Bn(i));
    } return o; }
    query(t) { return this.queryAll(t)[0] || null; }
    queryAll(t) { let n = []; return hh(this, t, n, !0), n; }
    queryAllNodes(t) { let n = []; return hh(this, t, n, !1), n; }
    triggerEventHandler(t, n) { let o = this.nativeNode, r = []; this.listeners.forEach(i => { if (i.name === t) {
        let s = i.callback;
        s.call(o, n), r.push(s);
    } }), typeof o.eventListeners == "function" && o.eventListeners(t).forEach(i => { if (i.toString().indexOf("__ngUnwrap__") !== -1) {
        let s = i("__ngUnwrap__");
        return r.indexOf(s) === -1 && s.call(o, n);
    } }); }
};
function rR(e, t) { if (e) {
    let n = Object.getPrototypeOf(e), o = Node.prototype;
    for (; n !== null && n !== o;) {
        let r = Object.getOwnPropertyDescriptors(n);
        for (let i in r)
            if (!i.startsWith("__") && !i.startsWith("on")) {
                let s = e[i];
                iR(s) && (t[i] = s);
            }
        n = Object.getPrototypeOf(n);
    }
} }
function iR(e) { return typeof e == "string" || typeof e == "boolean" || typeof e == "number" || e === null; }
function hh(e, t, n, o) { let r = ve(e.nativeNode), i = r ? r.lView : null; if (i !== null) {
    let s = i[y].data[r.nodeIndex];
    $t(s, i, t, n, o, e.nativeNode);
}
else
    tf(e.nativeNode, t, n, o); }
function $t(e, t, n, o, r, i) { let s = kf(e, t); if (e.type & 11) {
    if ($c(s, n, o, r, i), me(e)) {
        let c = le(e.index, t);
        c && c[y].firstChild && $t(c[y].firstChild, c, n, o, r, i);
    }
    else
        e.child && $t(e.child, t, n, o, r, i), s && tf(s, n, o, r);
    let a = t[e.index];
    K(a) && gh(a, n, o, r, i);
}
else if (e.type & 4) {
    let a = t[e.index];
    $c(a[Re], n, o, r, i), gh(a, n, o, r, i);
}
else if (e.type & 16) {
    let a = t[Q], l = a[se].projection[e.projection];
    if (Array.isArray(l))
        for (let u of l)
            $c(u, n, o, r, i);
    else if (l) {
        let u = a[q], d = u[y].data[l.index];
        $t(d, u, n, o, r, i);
    }
}
else
    e.child && $t(e.child, t, n, o, r, i); if (i !== s) {
    let a = e.flags & 2 ? e.projectionNext : e.next;
    a && $t(a, t, n, o, r, i);
} }
function gh(e, t, n, o, r) { for (let i = G; i < e.length; i++) {
    let s = e[i], a = s[y].firstChild;
    a && $t(a, s, t, n, o, r);
} }
function $c(e, t, n, o, r) { if (r !== e) {
    let i = Bn(e);
    if (!i)
        return;
    (o && i instanceof Jt && t(i) && n.indexOf(i) === -1 || !o && t(i) && n.indexOf(i) === -1) && n.push(i);
} }
function tf(e, t, n, o) { let r = e.childNodes, i = r.length; for (let s = 0; s < i; s++) {
    let a = r[s], c = Bn(a);
    c && ((o && c instanceof Jt && t(c) && n.indexOf(c) === -1 || !o && t(c) && n.indexOf(c) === -1) && n.push(c), tf(a, t, n, o));
} }
function sR(e, t, n, o) { let r = t.propertyBindings; if (r !== null)
    for (let i = 0; i < r.length; i++) {
        let s = r[i], c = o[s].split(BM), l = c[0];
        if (c.length > 1) {
            let u = c[1];
            for (let d = 1; d < c.length - 1; d++)
                u += M(n[s + d - 1]) + c[d + 1];
            e[l] = u;
        }
        else
            e[l] = n[s];
    } }
var Uc = "__ng_debug__";
function Bn(e) { return e instanceof Node ? (e.hasOwnProperty(Uc) || (e[Uc] = e.nodeType == Node.ELEMENT_NODE ? new Jt(e) : new ir(e)), e[Uc]) : null; }
import "rxjs";
import "@angular/core/primitives/signals";
import "@angular/core/primitives/di";
import "rxjs/operators";
typeof globalThis.ngServerMode > "u" && (globalThis.ngServerMode = typeof window > "u");
var ya = Symbol("InputSignalNode#UNSET"), UD = Le(W({}, Ca), { transformFn: void 0, applyValueToInputSignal(e, t) { Da(e, t); } }), kx = Symbol();
function GD(e, t) { let n = Object.create(UD); n.value = e, n.transformFn = t?.transform; function o() { if (kr(n), n.value === ya) {
    let r = null;
    throw new w(-950, r);
} return n.value; } return o[ut] = n, o; }
var so = (function (e) { return e[e.Directive = 0] = "Directive", e[e.Component = 1] = "Component", e[e.Injectable = 2] = "Injectable", e[e.Pipe = 3] = "Pipe", e[e.NgModule = 4] = "NgModule", e; })(so || {});
var MD = class {
    attributeName;
    constructor(t) { this.attributeName = t; }
    __NG_ELEMENT_ID__ = () => as(this.attributeName);
    toString() { return `HostAttributeToken ${this.attributeName}`; }
}, aR = new _("");
aR.__NG_ELEMENT_ID__ = e => { let t = T(); if (t === null)
    throw new w(204, !1); if (t.type & 2)
    return t.value; if (e & 8)
    return null; throw new w(204, !1); };
function xx(e) { return new gc; }
function ND(e, t) { return GD(e, t); }
function cR(e) { return GD(ya, e); }
var Ox = (ND.required = cR, ND);
function wD(e, t) { return zu(t); }
function lR(e, t) { return Qu(t); }
var Px = (wD.required = lR, wD);
function Lx(e, t) { return Zu(t); }
function _D(e, t) { return zu(t); }
function uR(e, t) { return Qu(t); }
var Fx = (_D.required = uR, _D);
function jx(e, t) { return Zu(t); }
function WD(e, t) { let n = Object.create(UD), o = new gc; n.value = e; function r() { return kr(n), bD(n.value), n.value; } return r[ut] = n, r.asReadonly = Yf.bind(r), r.set = i => { n.equal(n.value, i) || (Da(n, i), o.emit(i)); }, r.update = i => { bD(n.value), r.set(i(n.value)); }, r.subscribe = o.subscribe.bind(o), r.destroyRef = o.destroyRef, r; }
function bD(e) { if (e === ya)
    throw new w(952, !1); }
function SD(e, t) { return WD(e, t); }
function dR(e) { return WD(ya, e); }
var Vx = (SD.required = dR, SD), qD = !0, ao = class {
}, Hx = tt("ContentChildren", (e, t = {}) => W({ selector: e, first: !1, isViewQuery: !1, descendants: !1, emitDistinctChangesOnly: qD }, t), ao), Bx = tt("ContentChild", (e, t = {}) => W({ selector: e, first: !0, isViewQuery: !1, descendants: !0 }, t), ao), $x = tt("ViewChildren", (e, t = {}) => W({ selector: e, first: !1, isViewQuery: !0, descendants: !0, emitDistinctChangesOnly: qD }, t), ao), Ux = tt("ViewChild", (e, t) => W({ selector: e, first: !0, isViewQuery: !0, descendants: !0 }, t), ao), rf = class {
    full;
    major;
    minor;
    patch;
    constructor(t) { this.full = t; let n = t.split("."); this.major = n[0], this.minor = n[1], this.patch = n.slice(2).join("."); }
}, Gx = new rf("20.2.1");
function fR(e, t, n) { let o = new Ln(n); return Promise.resolve(o); }
function AD(e) { for (let t = e.length - 1; t >= 0; t--)
    if (e[t] !== void 0)
        return e[t]; }
var fa = new _(""), pR = new _("");
function Ar(e) { return !e.moduleRef; }
function zD(e) { let t = Ar(e) ? e.r3Injector : e.moduleRef.injector, n = t.get(L); return n.run(() => { Ar(e) ? e.r3Injector.resolveInjectorInitializers() : e.moduleRef.resolveInjectorInitializers(); let o = t.get(Et), r; if (n.runOutsideAngular(() => { r = n.onError.subscribe({ next: o }); }), Ar(e)) {
    let i = () => t.destroy(), s = e.platformInjector.get(fa);
    s.add(i), t.onDestroy(() => { r.unsubscribe(), s.delete(i); });
}
else {
    let i = () => e.moduleRef.destroy(), s = e.platformInjector.get(fa);
    s.add(i), e.moduleRef.onDestroy(() => { Oo(e.allPlatformModules, e.moduleRef), r.unsubscribe(), s.delete(i); });
} return gR(o, n, () => { let i = t.get(Dt), s = i.add(), a = t.get(pd); return a.runInitializers(), a.donePromise.then(() => { let c = t.get(ef, _r); if (gI(c || _r), !t.get(pR, !0))
    return Ar(e) ? t.get(Oe) : (e.allPlatformModules.push(e.moduleRef), e.moduleRef); if (Ar(e)) {
    let u = t.get(Oe);
    return e.rootComponent !== void 0 && u.bootstrap(e.rootComponent), u;
}
else
    return QD?.(e.moduleRef, e.allPlatformModules), e.moduleRef; }).finally(() => void i.remove(s)); }); }); }
var QD;
function RD() { QD = hR; }
function hR(e, t) { let n = e.injector.get(Oe); if (e._bootstrapComponents.length > 0)
    e._bootstrapComponents.forEach(o => n.bootstrap(o));
else if (e.instance.ngDoBootstrap)
    e.instance.ngDoBootstrap(n);
else
    throw new w(-403, !1); t.push(e); }
function gR(e, t, n) { try {
    let o = n();
    return dd(o) ? o.catch(r => { throw t.runOutsideAngular(() => e(r)), r; }) : o;
}
catch (o) {
    throw t.runOutsideAngular(() => e(o)), o;
} }
var ZD = (() => { class e {
    _injector;
    _modules = [];
    _destroyListeners = [];
    _destroyed = !1;
    constructor(n) { this._injector = n; }
    bootstrapModuleFactory(n, o) { let r = o?.scheduleInRootZone, i = () => ev(o?.ngZone, Le(W({}, ca({ eventCoalescing: o?.ngZoneEventCoalescing, runCoalescing: o?.ngZoneRunCoalescing })), { scheduleInRootZone: r })), s = o?.ignoreChangesOutsideZone, a = [aa({ ngZoneFactory: i, ignoreChangesOutsideZone: s }), { provide: Qe, useExisting: la }, lc], c = Oy(n.moduleType, this.injector, a); return RD(), zD({ moduleRef: c, allPlatformModules: this._modules, platformInjector: this.injector }); }
    bootstrapModule(n, o = []) { let r = gd({}, o); return RD(), fR(this.injector, r, n).then(i => this.bootstrapModuleFactory(i, r)); }
    onDestroy(n) { this._destroyListeners.push(n); }
    get injector() { return this._injector; }
    destroy() { if (this._destroyed)
        throw new w(404, !1); this._modules.slice().forEach(o => o.destroy()), this._destroyListeners.forEach(o => o()); let n = this._injector.get(fa, null); n && (n.forEach(o => o()), n.clear()), this._destroyed = !0; }
    get destroyed() { return this._destroyed; }
    static \u0275fac = function (o) { return new (o || e)(Se(Te)); };
    static \u0275prov = j({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })(), At = null, YD = new _("");
function mR(e) { if (At && !At.get(YD, !1))
    throw new w(400, !1); hd(), At = e; let t = e.get(ZD); return JD(e), t; }
function yR(e, t, n = []) { let o = `Platform: ${t}`, r = new _(o); return (i = []) => { let s = hf(); if (!s || s.injector.get(YD, !1)) {
    let a = [...n, ...i, { provide: r, useValue: !0 }];
    e ? e(a) : mR(KD(a, o));
} return vR(r); }; }
function KD(e = [], t) { return Te.create({ name: t, providers: [{ provide: _f, useValue: "platform" }, { provide: fa, useValue: new Set([() => At = null]) }, ...e] }); }
function vR(e) { let t = hf(); if (!t)
    throw new w(401, !1); return t; }
function hf() { return At?.get(ZD) ?? null; }
function Wx() { hf()?.destroy(); }
function IR(e = []) { if (At)
    return At; let t = KD(e); return At = t, hd(), JD(t), t; }
function qx(e) { return qe([{ provide: Kl, useValue: e, multi: !0 }]); }
function JD(e) { let t = e.get(Kl, null); Qr(e, () => { t?.forEach(n => n()); }); }
function zx(e) { return qe([]); }
function Qx() { return !1; }
function Zx() { }
function Yx(e) { let t = Ku(e); if (!t)
    throw XD(e); return new Ln(t); }
function Kx(e) { let t = Ku(e); if (!t)
    throw XD(e); return t; }
function XD(e) { return new Error(`No module with ID ${e} loaded`); }
var ER = (() => { class e {
    static __NG_ELEMENT_ID__ = DR;
} return e; })();
function DR(e) { return CR(T(), g(), (e & 16) === 16); }
function CR(e, t, n) { if (me(e) && !n) {
    let o = le(e.index, t);
    return new wt(o, o);
}
else if (e.type & 175) {
    let o = t[Q];
    return new wt(o, t);
} return null; }
var sf = class extends ER {
}, kD = class extends sf {
}, pa = class {
    constructor() { }
    supports(t) { return Jo(t); }
    create(t) { return new af(t); }
}, TR = (e, t) => t, af = class {
    length = 0;
    collection;
    _linkedRecords = null;
    _unlinkedRecords = null;
    _previousItHead = null;
    _itHead = null;
    _itTail = null;
    _additionsHead = null;
    _additionsTail = null;
    _movesHead = null;
    _movesTail = null;
    _removalsHead = null;
    _removalsTail = null;
    _identityChangesHead = null;
    _identityChangesTail = null;
    _trackByFn;
    constructor(t) { this._trackByFn = t || TR; }
    forEachItem(t) { let n; for (n = this._itHead; n !== null; n = n._next)
        t(n); }
    forEachOperation(t) { let n = this._itHead, o = this._removalsHead, r = 0, i = null; for (; n || o;) {
        let s = !o || n && n.currentIndex < xD(o, r, i) ? n : o, a = xD(s, r, i), c = s.currentIndex;
        if (s === o)
            r--, o = o._nextRemoved;
        else if (n = n._next, s.previousIndex == null)
            r++;
        else {
            i || (i = []);
            let l = a - r, u = c - r;
            if (l != u) {
                for (let f = 0; f < l; f++) {
                    let p = f < i.length ? i[f] : i[f] = 0, h = p + f;
                    u <= h && h < l && (i[f] = p + 1);
                }
                let d = s.previousIndex;
                i[d] = u - l;
            }
        }
        a !== c && t(s, a, c);
    } }
    forEachPreviousItem(t) { let n; for (n = this._previousItHead; n !== null; n = n._nextPrevious)
        t(n); }
    forEachAddedItem(t) { let n; for (n = this._additionsHead; n !== null; n = n._nextAdded)
        t(n); }
    forEachMovedItem(t) { let n; for (n = this._movesHead; n !== null; n = n._nextMoved)
        t(n); }
    forEachRemovedItem(t) { let n; for (n = this._removalsHead; n !== null; n = n._nextRemoved)
        t(n); }
    forEachIdentityChange(t) { let n; for (n = this._identityChangesHead; n !== null; n = n._nextIdentityChange)
        t(n); }
    diff(t) { if (t == null && (t = []), !Jo(t))
        throw new w(900, !1); return this.check(t) ? this : null; }
    onDestroy() { }
    check(t) { this._reset(); let n = this._itHead, o = !1, r, i, s; if (Array.isArray(t)) {
        this.length = t.length;
        for (let a = 0; a < this.length; a++)
            i = t[a], s = this._trackByFn(a, i), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, i, s, a), o = !0) : (o && (n = this._verifyReinsertion(n, i, s, a)), Object.is(n.item, i) || this._addIdentityChange(n, i)), n = n._next;
    }
    else
        r = 0, sy(t, a => { s = this._trackByFn(r, a), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, a, s, r), o = !0) : (o && (n = this._verifyReinsertion(n, a, s, r)), Object.is(n.item, a) || this._addIdentityChange(n, a)), n = n._next, r++; }), this.length = r; return this._truncate(n), this.collection = t, this.isDirty; }
    get isDirty() { return this._additionsHead !== null || this._movesHead !== null || this._removalsHead !== null || this._identityChangesHead !== null; }
    _reset() { if (this.isDirty) {
        let t;
        for (t = this._previousItHead = this._itHead; t !== null; t = t._next)
            t._nextPrevious = t._next;
        for (t = this._additionsHead; t !== null; t = t._nextAdded)
            t.previousIndex = t.currentIndex;
        for (this._additionsHead = this._additionsTail = null, t = this._movesHead; t !== null; t = t._nextMoved)
            t.previousIndex = t.currentIndex;
        this._movesHead = this._movesTail = null, this._removalsHead = this._removalsTail = null, this._identityChangesHead = this._identityChangesTail = null;
    } }
    _mismatch(t, n, o, r) { let i; return t === null ? i = this._itTail : (i = t._prev, this._remove(t)), t = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(o, null), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._reinsertAfter(t, i, r)) : (t = this._linkedRecords === null ? null : this._linkedRecords.get(o, r), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._moveAfter(t, i, r)) : t = this._addAfter(new cf(n, o), i, r)), t; }
    _verifyReinsertion(t, n, o, r) { let i = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(o, null); return i !== null ? t = this._reinsertAfter(i, t._prev, r) : t.currentIndex != r && (t.currentIndex = r, this._addToMoves(t, r)), t; }
    _truncate(t) { for (; t !== null;) {
        let n = t._next;
        this._addToRemovals(this._unlink(t)), t = n;
    } this._unlinkedRecords !== null && this._unlinkedRecords.clear(), this._additionsTail !== null && (this._additionsTail._nextAdded = null), this._movesTail !== null && (this._movesTail._nextMoved = null), this._itTail !== null && (this._itTail._next = null), this._removalsTail !== null && (this._removalsTail._nextRemoved = null), this._identityChangesTail !== null && (this._identityChangesTail._nextIdentityChange = null); }
    _reinsertAfter(t, n, o) { this._unlinkedRecords !== null && this._unlinkedRecords.remove(t); let r = t._prevRemoved, i = t._nextRemoved; return r === null ? this._removalsHead = i : r._nextRemoved = i, i === null ? this._removalsTail = r : i._prevRemoved = r, this._insertAfter(t, n, o), this._addToMoves(t, o), t; }
    _moveAfter(t, n, o) { return this._unlink(t), this._insertAfter(t, n, o), this._addToMoves(t, o), t; }
    _addAfter(t, n, o) { return this._insertAfter(t, n, o), this._additionsTail === null ? this._additionsTail = this._additionsHead = t : this._additionsTail = this._additionsTail._nextAdded = t, t; }
    _insertAfter(t, n, o) { let r = n === null ? this._itHead : n._next; return t._next = r, t._prev = n, r === null ? this._itTail = t : r._prev = t, n === null ? this._itHead = t : n._next = t, this._linkedRecords === null && (this._linkedRecords = new ha), this._linkedRecords.put(t), t.currentIndex = o, t; }
    _remove(t) { return this._addToRemovals(this._unlink(t)); }
    _unlink(t) { this._linkedRecords !== null && this._linkedRecords.remove(t); let n = t._prev, o = t._next; return n === null ? this._itHead = o : n._next = o, o === null ? this._itTail = n : o._prev = n, t; }
    _addToMoves(t, n) { return t.previousIndex === n || (this._movesTail === null ? this._movesTail = this._movesHead = t : this._movesTail = this._movesTail._nextMoved = t), t; }
    _addToRemovals(t) { return this._unlinkedRecords === null && (this._unlinkedRecords = new ha), this._unlinkedRecords.put(t), t.currentIndex = null, t._nextRemoved = null, this._removalsTail === null ? (this._removalsTail = this._removalsHead = t, t._prevRemoved = null) : (t._prevRemoved = this._removalsTail, this._removalsTail = this._removalsTail._nextRemoved = t), t; }
    _addIdentityChange(t, n) { return t.item = n, this._identityChangesTail === null ? this._identityChangesTail = this._identityChangesHead = t : this._identityChangesTail = this._identityChangesTail._nextIdentityChange = t, t; }
}, cf = class {
    item;
    trackById;
    currentIndex = null;
    previousIndex = null;
    _nextPrevious = null;
    _prev = null;
    _next = null;
    _prevDup = null;
    _nextDup = null;
    _prevRemoved = null;
    _nextRemoved = null;
    _nextAdded = null;
    _nextMoved = null;
    _nextIdentityChange = null;
    constructor(t, n) { this.item = t, this.trackById = n; }
}, lf = class {
    _head = null;
    _tail = null;
    add(t) { this._head === null ? (this._head = this._tail = t, t._nextDup = null, t._prevDup = null) : (this._tail._nextDup = t, t._prevDup = this._tail, t._nextDup = null, this._tail = t); }
    get(t, n) { let o; for (o = this._head; o !== null; o = o._nextDup)
        if ((n === null || n <= o.currentIndex) && Object.is(o.trackById, t))
            return o; return null; }
    remove(t) { let n = t._prevDup, o = t._nextDup; return n === null ? this._head = o : n._nextDup = o, o === null ? this._tail = n : o._prevDup = n, this._head === null; }
}, ha = class {
    map = new Map;
    put(t) { let n = t.trackById, o = this.map.get(n); o || (o = new lf, this.map.set(n, o)), o.add(t); }
    get(t, n) { let o = t, r = this.map.get(o); return r ? r.get(t, n) : null; }
    remove(t) { let n = t.trackById; return this.map.get(n).remove(t) && this.map.delete(n), t; }
    get isEmpty() { return this.map.size === 0; }
    clear() { this.map.clear(); }
};
function xD(e, t, n) { let o = e.previousIndex; if (o === null)
    return o; let r = 0; return n && o < n.length && (r = n[o]), o + t + r; }
var ga = class {
    constructor() { }
    supports(t) { return t instanceof Map || $s(t); }
    create() { return new uf; }
}, uf = class {
    _records = new Map;
    _mapHead = null;
    _appendAfter = null;
    _previousMapHead = null;
    _changesHead = null;
    _changesTail = null;
    _additionsHead = null;
    _additionsTail = null;
    _removalsHead = null;
    _removalsTail = null;
    get isDirty() { return this._additionsHead !== null || this._changesHead !== null || this._removalsHead !== null; }
    forEachItem(t) { let n; for (n = this._mapHead; n !== null; n = n._next)
        t(n); }
    forEachPreviousItem(t) { let n; for (n = this._previousMapHead; n !== null; n = n._nextPrevious)
        t(n); }
    forEachChangedItem(t) { let n; for (n = this._changesHead; n !== null; n = n._nextChanged)
        t(n); }
    forEachAddedItem(t) { let n; for (n = this._additionsHead; n !== null; n = n._nextAdded)
        t(n); }
    forEachRemovedItem(t) { let n; for (n = this._removalsHead; n !== null; n = n._nextRemoved)
        t(n); }
    diff(t) { if (!t)
        t = new Map;
    else if (!(t instanceof Map || $s(t)))
        throw new w(900, !1); return this.check(t) ? this : null; }
    onDestroy() { }
    check(t) { this._reset(); let n = this._mapHead; if (this._appendAfter = null, this._forEach(t, (o, r) => { if (n && n.key === r)
        this._maybeAddToChanges(n, o), this._appendAfter = n, n = n._next;
    else {
        let i = this._getOrCreateRecordForKey(r, o);
        n = this._insertBeforeOrAppend(n, i);
    } }), n) {
        n._prev && (n._prev._next = null), this._removalsHead = n;
        for (let o = n; o !== null; o = o._nextRemoved)
            o === this._mapHead && (this._mapHead = null), this._records.delete(o.key), o._nextRemoved = o._next, o.previousValue = o.currentValue, o.currentValue = null, o._prev = null, o._next = null;
    } return this._changesTail && (this._changesTail._nextChanged = null), this._additionsTail && (this._additionsTail._nextAdded = null), this.isDirty; }
    _insertBeforeOrAppend(t, n) { if (t) {
        let o = t._prev;
        return n._next = t, n._prev = o, t._prev = n, o && (o._next = n), t === this._mapHead && (this._mapHead = n), this._appendAfter = t, t;
    } return this._appendAfter ? (this._appendAfter._next = n, n._prev = this._appendAfter) : this._mapHead = n, this._appendAfter = n, null; }
    _getOrCreateRecordForKey(t, n) { if (this._records.has(t)) {
        let r = this._records.get(t);
        this._maybeAddToChanges(r, n);
        let i = r._prev, s = r._next;
        return i && (i._next = s), s && (s._prev = i), r._next = null, r._prev = null, r;
    } let o = new df(t); return this._records.set(t, o), o.currentValue = n, this._addToAdditions(o), o; }
    _reset() { if (this.isDirty) {
        let t;
        for (this._previousMapHead = this._mapHead, t = this._previousMapHead; t !== null; t = t._next)
            t._nextPrevious = t._next;
        for (t = this._changesHead; t !== null; t = t._nextChanged)
            t.previousValue = t.currentValue;
        for (t = this._additionsHead; t != null; t = t._nextAdded)
            t.previousValue = t.currentValue;
        this._changesHead = this._changesTail = null, this._additionsHead = this._additionsTail = null, this._removalsHead = null;
    } }
    _maybeAddToChanges(t, n) { Object.is(n, t.currentValue) || (t.previousValue = t.currentValue, t.currentValue = n, this._addToChanges(t)); }
    _addToAdditions(t) { this._additionsHead === null ? this._additionsHead = this._additionsTail = t : (this._additionsTail._nextAdded = t, this._additionsTail = t); }
    _addToChanges(t) { this._changesHead === null ? this._changesHead = this._changesTail = t : (this._changesTail._nextChanged = t, this._changesTail = t); }
    _forEach(t, n) { t instanceof Map ? t.forEach(n) : Object.keys(t).forEach(o => n(t[o], o)); }
}, df = class {
    key;
    previousValue = null;
    currentValue = null;
    _nextPrevious = null;
    _next = null;
    _prev = null;
    _nextAdded = null;
    _nextRemoved = null;
    _nextChanged = null;
    constructor(t) { this.key = t; }
};
function OD() { return new eC([new pa]); }
var eC = (() => { class e {
    factories;
    static \u0275prov = j({ token: e, providedIn: "root", factory: OD });
    constructor(n) { this.factories = n; }
    static create(n, o) { if (o != null) {
        let r = o.factories.slice();
        n = n.concat(r);
    } return new e(n); }
    static extend(n) { return { provide: e, useFactory: o => e.create(n, o || OD()), deps: [[e, new is, new rs]] }; }
    find(n) { let o = this.factories.find(r => r.supports(n)); if (o != null)
        return o; throw new w(901, !1); }
} return e; })();
function PD() { return new tC([new ga]); }
var tC = (() => { class e {
    static \u0275prov = j({ token: e, providedIn: "root", factory: PD });
    factories;
    constructor(n) { this.factories = n; }
    static create(n, o) { if (o) {
        let r = o.factories.slice();
        n = n.concat(r);
    } return new e(n); }
    static extend(n) { return { provide: e, useFactory: o => e.create(n, o || PD()), deps: [[e, new is, new rs]] }; }
    find(n) { let o = this.factories.find(r => r.supports(n)); if (o)
        return o; throw new w(901, !1); }
} return e; })(), MR = [new ga], NR = [new pa], Jx = new eC(NR), Xx = new tC(MR), eO = yR(null, "core", []), tO = (() => { class e {
    constructor(n) { }
    static \u0275fac = function (o) { return new (o || e)(Se(Oe)); };
    static \u0275mod = Xu({ type: e });
    static \u0275inj = fo({});
} return e; })();
function nO(e) { k(8); try {
    let { rootComponent: t, appProviders: n, platformProviders: o } = e, r = IR(o), i = [aa({}), { provide: Qe, useExisting: la }, lc, ...n || []], s = new er({ providers: i, parent: r, debugName: "", runEnvironmentInitializers: !1 });
    return zD({ r3Injector: s.injector, platformInjector: r, rootComponent: t });
}
catch (t) {
    return Promise.reject(t);
}
finally {
    k(9);
} }
var ua = new WeakSet, LD = "", da = [];
function FD(e) { return e.get(ms, ou); }
function wR() { let e = [{ provide: ms, useFactory: () => { let t = !0; if (typeof ngServerMode > "u" || !ngServerMode) {
            let n = D(ot);
            t = !!window._ejsas?.[n];
        } return t && Z("NgEventReplay"), t; } }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: ft, useValue: () => { let t = D(Oe), { injector: n } = t; if (!ua.has(t)) {
        let o = D(fr);
        if (FD(n)) {
            ug();
            let r = n.get(ot), i = cg(r, (s, a, c) => { s.nodeType === Node.ELEMENT_NODE && (ag(s, a, c), su(s, o)); });
            t.onDestroy(i);
        }
    } }, multi: !0 }, { provide: Mr, useFactory: () => { let t = D(Oe), { injector: n } = t; return () => { if (!FD(n) || ua.has(t))
        return; ua.add(t); let o = n.get(ot); t.onDestroy(() => { ua.delete(t), typeof ngServerMode < "u" && !ngServerMode && mc(o); }), t.whenStable().then(() => { if (t.destroyed)
        return; let r = n.get(cu); _R(r, n); let i = n.get(fr); i.get(LD)?.forEach(au), i.delete(LD); let s = r.instance; Es(n) ? t.onDestroy(() => s.cleanUp()) : s.cleanUp(); }); }; }, multi: !0 }), e; }
var _R = (e, t) => { let n = t.get(ot), o = window._ejsas[n], r = e.instance = new op(new Xf(o.c)); for (let a of o.et)
    r.addEvent(a); for (let a of o.etc)
    r.addEvent(a); let i = rp(n); r.replayEarlyEventInfos(i), mc(n); let s = new tp(a => { SR(t, a, a.currentTarget); }); np(r, s); };
function bR(e, t, n) { let o = new Map, r = t[Ot], i = e.cleanup; if (!i || !r)
    return o; for (let s = 0; s < i.length;) {
    let a = i[s++], c = i[s++];
    if (typeof a != "string")
        continue;
    let l = a;
    if (!Jf(l))
        continue;
    Kf(l) ? n.capture.add(l) : n.regular.add(l);
    let u = R(t[c]);
    s++;
    let d = i[s++];
    (typeof d == "boolean" || d >= 0) && (o.has(u) ? o.get(u).push(l) : o.set(u, [l]));
} return o; }
function SR(e, t, n) { let o = (n && n.getAttribute(Qn)) ?? ""; /d\d+/.test(o) ? AR(o, e, t, n) : t.eventPhase === ep.REPLAY && lu(t, n); }
function AR(e, t, n, o) { da.push({ event: n, currentTarget: o }), ct(t, e, RR); }
function RR(e) { let t = [...da], n = new Set(e); da = []; for (let { event: o, currentTarget: r } of t) {
    let i = r.getAttribute(Qn);
    n.has(i) ? lu(o, r) : da.push({ event: o, currentTarget: r });
} }
var ff = class {
    views = [];
    indexByContent = new Map;
    add(t) { let n = JSON.stringify(t); if (!this.indexByContent.has(n)) {
        let o = this.views.length;
        return this.views.push(t), this.indexByContent.set(n, o), o;
    } return this.indexByContent.get(n); }
    getAll() { return this.views; }
}, kR = 0;
function nC(e) { return e.ssrId || (e.ssrId = `t${kR++}`), e.ssrId; }
function oC(e, t, n) { let o = []; return Rn(e, t, n, o), o.length; }
function xR(e) { let t = []; return Os(e, t), t.length; }
function rC(e, t, n) { let o = e[F]; return o && !o.hasAttribute(Gn) ? ma(o, e, null, t) : null; }
function iC(e, t, n) { let o = Do(e[F]), r = rC(o, t); if (r === null)
    return; let i = R(o[F]), s = e[q], a = ma(i, s, null, t), c = o[C], l = `${r}|${a}`; c.setAttribute(i, Mn, l); }
function oO(e, t) { let n = e.injector, o = Um(n), r = Es(n), i = new ff, s = new Map, a = e._views, c = n.get(ms, ou), l = { regular: new Set, capture: new Set }, u = new Map, d = e.injector.get(ot); for (let h of a) {
    let m = uu(h);
    if (m !== null) {
        let v = { serializedViewCollection: i, corruptedTextNodes: s, isI18nHydrationEnabled: o, isIncrementalHydrationEnabled: r, i18nChildren: new Map, eventTypesToReplay: l, shouldReplayEvents: c, appId: d, deferBlocks: u };
        K(m) ? iC(m, v) : rC(m, v), jR(s, t);
    }
} let f = i.getAll(), p = n.get(Xt); if (p.set(ys, f), u.size > 0) {
    let h = {};
    for (let [m, v] of u.entries())
        h[m] = v;
    p.set(vs, h);
} return l; }
function OR(e, t, n, o, r) { let i = [], s = ""; for (let a = G; a < e.length; a++) {
    let c = e[a], l, u, d;
    if (Ve(c) && (c = c[I], K(c))) {
        u = xR(c) + 1, iC(c, r);
        let p = Do(c[F]);
        d = { [fs]: p[y].ssrId, [Je]: u };
    }
    if (!d) {
        let p = c[y];
        p.type === 1 ? (l = p.ssrId, u = 1) : (l = nC(p), u = oC(p, c, p.firstChild)), d = { [fs]: l, [Je]: u };
        let h = !1;
        if (sv(n[y], t)) {
            let m = he(n, t), v = re(n[y], t);
            if (r.isIncrementalHydrationEnabled && v.hydrateTriggers !== null) {
                let E = `d${r.deferBlocks.size}`;
                v.hydrateTriggers.has(7) && (h = !0);
                let A = [];
                Os(e, A);
                let ce = { [Je]: A.length, [dr]: m[at] }, Pe = PR(v.hydrateTriggers);
                Pe.length > 0 && (ce[gs] = Pe), o !== null && (ce[eu] = o), r.deferBlocks.set(E, ce);
                let pe = R(e);
                pe !== void 0 ? pe.nodeType === Node.COMMENT_NODE && jD(pe, E) : jD(pe, E), h || HR(v, A, E, r), o = E, d[hs] = E;
            }
            d[dr] = m[at];
        }
        h || Object.assign(d, sC(e[a], o, r));
    }
    let f = JSON.stringify(d);
    if (i.length > 0 && f === s) {
        let p = i[i.length - 1];
        p[lr] ??= 1, p[lr]++;
    }
    else
        s = f, i.push(d);
} return i; }
function PR(e) { let t = new Set([0, 1, 2, 5]), n = []; for (let [o, r] of e)
    t.has(o) && (r === null ? n.push(o) : n.push({ trigger: o, delay: r.delay })); return n; }
function Rr(e, t, n, o) { let r = t.index - I; e[ur] ??= {}, e[ur][r] ??= jm(t, n, o); }
function nf(e, t) { let n = typeof t == "number" ? t : t.index - I; e[zn] ??= [], e[zn].includes(n) || e[zn].push(n); }
function sC(e, t = null, n) { let o = {}, r = e[y], i = Gm(r, n), s = n.shouldReplayEvents ? bR(r, e, n.eventTypesToReplay) : null; for (let a = I; a < r.bindingStartIndex; a++) {
    let c = r.data[a], l = a - I, u = Wm(e, a, n);
    if (u) {
        o[ps] ??= {}, o[ps][l] = u.caseQueue;
        for (let d of u.disconnectedNodes)
            nf(o, d);
        for (let d of u.disjointNodes) {
            let f = r.data[d + I];
            Rr(o, f, e, i);
        }
        continue;
    }
    if (ss(c) && !Zn(c)) {
        if (K(e[a]) && c.tView && (o[ds] ??= {}, o[ds][l] = nC(c.tView)), to(c, e) && VR(c)) {
            nf(o, c);
            continue;
        }
        if (Array.isArray(c.projection)) {
            for (let d of c.projection)
                if (d)
                    if (!Array.isArray(d))
                        !Fa(d) && !Wn(d) && (to(d, e) ? nf(o, d) : Rr(o, d, e, i));
                    else
                        throw Sm(R(e[a]));
        }
        if (LR(o, c, e, i), K(e[a])) {
            let d = e[a][F];
            if (Array.isArray(d)) {
                let f = R(d);
                f.hasAttribute(Gn) || ma(f, d, t, n);
            }
            o[qn] ??= {}, o[qn][l] = OR(e[a], c, e, t, n);
        }
        else if (Array.isArray(e[a]) && !_h(c)) {
            let d = R(e[a][F]);
            d.hasAttribute(Gn) || ma(d, e[a], t, n);
        }
        else if (c.type & 8)
            o[cr] ??= {}, o[cr][l] = oC(r, e, c.child);
        else if (c.type & 144) {
            let d = c.next;
            for (; d !== null && d.type & 144;)
                d = d.next;
            d && !Wn(d) && Rr(o, d, e, i);
        }
        else if (c.type & 1) {
            let d = R(e[a]);
            fu(n, d);
        }
        if (s && c.type & 2) {
            let d = R(e[a]);
            s.has(d) && iu(d, s.get(d), t);
        }
    }
} return o; }
function LR(e, t, n, o) { Fa(t) || (t.projectionNext && t.projectionNext !== t.next && !Wn(t.projectionNext) && Rr(e, t.projectionNext, n, o), t.prev === null && t.parent !== null && to(t.parent, n) && !to(t, n) && Rr(e, t, n, o)); }
function FR(e) { let t = e[P]; return t?.constructor ? U(t.constructor)?.encapsulation === Xe.ShadowDom : !1; }
function ma(e, t, n, o) { let r = t[C]; if (Sf(t) && !js() || FR(t))
    return r.setAttribute(e, Gn, ""), null; {
    let i = sC(t, n, o), s = o.serializedViewCollection.add(i);
    return r.setAttribute(e, Mn, s.toString()), s;
} }
function jD(e, t) { e.textContent = `ngh=${t}`; }
function jR(e, t) { for (let [n, o] of e)
    n.after(t.createComment(o)); }
function VR(e) { let t = e; for (; t != null;) {
    if (me(t))
        return !0;
    t = t.parent;
} return !1; }
function HR(e, t, n, o) { let r = Cg(e.hydrateTriggers); for (let i of r)
    o.eventTypesToReplay.regular.add(i); if (r.length > 0) {
    let i = t.filter(s => s.nodeType === Node.ELEMENT_NODE);
    for (let s of i)
        iu(s, r, n);
} }
var VD = !1, HD = !1, BD = !1;
function BR() { VD || (VD = !0, mg(), cI(), nE(), lI(), Qy(), vy(), Km(), hm()); }
function $R() { HD || (HD = !0, yI(), $m(), zm()); }
function UR() { BD || (BD = !0, Ng()); }
function GR(e) { return e.whenStable(); }
var rO = "ngcm";
function iO() { let e = [{ provide: en, useFactory: () => { let t = !0; return (typeof ngServerMode > "u" || !ngServerMode) && (t = !!D(Xt, { optional: !0 })?.get(ys, null)), t && Z("NgHydration"), t; } }, { provide: ft, useValue: () => { ju(!1), !(typeof ngServerMode < "u" && ngServerMode) && D(en) && (_g(nt()), BR()); }, multi: !0 }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: tu, useFactory: () => D(en) }, { provide: Mr, useFactory: () => { if (D(en)) {
        let t = D(Oe);
        return () => { GR(t).then(() => { t.destroyed || Vu(t); }); };
    } return () => { }; }, multi: !0 }), qe(e); }
function sO() { return [{ provide: nu, useFactory: () => D(en) }, { provide: ft, useValue: () => { D(en) && ($R(), ju(!0), Z("NgI18nHydration")); }, multi: !0 }]; }
function aO() { let e = [wR(), { provide: ru, useValue: !0 }, { provide: rt, useClass: dg }, { provide: ft, useValue: () => { UR(), Z("NgIncrementalHydration"); }, multi: !0 }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: Mr, useFactory: () => { let t = D(Te), n = nt(); return () => { let o = wg(t), r = Vm(n, n.body); Tv(t, o, r), Tg(n, t); }; }, multi: !0 }), e; }
function cO(e) { return typeof e == "boolean" ? e : e != null && e !== "false"; }
function lO(e, t = NaN) { return !isNaN(parseFloat(e)) && !isNaN(Number(e)) ? Number(e) : t; }
var WR = "\u{1F170}\uFE0F", va = !1;
function uO(e) { if (!va)
    return; let { startLabel: t } = aC(e); performance.mark(t); }
function dO(e) { if (!va)
    return; let { startLabel: t, labelName: n, endLabel: o } = aC(e); performance.mark(o), performance.measure(n, t, o), performance.clearMarks(t), performance.clearMarks(o); }
function aC(e) { let t = `${WR}:${e}`; return { labelName: t, startLabel: `start:${t}`, endLabel: `end:${t}` }; }
var $D = !1;
function fO() { if (!$D && (typeof performance > "u" || !performance.mark || !performance.measure)) {
    $D = !0, console.warn("Performance API is not supported on this platform");
    return;
} va = !0; }
function pO() { va = !1; }
function hO(e) { let t = e; for (; t;) {
    let n = Wh(t);
    if (n !== null)
        for (let o = I; o < n.length; o++) {
            let r = n[o];
            if (!Y(r) && !K(r) || r[F] !== t)
                continue;
            let i = n[y], s = yt(i, o);
            if (me(s)) {
                let a = i.data[s.directiveStart + s.componentOffset], c = a.debugInfo?.className || a.type.name;
                if (c)
                    return c;
                break;
            }
        }
    t = t.parentNode;
} return null; }
function gO(e) { }
function mO(e) { return X({ usage: 1, kind: "directive", type: e.type }).compileDirectiveDeclaration(fe, `ng:///${e.type.name}/\u0275fac.js`, e); }
function yO(e) { ld(e.type, e.decorators, e.ctorParameters ?? null, e.propDecorators ?? null); }
function vO(e) { fv(e.type, e.resolveDeferredDeps, (...t) => { let n = e.resolveMetadata(...t); ld(e.type, n.decorators, n.ctorParameters, n.propDecorators); }); }
function IO(e) { return X({ usage: 1, kind: "component", type: e.type }).compileComponentDeclaration(fe, `ng:///${e.type.name}/\u0275cmp.js`, e); }
function EO(e) { return X({ usage: 1, kind: qR(e.target), type: e.type }).compileFactoryDeclaration(fe, `ng:///${e.type.name}/\u0275fac.js`, e); }
function qR(e) { switch (e) {
    case so.Directive: return "directive";
    case so.Component: return "component";
    case so.Injectable: return "injectable";
    case so.Pipe: return "pipe";
    case so.NgModule: return "NgModule";
} }
function DO(e) { return X({ usage: 1, kind: "injectable", type: e.type }).compileInjectableDeclaration(fe, `ng:///${e.type.name}/\u0275prov.js`, e); }
function CO(e) { return X({ usage: 1, kind: "NgModule", type: e.type }).compileInjectorDeclaration(fe, `ng:///${e.type.name}/\u0275inj.js`, e); }
function TO(e) { return X({ usage: 1, kind: "NgModule", type: e.type }).compileNgModuleDeclaration(fe, `ng:///${e.type.name}/\u0275mod.js`, e); }
function MO(e) { return X({ usage: 1, kind: "pipe", type: e.type }).compilePipeDeclaration(fe, `ng:///${e.type.name}/\u0275pipe.js`, e); }
var of = Symbol("NOT_SET"), cC = new Set, zR = Le(W({}, Ca), { consumerIsAlwaysLive: !0, consumerAllowSignalWrites: !0, value: of, cleanup: null, consumerMarkedDirty() { if (this.sequence.impl.executing) {
        if (this.sequence.lastPhase === null || this.sequence.lastPhase < this.phase)
            return;
        this.sequence.erroredOrDestroyed = !0;
    } this.sequence.scheduler.notify(7); }, phaseFn(e) { if (this.sequence.lastPhase = this.phase, !this.dirty)
        return this.signal; if (this.dirty = !1, this.value !== of && !Or(this))
        return this.signal; try {
        for (let r of this.cleanup ?? cC)
            r();
    }
    finally {
        this.cleanup?.clear();
    } let t = []; e !== void 0 && t.push(e), t.push(this.registerCleanupFn); let n = lo(this), o; try {
        o = this.userFn.apply(null, t);
    }
    finally {
        xr(this, n);
    } return (this.value === of || !this.equal(this.value, o)) && (this.value = o, this.version++), this.signal; } }), pf = class extends nr {
    scheduler;
    lastPhase = null;
    nodes = [void 0, void 0, void 0, void 0];
    constructor(t, n, o, r, i, s = null) { super(t, [void 0, void 0, void 0, void 0], o, !1, i.get(fn), s), this.scheduler = r; for (let a of sd) {
        let c = n[a];
        if (c === void 0)
            continue;
        let l = Object.create(zR);
        l.sequence = this, l.phase = a, l.userFn = c, l.dirty = !0, l.signal = () => (kr(l), l.value), l.signal[ut] = l, l.registerCleanupFn = u => (l.cleanup ??= new Set).add(u), this.nodes[a] = l, this.hooks[a] = u => l.phaseFn(u);
    } }
    afterRun() { super.afterRun(), this.lastPhase = null; }
    destroy() { super.destroy(); for (let t of this.nodes)
        if (t)
            try {
                for (let n of t.cleanup ?? cC)
                    n();
            }
            finally {
                uo(t);
            } }
};
function NO(e, t) { if (typeof ngServerMode < "u" && ngServerMode)
    return Qs; let n = t?.injector ?? D(Te), o = n.get(Qe), r = n.get(zs), i = n.get(oo, null, { optional: !0 }); r.impl ??= n.get(ad); let s = e; typeof s == "function" && (s = { mixedReadWrite: e }); let a = n.get(li, null, { optional: !0 }), c = new pf(r.impl, [s.earlyRead, s.write, s.mixedReadWrite, s.read], a?.view, o, n, i?.snapshot(null)); return r.impl.register(c), c; }
function wO(e, t) { let n = U(e), o = t.elementInjector || zr(); return new _t(n).create(o, t.projectableNodes, t.hostElement, t.environmentInjector, t.directives, t.bindings); }
function _O(e) { let t = U(e); if (!t)
    return null; let n = new _t(t); return { get selector() { return n.selector; }, get type() { return n.componentType; }, get inputs() { return n.inputs; }, get outputs() { return n.outputs; }, get ngContentSelectors() { return n.ngContentSelectors; }, get isStandalone() { return t.standalone; }, get isSignal() { return t.signals; } }; }
function bO(...e) { return e.reduce((t, n) => Object.assign(t, n, { providers: [...t.providers, ...n.providers] }), { providers: [] }); }
var SO = new _("", { providedIn: "platform", factory: () => null }), AO = new _("", { providedIn: "platform", factory: () => null }), RO = new _("", { providedIn: "platform", factory: () => null });
export { VT as ANIMATION_MODULE_TYPE, Mr as APP_BOOTSTRAP_LISTENER, ot as APP_ID, fd as APP_INITIALIZER, pd as ApplicationInitStatus, tO as ApplicationModule, Oe as ApplicationRef, Vh as Attribute, DD as COMPILER_OPTIONS, HT as CSP_NONCE, PM as CUSTOM_ELEMENTS_SCHEMA, ls as ChangeDetectionStrategy, ER as ChangeDetectorRef, QA as Compiler, Ul as CompilerFactory, BA as Component, Bs as ComponentFactory, Er as ComponentFactoryResolver, ey as ComponentRef, Bx as ContentChild, Hx as ContentChildren, eR as DEFAULT_CURRENCY_CODE, DC as DOCUMENT, Jt as DebugElement, Gl as DebugEventListener, ir as DebugNode, af as DefaultIterableDiffer, fn as DestroyRef, ED as Directive, ft as ENVIRONMENT_INITIALIZER, ar as ElementRef, kD as EmbeddedViewRef, pt as EnvironmentInjector, ai as ErrorHandler, Ye as EventEmitter, aR as HOST_TAG_NAME, vh as Host, MD as HostAttributeToken, WA as HostBinding, qA as HostListener, mC as INJECTOR, mh as Inject, uT as Injectable, _ as InjectionToken, Te as Injector, UA as Input, eC as IterableDiffers, tC as KeyValueDiffers, ef as LOCALE_ID, jb as MAX_ANIMATION_TIMEOUT, TD as MissingTranslationStrategy, os as ModuleWithComponentFactories, LM as NO_ERRORS_SCHEMA, zA as NgModule, ky as NgModuleFactory, On as NgModuleRef, Sl as NgProbeToken, L as NgZone, rs as Optional, GA as Output, gc as OutputEmitterRef, jT as PACKAGE_ROOT_URL, FT as PLATFORM_ID, Kl as PLATFORM_INITIALIZER, pc as PendingTasks, $A as Pipe, ZD as PlatformRef, ao as Query, Pi as QueryList, SO as REQUEST, RO as REQUEST_CONTEXT, AO as RESPONSE_INIT, Ow as Renderer2, Ko as RendererFactory2, Hi as RendererStyleFlags2, ty as Sanitizer, tn as SecurityContext, yh as Self, Ai as SimpleChange, is as SkipSelf, tR as TRANSLATIONS, nR as TRANSLATIONS_FORMAT, Zo as TemplateRef, Tb as Testability, gv as TestabilityRegistry, Xt as TransferState, Ih as Type, Gx as VERSION, rf as Version, Ux as ViewChild, $x as ViewChildren, Gs as ViewContainerRef, Xe as ViewEncapsulation, sf as ViewRef, tv as afterEveryRender, nv as afterNextRender, NO as afterRenderEffect, oR as asNativeElements, IC as assertInInjectionContext, MC as assertNotInReactiveContext, vR as assertPlatform, cO as booleanAttribute, _C as computed, Fx as contentChild, jx as contentChildren, wO as createComponent, Ju as createEnvironmentInjector, xy as createNgModule, b_ as createNgModuleRef, mR as createPlatform, yR as createPlatformFactory, dC as defineInjectable, Wx as destroyPlatform, bC as effect, Zx as enableProdMode, Ib as enableProfiling, Ma as forwardRef, Bn as getDebugNode, Yx as getModuleFactory, Kx as getNgModuleById, hf as getPlatform, vC as importProvidersFrom, D as inject, Ox as input, uy as inputBinding, Qx as isDevMode, Zf as isSignal, mo as isStandalone, SC as linkedSignal, qe as makeEnvironmentProviders, $T as makeStateKey, bO as mergeApplicationConfig, Vx as model, lO as numberAttribute, xx as output, dy as outputBinding, eO as platformCore, Mb as provideAppInitializer, CC as provideBrowserGlobalErrorListeners, zx as provideCheckNoChangesConfig, yC as provideEnvironmentInitializer, OM as provideNgReflectAttributes, qx as providePlatformInitializer, YA as provideZoneChangeDetection, JA as provideZonelessChangeDetection, _O as reflectComponentType, $ as resolveForwardRef, AC as resource, Qr as runInInjectionContext, mv as setTestabilityGetter, uc as signal, e_ as twoWayBinding, wC as untracked, Px as viewChild, Lx as viewChildren, YD as \u0275ALLOW_MULTIPLE_PLATFORMS, zv as \u0275ANIMATIONS_DISABLED, Jh as \u0275AcxChangeDetectionStrategy, Xh as \u0275AcxViewEncapsulation, zs as \u0275AfterRenderManager, rO as \u0275CLIENT_RENDER_MODE_FLAG, G as \u0275CONTAINER_HEADER_OFFSET, Qe as \u0275ChangeDetectionScheduler, la as \u0275ChangeDetectionSchedulerImpl, Bs as \u0275ComponentFactory, vb as \u0275Console, _r as \u0275DEFAULT_LOCALE_ID, lv as \u0275DEFER_BLOCK_CONFIG, pb as \u0275DEFER_BLOCK_DEPENDENCY_INTERCEPTOR, rt as \u0275DEHYDRATED_BLOCK_REGISTRY, od as \u0275DeferBlockBehavior, H as \u0275DeferBlockState, pR as \u0275ENABLE_ROOT_COMPONENT_BOOTSTRAP, hc as \u0275EffectScheduler, Ki as \u0275ElementRegistry, Kh as \u0275Framework, vg as \u0275HydrationStatus, BT as \u0275IMAGE_CONFIG, eg as \u0275IMAGE_CONFIG_DEFAULTS, _f as \u0275INJECTOR_SCOPE, kx as \u0275INPUT_SIGNAL_BRAND_WRITE_TYPE, Et as \u0275INTERNAL_APPLICATION_ERROR_HANDLER, GT as \u0275IS_ENABLED_BLOCKING_INITIAL_NAVIGATION, en as \u0275IS_HYDRATION_DOM_REUSE_ENABLED, ru as \u0275IS_INCREMENTAL_HYDRATION_ENABLED, fr as \u0275JSACTION_BLOCK_ELEMENT_MAP, cu as \u0275JSACTION_EVENT_CONTRACT, Li as \u0275LContext, jn as \u0275LocaleDataIndex, rn as \u0275NG_COMP_DEF, Vr as \u0275NG_DIR_DEF, kt as \u0275NG_ELEMENT_ID, Na as \u0275NG_INJ_DEF, wa as \u0275NG_MOD_DEF, Hr as \u0275NG_PIPE_DEF, jr as \u0275NG_PROV_DEF, Mi as \u0275NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR, x as \u0275NO_CHANGE, Ln as \u0275NgModuleFactory, Fn as \u0275NoopNgZone, WR as \u0275PERFORMANCE_MARK_PREFIX, CD as \u0275PROVIDED_NG_ZONE, Dt as \u0275PendingTasksInternal, ka as \u0275R3Injector, Si as \u0275ReflectionCapabilities, _t as \u0275Render3ComponentFactory, zi as \u0275Render3ComponentRef, Pn as \u0275Render3NgModuleRef, RC as \u0275ResourceImpl, w as \u0275RuntimeError, ut as \u0275SIGNAL, hg as \u0275SSR_CONTENT_INTEGRITY_MARKER, pv as \u0275TESTABILITY, hv as \u0275TESTABILITY_GETTER, cv as \u0275TimerScheduler, qs as \u0275TracingAction, oo as \u0275TracingService, wt as \u0275ViewRef, Pr as \u0275XSS_SECURITY_URL, pn as \u0275ZONELESS_ENABLED, Fg as \u0275_sanitizeHtml, Ts as \u0275_sanitizeUrl, Kn as \u0275allowSanitizationBypassAndThrow, oO as \u0275annotateForHydration, gO as \u0275assertType, uM as \u0275bypassSanitizationTrustHtml, hM as \u0275bypassSanitizationTrustResourceUrl, fM as \u0275bypassSanitizationTrustScript, dM as \u0275bypassSanitizationTrustStyle, pM as \u0275bypassSanitizationTrustUrl, by as \u0275clearResolutionOfComponentResourcesQueue, uD as \u0275compileComponent, Xd as \u0275compileDirective, cD as \u0275compileNgModule, lD as \u0275compileNgModuleDefs, fR as \u0275compileNgModuleFactory, ID as \u0275compilePipe, ba as \u0275convertToBitFlags, EC as \u0275createInjector, IR as \u0275createOrReusePlatformInjector, Jx as \u0275defaultIterableDiffers, Xx as \u0275defaultKeyValueDiffers, kn as \u0275depsTracker, ay as \u0275devModeEqual, pO as \u0275disableProfiling, fO as \u0275enableProfiling, kC as \u0275encapsulateResourceError, Sd as \u0275findLocaleData, sD as \u0275flushModuleScopingQueueAsMuchAsPossible, If as \u0275formatRuntimeError, bA as \u0275generateStandaloneInDeclarationsError, si as \u0275getAnimationElementRemovalRegistry, yb as \u0275getAsyncClassMetadataFn, hO as \u0275getClosestComponentName, U as \u0275getComponentDef, Bn as \u0275getDebugNode, _i as \u0275getDeferBlocks, bT as \u0275getDirectives, nt as \u0275getDocument, AT as \u0275getHostElement, fC as \u0275getInjectableDef, ve as \u0275getLContext, sS as \u0275getLocaleCurrencyCode, dI as \u0275getLocalePluralCase, NC as \u0275getOutputDestroyRef, Ag as \u0275getSanitizationBypassType, Eb as \u0275getTransferState, jM as \u0275getUnknownElementStrictMode, HM as \u0275getUnknownPropertyStrictMode, Ie as \u0275global, fy as \u0275inferTagNameFromDefinition, DR as \u0275injectChangeDetectorRef, nO as \u0275internalCreateApplication, aa as \u0275internalProvideZoneChangeDetection, vv as \u0275isBoundToModule, C_ as \u0275isComponentDefPendingResolution, gC as \u0275isEnvironmentProviders, pC as \u0275isInjectable, Bt as \u0275isNgModule, dd as \u0275isPromise, yv as \u0275isSubscribable, jN as \u0275isViewDirty, VN as \u0275markForRefresh, Ge as \u0275noSideEffects, Kd as \u0275patchComponentDefWithScope, Z as \u0275performanceMarkFeature, Db as \u0275publishExternalGlobalUtil, eM as \u0275readHydrationInfo, iS as \u0275registerLocaleData, Ke as \u0275renderDeferBlockState, RA as \u0275resetCompiledComponents, wA as \u0275resetJitOptions, wy as \u0275resolveComponentResources, T_ as \u0275restoreComponentResolutionQueue, __ as \u0275setAllowDuplicateNgModuleIdsForTest, xC as \u0275setAlternateWeakRefImpl, nD as \u0275setClassDebugInfo, ld as \u0275setClassMetadata, fv as \u0275setClassMetadataAsync, lC as \u0275setCurrentInjector, PT as \u0275setDocument, hC as \u0275setInjectorProfilerContext, gI as \u0275setLocaleId, FM as \u0275setUnknownElementStrictMode, VM as \u0275setUnknownPropertyStrictMode, uO as \u0275startMeasuring, dO as \u0275stopMeasuring, Co as \u0275store, on as \u0275stringify, Jd as \u0275transitiveScopesFor, Ks as \u0275triggerResourceLoading, uC as \u0275truncateMiddle, aS as \u0275unregisterLocaleData, it as \u0275unwrapSafeValue, TC as \u0275unwrapWritableSignal, iO as \u0275withDomHydration, wR as \u0275withEventReplay, sO as \u0275withI18nSupport, aO as \u0275withIncrementalHydration, AE as \u0275\u0275AnimationsFeature, $y as \u0275\u0275CopyDefinitionFeature, SE as \u0275\u0275ExternalStylesFeature, so as \u0275\u0275FactoryTarget, Uy as \u0275\u0275HostDirectivesFeature, ed as \u0275\u0275InheritDefinitionFeature, Dh as \u0275\u0275NgOnChangesFeature, bE as \u0275\u0275ProvidersFeature, tm as \u0275\u0275advance, Po as \u0275\u0275animateEnter, Lo as \u0275\u0275animateEnterListener, Fo as \u0275\u0275animateLeave, jo as \u0275\u0275animateLeaveListener, md as \u0275\u0275ariaProperty, mE as \u0275\u0275attachSourceLocations, yd as \u0275\u0275attribute, qI as \u0275\u0275classMap, jd as \u0275\u0275classProp, tI as \u0275\u0275componentInstance, oI as \u0275\u0275conditional, Xs as \u0275\u0275conditionalBranchCreate, nI as \u0275\u0275conditionalCreate, xI as \u0275\u0275contentQuery, FI as \u0275\u0275contentQuerySignal, Yd as \u0275\u0275declareLet, Mv as \u0275\u0275defer, dv as \u0275\u0275deferEnableTimerScheduling, bv as \u0275\u0275deferHydrateNever, Hv as \u0275\u0275deferHydrateOnHover, Rv as \u0275\u0275deferHydrateOnIdle, Ov as \u0275\u0275deferHydrateOnImmediate, Uv as \u0275\u0275deferHydrateOnInteraction, Fv as \u0275\u0275deferHydrateOnTimer, qv as \u0275\u0275deferHydrateOnViewport, _v as \u0275\u0275deferHydrateWhen, jv as \u0275\u0275deferOnHover, Sv as \u0275\u0275deferOnIdle, kv as \u0275\u0275deferOnImmediate, Bv as \u0275\u0275deferOnInteraction, Pv as \u0275\u0275deferOnTimer, Gv as \u0275\u0275deferOnViewport, Vv as \u0275\u0275deferPrefetchOnHover, Av as \u0275\u0275deferPrefetchOnIdle, xv as \u0275\u0275deferPrefetchOnImmediate, $v as \u0275\u0275deferPrefetchOnInteraction, Lv as \u0275\u0275deferPrefetchOnTimer, Wv as \u0275\u0275deferPrefetchOnViewport, wv as \u0275\u0275deferPrefetchWhen, Nv as \u0275\u0275deferWhen, Py as \u0275\u0275defineComponent, Fy as \u0275\u0275defineDirective, j as \u0275\u0275defineInjectable, fo as \u0275\u0275defineInjector, Xu as \u0275\u0275defineNgModule, jy as \u0275\u0275definePipe, no as \u0275\u0275directiveInject, Ga as \u0275\u0275disableBindings, Dd as \u0275\u0275domElement, Nd as \u0275\u0275domElementContainer, Md as \u0275\u0275domElementContainerEnd, ia as \u0275\u0275domElementContainerStart, oa as \u0275\u0275domElementEnd, na as \u0275\u0275domElementStart, Pd as \u0275\u0275domListener, _d as \u0275\u0275domProperty, nd as \u0275\u0275domTemplate, Ed as \u0275\u0275element, Td as \u0275\u0275elementContainer, wr as \u0275\u0275elementContainerEnd, ra as \u0275\u0275elementContainerStart, ta as \u0275\u0275elementEnd, ea as \u0275\u0275elementStart, Ua as \u0275\u0275enableBindings, tD as \u0275\u0275getComponentDepsFactory, uI as \u0275\u0275getCurrentView, Fh as \u0275\u0275getInheritedFactory, oD as \u0275\u0275getReplaceMetadataURL, wI as \u0275\u0275i18n, bI as \u0275\u0275i18nApply, _I as \u0275\u0275i18nAttributes, Rd as \u0275\u0275i18nEnd, kd as \u0275\u0275i18nExp, SI as \u0275\u0275i18nPostprocess, Ad as \u0275\u0275i18nStart, Se as \u0275\u0275inject, as as \u0275\u0275injectAttribute, yE as \u0275\u0275interpolate, vE as \u0275\u0275interpolate1, IE as \u0275\u0275interpolate2, EE as \u0275\u0275interpolate3, DE as \u0275\u0275interpolate4, CE as \u0275\u0275interpolate5, TE as \u0275\u0275interpolate6, ME as \u0275\u0275interpolate7, NE as \u0275\u0275interpolate8, wE as \u0275\u0275interpolateV, ny as \u0275\u0275invalidFactory, Br as \u0275\u0275invalidFactoryDep, xd as \u0275\u0275listener, LI as \u0275\u0275loadQuery, ac as \u0275\u0275namespaceHTML, sc as \u0275\u0275namespaceMathML, ic as \u0275\u0275namespaceSVG, AI as \u0275\u0275nextContext, yO as \u0275\u0275ngDeclareClassMetadata, vO as \u0275\u0275ngDeclareClassMetadataAsync, IO as \u0275\u0275ngDeclareComponent, mO as \u0275\u0275ngDeclareDirective, EO as \u0275\u0275ngDeclareFactory, DO as \u0275\u0275ngDeclareInjectable, CO as \u0275\u0275ngDeclareInjector, TO as \u0275\u0275ngDeclareNgModule, MO as \u0275\u0275ngDeclarePipe, QE as \u0275\u0275pipe, ZE as \u0275\u0275pipeBind1, YE as \u0275\u0275pipeBind2, KE as \u0275\u0275pipeBind3, JE as \u0275\u0275pipeBind4, XE as \u0275\u0275pipeBindV, kI as \u0275\u0275projection, RI as \u0275\u0275projectionDef, Id as \u0275\u0275property, xE as \u0275\u0275pureFunction0, OE as \u0275\u0275pureFunction1, PE as \u0275\u0275pureFunction2, LE as \u0275\u0275pureFunction3, FE as \u0275\u0275pureFunction4, jE as \u0275\u0275pureFunction5, VE as \u0275\u0275pureFunction6, HE as \u0275\u0275pureFunction7, BE as \u0275\u0275pureFunction8, $E as \u0275\u0275pureFunctionV, VI as \u0275\u0275queryAdvance, PI as \u0275\u0275queryRefresh, gE as \u0275\u0275readContextLet, HI as \u0275\u0275reference, Yu as \u0275\u0275registerNgModuleType, aI as \u0275\u0275repeater, sI as \u0275\u0275repeaterCreate, iI as \u0275\u0275repeaterTrackByIdentity, rI as \u0275\u0275repeaterTrackByIndex, rD as \u0275\u0275replaceMetadata, za as \u0275\u0275resetView, vu as \u0275\u0275resolveBody, zg as \u0275\u0275resolveDocument, qg as \u0275\u0275resolveWindow, qa as \u0275\u0275restoreView, jg as \u0275\u0275sanitizeHtml, yu as \u0275\u0275sanitizeResourceUrl, Hg as \u0275\u0275sanitizeScript, Vg as \u0275\u0275sanitizeStyle, mu as \u0275\u0275sanitizeUrl, Ug as \u0275\u0275sanitizeUrlOrResourceUrl, RE as \u0275\u0275setComponentScope, kE as \u0275\u0275setNgModuleScope, hE as \u0275\u0275storeLet, WI as \u0275\u0275styleMap, Fd as \u0275\u0275styleProp, Od as \u0275\u0275syntheticHostListener, bd as \u0275\u0275syntheticHostProperty, td as \u0275\u0275template, eD as \u0275\u0275templateRefExtractor, eE as \u0275\u0275text, Vd as \u0275\u0275textInterpolate, sa as \u0275\u0275textInterpolate1, Hd as \u0275\u0275textInterpolate2, Bd as \u0275\u0275textInterpolate3, $d as \u0275\u0275textInterpolate4, Ud as \u0275\u0275textInterpolate5, Gd as \u0275\u0275textInterpolate6, Wd as \u0275\u0275textInterpolate7, qd as \u0275\u0275textInterpolate8, zd as \u0275\u0275textInterpolateV, Bg as \u0275\u0275trustConstantHtml, $g as \u0275\u0275trustConstantResourceUrl, fE as \u0275\u0275twoWayBindingSet, Zd as \u0275\u0275twoWayListener, Qd as \u0275\u0275twoWayProperty, Ry as \u0275\u0275validateIframeAttribute, OI as \u0275\u0275viewQuery, jI as \u0275\u0275viewQuerySignal };
/*! Bundled license information:

@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/core.mjs:
  (**
   * @license Angular v20.2.1
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)

@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/debug_node.mjs:
@angular/core/fesm2022/core.mjs:
@angular/core/fesm2022/core.mjs:
  (*!
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.dev/license
   *)
*/
