import { a as n, b as d } from "@nf-internal/chunk-XSLIODQX";
import "@nf-internal/chunk-DQM2BKPX";
import "@nf-internal/chunk-FSAIB72R";
import "@nf-internal/chunk-66YHNWRR";
import * as a from "@angular/core";
import "@angular/core";
import "rxjs";
import "rxjs/operators";
import "@angular/common";
var h = (() => { class t {
    static \u0275fac = function (i) { return new (i || t); };
    static \u0275mod = a.\u0275\u0275defineNgModule({ type: t });
    static \u0275inj = a.\u0275\u0275defineInjector({});
} return t; })(), w = { XSmall: "(max-width: 599.98px)", Small: "(min-width: 600px) and (max-width: 959.98px)", Medium: "(min-width: 960px) and (max-width: 1279.98px)", Large: "(min-width: 1280px) and (max-width: 1919.98px)", XLarge: "(min-width: 1920px)", Handset: "(max-width: 599.98px) and (orientation: portrait), (max-width: 959.98px) and (orientation: landscape)", Tablet: "(min-width: 600px) and (max-width: 839.98px) and (orientation: portrait), (min-width: 960px) and (max-width: 1279.98px) and (orientation: landscape)", Web: "(min-width: 840px) and (orientation: portrait), (min-width: 1280px) and (orientation: landscape)", HandsetPortrait: "(max-width: 599.98px) and (orientation: portrait)", TabletPortrait: "(min-width: 600px) and (max-width: 839.98px) and (orientation: portrait)", WebPortrait: "(min-width: 840px) and (orientation: portrait)", HandsetLandscape: "(max-width: 959.98px) and (orientation: landscape)", TabletLandscape: "(min-width: 960px) and (max-width: 1279.98px) and (orientation: landscape)", WebLandscape: "(min-width: 1280px) and (orientation: landscape)" };
export { d as BreakpointObserver, w as Breakpoints, h as LayoutModule, n as MediaMatcher };
