function L_(E, ..._) { return _.length ? _.some(A => E[A]) : E.altKey || E.shiftKey || E.ctrlKey || E.metaKey; }
export { L_ as a };
