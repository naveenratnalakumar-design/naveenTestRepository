var o = (function (e) { return e[e.NORMAL = 0] = "NORMAL", e[e.NEGATED = 1] = "NEGATED", e[e.INVERTED = 2] = "INVERTED", e; })(o || {}), l, t;
function i() {
    if (t == null) {
        if (typeof document != "object" || !document || typeof Element != "function" || !Element)
            return t = !1, t;
        if ("scrollBehavior" in document.documentElement.style)
            t = !0;
        else {
            let e = Element.prototype.scrollTo;
            e ? t = !/\{\s*\[native code\]\s*\}/.test(e.toString()) : t = !1;
        }
    }
    return t;
}
function s() {
    if (typeof document != "object" || !document)
        return o.NORMAL;
    if (l == null) {
        let e = document.createElement("div"), n = e.style;
        e.dir = "rtl", n.width = "1px", n.overflow = "auto", n.visibility = "hidden", n.pointerEvents = "none", n.position = "absolute";
        let r = document.createElement("div"), c = r.style;
        c.width = "2px", c.height = "1px", e.appendChild(r), document.body.appendChild(e), l = o.NORMAL, e.scrollLeft === 0 && (e.scrollLeft = 1, l = e.scrollLeft === 0 ? o.NEGATED : o.INVERTED), e.remove();
    }
    return l;
}
export { o as a, i as b, s as c };
