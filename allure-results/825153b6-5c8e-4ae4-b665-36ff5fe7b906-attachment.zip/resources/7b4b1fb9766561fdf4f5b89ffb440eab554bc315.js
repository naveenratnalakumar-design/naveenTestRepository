import { b as w } from "@nf-internal/chunk-QXX5WOHX";
import { a as g, b as p } from "@nf-internal/chunk-VP6KNDS4";
import { b as T, d as c } from "@nf-internal/chunk-OIQ2QPHM";
import { f as O, g as b, h as C, ka as N, kb as k } from "@nf-internal/chunk-N26NRATF";
import { a as m } from "@nf-internal/chunk-DQM2BKPX";
import { c as a } from "@nf-internal/chunk-JYXTBF5A";
import { a as h } from "@nf-internal/chunk-66YHNWRR";
import * as d from "@angular/core";
import { InjectionToken as I, inject as n, NgZone as y, DOCUMENT as E, RendererFactory2 as D, ElementRef as A, EventEmitter as v } from "@angular/core";
import { BehaviorSubject as R, Subject as F, of as S } from "rxjs";
import { skip as B, distinctUntilChanged as U, takeUntil as j } from "rxjs/operators";
var x = new I("cdk-input-modality-detector-options"), P = { ignoreKeys: [18, 17, 224, 91, 16] }, M = 650, f = { passive: !0, capture: !0 }, Z = (() => { class s {
    _platform = n(m);
    _listenerCleanups;
    modalityDetected;
    modalityChanged;
    get mostRecentModality() { return this._modality.value; }
    _mostRecentTarget = null;
    _modality = new R(null);
    _options;
    _lastTouchMs = 0;
    _onKeydown = t => { this._options?.ignoreKeys?.some(e => e === t.keyCode) || (this._modality.next("keyboard"), this._mostRecentTarget = c(t)); };
    _onMousedown = t => { Date.now() - this._lastTouchMs < M || (this._modality.next(g(t) ? "keyboard" : "mouse"), this._mostRecentTarget = c(t)); };
    _onTouchstart = t => { if (p(t)) {
        this._modality.next("keyboard");
        return;
    } this._lastTouchMs = Date.now(), this._modality.next("touch"), this._mostRecentTarget = c(t); };
    constructor() { let t = n(y), e = n(E), o = n(x, { optional: !0 }); if (this._options = h(h({}, P), o), this.modalityDetected = this._modality.pipe(B(1)), this.modalityChanged = this.modalityDetected.pipe(U()), this._platform.isBrowser) {
        let i = n(D).createRenderer(null, null);
        this._listenerCleanups = t.runOutsideAngular(() => [i.listen(e, "keydown", this._onKeydown, f), i.listen(e, "mousedown", this._onMousedown, f), i.listen(e, "touchstart", this._onTouchstart, f)]);
    } }
    ngOnDestroy() { this._modality.complete(), this._listenerCleanups?.forEach(t => t()); }
    static \u0275fac = function (e) { return new (e || s); };
    static \u0275prov = d.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), _ = (function (s) { return s[s.IMMEDIATE = 0] = "IMMEDIATE", s[s.EVENTUAL = 1] = "EVENTUAL", s; })(_ || {}), V = new I("cdk-focus-monitor-default-options"), l = w({ passive: !0, capture: !0 }), G = (() => { class s {
    _ngZone = n(y);
    _platform = n(m);
    _inputModalityDetector = n(Z);
    _origin = null;
    _lastFocusOrigin;
    _windowFocused = !1;
    _windowFocusTimeoutId;
    _originTimeoutId;
    _originFromTouchInteraction = !1;
    _elementInfo = new Map;
    _monitoredElementCount = 0;
    _rootNodeFocusListenerCount = new Map;
    _detectionMode;
    _windowFocusListener = () => { this._windowFocused = !0, this._windowFocusTimeoutId = setTimeout(() => this._windowFocused = !1); };
    _document = n(E);
    _stopInputModalityDetector = new F;
    constructor() { let t = n(V, { optional: !0 }); this._detectionMode = t?.detectionMode || _.IMMEDIATE; }
    _rootNodeFocusAndBlurListener = t => { let e = c(t); for (let o = e; o; o = o.parentElement)
        t.type === "focus" ? this._onFocus(t, o) : this._onBlur(t, o); };
    monitor(t, e = !1) { let o = a(t); if (!this._platform.isBrowser || o.nodeType !== 1)
        return S(); let i = T(o) || this._document, r = this._elementInfo.get(o); if (r)
        return e && (r.checkChildren = !0), r.subject; let u = { checkChildren: e, subject: new F, rootNode: i }; return this._elementInfo.set(o, u), this._registerGlobalListeners(u), u.subject; }
    stopMonitoring(t) { let e = a(t), o = this._elementInfo.get(e); o && (o.subject.complete(), this._setClasses(e), this._elementInfo.delete(e), this._removeGlobalListeners(o)); }
    focusVia(t, e, o) { let i = a(t), r = this._document.activeElement; i === r ? this._getClosestElementsInfo(i).forEach(([u, L]) => this._originChanged(u, e, L)) : (this._setOrigin(e), typeof i.focus == "function" && i.focus(o)); }
    ngOnDestroy() { this._elementInfo.forEach((t, e) => this.stopMonitoring(e)); }
    _getWindow() { return this._document.defaultView || window; }
    _getFocusOrigin(t) { return this._origin ? this._originFromTouchInteraction ? this._shouldBeAttributedToTouch(t) ? "touch" : "program" : this._origin : this._windowFocused && this._lastFocusOrigin ? this._lastFocusOrigin : t && this._isLastInteractionFromInputLabel(t) ? "mouse" : "program"; }
    _shouldBeAttributedToTouch(t) { return this._detectionMode === _.EVENTUAL || !!t?.contains(this._inputModalityDetector._mostRecentTarget); }
    _setClasses(t, e) { t.classList.toggle("cdk-focused", !!e), t.classList.toggle("cdk-touch-focused", e === "touch"), t.classList.toggle("cdk-keyboard-focused", e === "keyboard"), t.classList.toggle("cdk-mouse-focused", e === "mouse"), t.classList.toggle("cdk-program-focused", e === "program"); }
    _setOrigin(t, e = !1) { this._ngZone.runOutsideAngular(() => { if (this._origin = t, this._originFromTouchInteraction = t === "touch" && e, this._detectionMode === _.IMMEDIATE) {
        clearTimeout(this._originTimeoutId);
        let o = this._originFromTouchInteraction ? M : 1;
        this._originTimeoutId = setTimeout(() => this._origin = null, o);
    } }); }
    _onFocus(t, e) { let o = this._elementInfo.get(e), i = c(t); !o || !o.checkChildren && e !== i || this._originChanged(e, this._getFocusOrigin(i), o); }
    _onBlur(t, e) { let o = this._elementInfo.get(e); !o || o.checkChildren && t.relatedTarget instanceof Node && e.contains(t.relatedTarget) || (this._setClasses(e), this._emitOrigin(o, null)); }
    _emitOrigin(t, e) { t.subject.observers.length && this._ngZone.run(() => t.subject.next(e)); }
    _registerGlobalListeners(t) { if (!this._platform.isBrowser)
        return; let e = t.rootNode, o = this._rootNodeFocusListenerCount.get(e) || 0; o || this._ngZone.runOutsideAngular(() => { e.addEventListener("focus", this._rootNodeFocusAndBlurListener, l), e.addEventListener("blur", this._rootNodeFocusAndBlurListener, l); }), this._rootNodeFocusListenerCount.set(e, o + 1), ++this._monitoredElementCount === 1 && (this._ngZone.runOutsideAngular(() => { this._getWindow().addEventListener("focus", this._windowFocusListener); }), this._inputModalityDetector.modalityDetected.pipe(j(this._stopInputModalityDetector)).subscribe(i => { this._setOrigin(i, !0); })); }
    _removeGlobalListeners(t) { let e = t.rootNode; if (this._rootNodeFocusListenerCount.has(e)) {
        let o = this._rootNodeFocusListenerCount.get(e);
        o > 1 ? this._rootNodeFocusListenerCount.set(e, o - 1) : (e.removeEventListener("focus", this._rootNodeFocusAndBlurListener, l), e.removeEventListener("blur", this._rootNodeFocusAndBlurListener, l), this._rootNodeFocusListenerCount.delete(e));
    } --this._monitoredElementCount || (this._getWindow().removeEventListener("focus", this._windowFocusListener), this._stopInputModalityDetector.next(), clearTimeout(this._windowFocusTimeoutId), clearTimeout(this._originTimeoutId)); }
    _originChanged(t, e, o) { this._setClasses(t, e), this._emitOrigin(o, e), this._lastFocusOrigin = e; }
    _getClosestElementsInfo(t) { let e = []; return this._elementInfo.forEach((o, i) => { (i === t || o.checkChildren && i.contains(t)) && e.push([i, o]); }), e; }
    _isLastInteractionFromInputLabel(t) { let { _mostRecentTarget: e, mostRecentModality: o } = this._inputModalityDetector; if (o !== "mouse" || !e || e === t || t.nodeName !== "INPUT" && t.nodeName !== "TEXTAREA" || t.disabled)
        return !1; let i = t.labels; if (i) {
        for (let r = 0; r < i.length; r++)
            if (i[r].contains(e))
                return !0;
    } return !1; }
    static \u0275fac = function (e) { return new (e || s); };
    static \u0275prov = d.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), et = (() => { class s {
    _elementRef = n(A);
    _focusMonitor = n(G);
    _monitorSubscription;
    _focusOrigin = null;
    cdkFocusChange = new v;
    constructor() { }
    get focusOrigin() { return this._focusOrigin; }
    ngAfterViewInit() { let t = this._elementRef.nativeElement; this._monitorSubscription = this._focusMonitor.monitor(t, t.nodeType === 1 && t.hasAttribute("cdkMonitorSubtreeFocus")).subscribe(e => { this._focusOrigin = e, this.cdkFocusChange.emit(e); }); }
    ngOnDestroy() { this._focusMonitor.stopMonitoring(this._elementRef), this._monitorSubscription && this._monitorSubscription.unsubscribe(); }
    static \u0275fac = function (e) { return new (e || s); };
    static \u0275dir = d.\u0275\u0275defineDirective({ type: s, selectors: [["", "cdkMonitorElementFocus", ""], ["", "cdkMonitorSubtreeFocus", ""]], outputs: { cdkFocusChange: "cdkFocusChange" }, exportAs: ["cdkMonitorFocus"] });
} return s; })();
export { x as a, P as b, Z as c, _ as d, V as e, G as f, et as g };
