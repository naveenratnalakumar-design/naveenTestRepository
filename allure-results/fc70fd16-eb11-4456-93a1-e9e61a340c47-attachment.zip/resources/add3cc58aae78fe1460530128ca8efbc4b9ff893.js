function l(c, o) { o = encodeURIComponent(o); for (let e of c.split(";")) {
    let n = e.indexOf("="), [t, s] = n == -1 ? [e, ""] : [e.slice(0, n), e.slice(n + 1)];
    if (t.trim() === o)
        return decodeURIComponent(s);
} return null; }
var i = class {
};
export { l as a, i as b };
/*! Bundled license information:

@angular/common/fesm2022/xhr.mjs:
  (**
   * @license Angular v20.2.1
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)
*/
