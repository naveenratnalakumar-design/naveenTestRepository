import "@nf-internal/chunk-66YHNWRR";
var me = ["onChange", "onClose", "onDayCreate", "onDestroy", "onKeyDown", "onMonthChange", "onOpen", "onParseConfig", "onReady", "onValueUpdate", "onYearChange", "onPreCalendarPosition"], R = { _disable: [], allowInput: !1, allowInvalidPreload: !1, altFormat: "F j, Y", altInput: !1, altInputClass: "form-control input", animate: typeof window == "object" && window.navigator.userAgent.indexOf("MSIE") === -1, ariaDateFormat: "F j, Y", autoFillDefaultTime: !0, clickOpens: !0, closeOnSelect: !0, conjunction: ", ", dateFormat: "Y-m-d", defaultHour: 12, defaultMinute: 0, defaultSeconds: 0, disable: [], disableMobile: !1, enableSeconds: !1, enableTime: !1, errorHandler: function (a) { return typeof console < "u" && console.warn(a); }, getWeek: function (a) { var r = new Date(a.getTime()); r.setHours(0, 0, 0, 0), r.setDate(r.getDate() + 3 - (r.getDay() + 6) % 7); var e = new Date(r.getFullYear(), 0, 4); return 1 + Math.round(((r.getTime() - e.getTime()) / 864e5 - 3 + (e.getDay() + 6) % 7) / 7); }, hourIncrement: 1, ignoredFocusElements: [], inline: !1, locale: "default", minuteIncrement: 5, mode: "single", monthSelectorType: "dropdown", nextArrow: "<svg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 17 17'><g></g><path d='M13.207 8.472l-7.854 7.854-0.707-0.707 7.146-7.146-7.146-7.148 0.707-0.707 7.854 7.854z' /></svg>", noCalendar: !1, now: new Date, onChange: [], onClose: [], onDayCreate: [], onDestroy: [], onKeyDown: [], onMonthChange: [], onOpen: [], onParseConfig: [], onReady: [], onValueUpdate: [], onYearChange: [], onPreCalendarPosition: [], plugins: [], position: "auto", positionElement: void 0, prevArrow: "<svg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 17 17'><g></g><path d='M5.207 8.471l7.146 7.147-0.707 0.707-7.853-7.854 7.854-7.853 0.707 0.707-7.147 7.146z' /></svg>", shorthandCurrentMonth: !1, showMonths: 1, static: !1, time_24hr: !1, weekNumbers: !1, wrap: !1 };
var ge = { weekdays: { shorthand: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], longhand: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] }, months: { shorthand: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], longhand: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"] }, daysInMonth: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], firstDayOfWeek: 0, ordinal: function (a) { var r = a % 100; if (r > 3 && r < 21)
        return "th"; switch (r % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
    } }, rangeSeparator: " to ", weekAbbreviation: "Wk", scrollTitle: "Scroll to increment", toggleTitle: "Click to toggle", amPM: ["AM", "PM"], yearAriaLabel: "Year", monthAriaLabel: "Month", hourAriaLabel: "Hour", minuteAriaLabel: "Minute", time_24hr: !1 }, pe = ge;
var k = function (a, r) { return r === void 0 && (r = 2), ("000" + a).slice(r * -1); }, I = function (a) { return a === !0 ? 1 : 0; };
function _e(a, r) { var e; return function () { var g = this, h = arguments; clearTimeout(e), e = setTimeout(function () { return a.apply(g, h); }, r); }; }
var he = function (a) { return a instanceof Array ? a : [a]; };
function T(a, r, e) { if (e === !0)
    return a.classList.add(r); a.classList.remove(r); }
function v(a, r, e) { var g = window.document.createElement(a); return r = r || "", e = e || "", g.className = r, e !== void 0 && (g.textContent = e), g; }
function te(a) { for (; a.firstChild;)
    a.removeChild(a.firstChild); }
function Oe(a, r) { if (r(a))
    return a; if (a.parentNode)
    return Oe(a.parentNode, r); }
function ae(a, r) { var e = v("div", "numInputWrapper"), g = v("input", "numInput " + a), h = v("span", "arrowUp"), m = v("span", "arrowDown"); if (navigator.userAgent.indexOf("MSIE 9.0") === -1 ? g.type = "number" : (g.type = "text", g.pattern = "\\d*"), r !== void 0)
    for (var w in r)
        g.setAttribute(w, r[w]); return e.appendChild(g), e.appendChild(h), e.appendChild(m), e; }
function _(a) { try {
    if (typeof a.composedPath == "function") {
        var r = a.composedPath();
        return r[0];
    }
    return a.target;
}
catch {
    return a.target;
} }
var Fe = function () { }, ie = function (a, r, e) { return e.months[r ? "shorthand" : "longhand"][a]; }, Ve = { D: Fe, F: function (a, r, e) { a.setMonth(e.months.longhand.indexOf(r)); }, G: function (a, r) { a.setHours((a.getHours() >= 12 ? 12 : 0) + parseFloat(r)); }, H: function (a, r) { a.setHours(parseFloat(r)); }, J: function (a, r) { a.setDate(parseFloat(r)); }, K: function (a, r, e) { a.setHours(a.getHours() % 12 + 12 * I(new RegExp(e.amPM[1], "i").test(r))); }, M: function (a, r, e) { a.setMonth(e.months.shorthand.indexOf(r)); }, S: function (a, r) { a.setSeconds(parseFloat(r)); }, U: function (a, r) { return new Date(parseFloat(r) * 1e3); }, W: function (a, r, e) { var g = parseInt(r), h = new Date(a.getFullYear(), 0, 2 + (g - 1) * 7, 0, 0, 0, 0); return h.setDate(h.getDate() - h.getDay() + e.firstDayOfWeek), h; }, Y: function (a, r) { a.setFullYear(parseFloat(r)); }, Z: function (a, r) { return new Date(r); }, d: function (a, r) { a.setDate(parseFloat(r)); }, h: function (a, r) { a.setHours((a.getHours() >= 12 ? 12 : 0) + parseFloat(r)); }, i: function (a, r) { a.setMinutes(parseFloat(r)); }, j: function (a, r) { a.setDate(parseFloat(r)); }, l: Fe, m: function (a, r) { a.setMonth(parseFloat(r) - 1); }, n: function (a, r) { a.setMonth(parseFloat(r) - 1); }, s: function (a, r) { a.setSeconds(parseFloat(r)); }, u: function (a, r) { return new Date(parseFloat(r)); }, w: Fe, y: function (a, r) { a.setFullYear(2e3 + parseFloat(r)); } }, L = { D: "", F: "", G: "(\\d\\d|\\d)", H: "(\\d\\d|\\d)", J: "(\\d\\d|\\d)\\w+", K: "", M: "", S: "(\\d\\d|\\d)", U: "(.+)", W: "(\\d\\d|\\d)", Y: "(\\d{4})", Z: "(.+)", d: "(\\d\\d|\\d)", h: "(\\d\\d|\\d)", i: "(\\d\\d|\\d)", j: "(\\d\\d|\\d)", l: "", m: "(\\d\\d|\\d)", n: "(\\d\\d|\\d)", s: "(\\d\\d|\\d)", u: "(.+)", w: "(\\d\\d|\\d)", y: "(\\d{2})" }, G = { Z: function (a) { return a.toISOString(); }, D: function (a, r, e) { return r.weekdays.shorthand[G.w(a, r, e)]; }, F: function (a, r, e) { return ie(G.n(a, r, e) - 1, !1, r); }, G: function (a, r, e) { return k(G.h(a, r, e)); }, H: function (a) { return k(a.getHours()); }, J: function (a, r) { return r.ordinal !== void 0 ? a.getDate() + r.ordinal(a.getDate()) : a.getDate(); }, K: function (a, r) { return r.amPM[I(a.getHours() > 11)]; }, M: function (a, r) { return ie(a.getMonth(), !0, r); }, S: function (a) { return k(a.getSeconds()); }, U: function (a) { return a.getTime() / 1e3; }, W: function (a, r, e) { return e.getWeek(a); }, Y: function (a) { return k(a.getFullYear(), 4); }, d: function (a) { return k(a.getDate()); }, h: function (a) { return a.getHours() % 12 ? a.getHours() % 12 : 12; }, i: function (a) { return k(a.getMinutes()); }, j: function (a) { return a.getDate(); }, l: function (a, r) { return r.weekdays.longhand[a.getDay()]; }, m: function (a) { return k(a.getMonth() + 1); }, n: function (a) { return a.getMonth() + 1; }, s: function (a) { return a.getSeconds(); }, u: function (a) { return a.getTime(); }, w: function (a) { return a.getDay(); }, y: function (a) { return String(a.getFullYear()).substring(2); } };
var Ae = function (a) { var r = a.config, e = r === void 0 ? R : r, g = a.l10n, h = g === void 0 ? ge : g, m = a.isMobile, w = m === void 0 ? !1 : m; return function (x, E, Q) { var C = Q || h; return e.formatDate !== void 0 && !w ? e.formatDate(x, E, C) : E.split("").map(function (A, N, Y) { return G[A] && Y[N - 1] !== "\\" ? G[A](x, C, e) : A !== "\\" ? A : ""; }).join(""); }; }, ve = function (a) { var r = a.config, e = r === void 0 ? R : r, g = a.l10n, h = g === void 0 ? ge : g; return function (m, w, x, E) { if (!(m !== 0 && !m)) {
    var Q = E || h, C, A = m;
    if (m instanceof Date)
        C = new Date(m.getTime());
    else if (typeof m != "string" && m.toFixed !== void 0)
        C = new Date(m);
    else if (typeof m == "string") {
        var N = w || (e || R).dateFormat, Y = String(m).trim();
        if (Y === "today")
            C = new Date, x = !0;
        else if (e && e.parseDate)
            C = e.parseDate(m, N);
        else if (/Z$/.test(Y) || /GMT$/.test(Y))
            C = new Date(m);
        else {
            for (var re = void 0, D = [], W = 0, be = 0, j = ""; W < N.length; W++) {
                var B = N[W], U = B === "\\", we = N[W - 1] === "\\" || U;
                if (L[B] && !we) {
                    j += L[B];
                    var K = new RegExp(j).exec(m);
                    K && (re = !0) && D[B !== "Y" ? "push" : "unshift"]({ fn: Ve[B], val: K[++be] });
                }
                else
                    U || (j += ".");
            }
            C = !e || !e.noCalendar ? new Date(new Date().getFullYear(), 0, 1, 0, 0, 0, 0) : new Date(new Date().setHours(0, 0, 0, 0)), D.forEach(function (V) { var q = V.fn, Ce = V.val; return C = q(C, Ce, Q) || C; }), C = re ? C : void 0;
        }
    }
    if (!(C instanceof Date && !isNaN(C.getTime()))) {
        e.errorHandler(new Error("Invalid date provided: " + A));
        return;
    }
    return x === !0 && C.setHours(0, 0, 0, 0), C;
} }; };
function O(a, r, e) { return e === void 0 && (e = !0), e !== !1 ? new Date(a.getTime()).setHours(0, 0, 0, 0) - new Date(r.getTime()).setHours(0, 0, 0, 0) : a.getTime() - r.getTime(); }
var qe = function (a, r, e) { return a > Math.min(r, e) && a < Math.max(r, e); }, De = function (a, r, e) { return a * 3600 + r * 60 + e; }, ze = function (a) { var r = Math.floor(a / 3600), e = (a - r * 3600) / 60; return [r, e, a - r * 3600 - e * 60]; }, $e = { DAY: 864e5 };
function Me(a) { var r = a.defaultHour, e = a.defaultMinute, g = a.defaultSeconds; if (a.minDate !== void 0) {
    var h = a.minDate.getHours(), m = a.minDate.getMinutes(), w = a.minDate.getSeconds();
    r < h && (r = h), r === h && e < m && (e = m), r === h && e === m && g < w && (g = a.minDate.getSeconds());
} if (a.maxDate !== void 0) {
    var x = a.maxDate.getHours(), E = a.maxDate.getMinutes();
    r = Math.min(r, x), r === x && (e = Math.min(E, e)), r === x && e === E && (g = a.maxDate.getSeconds());
} return { hours: r, minutes: e, seconds: g }; }
typeof Object.assign != "function" && (Object.assign = function (a) { for (var r = [], e = 1; e < arguments.length; e++)
    r[e - 1] = arguments[e]; if (!a)
    throw TypeError("Cannot convert undefined or null to object"); for (var g = function (x) { x && Object.keys(x).forEach(function (E) { return a[E] = x[E]; }); }, h = 0, m = r; h < m.length; h++) {
    var w = m[h];
    g(w);
} return a; });
var S = function () { return S = Object.assign || function (a) { for (var r, e = 1, g = arguments.length; e < g; e++) {
    r = arguments[e];
    for (var h in r)
        Object.prototype.hasOwnProperty.call(r, h) && (a[h] = r[h]);
} return a; }, S.apply(this, arguments); }, Ge = function () { for (var a = 0, r = 0, e = arguments.length; r < e; r++)
    a += arguments[r].length; for (var g = Array(a), h = 0, r = 0; r < e; r++)
    for (var m = arguments[r], w = 0, x = m.length; w < x; w++, h++)
        g[h] = m[w]; return g; }, _n = 300;
function On(a, r) {
    var e = { config: S(S({}, R), y.defaultConfig), l10n: pe };
    e.parseDate = ve({ config: e.config, l10n: e.l10n }), e._handlers = [], e.pluginElements = [], e.loadedPlugins = [], e._bind = D, e._setHoursFromDate = N, e._positionCalendar = se, e.changeMonth = ye, e.changeYear = le, e.clear = tn, e.close = an, e.onMouseOver = ue, e._createElement = v, e.createDay = K, e.destroy = rn, e.isEnabled = J, e.jumpToDate = j, e.updateValue = H, e.open = fn, e.redraw = We, e.set = dn, e.setDate = mn, e.toggle = vn;
    function g() { e.utils = { getDaysInMonth: function (n, t) { return n === void 0 && (n = e.currentMonth), t === void 0 && (t = e.currentYear), n === 1 && (t % 4 === 0 && t % 100 !== 0 || t % 400 === 0) ? 29 : e.l10n.daysInMonth[n]; } }; }
    function h() { e.element = e.input = a, e.isOpen = !1, un(), Re(), pn(), gn(), g(), e.isMobile || we(), be(), (e.selectedDates.length || e.config.noCalendar) && (e.config.enableTime && N(e.config.noCalendar ? e.latestSelectedDateObj : void 0), H(!1)), x(); var n = /^((?!chrome|android).)*safari/i.test(navigator.userAgent); !e.isMobile && n && se(), b("onReady"); }
    function m() { var n; return ((n = e.calendarContainer) === null || n === void 0 ? void 0 : n.getRootNode()).activeElement || document.activeElement; }
    function w(n) { return n.bind(e); }
    function x() { var n = e.config; n.weekNumbers === !1 && n.showMonths === 1 || n.noCalendar !== !0 && window.requestAnimationFrame(function () { if (e.calendarContainer !== void 0 && (e.calendarContainer.style.visibility = "hidden", e.calendarContainer.style.display = "block"), e.daysContainer !== void 0) {
        var t = (e.days.offsetWidth + 1) * n.showMonths;
        e.daysContainer.style.width = t + "px", e.calendarContainer.style.width = t + (e.weekWrapper !== void 0 ? e.weekWrapper.offsetWidth : 0) + "px", e.calendarContainer.style.removeProperty("visibility"), e.calendarContainer.style.removeProperty("display");
    } }); }
    function E(n) { if (e.selectedDates.length === 0) {
        var t = e.config.minDate === void 0 || O(new Date, e.config.minDate) >= 0 ? new Date : new Date(e.config.minDate.getTime()), i = Me(e.config);
        t.setHours(i.hours, i.minutes, i.seconds, t.getMilliseconds()), e.selectedDates = [t], e.latestSelectedDateObj = t;
    } n !== void 0 && n.type !== "blur" && bn(n); var o = e._input.value; A(), H(), e._input.value !== o && e._debouncedChange(); }
    function Q(n, t) { return n % 12 + 12 * I(t === e.l10n.amPM[1]); }
    function C(n) { switch (n % 24) {
        case 0:
        case 12: return 12;
        default: return n % 12;
    } }
    function A() { if (!(e.hourElement === void 0 || e.minuteElement === void 0)) {
        var n = (parseInt(e.hourElement.value.slice(-2), 10) || 0) % 24, t = (parseInt(e.minuteElement.value, 10) || 0) % 60, i = e.secondElement !== void 0 ? (parseInt(e.secondElement.value, 10) || 0) % 60 : 0;
        e.amPM !== void 0 && (n = Q(n, e.amPM.textContent));
        var o = e.config.minTime !== void 0 || e.config.minDate && e.minDateHasTime && e.latestSelectedDateObj && O(e.latestSelectedDateObj, e.config.minDate, !0) === 0, l = e.config.maxTime !== void 0 || e.config.maxDate && e.maxDateHasTime && e.latestSelectedDateObj && O(e.latestSelectedDateObj, e.config.maxDate, !0) === 0;
        if (e.config.maxTime !== void 0 && e.config.minTime !== void 0 && e.config.minTime > e.config.maxTime) {
            var f = De(e.config.minTime.getHours(), e.config.minTime.getMinutes(), e.config.minTime.getSeconds()), d = De(e.config.maxTime.getHours(), e.config.maxTime.getMinutes(), e.config.maxTime.getSeconds()), s = De(n, t, i);
            if (s > d && s < f) {
                var p = ze(f);
                n = p[0], t = p[1], i = p[2];
            }
        }
        else {
            if (l) {
                var u = e.config.maxTime !== void 0 ? e.config.maxTime : e.config.maxDate;
                n = Math.min(n, u.getHours()), n === u.getHours() && (t = Math.min(t, u.getMinutes())), t === u.getMinutes() && (i = Math.min(i, u.getSeconds()));
            }
            if (o) {
                var c = e.config.minTime !== void 0 ? e.config.minTime : e.config.minDate;
                n = Math.max(n, c.getHours()), n === c.getHours() && t < c.getMinutes() && (t = c.getMinutes()), t === c.getMinutes() && (i = Math.max(i, c.getSeconds()));
            }
        }
        Y(n, t, i);
    } }
    function N(n) { var t = n || e.latestSelectedDateObj; t && t instanceof Date && Y(t.getHours(), t.getMinutes(), t.getSeconds()); }
    function Y(n, t, i) { e.latestSelectedDateObj !== void 0 && e.latestSelectedDateObj.setHours(n % 24, t, i || 0, 0), !(!e.hourElement || !e.minuteElement || e.isMobile) && (e.hourElement.value = k(e.config.time_24hr ? n : (12 + n) % 12 + 12 * I(n % 12 === 0)), e.minuteElement.value = k(t), e.amPM !== void 0 && (e.amPM.textContent = e.l10n.amPM[I(n >= 12)]), e.secondElement !== void 0 && (e.secondElement.value = k(i))); }
    function re(n) { var t = _(n), i = parseInt(t.value) + (n.delta || 0); (i / 1e3 > 1 || n.key === "Enter" && !/[^\d]/.test(i.toString())) && le(i); }
    function D(n, t, i, o) { if (t instanceof Array)
        return t.forEach(function (l) { return D(n, l, i, o); }); if (n instanceof Array)
        return n.forEach(function (l) { return D(l, t, i, o); }); n.addEventListener(t, i, o), e._handlers.push({ remove: function () { return n.removeEventListener(t, i, o); } }); }
    function W() { b("onChange"); }
    function be() { if (e.config.wrap && ["open", "close", "toggle", "clear"].forEach(function (i) { Array.prototype.forEach.call(e.element.querySelectorAll("[data-" + i + "]"), function (o) { return D(o, "click", e[i]); }); }), e.isMobile) {
        hn();
        return;
    } var n = _e(ln, 50); if (e._debouncedChange = _e(W, _n), e.daysContainer && !/iPhone|iPad|iPod/i.test(navigator.userAgent) && D(e.daysContainer, "mouseover", function (i) { e.config.mode === "range" && ue(_(i)); }), D(e._input, "keydown", He), e.calendarContainer !== void 0 && D(e.calendarContainer, "keydown", He), !e.config.inline && !e.config.static && D(window, "resize", n), window.ontouchstart !== void 0 ? D(window.document, "touchstart", xe) : D(window.document, "mousedown", xe), D(window.document, "focus", xe, { capture: !0 }), e.config.clickOpens === !0 && (D(e._input, "focus", e.open), D(e._input, "click", e.open)), e.daysContainer !== void 0 && (D(e.monthNav, "click", Mn), D(e.monthNav, ["keyup", "increment"], re), D(e.daysContainer, "click", Be)), e.timeContainer !== void 0 && e.minuteElement !== void 0 && e.hourElement !== void 0) {
        var t = function (i) { return _(i).select(); };
        D(e.timeContainer, ["increment"], E), D(e.timeContainer, "blur", E, { capture: !0 }), D(e.timeContainer, "click", B), D([e.hourElement, e.minuteElement], ["focus", "click"], t), e.secondElement !== void 0 && D(e.secondElement, "focus", function () { return e.secondElement && e.secondElement.select(); }), e.amPM !== void 0 && D(e.amPM, "click", function (i) { E(i); });
    } e.config.allowInput && D(e._input, "blur", on); }
    function j(n, t) { var i = n !== void 0 ? e.parseDate(n) : e.latestSelectedDateObj || (e.config.minDate && e.config.minDate > e.now ? e.config.minDate : e.config.maxDate && e.config.maxDate < e.now ? e.config.maxDate : e.now), o = e.currentYear, l = e.currentMonth; try {
        i !== void 0 && (e.currentYear = i.getFullYear(), e.currentMonth = i.getMonth());
    }
    catch (f) {
        f.message = "Invalid date supplied: " + i, e.config.errorHandler(f);
    } t && e.currentYear !== o && (b("onYearChange"), z()), t && (e.currentYear !== o || e.currentMonth !== l) && b("onMonthChange"), e.redraw(); }
    function B(n) { var t = _(n); ~t.className.indexOf("arrow") && U(n, t.classList.contains("arrowUp") ? 1 : -1); }
    function U(n, t, i) { var o = n && _(n), l = i || o && o.parentNode && o.parentNode.firstChild, f = ke("increment"); f.delta = t, l && l.dispatchEvent(f); }
    function we() { var n = window.document.createDocumentFragment(); if (e.calendarContainer = v("div", "flatpickr-calendar"), e.calendarContainer.tabIndex = -1, !e.config.noCalendar) {
        if (n.appendChild(Xe()), e.innerContainer = v("div", "flatpickr-innerContainer"), e.config.weekNumbers) {
            var t = nn(), i = t.weekWrapper, o = t.weekNumbers;
            e.innerContainer.appendChild(i), e.weekNumbers = o, e.weekWrapper = i;
        }
        e.rContainer = v("div", "flatpickr-rContainer"), e.rContainer.appendChild(Pe()), e.daysContainer || (e.daysContainer = v("div", "flatpickr-days"), e.daysContainer.tabIndex = -1), oe(), e.rContainer.appendChild(e.daysContainer), e.innerContainer.appendChild(e.rContainer), n.appendChild(e.innerContainer);
    } e.config.enableTime && n.appendChild(en()), T(e.calendarContainer, "rangeMode", e.config.mode === "range"), T(e.calendarContainer, "animate", e.config.animate === !0), T(e.calendarContainer, "multiMonth", e.config.showMonths > 1), e.calendarContainer.appendChild(n); var l = e.config.appendTo !== void 0 && e.config.appendTo.nodeType !== void 0; if ((e.config.inline || e.config.static) && (e.calendarContainer.classList.add(e.config.inline ? "inline" : "static"), e.config.inline && (!l && e.element.parentNode ? e.element.parentNode.insertBefore(e.calendarContainer, e._input.nextSibling) : e.config.appendTo !== void 0 && e.config.appendTo.appendChild(e.calendarContainer)), e.config.static)) {
        var f = v("div", "flatpickr-wrapper");
        e.element.parentNode && e.element.parentNode.insertBefore(f, e.element), f.appendChild(e.element), e.altInput && f.appendChild(e.altInput), f.appendChild(e.calendarContainer);
    } !e.config.static && !e.config.inline && (e.config.appendTo !== void 0 ? e.config.appendTo : window.document.body).appendChild(e.calendarContainer); }
    function K(n, t, i, o) { var l = J(t, !0), f = v("span", n, t.getDate().toString()); return f.dateObj = t, f.$i = o, f.setAttribute("aria-label", e.formatDate(t, e.config.ariaDateFormat)), n.indexOf("hidden") === -1 && O(t, e.now) === 0 && (e.todayDateElem = f, f.classList.add("today"), f.setAttribute("aria-current", "date")), l ? (f.tabIndex = -1, Te(t) && (f.classList.add("selected"), e.selectedDateElem = f, e.config.mode === "range" && (T(f, "startRange", e.selectedDates[0] && O(t, e.selectedDates[0], !0) === 0), T(f, "endRange", e.selectedDates[1] && O(t, e.selectedDates[1], !0) === 0), n === "nextMonthDay" && f.classList.add("inRange")))) : f.classList.add("flatpickr-disabled"), e.config.mode === "range" && Dn(t) && !Te(t) && f.classList.add("inRange"), e.weekNumbers && e.config.showMonths === 1 && n !== "prevMonthDay" && o % 7 === 6 && e.weekNumbers.insertAdjacentHTML("beforeend", "<span class='flatpickr-day'>" + e.config.getWeek(t) + "</span>"), b("onDayCreate", f), f; }
    function V(n) { n.focus(), e.config.mode === "range" && ue(n); }
    function q(n) { for (var t = n > 0 ? 0 : e.config.showMonths - 1, i = n > 0 ? e.config.showMonths : -1, o = t; o != i; o += n)
        for (var l = e.daysContainer.children[o], f = n > 0 ? 0 : l.children.length - 1, d = n > 0 ? l.children.length : -1, s = f; s != d; s += n) {
            var p = l.children[s];
            if (p.className.indexOf("hidden") === -1 && J(p.dateObj))
                return p;
        } }
    function Ce(n, t) { for (var i = n.className.indexOf("Month") === -1 ? n.dateObj.getMonth() : e.currentMonth, o = t > 0 ? e.config.showMonths : -1, l = t > 0 ? 1 : -1, f = i - e.currentMonth; f != o; f += l)
        for (var d = e.daysContainer.children[f], s = i - e.currentMonth === f ? n.$i + t : t < 0 ? d.children.length - 1 : 0, p = d.children.length, u = s; u >= 0 && u < p && u != (t > 0 ? p : -1); u += l) {
            var c = d.children[u];
            if (c.className.indexOf("hidden") === -1 && J(c.dateObj) && Math.abs(n.$i - u) >= Math.abs(t))
                return V(c);
        } e.changeMonth(l), X(q(l), 0); }
    function X(n, t) { var i = m(), o = fe(i || document.body), l = n !== void 0 ? n : o ? i : e.selectedDateElem !== void 0 && fe(e.selectedDateElem) ? e.selectedDateElem : e.todayDateElem !== void 0 && fe(e.todayDateElem) ? e.todayDateElem : q(t > 0 ? 1 : -1); l === void 0 ? e._input.focus() : o ? Ce(l, t) : V(l); }
    function Ze(n, t) { for (var i = (new Date(n, t, 1).getDay() - e.l10n.firstDayOfWeek + 7) % 7, o = e.utils.getDaysInMonth((t - 1 + 12) % 12, n), l = e.utils.getDaysInMonth(t, n), f = window.document.createDocumentFragment(), d = e.config.showMonths > 1, s = d ? "prevMonthDay hidden" : "prevMonthDay", p = d ? "nextMonthDay hidden" : "nextMonthDay", u = o + 1 - i, c = 0; u <= o; u++, c++)
        f.appendChild(K("flatpickr-day " + s, new Date(n, t - 1, u), u, c)); for (u = 1; u <= l; u++, c++)
        f.appendChild(K("flatpickr-day", new Date(n, t, u), u, c)); for (var M = l + 1; M <= 42 - i && (e.config.showMonths === 1 || c % 7 !== 0); M++, c++)
        f.appendChild(K("flatpickr-day " + p, new Date(n, t + 1, M % l), M, c)); var P = v("div", "dayContainer"); return P.appendChild(f), P; }
    function oe() { if (e.daysContainer !== void 0) {
        te(e.daysContainer), e.weekNumbers && te(e.weekNumbers);
        for (var n = document.createDocumentFragment(), t = 0; t < e.config.showMonths; t++) {
            var i = new Date(e.currentYear, e.currentMonth, 1);
            i.setMonth(e.currentMonth + t), n.appendChild(Ze(i.getFullYear(), i.getMonth()));
        }
        e.daysContainer.appendChild(n), e.days = e.daysContainer.firstChild, e.config.mode === "range" && e.selectedDates.length === 1 && ue();
    } }
    function z() { if (!(e.config.showMonths > 1 || e.config.monthSelectorType !== "dropdown")) {
        var n = function (o) { return e.config.minDate !== void 0 && e.currentYear === e.config.minDate.getFullYear() && o < e.config.minDate.getMonth() ? !1 : !(e.config.maxDate !== void 0 && e.currentYear === e.config.maxDate.getFullYear() && o > e.config.maxDate.getMonth()); };
        e.monthsDropdownContainer.tabIndex = -1, e.monthsDropdownContainer.innerHTML = "";
        for (var t = 0; t < 12; t++)
            if (n(t)) {
                var i = v("option", "flatpickr-monthDropdown-month");
                i.value = new Date(e.currentYear, t).getMonth().toString(), i.textContent = ie(t, e.config.shorthandCurrentMonth, e.l10n), i.tabIndex = -1, e.currentMonth === t && (i.selected = !0), e.monthsDropdownContainer.appendChild(i);
            }
    } }
    function Qe() { var n = v("div", "flatpickr-month"), t = window.document.createDocumentFragment(), i; e.config.showMonths > 1 || e.config.monthSelectorType === "static" ? i = v("span", "cur-month") : (e.monthsDropdownContainer = v("select", "flatpickr-monthDropdown-months"), e.monthsDropdownContainer.setAttribute("aria-label", e.l10n.monthAriaLabel), D(e.monthsDropdownContainer, "change", function (d) { var s = _(d), p = parseInt(s.value, 10); e.changeMonth(p - e.currentMonth), b("onMonthChange"); }), z(), i = e.monthsDropdownContainer); var o = ae("cur-year", { tabindex: "-1" }), l = o.getElementsByTagName("input")[0]; l.setAttribute("aria-label", e.l10n.yearAriaLabel), e.config.minDate && l.setAttribute("min", e.config.minDate.getFullYear().toString()), e.config.maxDate && (l.setAttribute("max", e.config.maxDate.getFullYear().toString()), l.disabled = !!e.config.minDate && e.config.minDate.getFullYear() === e.config.maxDate.getFullYear()); var f = v("div", "flatpickr-current-month"); return f.appendChild(i), f.appendChild(o), t.appendChild(f), n.appendChild(t), { container: n, yearElement: l, monthElement: i }; }
    function Ne() { te(e.monthNav), e.monthNav.appendChild(e.prevMonthNav), e.config.showMonths && (e.yearElements = [], e.monthElements = []); for (var n = e.config.showMonths; n--;) {
        var t = Qe();
        e.yearElements.push(t.yearElement), e.monthElements.push(t.monthElement), e.monthNav.appendChild(t.container);
    } e.monthNav.appendChild(e.nextMonthNav); }
    function Xe() { return e.monthNav = v("div", "flatpickr-months"), e.yearElements = [], e.monthElements = [], e.prevMonthNav = v("span", "flatpickr-prev-month"), e.prevMonthNav.innerHTML = e.config.prevArrow, e.nextMonthNav = v("span", "flatpickr-next-month"), e.nextMonthNav.innerHTML = e.config.nextArrow, Ne(), Object.defineProperty(e, "_hidePrevMonthArrow", { get: function () { return e.__hidePrevMonthArrow; }, set: function (n) { e.__hidePrevMonthArrow !== n && (T(e.prevMonthNav, "flatpickr-disabled", n), e.__hidePrevMonthArrow = n); } }), Object.defineProperty(e, "_hideNextMonthArrow", { get: function () { return e.__hideNextMonthArrow; }, set: function (n) { e.__hideNextMonthArrow !== n && (T(e.nextMonthNav, "flatpickr-disabled", n), e.__hideNextMonthArrow = n); } }), e.currentYearElement = e.yearElements[0], de(), e.monthNav; }
    function en() { e.calendarContainer.classList.add("hasTime"), e.config.noCalendar && e.calendarContainer.classList.add("noCalendar"); var n = Me(e.config); e.timeContainer = v("div", "flatpickr-time"), e.timeContainer.tabIndex = -1; var t = v("span", "flatpickr-time-separator", ":"), i = ae("flatpickr-hour", { "aria-label": e.l10n.hourAriaLabel }); e.hourElement = i.getElementsByTagName("input")[0]; var o = ae("flatpickr-minute", { "aria-label": e.l10n.minuteAriaLabel }); if (e.minuteElement = o.getElementsByTagName("input")[0], e.hourElement.tabIndex = e.minuteElement.tabIndex = -1, e.hourElement.value = k(e.latestSelectedDateObj ? e.latestSelectedDateObj.getHours() : e.config.time_24hr ? n.hours : C(n.hours)), e.minuteElement.value = k(e.latestSelectedDateObj ? e.latestSelectedDateObj.getMinutes() : n.minutes), e.hourElement.setAttribute("step", e.config.hourIncrement.toString()), e.minuteElement.setAttribute("step", e.config.minuteIncrement.toString()), e.hourElement.setAttribute("min", e.config.time_24hr ? "0" : "1"), e.hourElement.setAttribute("max", e.config.time_24hr ? "23" : "12"), e.hourElement.setAttribute("maxlength", "2"), e.minuteElement.setAttribute("min", "0"), e.minuteElement.setAttribute("max", "59"), e.minuteElement.setAttribute("maxlength", "2"), e.timeContainer.appendChild(i), e.timeContainer.appendChild(t), e.timeContainer.appendChild(o), e.config.time_24hr && e.timeContainer.classList.add("time24hr"), e.config.enableSeconds) {
        e.timeContainer.classList.add("hasSeconds");
        var l = ae("flatpickr-second");
        e.secondElement = l.getElementsByTagName("input")[0], e.secondElement.value = k(e.latestSelectedDateObj ? e.latestSelectedDateObj.getSeconds() : n.seconds), e.secondElement.setAttribute("step", e.minuteElement.getAttribute("step")), e.secondElement.setAttribute("min", "0"), e.secondElement.setAttribute("max", "59"), e.secondElement.setAttribute("maxlength", "2"), e.timeContainer.appendChild(v("span", "flatpickr-time-separator", ":")), e.timeContainer.appendChild(l);
    } return e.config.time_24hr || (e.amPM = v("span", "flatpickr-am-pm", e.l10n.amPM[I((e.latestSelectedDateObj ? e.hourElement.value : e.config.defaultHour) > 11)]), e.amPM.title = e.l10n.toggleTitle, e.amPM.tabIndex = -1, e.timeContainer.appendChild(e.amPM)), e.timeContainer; }
    function Pe() { e.weekdayContainer ? te(e.weekdayContainer) : e.weekdayContainer = v("div", "flatpickr-weekdays"); for (var n = e.config.showMonths; n--;) {
        var t = v("div", "flatpickr-weekdaycontainer");
        e.weekdayContainer.appendChild(t);
    } return Ye(), e.weekdayContainer; }
    function Ye() {
        if (e.weekdayContainer) {
            var n = e.l10n.firstDayOfWeek, t = Ge(e.l10n.weekdays.shorthand);
            n > 0 && n < t.length && (t = Ge(t.splice(n, t.length), t.splice(0, n)));
            for (var i = e.config.showMonths; i--;)
                e.weekdayContainer.children[i].innerHTML = `
      <span class='flatpickr-weekday'>
        ` + t.join("</span><span class='flatpickr-weekday'>") + `
      </span>
      `;
        }
    }
    function nn() { e.calendarContainer.classList.add("hasWeeks"); var n = v("div", "flatpickr-weekwrapper"); n.appendChild(v("span", "flatpickr-weekday", e.l10n.weekAbbreviation)); var t = v("div", "flatpickr-weeks"); return n.appendChild(t), { weekWrapper: n, weekNumbers: t }; }
    function ye(n, t) { t === void 0 && (t = !0); var i = t ? n : n - e.currentMonth; i < 0 && e._hidePrevMonthArrow === !0 || i > 0 && e._hideNextMonthArrow === !0 || (e.currentMonth += i, (e.currentMonth < 0 || e.currentMonth > 11) && (e.currentYear += e.currentMonth > 11 ? 1 : -1, e.currentMonth = (e.currentMonth + 12) % 12, b("onYearChange"), z()), oe(), b("onMonthChange"), de()); }
    function tn(n, t) { if (n === void 0 && (n = !0), t === void 0 && (t = !0), e.input.value = "", e.altInput !== void 0 && (e.altInput.value = ""), e.mobileInput !== void 0 && (e.mobileInput.value = ""), e.selectedDates = [], e.latestSelectedDateObj = void 0, t === !0 && (e.currentYear = e._initialDate.getFullYear(), e.currentMonth = e._initialDate.getMonth()), e.config.enableTime === !0) {
        var i = Me(e.config), o = i.hours, l = i.minutes, f = i.seconds;
        Y(o, l, f);
    } e.redraw(), n && b("onChange"); }
    function an() { e.isOpen = !1, e.isMobile || (e.calendarContainer !== void 0 && e.calendarContainer.classList.remove("open"), e._input !== void 0 && e._input.classList.remove("active")), b("onClose"); }
    function rn() { e.config !== void 0 && b("onDestroy"); for (var n = e._handlers.length; n--;)
        e._handlers[n].remove(); if (e._handlers = [], e.mobileInput)
        e.mobileInput.parentNode && e.mobileInput.parentNode.removeChild(e.mobileInput), e.mobileInput = void 0;
    else if (e.calendarContainer && e.calendarContainer.parentNode)
        if (e.config.static && e.calendarContainer.parentNode) {
            var t = e.calendarContainer.parentNode;
            if (t.lastChild && t.removeChild(t.lastChild), t.parentNode) {
                for (; t.firstChild;)
                    t.parentNode.insertBefore(t.firstChild, t);
                t.parentNode.removeChild(t);
            }
        }
        else
            e.calendarContainer.parentNode.removeChild(e.calendarContainer); e.altInput && (e.input.type = "text", e.altInput.parentNode && e.altInput.parentNode.removeChild(e.altInput), delete e.altInput), e.input && (e.input.type = e.input._type, e.input.classList.remove("flatpickr-input"), e.input.removeAttribute("readonly")), ["_showTimeInput", "latestSelectedDateObj", "_hideNextMonthArrow", "_hidePrevMonthArrow", "__hideNextMonthArrow", "__hidePrevMonthArrow", "isMobile", "isOpen", "selectedDateElem", "minDateHasTime", "maxDateHasTime", "days", "daysContainer", "_input", "_positionElement", "innerContainer", "rContainer", "monthNav", "todayDateElem", "calendarContainer", "weekdayContainer", "prevMonthNav", "nextMonthNav", "monthsDropdownContainer", "currentMonthElement", "currentYearElement", "navigationCurrentMonth", "selectedDateElem", "config"].forEach(function (i) { try {
        delete e[i];
    }
    catch { } }); }
    function ee(n) { return e.calendarContainer.contains(n); }
    function xe(n) { if (e.isOpen && !e.config.inline) {
        var t = _(n), i = ee(t), o = t === e.input || t === e.altInput || e.element.contains(t) || n.path && n.path.indexOf && (~n.path.indexOf(e.input) || ~n.path.indexOf(e.altInput)), l = !o && !i && !ee(n.relatedTarget), f = !e.config.ignoredFocusElements.some(function (d) { return d.contains(t); });
        l && f && (e.config.allowInput && e.setDate(e._input.value, !1, e.config.altInput ? e.config.altFormat : e.config.dateFormat), e.timeContainer !== void 0 && e.minuteElement !== void 0 && e.hourElement !== void 0 && e.input.value !== "" && e.input.value !== void 0 && E(), e.close(), e.config && e.config.mode === "range" && e.selectedDates.length === 1 && e.clear(!1));
    } }
    function le(n) { if (!(!n || e.config.minDate && n < e.config.minDate.getFullYear() || e.config.maxDate && n > e.config.maxDate.getFullYear())) {
        var t = n, i = e.currentYear !== t;
        e.currentYear = t || e.currentYear, e.config.maxDate && e.currentYear === e.config.maxDate.getFullYear() ? e.currentMonth = Math.min(e.config.maxDate.getMonth(), e.currentMonth) : e.config.minDate && e.currentYear === e.config.minDate.getFullYear() && (e.currentMonth = Math.max(e.config.minDate.getMonth(), e.currentMonth)), i && (e.redraw(), b("onYearChange"), z());
    } }
    function J(n, t) { var i; t === void 0 && (t = !0); var o = e.parseDate(n, void 0, t); if (e.config.minDate && o && O(o, e.config.minDate, t !== void 0 ? t : !e.minDateHasTime) < 0 || e.config.maxDate && o && O(o, e.config.maxDate, t !== void 0 ? t : !e.maxDateHasTime) > 0)
        return !1; if (!e.config.enable && e.config.disable.length === 0)
        return !0; if (o === void 0)
        return !1; for (var l = !!e.config.enable, f = (i = e.config.enable) !== null && i !== void 0 ? i : e.config.disable, d = 0, s = void 0; d < f.length; d++) {
        if (s = f[d], typeof s == "function" && s(o))
            return l;
        if (s instanceof Date && o !== void 0 && s.getTime() === o.getTime())
            return l;
        if (typeof s == "string") {
            var p = e.parseDate(s, void 0, !0);
            return p && p.getTime() === o.getTime() ? l : !l;
        }
        else if (typeof s == "object" && o !== void 0 && s.from && s.to && o.getTime() >= s.from.getTime() && o.getTime() <= s.to.getTime())
            return l;
    } return !l; }
    function fe(n) { return e.daysContainer !== void 0 ? n.className.indexOf("hidden") === -1 && n.className.indexOf("flatpickr-disabled") === -1 && e.daysContainer.contains(n) : !1; }
    function on(n) { var t = n.target === e._input, i = e._input.value.trimEnd() !== Se(); t && i && !(n.relatedTarget && ee(n.relatedTarget)) && e.setDate(e._input.value, !0, n.target === e.altInput ? e.config.altFormat : e.config.dateFormat); }
    function He(n) { var t = _(n), i = e.config.wrap ? a.contains(t) : t === e._input, o = e.config.allowInput, l = e.isOpen && (!o || !i), f = e.config.inline && i && !o; if (n.keyCode === 13 && i) {
        if (o)
            return e.setDate(e._input.value, !0, t === e.altInput ? e.config.altFormat : e.config.dateFormat), e.close(), t.blur();
        e.open();
    }
    else if (ee(t) || l || f) {
        var d = !!e.timeContainer && e.timeContainer.contains(t);
        switch (n.keyCode) {
            case 13:
                d ? (n.preventDefault(), E(), Ee()) : Be(n);
                break;
            case 27:
                n.preventDefault(), Ee();
                break;
            case 8:
            case 46:
                i && !e.config.allowInput && (n.preventDefault(), e.clear());
                break;
            case 37:
            case 39:
                if (!d && !i) {
                    n.preventDefault();
                    var s = m();
                    if (e.daysContainer !== void 0 && (o === !1 || s && fe(s))) {
                        var p = n.keyCode === 39 ? 1 : -1;
                        n.ctrlKey ? (n.stopPropagation(), ye(p), X(q(1), 0)) : X(void 0, p);
                    }
                }
                else
                    e.hourElement && e.hourElement.focus();
                break;
            case 38:
            case 40:
                n.preventDefault();
                var u = n.keyCode === 40 ? 1 : -1;
                e.daysContainer && t.$i !== void 0 || t === e.input || t === e.altInput ? n.ctrlKey ? (n.stopPropagation(), le(e.currentYear - u), X(q(1), 0)) : d || X(void 0, u * 7) : t === e.currentYearElement ? le(e.currentYear - u) : e.config.enableTime && (!d && e.hourElement && e.hourElement.focus(), E(n), e._debouncedChange());
                break;
            case 9:
                if (d) {
                    var c = [e.hourElement, e.minuteElement, e.secondElement, e.amPM].concat(e.pluginElements).filter(function (F) { return F; }), M = c.indexOf(t);
                    if (M !== -1) {
                        var P = c[M + (n.shiftKey ? -1 : 1)];
                        n.preventDefault(), (P || e._input).focus();
                    }
                }
                else
                    !e.config.noCalendar && e.daysContainer && e.daysContainer.contains(t) && n.shiftKey && (n.preventDefault(), e._input.focus());
                break;
            default: break;
        }
    } if (e.amPM !== void 0 && t === e.amPM)
        switch (n.key) {
            case e.l10n.amPM[0].charAt(0):
            case e.l10n.amPM[0].charAt(0).toLowerCase():
                e.amPM.textContent = e.l10n.amPM[0], A(), H();
                break;
            case e.l10n.amPM[1].charAt(0):
            case e.l10n.amPM[1].charAt(0).toLowerCase():
                e.amPM.textContent = e.l10n.amPM[1], A(), H();
                break;
        } (i || ee(t)) && b("onKeyDown", n); }
    function ue(n, t) { if (t === void 0 && (t = "flatpickr-day"), !(e.selectedDates.length !== 1 || n && (!n.classList.contains(t) || n.classList.contains("flatpickr-disabled")))) {
        for (var i = n ? n.dateObj.getTime() : e.days.firstElementChild.dateObj.getTime(), o = e.parseDate(e.selectedDates[0], void 0, !0).getTime(), l = Math.min(i, e.selectedDates[0].getTime()), f = Math.max(i, e.selectedDates[0].getTime()), d = !1, s = 0, p = 0, u = l; u < f; u += $e.DAY)
            J(new Date(u), !0) || (d = d || u > l && u < f, u < o && (!s || u > s) ? s = u : u > o && (!p || u < p) && (p = u));
        var c = Array.from(e.rContainer.querySelectorAll("*:nth-child(-n+" + e.config.showMonths + ") > ." + t));
        c.forEach(function (M) { var P = M.dateObj, F = P.getTime(), ne = s > 0 && F < s || p > 0 && F > p; if (ne) {
            M.classList.add("notAllowed"), ["inRange", "startRange", "endRange"].forEach(function ($) { M.classList.remove($); });
            return;
        }
        else if (d && !ne)
            return; ["startRange", "inRange", "endRange", "notAllowed"].forEach(function ($) { M.classList.remove($); }), n !== void 0 && (n.classList.add(i <= e.selectedDates[0].getTime() ? "startRange" : "endRange"), o < i && F === o ? M.classList.add("startRange") : o > i && F === o && M.classList.add("endRange"), F >= s && (p === 0 || F <= p) && qe(F, o, i) && M.classList.add("inRange")); });
    } }
    function ln() { e.isOpen && !e.config.static && !e.config.inline && se(); }
    function fn(n, t) { if (t === void 0 && (t = e._positionElement), e.isMobile === !0) {
        if (n) {
            n.preventDefault();
            var i = _(n);
            i && i.blur();
        }
        e.mobileInput !== void 0 && (e.mobileInput.focus(), e.mobileInput.click()), b("onOpen");
        return;
    }
    else if (e._input.disabled || e.config.inline)
        return; var o = e.isOpen; e.isOpen = !0, o || (e.calendarContainer.classList.add("open"), e._input.classList.add("active"), b("onOpen"), se(t)), e.config.enableTime === !0 && e.config.noCalendar === !0 && e.config.allowInput === !1 && (n === void 0 || !e.timeContainer.contains(n.relatedTarget)) && setTimeout(function () { return e.hourElement.select(); }, 50); }
    function Le(n) { return function (t) { var i = e.config["_" + n + "Date"] = e.parseDate(t, e.config.dateFormat), o = e.config["_" + (n === "min" ? "max" : "min") + "Date"]; i !== void 0 && (e[n === "min" ? "minDateHasTime" : "maxDateHasTime"] = i.getHours() > 0 || i.getMinutes() > 0 || i.getSeconds() > 0), e.selectedDates && (e.selectedDates = e.selectedDates.filter(function (l) { return J(l); }), !e.selectedDates.length && n === "min" && N(i), H()), e.daysContainer && (We(), i !== void 0 ? e.currentYearElement[n] = i.getFullYear().toString() : e.currentYearElement.removeAttribute(n), e.currentYearElement.disabled = !!o && i !== void 0 && o.getFullYear() === i.getFullYear()); }; }
    function un() { var n = ["wrap", "weekNumbers", "allowInput", "allowInvalidPreload", "clickOpens", "time_24hr", "enableTime", "noCalendar", "altInput", "shorthandCurrentMonth", "inline", "static", "enableSeconds", "disableMobile"], t = S(S({}, JSON.parse(JSON.stringify(a.dataset || {}))), r), i = {}; e.config.parseDate = t.parseDate, e.config.formatDate = t.formatDate, Object.defineProperty(e.config, "enable", { get: function () { return e.config._enable; }, set: function (c) { e.config._enable = Je(c); } }), Object.defineProperty(e.config, "disable", { get: function () { return e.config._disable; }, set: function (c) { e.config._disable = Je(c); } }); var o = t.mode === "time"; if (!t.dateFormat && (t.enableTime || o)) {
        var l = y.defaultConfig.dateFormat || R.dateFormat;
        i.dateFormat = t.noCalendar || o ? "H:i" + (t.enableSeconds ? ":S" : "") : l + " H:i" + (t.enableSeconds ? ":S" : "");
    } if (t.altInput && (t.enableTime || o) && !t.altFormat) {
        var f = y.defaultConfig.altFormat || R.altFormat;
        i.altFormat = t.noCalendar || o ? "h:i" + (t.enableSeconds ? ":S K" : " K") : f + (" h:i" + (t.enableSeconds ? ":S" : "") + " K");
    } Object.defineProperty(e.config, "minDate", { get: function () { return e.config._minDate; }, set: Le("min") }), Object.defineProperty(e.config, "maxDate", { get: function () { return e.config._maxDate; }, set: Le("max") }); var d = function (c) { return function (M) { e.config[c === "min" ? "_minTime" : "_maxTime"] = e.parseDate(M, "H:i:S"); }; }; Object.defineProperty(e.config, "minTime", { get: function () { return e.config._minTime; }, set: d("min") }), Object.defineProperty(e.config, "maxTime", { get: function () { return e.config._maxTime; }, set: d("max") }), t.mode === "time" && (e.config.noCalendar = !0, e.config.enableTime = !0), Object.assign(e.config, i, t); for (var s = 0; s < n.length; s++)
        e.config[n[s]] = e.config[n[s]] === !0 || e.config[n[s]] === "true"; me.filter(function (c) { return e.config[c] !== void 0; }).forEach(function (c) { e.config[c] = he(e.config[c] || []).map(w); }), e.isMobile = !e.config.disableMobile && !e.config.inline && e.config.mode === "single" && !e.config.disable.length && !e.config.enable && !e.config.weekNumbers && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent); for (var s = 0; s < e.config.plugins.length; s++) {
        var p = e.config.plugins[s](e) || {};
        for (var u in p)
            me.indexOf(u) > -1 ? e.config[u] = he(p[u]).map(w).concat(e.config[u]) : typeof t[u] > "u" && (e.config[u] = p[u]);
    } t.altInputClass || (e.config.altInputClass = je().className + " " + e.config.altInputClass), b("onParseConfig"); }
    function je() { return e.config.wrap ? a.querySelector("[data-input]") : a; }
    function Re() { typeof e.config.locale != "object" && typeof y.l10ns[e.config.locale] > "u" && e.config.errorHandler(new Error("flatpickr: invalid locale " + e.config.locale)), e.l10n = S(S({}, y.l10ns.default), typeof e.config.locale == "object" ? e.config.locale : e.config.locale !== "default" ? y.l10ns[e.config.locale] : void 0), L.D = "(" + e.l10n.weekdays.shorthand.join("|") + ")", L.l = "(" + e.l10n.weekdays.longhand.join("|") + ")", L.M = "(" + e.l10n.months.shorthand.join("|") + ")", L.F = "(" + e.l10n.months.longhand.join("|") + ")", L.K = "(" + e.l10n.amPM[0] + "|" + e.l10n.amPM[1] + "|" + e.l10n.amPM[0].toLowerCase() + "|" + e.l10n.amPM[1].toLowerCase() + ")"; var n = S(S({}, r), JSON.parse(JSON.stringify(a.dataset || {}))); n.time_24hr === void 0 && y.defaultConfig.time_24hr === void 0 && (e.config.time_24hr = e.l10n.time_24hr), e.formatDate = Ae(e), e.parseDate = ve({ config: e.config, l10n: e.l10n }); }
    function se(n) { if (typeof e.config.position == "function")
        return void e.config.position(e, n); if (e.calendarContainer !== void 0) {
        b("onPreCalendarPosition");
        var t = n || e._positionElement, i = Array.prototype.reduce.call(e.calendarContainer.children, function (Sn, In) { return Sn + In.offsetHeight; }, 0), o = e.calendarContainer.offsetWidth, l = e.config.position.split(" "), f = l[0], d = l.length > 1 ? l[1] : null, s = t.getBoundingClientRect(), p = window.innerHeight - s.bottom, u = f === "above" || f !== "below" && p < i && s.top > i, c = window.pageYOffset + s.top + (u ? -i - 2 : t.offsetHeight + 2);
        if (T(e.calendarContainer, "arrowTop", !u), T(e.calendarContainer, "arrowBottom", u), !e.config.inline) {
            var M = window.pageXOffset + s.left, P = !1, F = !1;
            d === "center" ? (M -= (o - s.width) / 2, P = !0) : d === "right" && (M -= o - s.width, F = !0), T(e.calendarContainer, "arrowLeft", !P && !F), T(e.calendarContainer, "arrowCenter", P), T(e.calendarContainer, "arrowRight", F);
            var ne = window.document.body.offsetWidth - (window.pageXOffset + s.right), $ = M + o > window.document.body.offsetWidth, wn = ne + o > window.document.body.offsetWidth;
            if (T(e.calendarContainer, "rightMost", $), !e.config.static)
                if (e.calendarContainer.style.top = c + "px", !$)
                    e.calendarContainer.style.left = M + "px", e.calendarContainer.style.right = "auto";
                else if (!wn)
                    e.calendarContainer.style.left = "auto", e.calendarContainer.style.right = ne + "px";
                else {
                    var Ie = sn();
                    if (Ie === void 0)
                        return;
                    var Cn = window.document.body.offsetWidth, yn = Math.max(0, Cn / 2 - o / 2), xn = ".flatpickr-calendar.centerMost:before", En = ".flatpickr-calendar.centerMost:after", kn = Ie.cssRules.length, Tn = "{left:" + s.left + "px;right:auto;}";
                    T(e.calendarContainer, "rightMost", !1), T(e.calendarContainer, "centerMost", !0), Ie.insertRule(xn + "," + En + Tn, kn), e.calendarContainer.style.left = yn + "px", e.calendarContainer.style.right = "auto";
                }
        }
    } }
    function sn() { for (var n = null, t = 0; t < document.styleSheets.length; t++) {
        var i = document.styleSheets[t];
        if (i.cssRules) {
            try {
                i.cssRules;
            }
            catch {
                continue;
            }
            n = i;
            break;
        }
    } return n ?? cn(); }
    function cn() { var n = document.createElement("style"); return document.head.appendChild(n), n.sheet; }
    function We() { e.config.noCalendar || e.isMobile || (z(), de(), oe()); }
    function Ee() { e._input.focus(), window.navigator.userAgent.indexOf("MSIE") !== -1 || navigator.msMaxTouchPoints !== void 0 ? setTimeout(e.close, 0) : e.close(); }
    function Be(n) { n.preventDefault(), n.stopPropagation(); var t = function (c) { return c.classList && c.classList.contains("flatpickr-day") && !c.classList.contains("flatpickr-disabled") && !c.classList.contains("notAllowed"); }, i = Oe(_(n), t); if (i !== void 0) {
        var o = i, l = e.latestSelectedDateObj = new Date(o.dateObj.getTime()), f = (l.getMonth() < e.currentMonth || l.getMonth() > e.currentMonth + e.config.showMonths - 1) && e.config.mode !== "range";
        if (e.selectedDateElem = o, e.config.mode === "single")
            e.selectedDates = [l];
        else if (e.config.mode === "multiple") {
            var d = Te(l);
            d ? e.selectedDates.splice(parseInt(d), 1) : e.selectedDates.push(l);
        }
        else
            e.config.mode === "range" && (e.selectedDates.length === 2 && e.clear(!1, !1), e.latestSelectedDateObj = l, e.selectedDates.push(l), O(l, e.selectedDates[0], !0) !== 0 && e.selectedDates.sort(function (c, M) { return c.getTime() - M.getTime(); }));
        if (A(), f) {
            var s = e.currentYear !== l.getFullYear();
            e.currentYear = l.getFullYear(), e.currentMonth = l.getMonth(), s && (b("onYearChange"), z()), b("onMonthChange");
        }
        if (de(), oe(), H(), !f && e.config.mode !== "range" && e.config.showMonths === 1 ? V(o) : e.selectedDateElem !== void 0 && e.hourElement === void 0 && e.selectedDateElem && e.selectedDateElem.focus(), e.hourElement !== void 0 && e.hourElement !== void 0 && e.hourElement.focus(), e.config.closeOnSelect) {
            var p = e.config.mode === "single" && !e.config.enableTime, u = e.config.mode === "range" && e.selectedDates.length === 2 && !e.config.enableTime;
            (p || u) && Ee();
        }
        W();
    } }
    var ce = { locale: [Re, Ye], showMonths: [Ne, x, Pe], minDate: [j], maxDate: [j], positionElement: [Ue], clickOpens: [function () { e.config.clickOpens === !0 ? (D(e._input, "focus", e.open), D(e._input, "click", e.open)) : (e._input.removeEventListener("focus", e.open), e._input.removeEventListener("click", e.open)); }] };
    function dn(n, t) { if (n !== null && typeof n == "object") {
        Object.assign(e.config, n);
        for (var i in n)
            ce[i] !== void 0 && ce[i].forEach(function (o) { return o(); });
    }
    else
        e.config[n] = t, ce[n] !== void 0 ? ce[n].forEach(function (o) { return o(); }) : me.indexOf(n) > -1 && (e.config[n] = he(t)); e.redraw(), H(!0); }
    function Ke(n, t) { var i = []; if (n instanceof Array)
        i = n.map(function (o) { return e.parseDate(o, t); });
    else if (n instanceof Date || typeof n == "number")
        i = [e.parseDate(n, t)];
    else if (typeof n == "string")
        switch (e.config.mode) {
            case "single":
            case "time":
                i = [e.parseDate(n, t)];
                break;
            case "multiple":
                i = n.split(e.config.conjunction).map(function (o) { return e.parseDate(o, t); });
                break;
            case "range":
                i = n.split(e.l10n.rangeSeparator).map(function (o) { return e.parseDate(o, t); });
                break;
            default: break;
        }
    else
        e.config.errorHandler(new Error("Invalid date supplied: " + JSON.stringify(n))); e.selectedDates = e.config.allowInvalidPreload ? i : i.filter(function (o) { return o instanceof Date && J(o, !1); }), e.config.mode === "range" && e.selectedDates.sort(function (o, l) { return o.getTime() - l.getTime(); }); }
    function mn(n, t, i) { if (t === void 0 && (t = !1), i === void 0 && (i = e.config.dateFormat), n !== 0 && !n || n instanceof Array && n.length === 0)
        return e.clear(t); Ke(n, i), e.latestSelectedDateObj = e.selectedDates[e.selectedDates.length - 1], e.redraw(), j(void 0, t), N(), e.selectedDates.length === 0 && e.clear(!1), H(t), t && b("onChange"); }
    function Je(n) { return n.slice().map(function (t) { return typeof t == "string" || typeof t == "number" || t instanceof Date ? e.parseDate(t, void 0, !0) : t && typeof t == "object" && t.from && t.to ? { from: e.parseDate(t.from, void 0), to: e.parseDate(t.to, void 0) } : t; }).filter(function (t) { return t; }); }
    function gn() { e.selectedDates = [], e.now = e.parseDate(e.config.now) || new Date; var n = e.config.defaultDate || ((e.input.nodeName === "INPUT" || e.input.nodeName === "TEXTAREA") && e.input.placeholder && e.input.value === e.input.placeholder ? null : e.input.value); n && Ke(n, e.config.dateFormat), e._initialDate = e.selectedDates.length > 0 ? e.selectedDates[0] : e.config.minDate && e.config.minDate.getTime() > e.now.getTime() ? e.config.minDate : e.config.maxDate && e.config.maxDate.getTime() < e.now.getTime() ? e.config.maxDate : e.now, e.currentYear = e._initialDate.getFullYear(), e.currentMonth = e._initialDate.getMonth(), e.selectedDates.length > 0 && (e.latestSelectedDateObj = e.selectedDates[0]), e.config.minTime !== void 0 && (e.config.minTime = e.parseDate(e.config.minTime, "H:i")), e.config.maxTime !== void 0 && (e.config.maxTime = e.parseDate(e.config.maxTime, "H:i")), e.minDateHasTime = !!e.config.minDate && (e.config.minDate.getHours() > 0 || e.config.minDate.getMinutes() > 0 || e.config.minDate.getSeconds() > 0), e.maxDateHasTime = !!e.config.maxDate && (e.config.maxDate.getHours() > 0 || e.config.maxDate.getMinutes() > 0 || e.config.maxDate.getSeconds() > 0); }
    function pn() { if (e.input = je(), !e.input) {
        e.config.errorHandler(new Error("Invalid input element specified"));
        return;
    } e.input._type = e.input.type, e.input.type = "text", e.input.classList.add("flatpickr-input"), e._input = e.input, e.config.altInput && (e.altInput = v(e.input.nodeName, e.config.altInputClass), e._input = e.altInput, e.altInput.placeholder = e.input.placeholder, e.altInput.disabled = e.input.disabled, e.altInput.required = e.input.required, e.altInput.tabIndex = e.input.tabIndex, e.altInput.type = "text", e.input.setAttribute("type", "hidden"), !e.config.static && e.input.parentNode && e.input.parentNode.insertBefore(e.altInput, e.input.nextSibling)), e.config.allowInput || e._input.setAttribute("readonly", "readonly"), Ue(); }
    function Ue() { e._positionElement = e.config.positionElement || e._input; }
    function hn() { var n = e.config.enableTime ? e.config.noCalendar ? "time" : "datetime-local" : "date"; e.mobileInput = v("input", e.input.className + " flatpickr-mobile"), e.mobileInput.tabIndex = 1, e.mobileInput.type = n, e.mobileInput.disabled = e.input.disabled, e.mobileInput.required = e.input.required, e.mobileInput.placeholder = e.input.placeholder, e.mobileFormatStr = n === "datetime-local" ? "Y-m-d\\TH:i:S" : n === "date" ? "Y-m-d" : "H:i:S", e.selectedDates.length > 0 && (e.mobileInput.defaultValue = e.mobileInput.value = e.formatDate(e.selectedDates[0], e.mobileFormatStr)), e.config.minDate && (e.mobileInput.min = e.formatDate(e.config.minDate, "Y-m-d")), e.config.maxDate && (e.mobileInput.max = e.formatDate(e.config.maxDate, "Y-m-d")), e.input.getAttribute("step") && (e.mobileInput.step = String(e.input.getAttribute("step"))), e.input.type = "hidden", e.altInput !== void 0 && (e.altInput.type = "hidden"); try {
        e.input.parentNode && e.input.parentNode.insertBefore(e.mobileInput, e.input.nextSibling);
    }
    catch { } D(e.mobileInput, "change", function (t) { e.setDate(_(t).value, !1, e.mobileFormatStr), b("onChange"), b("onClose"); }); }
    function vn(n) { if (e.isOpen === !0)
        return e.close(); e.open(n); }
    function b(n, t) { if (e.config !== void 0) {
        var i = e.config[n];
        if (i !== void 0 && i.length > 0)
            for (var o = 0; i[o] && o < i.length; o++)
                i[o](e.selectedDates, e.input.value, e, t);
        n === "onChange" && (e.input.dispatchEvent(ke("change")), e.input.dispatchEvent(ke("input")));
    } }
    function ke(n) { var t = document.createEvent("Event"); return t.initEvent(n, !0, !0), t; }
    function Te(n) { for (var t = 0; t < e.selectedDates.length; t++) {
        var i = e.selectedDates[t];
        if (i instanceof Date && O(i, n) === 0)
            return "" + t;
    } return !1; }
    function Dn(n) { return e.config.mode !== "range" || e.selectedDates.length < 2 ? !1 : O(n, e.selectedDates[0]) >= 0 && O(n, e.selectedDates[1]) <= 0; }
    function de() { e.config.noCalendar || e.isMobile || !e.monthNav || (e.yearElements.forEach(function (n, t) { var i = new Date(e.currentYear, e.currentMonth, 1); i.setMonth(e.currentMonth + t), e.config.showMonths > 1 || e.config.monthSelectorType === "static" ? e.monthElements[t].textContent = ie(i.getMonth(), e.config.shorthandCurrentMonth, e.l10n) + " " : e.monthsDropdownContainer.value = i.getMonth().toString(), n.value = i.getFullYear().toString(); }), e._hidePrevMonthArrow = e.config.minDate !== void 0 && (e.currentYear === e.config.minDate.getFullYear() ? e.currentMonth <= e.config.minDate.getMonth() : e.currentYear < e.config.minDate.getFullYear()), e._hideNextMonthArrow = e.config.maxDate !== void 0 && (e.currentYear === e.config.maxDate.getFullYear() ? e.currentMonth + 1 > e.config.maxDate.getMonth() : e.currentYear > e.config.maxDate.getFullYear())); }
    function Se(n) { var t = n || (e.config.altInput ? e.config.altFormat : e.config.dateFormat); return e.selectedDates.map(function (i) { return e.formatDate(i, t); }).filter(function (i, o, l) { return e.config.mode !== "range" || e.config.enableTime || l.indexOf(i) === o; }).join(e.config.mode !== "range" ? e.config.conjunction : e.l10n.rangeSeparator); }
    function H(n) { n === void 0 && (n = !0), e.mobileInput !== void 0 && e.mobileFormatStr && (e.mobileInput.value = e.latestSelectedDateObj !== void 0 ? e.formatDate(e.latestSelectedDateObj, e.mobileFormatStr) : ""), e.input.value = Se(e.config.dateFormat), e.altInput !== void 0 && (e.altInput.value = Se(e.config.altFormat)), n !== !1 && b("onValueUpdate"); }
    function Mn(n) { var t = _(n), i = e.prevMonthNav.contains(t), o = e.nextMonthNav.contains(t); i || o ? ye(i ? -1 : 1) : e.yearElements.indexOf(t) >= 0 ? t.select() : t.classList.contains("arrowUp") ? e.changeYear(e.currentYear + 1) : t.classList.contains("arrowDown") && e.changeYear(e.currentYear - 1); }
    function bn(n) { n.preventDefault(); var t = n.type === "keydown", i = _(n), o = i; e.amPM !== void 0 && i === e.amPM && (e.amPM.textContent = e.l10n.amPM[I(e.amPM.textContent === e.l10n.amPM[0])]); var l = parseFloat(o.getAttribute("min")), f = parseFloat(o.getAttribute("max")), d = parseFloat(o.getAttribute("step")), s = parseInt(o.value, 10), p = n.delta || (t ? n.which === 38 ? 1 : -1 : 0), u = s + d * p; if (typeof o.value < "u" && o.value.length === 2) {
        var c = o === e.hourElement, M = o === e.minuteElement;
        u < l ? (u = f + u + I(!c) + (I(c) && I(!e.amPM)), M && U(void 0, -1, e.hourElement)) : u > f && (u = o === e.hourElement ? u - f - I(!e.amPM) : l, M && U(void 0, 1, e.hourElement)), e.amPM && c && (d === 1 ? u + s === 23 : Math.abs(u - s) > d) && (e.amPM.textContent = e.l10n.amPM[I(e.amPM.textContent === e.l10n.amPM[0])]), o.value = k(u);
    } }
    return h(), e;
}
function Z(a, r) { for (var e = Array.prototype.slice.call(a).filter(function (w) { return w instanceof HTMLElement; }), g = [], h = 0; h < e.length; h++) {
    var m = e[h];
    try {
        if (m.getAttribute("data-fp-omit") !== null)
            continue;
        m._flatpickr !== void 0 && (m._flatpickr.destroy(), m._flatpickr = void 0), m._flatpickr = On(m, r || {}), g.push(m._flatpickr);
    }
    catch (w) {
        console.error(w);
    }
} return g.length === 1 ? g[0] : g; }
typeof HTMLElement < "u" && typeof HTMLCollection < "u" && typeof NodeList < "u" && (HTMLCollection.prototype.flatpickr = NodeList.prototype.flatpickr = function (a) { return Z(this, a); }, HTMLElement.prototype.flatpickr = function (a) { return Z([this], a); });
var y = function (a, r) { return typeof a == "string" ? Z(window.document.querySelectorAll(a), r) : a instanceof Node ? Z([a], r) : Z(a, r); };
y.defaultConfig = {};
y.l10ns = { en: S({}, pe), default: S({}, pe) };
y.localize = function (a) { y.l10ns.default = S(S({}, y.l10ns.default), a); };
y.setDefaults = function (a) { y.defaultConfig = S(S({}, y.defaultConfig), a); };
y.parseDate = ve({});
y.formatDate = Ae({});
y.compareDates = O;
typeof jQuery < "u" && typeof jQuery.fn < "u" && (jQuery.fn.flatpickr = function (a) { return Z(this, a); });
Date.prototype.fp_incr = function (a) { return new Date(this.getFullYear(), this.getMonth(), this.getDate() + (typeof a == "string" ? parseInt(a, 10) : a)); };
typeof window < "u" && (window.flatpickr = y);
var $n = y;
export { $n as default };
