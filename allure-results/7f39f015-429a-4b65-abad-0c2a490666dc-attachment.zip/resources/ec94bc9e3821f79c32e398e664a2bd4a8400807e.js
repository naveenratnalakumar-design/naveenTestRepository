var s = class {
    _defaultMatcher;
    ngControl;
    _parentFormGroup;
    _parentForm;
    _stateChanges;
    errorState = !1;
    matcher;
    constructor(r, e, o, a, t) { this._defaultMatcher = r, this.ngControl = e, this._parentFormGroup = o, this._parentForm = a, this._stateChanges = t; }
    updateErrorState() { let r = this.errorState, e = this._parentFormGroup || this._parentForm, o = this.matcher || this._defaultMatcher, a = this.ngControl ? this.ngControl.control : null, t = o?.isErrorState(a, e) ?? !1; t !== r && (this.errorState = t, this._stateChanges.next()); }
};
export { s as a };
