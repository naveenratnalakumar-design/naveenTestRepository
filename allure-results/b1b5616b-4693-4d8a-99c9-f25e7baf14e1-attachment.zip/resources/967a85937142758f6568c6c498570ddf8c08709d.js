import "@nf-internal/chunk-66YHNWRR";
import { ComponentFactoryResolver as d, NgZone as E, ApplicationRef as b, \u0275ChangeDetectionScheduler as I, \u0275isViewDirty as v, \u0275markForRefresh as R, Injector as S, Version as F } from "@angular/core";
import { ReplaySubject as V, merge as w, Observable as j } from "rxjs";
import { switchMap as Z } from "rxjs/operators";
var D = { schedule(n, t) { let e = setTimeout(n, t); return () => clearTimeout(e); } };
function M(n) { return n.replace(/[A-Z]/g, t => `-${t.toLowerCase()}`); }
function T(n) { return !!n && n.nodeType === Node.ELEMENT_NODE; }
var l;
function C(n, t) { if (!l) {
    let e = Element.prototype;
    l = e.matches || e.matchesSelector || e.mozMatchesSelector || e.msMatchesSelector || e.oMatchesSelector || e.webkitMatchesSelector;
} return n.nodeType === Node.ELEMENT_NODE ? l.call(n, t) : !1; }
function _(n) { let t = {}; return n.forEach(({ propName: e, templateName: s, transform: r }) => { t[M(s)] = [e, r]; }), t; }
function x(n, t) { return t.get(d).resolveComponentFactory(n).inputs; }
function O(n, t) { let e = n.childNodes, s = t.map(() => []), r = -1; t.some((c, u) => c === "*" ? (r = u, !0) : !1); for (let c = 0, u = e.length; c < u; ++c) {
    let o = e[c], i = N(o, t, r);
    i !== -1 && s[i].push(o);
} return s; }
function N(n, t, e) { let s = e; return T(n) && t.some((r, c) => r !== "*" && C(n, r) ? (s = c, !0) : !1), s; }
var k = 10, h = class {
    componentFactory;
    inputMap = new Map;
    constructor(t, e) { this.componentFactory = e.get(d).resolveComponentFactory(t); for (let s of this.componentFactory.inputs)
        this.inputMap.set(s.propName, s.templateName); }
    create(t) { return new p(this.componentFactory, t, this.inputMap); }
}, p = class {
    componentFactory;
    injector;
    inputMap;
    eventEmitters = new V(1);
    events = this.eventEmitters.pipe(Z(t => w(...t)));
    componentRef = null;
    scheduledDestroyFn = null;
    initialInputValues = new Map;
    ngZone;
    elementZone;
    appRef;
    cdScheduler;
    constructor(t, e, s) { this.componentFactory = t, this.injector = e, this.inputMap = s, this.ngZone = this.injector.get(E), this.appRef = this.injector.get(b), this.cdScheduler = e.get(I), this.elementZone = typeof Zone > "u" ? null : this.ngZone.run(() => Zone.current); }
    connect(t) { this.runInZone(() => { if (this.scheduledDestroyFn !== null) {
        this.scheduledDestroyFn(), this.scheduledDestroyFn = null;
        return;
    } this.componentRef === null && this.initializeComponent(t); }); }
    disconnect() { this.runInZone(() => { this.componentRef === null || this.scheduledDestroyFn !== null || (this.scheduledDestroyFn = D.schedule(() => { this.componentRef !== null && (this.componentRef.destroy(), this.componentRef = null); }, k)); }); }
    getInputValue(t) { return this.runInZone(() => this.componentRef === null ? this.initialInputValues.get(t) : this.componentRef.instance[t]); }
    setInputValue(t, e) { if (this.componentRef === null) {
        this.initialInputValues.set(t, e);
        return;
    } this.runInZone(() => { this.componentRef.setInput(this.inputMap.get(t) ?? t, e), v(this.componentRef.hostView) && (R(this.componentRef.changeDetectorRef), this.cdScheduler.notify(6)); }); }
    initializeComponent(t) { let e = S.create({ providers: [], parent: this.injector }), s = O(t, this.componentFactory.ngContentSelectors); this.componentRef = this.componentFactory.create(e, s, t), this.initializeInputs(), this.initializeOutputs(this.componentRef), this.appRef.attachView(this.componentRef.hostView), this.componentRef.hostView.detectChanges(); }
    initializeInputs() { for (let [t, e] of this.initialInputValues)
        this.setInputValue(t, e); this.initialInputValues.clear(); }
    initializeOutputs(t) { let e = this.componentFactory.outputs.map(({ propName: s, templateName: r }) => { let c = t.instance[s]; return new j(u => { let o = c.subscribe(i => u.next({ name: r, value: i })); return () => o.unsubscribe(); }); }); this.eventEmitters.next(e); }
    runInZone(t) { return this.elementZone && Zone.current !== this.elementZone ? this.ngZone.run(t) : t(); }
}, m = class extends HTMLElement {
    ngElementEventsSubscription = null;
};
function L(n, t) { let e = x(n, t.injector), s = t.strategyFactory || new h(n, t.injector), r = _(e); class c extends m {
    injector;
    static observedAttributes = Object.keys(r);
    get ngElementStrategy() { if (!this._ngElementStrategy) {
        let o = this._ngElementStrategy = s.create(this.injector || t.injector);
        e.forEach(({ propName: i, transform: a }) => { if (!this.hasOwnProperty(i))
            return; let f = this[i]; delete this[i], o.setInputValue(i, f, a); });
    } return this._ngElementStrategy; }
    _ngElementStrategy;
    constructor(o) { super(), this.injector = o; }
    attributeChangedCallback(o, i, a, f) { let [g, y] = r[o]; this.ngElementStrategy.setInputValue(g, a, y); }
    connectedCallback() { let o = !1; this.ngElementStrategy.events && (this.subscribeToEvents(), o = !0), this.ngElementStrategy.connect(this), o || this.subscribeToEvents(); }
    disconnectedCallback() { this._ngElementStrategy && this._ngElementStrategy.disconnect(), this.ngElementEventsSubscription && (this.ngElementEventsSubscription.unsubscribe(), this.ngElementEventsSubscription = null); }
    subscribeToEvents() { this.ngElementEventsSubscription = this.ngElementStrategy.events.subscribe(o => { let i = new CustomEvent(o.name, { detail: o.value }); this.dispatchEvent(i); }); }
} return e.forEach(({ propName: u, transform: o }) => { Object.defineProperty(c.prototype, u, { get() { return this.ngElementStrategy.getInputValue(u); }, set(i) { this.ngElementStrategy.setInputValue(u, i, o); }, configurable: !0, enumerable: !0 }); }), c; }
var Y = new F("20.2.1");
export { m as NgElement, Y as VERSION, L as createCustomElement };
/*! Bundled license information:

@angular/elements/fesm2022/elements.mjs:
  (**
   * @license Angular v20.2.1
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)
*/
