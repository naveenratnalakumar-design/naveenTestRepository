import { a as o, b as t, c as n, d as e } from "@nf-internal/chunk-2LWLR5XT";
import "@nf-internal/chunk-66YHNWRR";
export { e as Mention, n as MentionBlot, o as MentionEvent, t as isMentionBlotData };
