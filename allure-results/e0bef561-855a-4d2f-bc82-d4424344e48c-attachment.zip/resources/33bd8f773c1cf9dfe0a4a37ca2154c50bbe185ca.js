import "@nf-internal/chunk-66YHNWRR";
import * as o from "@angular/core";
import { inject as l, effect as n, untracked as a } from "@angular/core";
import { MatSelect as f } from "@angular/material/select";
import { NG_SCROLLBAR as m } from "ngx-scrollbar";
var u = (() => { let e = class e {
    constructor() { this.scrollbar = l(m, { self: !0 }), this.matSelect = l(f), n(() => { let r = this.scrollbar.isVerticallyScrollable(); a(() => { if (r && this.matSelect.panelOpen) {
        let t = this.matSelect.selected;
        if (t) {
            let s = Array.isArray(t) ? t[0]._getHostElement() : t._getHostElement(), c = this.scrollbar.nativeElement.clientHeight;
            this.scrollbar.viewport.scrollYTo(s.offsetTop + s.offsetHeight - c);
        }
    } }); }); }
}; e.\u0275fac = function (t) { return new (t || e); }, e.\u0275dir = o.\u0275\u0275defineDirective({ type: e, selectors: [["ng-scrollbar", "matSelectViewport", ""]] }); let i = e; return i; })();
export { u as NgScrollbarMatSelectViewport };
