import { e } from "@nf-internal/chunk-W3SOS5TP";
import { a as m } from "@nf-internal/chunk-HOKO2ONL";
import { a as r } from "@nf-internal/chunk-4UKDDKDA";
import { b as i } from "@nf-internal/chunk-RXMLTE5A";
import * as t from "@angular/core";
import "@angular/core";
var s = (() => { class o {
    static \u0275fac = function (n) { return new (n || o); };
    static \u0275mod = t.\u0275\u0275defineNgModule({ type: o });
    static \u0275inj = t.\u0275\u0275defineInjector({ imports: [r, i, m, e] });
} return o; })();
export { s as a };
