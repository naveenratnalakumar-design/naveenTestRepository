import { a, b, c, d, e, f, g, h, i, j, k } from "@nf-internal/chunk-NPG5RFMM";
import "@nf-internal/chunk-66YHNWRR";
export { e as BasePortalOutlet, g as CdkPortal, i as CdkPortalOutlet, b as ComponentPortal, d as DomPortal, f as DomPortalOutlet, a as Portal, j as PortalHostDirective, k as PortalModule, c as TemplatePortal, h as TemplatePortalDirective };
