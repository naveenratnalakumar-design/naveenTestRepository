import { InjectionToken as o } from "@angular/core";
var _ = new o("MAT_INPUT_VALUE_ACCESSOR");
export { _ as a };
