var t;
function n() {
    if (t == null) {
        let o = typeof document < "u" ? document.head : null;
        t = !!(o && (o.createShadowRoot || o.attachShadow));
    }
    return t;
}
function d(o) {
    if (n()) {
        let e = o.getRootNode ? o.getRootNode() : null;
        if (typeof ShadowRoot < "u" && ShadowRoot && e instanceof ShadowRoot)
            return e;
    }
    return null;
}
function a() {
    let o = typeof document < "u" && document ? document.activeElement : null;
    for (; o && o.shadowRoot;) {
        let e = o.shadowRoot.activeElement;
        if (e === o)
            break;
        o = e;
    }
    return o;
}
function u(o) { return o.composedPath ? o.composedPath()[0] : o.target; }
export { n as a, d as b, a as c, u as d };
