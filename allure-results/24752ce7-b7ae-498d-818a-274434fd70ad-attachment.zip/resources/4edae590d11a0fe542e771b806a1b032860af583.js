import { a as p, b as A, c as m, d as I, f as E } from "@nf-internal/chunk-QDN2SA6S";
import { a as y } from "@nf-internal/chunk-66YHNWRR";
import { \u0275DomAdapter as P, \u0275setRootDomAdapter as N, \u0275parseCookieValue as B, \u0275getDOM as O, DOCUMENT as d, \u0275PLATFORM_BROWSER_ID as V, XhrFactory as j, CommonModule as x } from "@angular/common";
import * as s from "@angular/core";
import { \u0275global as l, \u0275RuntimeError as U, \u0275internalCreateApplication as S, PLATFORM_ID as K, PLATFORM_INITIALIZER as H, createPlatformFactory as W, platformCore as G, InjectionToken as fe, \u0275TESTABILITY_GETTER as v, \u0275TESTABILITY as Y, Testability as R, NgZone as h, TestabilityRegistry as b, \u0275INJECTOR_SCOPE as z, ErrorHandler as _, RendererFactory2 as J, ApplicationModule as Z, \u0275setDocument as X } from "@angular/core";
var g = class t extends P {
    supportsDOMEvents = !0;
    static makeCurrent() { N(new t); }
    onAndCancel(o, e, n, r) { return o.addEventListener(e, n, r), () => { o.removeEventListener(e, n, r); }; }
    dispatchEvent(o, e) { o.dispatchEvent(e); }
    remove(o) { o.remove(); }
    createElement(o, e) { return e = e || this.getDefaultDocument(), e.createElement(o); }
    createHtmlDocument() { return document.implementation.createHTMLDocument("fakeTitle"); }
    getDefaultDocument() { return document; }
    isElementNode(o) { return o.nodeType === Node.ELEMENT_NODE; }
    isShadowRoot(o) { return o instanceof DocumentFragment; }
    getGlobalEventTarget(o, e) { return e === "window" ? window : e === "document" ? o : e === "body" ? o.body : null; }
    getBaseHref(o) { let e = q(); return e == null ? null : Q(e); }
    resetBaseElement() { c = null; }
    getUserAgent() { return window.navigator.userAgent; }
    getCookie(o) { return B(document.cookie, o); }
}, c = null;
function q() { return c = c || document.head.querySelector("base"), c ? c.getAttribute("href") : null; }
function Q(t) { return new URL(t, document.baseURI).pathname; }
var D = class {
    addToWindow(o) { l.getAngularTestability = (n, r = !0) => { let i = o.findTestabilityInTree(n, r); if (i == null)
        throw new U(5103, !1); return i; }, l.getAllAngularTestabilities = () => o.getAllTestabilities(), l.getAllAngularRootElements = () => o.getAllRootElements(); let e = n => { let r = l.getAllAngularTestabilities(), i = r.length, a = function () { i--, i == 0 && n(); }; r.forEach(u => { u.whenStable(a); }); }; l.frameworkStabilizers || (l.frameworkStabilizers = []), l.frameworkStabilizers.push(e); }
    findTestabilityInTree(o, e, n) { if (e == null)
        return null; let r = o.getTestability(e); return r ?? (n ? O().isShadowRoot(e) ? this.findTestabilityInTree(o, e.host, !0) : this.findTestabilityInTree(o, e.parentElement, !0) : null); }
}, $ = (() => { class t {
    build() { return new XMLHttpRequest; }
    static \u0275fac = function (n) { return new (n || t); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac });
} return t; })(), ee = (() => { class t extends m {
    constructor(e) { super(e); }
    supports(e) { return !0; }
    addEventListener(e, n, r, i) { return e.addEventListener(n, r, i), () => this.removeEventListener(e, n, r, i); }
    removeEventListener(e, n, r, i) { return e.removeEventListener(n, r, i); }
    static \u0275fac = function (n) { return new (n || t)(s.\u0275\u0275inject(d)); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac });
} return t; })(), w = ["alt", "control", "meta", "shift"], te = { "\b": "Backspace", "	": "Tab", "\x7F": "Delete", "\x1B": "Escape", Del: "Delete", Esc: "Escape", Left: "ArrowLeft", Right: "ArrowRight", Up: "ArrowUp", Down: "ArrowDown", Menu: "ContextMenu", Scroll: "ScrollLock", Win: "OS" }, ne = { alt: t => t.altKey, control: t => t.ctrlKey, meta: t => t.metaKey, shift: t => t.shiftKey }, re = (() => { class t extends m {
    constructor(e) { super(e); }
    supports(e) { return t.parseEventName(e) != null; }
    addEventListener(e, n, r, i) { let a = t.parseEventName(n), u = t.eventCallback(a.fullKey, r, this.manager.getZone()); return this.manager.getZone().runOutsideAngular(() => O().onAndCancel(e, a.domEventName, u, i)); }
    static parseEventName(e) { let n = e.toLowerCase().split("."), r = n.shift(); if (n.length === 0 || !(r === "keydown" || r === "keyup"))
        return null; let i = t._normalizeKey(n.pop()), a = "", u = n.indexOf("code"); if (u > -1 && (n.splice(u, 1), a = "code."), w.forEach(T => { let M = n.indexOf(T); M > -1 && (n.splice(M, 1), a += T + "."); }), a += i, n.length != 0 || i.length === 0)
        return null; let f = {}; return f.domEventName = r, f.fullKey = a, f; }
    static matchEventFullKeyCode(e, n) { let r = te[e.key] || e.key, i = ""; return n.indexOf("code.") > -1 && (r = e.code, i = "code."), r == null || !r ? !1 : (r = r.toLowerCase(), r === " " ? r = "space" : r === "." && (r = "dot"), w.forEach(a => { if (a !== r) {
        let u = ne[a];
        u(e) && (i += a + ".");
    } }), i += r, i === n); }
    static eventCallback(e, n, r) { return i => { t.matchEventFullKeyCode(i, e) && r.runGuarded(() => n(i)); }; }
    static _normalizeKey(e) { return e === "esc" ? "escape" : e; }
    static \u0275fac = function (n) { return new (n || t)(s.\u0275\u0275inject(d)); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac });
} return t; })();
function ve(t, o) { let e = y({ rootComponent: t }, C(o)); return S(e); }
function Re(t) { return S(C(t)); }
function C(t) { return { appProviders: [...F, ...t?.providers ?? []], platformProviders: L }; }
function ge() { return [...k]; }
function oe() { g.makeCurrent(); }
function ie() { return new _; }
function ae() { return X(document), document; }
var L = [{ provide: K, useValue: V }, { provide: H, useValue: oe, multi: !0 }, { provide: d, useFactory: ae }], De = W(G, "browser", L);
var k = [{ provide: v, useClass: D }, { provide: Y, useClass: R, deps: [h, b, v] }, { provide: R, useClass: R, deps: [h, b, v] }], F = [{ provide: z, useValue: "root" }, { provide: _, useFactory: ie }, { provide: p, useClass: ee, multi: !0, deps: [d] }, { provide: p, useClass: re, multi: !0, deps: [d] }, E, I, A, { provide: J, useExisting: E }, { provide: j, useClass: $ }, []], Te = (() => { class t {
    constructor() { }
    static \u0275fac = function (n) { return new (n || t); };
    static \u0275mod = s.\u0275\u0275defineNgModule({ type: t });
    static \u0275inj = s.\u0275\u0275defineInjector({ providers: [...F, ...k], imports: [x, Z] });
} return t; })();
export { g as a, D as b, ee as c, re as d, ve as e, Re as f, ge as g, De as h, Te as i };
/*! Bundled license information:

@angular/platform-browser/fesm2022/browser.mjs:
  (**
   * @license Angular v20.2.1
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)
*/
