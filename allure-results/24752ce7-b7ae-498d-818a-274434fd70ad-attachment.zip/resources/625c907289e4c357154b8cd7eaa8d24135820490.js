import "@nf-internal/chunk-66YHNWRR";
import * as t from "@angular/core";
import { InjectionToken as d, makeEnvironmentProviders as s } from "@angular/core";
var a = { toolbar: [["bold", "italic", "underline", "strike"], ["blockquote", "code-block"], [{ header: 1 }, { header: 2 }], [{ list: "ordered" }, { list: "bullet" }], [{ script: "sub" }, { script: "super" }], [{ indent: "-1" }, { indent: "+1" }], [{ direction: "rtl" }], [{ size: ["small", !1, "large", "huge"] }], [{ header: [1, 2, 3, 4, 5, 6, !1] }], [{ color: [] }, { background: [] }], [{ font: [] }], [{ align: [] }], ["clean"], ["link", "image", "video"], ["table"]] }, r = new d("config", { providedIn: "root", factory: () => ({ modules: a }) }), u = (() => { let e = class e {
    static forRoot(i) { return { ngModule: e, providers: [{ provide: r, useValue: i }] }; }
}; e.\u0275fac = function (n) { return new (n || e); }, e.\u0275mod = t.\u0275\u0275defineNgModule({ type: e }), e.\u0275inj = t.\u0275\u0275defineInjector({}); let o = e; return o; })(), f = o => s([{ provide: r, useValue: o }]);
export { r as QUILL_CONFIG_TOKEN, u as QuillConfigModule, a as defaultModules, f as provideQuillConfig };
