function N(e) { return e + .5 | 0; }
var P = (e, t, n) => Math.max(Math.min(e, n), t);
function L(e) { return P(N(e * 2.55), 0, 255); }
function T(e) { return P(N(e * 255), 0, 255); }
function w(e) { return P(N(e / 2.55) / 100, 0, 1); }
function ye(e) { return P(N(e * 100), 0, 100); }
var M = { 0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, A: 10, B: 11, C: 12, D: 13, E: 14, F: 15, a: 10, b: 11, c: 12, d: 13, e: 14, f: 15 }, oe = [..."0123456789ABCDEF"], ot = e => oe[e & 15], it = e => oe[(e & 240) >> 4] + oe[e & 15], H = e => (e & 240) >> 4 === (e & 15), st = e => H(e.r) && H(e.g) && H(e.b) && H(e.a);
function at(e) { var t = e.length, n; return e[0] === "#" && (t === 4 || t === 5 ? n = { r: 255 & M[e[1]] * 17, g: 255 & M[e[2]] * 17, b: 255 & M[e[3]] * 17, a: t === 5 ? M[e[4]] * 17 : 255 } : (t === 7 || t === 9) && (n = { r: M[e[1]] << 4 | M[e[2]], g: M[e[3]] << 4 | M[e[4]], b: M[e[5]] << 4 | M[e[6]], a: t === 9 ? M[e[7]] << 4 | M[e[8]] : 255 })), n; }
var ct = (e, t) => e < 255 ? t(e) : "";
function ft(e) { var t = st(e) ? ot : it; return e ? "#" + t(e.r) + t(e.g) + t(e.b) + ct(e.a, t) : void 0; }
var lt = /^(hsla?|hwb|hsv)\(\s*([-+.e\d]+)(?:deg)?[\s,]+([-+.e\d]+)%[\s,]+([-+.e\d]+)%(?:[\s,]+([-+.e\d]+)(%)?)?\s*\)$/;
function Se(e, t, n) { let r = t * Math.min(n, 1 - n), o = (i, s = (i + e / 30) % 12) => n - r * Math.max(Math.min(s - 3, 9 - s, 1), -1); return [o(0), o(8), o(4)]; }
function ut(e, t, n) { let r = (o, i = (o + e / 60) % 6) => n - n * t * Math.max(Math.min(i, 4 - i, 1), 0); return [r(5), r(3), r(1)]; }
function dt(e, t, n) { let r = Se(e, 1, .5), o; for (t + n > 1 && (o = 1 / (t + n), t *= o, n *= o), o = 0; o < 3; o++)
    r[o] *= 1 - t - n, r[o] += t; return r; }
function ht(e, t, n, r, o) { return e === o ? (t - n) / r + (t < n ? 6 : 0) : t === o ? (n - e) / r + 2 : (e - t) / r + 4; }
function ie(e) { let n = e.r / 255, r = e.g / 255, o = e.b / 255, i = Math.max(n, r, o), s = Math.min(n, r, o), a = (i + s) / 2, c, f, l; return i !== s && (l = i - s, f = a > .5 ? l / (2 - i - s) : l / (i + s), c = ht(n, r, o, l, i), c = c * 60 + .5), [c | 0, f || 0, a]; }
function se(e, t, n, r) { return (Array.isArray(t) ? e(t[0], t[1], t[2]) : e(t, n, r)).map(T); }
function ae(e, t, n) { return se(Se, e, t, n); }
function gt(e, t, n) { return se(dt, e, t, n); }
function bt(e, t, n) { return se(ut, e, t, n); }
function we(e) { return (e % 360 + 360) % 360; }
function mt(e) { let t = lt.exec(e), n = 255, r; if (!t)
    return; t[5] !== r && (n = t[6] ? L(+t[5]) : T(+t[5])); let o = we(+t[2]), i = +t[3] / 100, s = +t[4] / 100; return t[1] === "hwb" ? r = gt(o, i, s) : t[1] === "hsv" ? r = bt(o, i, s) : r = ae(o, i, s), { r: r[0], g: r[1], b: r[2], a: n }; }
function pt(e, t) { var n = ie(e); n[0] = we(n[0] + t), n = ae(n), e.r = n[0], e.g = n[1], e.b = n[2]; }
function yt(e) { if (!e)
    return; let t = ie(e), n = t[0], r = ye(t[1]), o = ye(t[2]); return e.a < 255 ? `hsla(${n}, ${r}%, ${o}%, ${w(e.a)})` : `hsl(${n}, ${r}%, ${o}%)`; }
var _e = { x: "dark", Z: "light", Y: "re", X: "blu", W: "gr", V: "medium", U: "slate", A: "ee", T: "ol", S: "or", B: "ra", C: "lateg", D: "ights", R: "in", Q: "turquois", E: "hi", P: "ro", O: "al", N: "le", M: "de", L: "yello", F: "en", K: "ch", G: "arks", H: "ea", I: "ightg", J: "wh" }, Me = { OiceXe: "f0f8ff", antiquewEte: "faebd7", aqua: "ffff", aquamarRe: "7fffd4", azuY: "f0ffff", beige: "f5f5dc", bisque: "ffe4c4", black: "0", blanKedOmond: "ffebcd", Xe: "ff", XeviTet: "8a2be2", bPwn: "a52a2a", burlywood: "deb887", caMtXe: "5f9ea0", KartYuse: "7fff00", KocTate: "d2691e", cSO: "ff7f50", cSnflowerXe: "6495ed", cSnsilk: "fff8dc", crimson: "dc143c", cyan: "ffff", xXe: "8b", xcyan: "8b8b", xgTMnPd: "b8860b", xWay: "a9a9a9", xgYF: "6400", xgYy: "a9a9a9", xkhaki: "bdb76b", xmagFta: "8b008b", xTivegYF: "556b2f", xSange: "ff8c00", xScEd: "9932cc", xYd: "8b0000", xsOmon: "e9967a", xsHgYF: "8fbc8f", xUXe: "483d8b", xUWay: "2f4f4f", xUgYy: "2f4f4f", xQe: "ced1", xviTet: "9400d3", dAppRk: "ff1493", dApskyXe: "bfff", dimWay: "696969", dimgYy: "696969", dodgerXe: "1e90ff", fiYbrick: "b22222", flSOwEte: "fffaf0", foYstWAn: "228b22", fuKsia: "ff00ff", gaRsbSo: "dcdcdc", ghostwEte: "f8f8ff", gTd: "ffd700", gTMnPd: "daa520", Way: "808080", gYF: "8000", gYFLw: "adff2f", gYy: "808080", honeyMw: "f0fff0", hotpRk: "ff69b4", RdianYd: "cd5c5c", Rdigo: "4b0082", ivSy: "fffff0", khaki: "f0e68c", lavFMr: "e6e6fa", lavFMrXsh: "fff0f5", lawngYF: "7cfc00", NmoncEffon: "fffacd", ZXe: "add8e6", ZcSO: "f08080", Zcyan: "e0ffff", ZgTMnPdLw: "fafad2", ZWay: "d3d3d3", ZgYF: "90ee90", ZgYy: "d3d3d3", ZpRk: "ffb6c1", ZsOmon: "ffa07a", ZsHgYF: "20b2aa", ZskyXe: "87cefa", ZUWay: "778899", ZUgYy: "778899", ZstAlXe: "b0c4de", ZLw: "ffffe0", lime: "ff00", limegYF: "32cd32", lRF: "faf0e6", magFta: "ff00ff", maPon: "800000", VaquamarRe: "66cdaa", VXe: "cd", VScEd: "ba55d3", VpurpN: "9370db", VsHgYF: "3cb371", VUXe: "7b68ee", VsprRggYF: "fa9a", VQe: "48d1cc", VviTetYd: "c71585", midnightXe: "191970", mRtcYam: "f5fffa", mistyPse: "ffe4e1", moccasR: "ffe4b5", navajowEte: "ffdead", navy: "80", Tdlace: "fdf5e6", Tive: "808000", TivedBb: "6b8e23", Sange: "ffa500", SangeYd: "ff4500", ScEd: "da70d6", pOegTMnPd: "eee8aa", pOegYF: "98fb98", pOeQe: "afeeee", pOeviTetYd: "db7093", papayawEp: "ffefd5", pHKpuff: "ffdab9", peru: "cd853f", pRk: "ffc0cb", plum: "dda0dd", powMrXe: "b0e0e6", purpN: "800080", YbeccapurpN: "663399", Yd: "ff0000", Psybrown: "bc8f8f", PyOXe: "4169e1", saddNbPwn: "8b4513", sOmon: "fa8072", sandybPwn: "f4a460", sHgYF: "2e8b57", sHshell: "fff5ee", siFna: "a0522d", silver: "c0c0c0", skyXe: "87ceeb", UXe: "6a5acd", UWay: "708090", UgYy: "708090", snow: "fffafa", sprRggYF: "ff7f", stAlXe: "4682b4", tan: "d2b48c", teO: "8080", tEstN: "d8bfd8", tomato: "ff6347", Qe: "40e0d0", viTet: "ee82ee", JHt: "f5deb3", wEte: "ffffff", wEtesmoke: "f5f5f5", Lw: "ffff00", LwgYF: "9acd32" };
function _t() { let e = {}, t = Object.keys(Me), n = Object.keys(_e), r, o, i, s, a; for (r = 0; r < t.length; r++) {
    for (s = a = t[r], o = 0; o < n.length; o++)
        i = n[o], a = a.replace(i, _e[i]);
    i = parseInt(Me[s], 16), e[a] = [i >> 16 & 255, i >> 8 & 255, i & 255];
} return e; }
var z;
function Mt(e) { z || (z = _t(), z.transparent = [0, 0, 0, 0]); let t = z[e.toLowerCase()]; return t && { r: t[0], g: t[1], b: t[2], a: t.length === 4 ? t[3] : 255 }; }
var xt = /^rgba?\(\s*([-+.\d]+)(%)?[\s,]+([-+.e\d]+)(%)?[\s,]+([-+.e\d]+)(%)?(?:[\s,/]+([-+.e\d]+)(%)?)?\s*\)$/;
function St(e) { let t = xt.exec(e), n = 255, r, o, i; if (t) {
    if (t[7] !== r) {
        let s = +t[7];
        n = t[8] ? L(s) : P(s * 255, 0, 255);
    }
    return r = +t[1], o = +t[3], i = +t[5], r = 255 & (t[2] ? L(r) : P(r, 0, 255)), o = 255 & (t[4] ? L(o) : P(o, 0, 255)), i = 255 & (t[6] ? L(i) : P(i, 0, 255)), { r, g: o, b: i, a: n };
} }
function wt(e) { return e && (e.a < 255 ? `rgba(${e.r}, ${e.g}, ${e.b}, ${w(e.a)})` : `rgb(${e.r}, ${e.g}, ${e.b})`); }
var re = e => e <= .0031308 ? e * 12.92 : Math.pow(e, 1 / 2.4) * 1.055 - .055, A = e => e <= .04045 ? e / 12.92 : Math.pow((e + .055) / 1.055, 2.4);
function Ot(e, t, n) { let r = A(w(e.r)), o = A(w(e.g)), i = A(w(e.b)); return { r: T(re(r + n * (A(w(t.r)) - r))), g: T(re(o + n * (A(w(t.g)) - o))), b: T(re(i + n * (A(w(t.b)) - i))), a: e.a + n * (t.a - e.a) }; }
function $(e, t, n) { if (e) {
    let r = ie(e);
    r[t] = Math.max(0, Math.min(r[t] + r[t] * n, t === 0 ? 360 : 1)), r = ae(r), e.r = r[0], e.g = r[1], e.b = r[2];
} }
function Oe(e, t) { return e && Object.assign(t || {}, e); }
function xe(e) { var t = { r: 0, g: 0, b: 0, a: 255 }; return Array.isArray(e) ? e.length >= 3 && (t = { r: e[0], g: e[1], b: e[2], a: 255 }, e.length > 3 && (t.a = T(e[3]))) : (t = Oe(e, { r: 0, g: 0, b: 0, a: 1 }), t.a = T(t.a)), t; }
function Pt(e) { return e.charAt(0) === "r" ? St(e) : mt(e); }
var D = class e {
    constructor(t) { if (t instanceof e)
        return t; let n = typeof t, r; n === "object" ? r = xe(t) : n === "string" && (r = at(t) || Mt(t) || Pt(t)), this._rgb = r, this._valid = !!r; }
    get valid() { return this._valid; }
    get rgb() { var t = Oe(this._rgb); return t && (t.a = w(t.a)), t; }
    set rgb(t) { this._rgb = xe(t); }
    rgbString() { return this._valid ? wt(this._rgb) : void 0; }
    hexString() { return this._valid ? ft(this._rgb) : void 0; }
    hslString() { return this._valid ? yt(this._rgb) : void 0; }
    mix(t, n) { if (t) {
        let r = this.rgb, o = t.rgb, i, s = n === i ? .5 : n, a = 2 * s - 1, c = r.a - o.a, f = ((a * c === -1 ? a : (a + c) / (1 + a * c)) + 1) / 2;
        i = 1 - f, r.r = 255 & f * r.r + i * o.r + .5, r.g = 255 & f * r.g + i * o.g + .5, r.b = 255 & f * r.b + i * o.b + .5, r.a = s * r.a + (1 - s) * o.a, this.rgb = r;
    } return this; }
    interpolate(t, n) { return t && (this._rgb = Ot(this._rgb, t._rgb, n)), this; }
    clone() { return new e(this.rgb); }
    alpha(t) { return this._rgb.a = T(t), this; }
    clearer(t) { let n = this._rgb; return n.a *= 1 - t, this; }
    greyscale() { let t = this._rgb, n = N(t.r * .3 + t.g * .59 + t.b * .11); return t.r = t.g = t.b = n, this; }
    opaquer(t) { let n = this._rgb; return n.a *= 1 + t, this; }
    negate() { let t = this._rgb; return t.r = 255 - t.r, t.g = 255 - t.g, t.b = 255 - t.b, this; }
    lighten(t) { return $(this._rgb, 2, t), this; }
    darken(t) { return $(this._rgb, 2, -t), this; }
    saturate(t) { return $(this._rgb, 1, t), this; }
    desaturate(t) { return $(this._rgb, 1, -t), this; }
    rotate(t) { return pt(this._rgb, t), this; }
};
function zn() { }
var $n = (() => { let e = 0; return () => e++; })();
function j(e) { return e == null; }
function x(e) { if (Array.isArray && Array.isArray(e))
    return !0; let t = Object.prototype.toString.call(e); return t.slice(0, 7) === "[object" && t.slice(-6) === "Array]"; }
function _(e) { return e !== null && Object.prototype.toString.call(e) === "[object Object]"; }
function De(e) { return (typeof e == "number" || e instanceof Number) && isFinite(+e); }
function qn(e, t) { return De(e) ? e : t; }
function C(e, t) { return typeof e > "u" ? t : e; }
var Xn = (e, t) => typeof e == "string" && e.endsWith("%") ? parseFloat(e) / 100 : +e / t, Tt = (e, t) => typeof e == "string" && e.endsWith("%") ? parseFloat(e) / 100 * t : +e;
function Kn(e, t, n) { if (e && typeof e.call == "function")
    return e.apply(n, t); }
function Un(e, t, n, r) { let o, i, s; if (x(e))
    if (i = e.length, r)
        for (o = i - 1; o >= 0; o--)
            t.call(n, e[o], o);
    else
        for (o = 0; o < i; o++)
            t.call(n, e[o], o);
else if (_(e))
    for (s = Object.keys(e), i = s.length, o = 0; o < i; o++)
        t.call(n, e[s[o]], s[o]); }
function Zn(e, t) { let n, r, o, i; if (!e || !t || e.length !== t.length)
    return !1; for (n = 0, r = e.length; n < r; ++n)
    if (o = e[n], i = t[n], o.datasetIndex !== i.datasetIndex || o.index !== i.index)
        return !1; return !0; }
function Q(e) { if (x(e))
    return e.map(Q); if (_(e)) {
    let t = Object.create(null), n = Object.keys(e), r = n.length, o = 0;
    for (; o < r; ++o)
        t[n[o]] = Q(e[n[o]]);
    return t;
} return e; }
function Ne(e) { return ["__proto__", "prototype", "constructor"].indexOf(e) === -1; }
function kt(e, t, n, r) { if (!Ne(e))
    return; let o = t[e], i = n[e]; _(o) && _(i) ? G(o, i, r) : t[e] = Q(i); }
function G(e, t, n) { let r = x(t) ? t : [t], o = r.length; if (!_(e))
    return e; n = n || {}; let i = n.merger || kt, s; for (let a = 0; a < o; ++a) {
    if (s = r[a], !_(s))
        continue;
    let c = Object.keys(s);
    for (let f = 0, l = c.length; f < l; ++f)
        i(c[f], e, s, n);
} return e; }
function Rt(e, t) { return G(e, t, { merger: Ct }); }
function Ct(e, t, n) { if (!Ne(e))
    return; let r = t[e], o = n[e]; _(r) && _(o) ? Rt(r, o) : Object.prototype.hasOwnProperty.call(t, e) || (t[e] = Q(o)); }
function Qn(e, t, n, r) { t !== void 0 && console.warn(e + ': "' + n + '" is deprecated. Please use "' + r + '" instead'); }
var Pe = { "": e => e, x: e => e.x, y: e => e.y };
function Ft(e) { let t = e.split("."), n = [], r = ""; for (let o of t)
    r += o, r.endsWith("\\") ? r = r.slice(0, -1) + "." : (n.push(r), r = ""); return n; }
function It(e) { let t = Ft(e); return n => { for (let r of t) {
    if (r === "")
        break;
    n = n && n[r];
} return n; }; }
function Ye(e, t) { return (Pe[t] || (Pe[t] = It(t)))(e); }
function He(e) { return e.charAt(0).toUpperCase() + e.slice(1); }
var Gn = e => typeof e < "u", V = e => typeof e == "function", Vn = (e, t) => { if (e.size !== t.size)
    return !1; for (let n of e)
    if (!t.has(n))
        return !1; return !0; };
function Jn(e) { return e.type === "mouseup" || e.type === "click" || e.type === "contextmenu"; }
var y = Math.PI, S = 2 * y, vt = S + y, J = Number.POSITIVE_INFINITY, At = y / 180, O = y / 2, R = y / 4, Te = y * 2 / 3, ue = Math.log10, ke = Math.sign;
function ze(e, t, n) { return Math.abs(e - t) < n; }
function er(e) { let t = Math.round(e); e = ze(e, t, e / 1e3) ? t : e; let n = Math.pow(10, Math.floor(ue(e))), r = e / n; return (r <= 1 ? 1 : r <= 2 ? 2 : r <= 5 ? 5 : 10) * n; }
function tr(e) { let t = [], n = Math.sqrt(e), r; for (r = 1; r < n; r++)
    e % r === 0 && (t.push(r), t.push(e / r)); return n === (n | 0) && t.push(n), t.sort((o, i) => o - i).pop(), t; }
function Bt(e) { return typeof e == "symbol" || typeof e == "object" && e !== null && !(Symbol.toPrimitive in e || "toString" in e || "valueOf" in e); }
function nr(e) { return !Bt(e) && !isNaN(parseFloat(e)) && isFinite(e); }
function rr(e, t) { let n = Math.round(e); return n - t <= e && n + t >= e; }
function or(e, t, n) { let r, o, i; for (r = 0, o = e.length; r < o; r++)
    i = e[r][n], isNaN(i) || (t.min = Math.min(t.min, i), t.max = Math.max(t.max, i)); }
function ir(e) { return e * (y / 180); }
function sr(e) { return e * (180 / y); }
function ar(e) { if (!De(e))
    return; let t = 1, n = 0; for (; Math.round(e * t) / t !== e;)
    t *= 10, n++; return n; }
function cr(e, t) { let n = t.x - e.x, r = t.y - e.y, o = Math.sqrt(n * n + r * r), i = Math.atan2(r, n); return i < -.5 * y && (i += S), { angle: i, distance: o }; }
function Re(e, t) { return Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2)); }
function jt(e, t) { return (e - t + vt) % S - y; }
function k(e) { return (e % S + S) % S; }
function Et(e, t, n, r) { let o = k(e), i = k(t), s = k(n), a = k(i - o), c = k(s - o), f = k(o - i), l = k(o - s); return o === i || o === s || r && i === s || a > c && f < l; }
function de(e, t, n) { return Math.max(t, Math.min(n, e)); }
function fr(e) { return de(e, -32768, 32767); }
function Wt(e, t, n, r = 1e-6) { return e >= Math.min(t, n) - r && e <= Math.max(t, n) + r; }
function $e(e, t, n) { n = n || (s => e[s] < t); let r = e.length - 1, o = 0, i; for (; r - o > 1;)
    i = o + r >> 1, n(i) ? o = i : r = i; return { lo: o, hi: r }; }
var q = (e, t, n, r) => $e(e, n, r ? o => { let i = e[o][t]; return i < n || i === n && e[o + 1][t] === n; } : o => e[o][t] < n), lr = (e, t, n) => $e(e, n, r => e[r][t] >= n);
function ur(e, t, n) { let r = 0, o = e.length; for (; r < o && e[r] < t;)
    r++; for (; o > r && e[o - 1] > n;)
    o--; return r > 0 || o < e.length ? e.slice(r, o) : e; }
var qe = ["push", "pop", "shift", "splice", "unshift"];
function dr(e, t) { if (e._chartjs) {
    e._chartjs.listeners.push(t);
    return;
} Object.defineProperty(e, "_chartjs", { configurable: !0, enumerable: !1, value: { listeners: [t] } }), qe.forEach(n => { let r = "_onData" + He(n), o = e[n]; Object.defineProperty(e, n, { configurable: !0, enumerable: !1, value(...i) { let s = o.apply(this, i); return e._chartjs.listeners.forEach(a => { typeof a[r] == "function" && a[r](...i); }), s; } }); }); }
function hr(e, t) { let n = e._chartjs; if (!n)
    return; let r = n.listeners, o = r.indexOf(t); o !== -1 && r.splice(o, 1), !(r.length > 0) && (qe.forEach(i => { delete e[i]; }), delete e._chartjs); }
function gr(e) { let t = new Set(e); return t.size === e.length ? e : Array.from(t); }
function br(e, t, n) { return t + " " + e + "px " + n; }
var Lt = (function () { return typeof window > "u" ? function (e) { return e(); } : window.requestAnimationFrame; })();
function mr(e, t) { let n = [], r = !1; return function (...o) { n = o, r || (r = !0, Lt.call(window, () => { r = !1, e.apply(t, n); })); }; }
function pr(e, t) { let n; return function (...r) { return t ? (clearTimeout(n), n = setTimeout(e, t, r)) : e.apply(this, r), t; }; }
var yr = e => e === "start" ? "left" : e === "end" ? "right" : "center", _r = (e, t, n) => e === "start" ? t : e === "end" ? n : (t + n) / 2, Mr = (e, t, n, r) => e === (r ? "left" : "right") ? n : e === "center" ? (t + n) / 2 : t;
function xr(e, t, n) { let r = t.length, o = 0, i = r; if (e._sorted) {
    let { iScale: s, vScale: a, _parsed: c } = e, f = e.dataset && e.dataset.options ? e.dataset.options.spanGaps : null, l = s.axis, { min: d, max: g, minDefined: b, maxDefined: m } = s.getUserBounds();
    if (b) {
        if (o = Math.min(q(c, l, d).lo, n ? r : q(t, l, s.getPixelForValue(d)).lo), f) {
            let h = c.slice(0, o + 1).reverse().findIndex(u => !j(u[a.axis]));
            o -= Math.max(0, h);
        }
        o = de(o, 0, r - 1);
    }
    if (m) {
        let h = Math.max(q(c, s.axis, g, !0).hi + 1, n ? 0 : q(t, l, s.getPixelForValue(g), !0).hi + 1);
        if (f) {
            let u = c.slice(h - 1).findIndex(p => !j(p[a.axis]));
            h += Math.max(0, u);
        }
        i = de(h, o, r) - o;
    }
    else
        i = r - o;
} return { start: o, count: i }; }
function Sr(e) { let { xScale: t, yScale: n, _scaleRanges: r } = e, o = { xmin: t.min, xmax: t.max, ymin: n.min, ymax: n.max }; if (!r)
    return e._scaleRanges = o, !0; let i = r.xmin !== t.min || r.xmax !== t.max || r.ymin !== n.min || r.ymax !== n.max; return Object.assign(r, o), i; }
var X = e => e === 0 || e === 1, Ce = (e, t, n) => -(Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * S / n)), Fe = (e, t, n) => Math.pow(2, -10 * e) * Math.sin((e - t) * S / n) + 1, ce = { linear: e => e, easeInQuad: e => e * e, easeOutQuad: e => -e * (e - 2), easeInOutQuad: e => (e /= .5) < 1 ? .5 * e * e : -.5 * (--e * (e - 2) - 1), easeInCubic: e => e * e * e, easeOutCubic: e => (e -= 1) * e * e + 1, easeInOutCubic: e => (e /= .5) < 1 ? .5 * e * e * e : .5 * ((e -= 2) * e * e + 2), easeInQuart: e => e * e * e * e, easeOutQuart: e => -((e -= 1) * e * e * e - 1), easeInOutQuart: e => (e /= .5) < 1 ? .5 * e * e * e * e : -.5 * ((e -= 2) * e * e * e - 2), easeInQuint: e => e * e * e * e * e, easeOutQuint: e => (e -= 1) * e * e * e * e + 1, easeInOutQuint: e => (e /= .5) < 1 ? .5 * e * e * e * e * e : .5 * ((e -= 2) * e * e * e * e + 2), easeInSine: e => -Math.cos(e * O) + 1, easeOutSine: e => Math.sin(e * O), easeInOutSine: e => -.5 * (Math.cos(y * e) - 1), easeInExpo: e => e === 0 ? 0 : Math.pow(2, 10 * (e - 1)), easeOutExpo: e => e === 1 ? 1 : -Math.pow(2, -10 * e) + 1, easeInOutExpo: e => X(e) ? e : e < .5 ? .5 * Math.pow(2, 10 * (e * 2 - 1)) : .5 * (-Math.pow(2, -10 * (e * 2 - 1)) + 2), easeInCirc: e => e >= 1 ? e : -(Math.sqrt(1 - e * e) - 1), easeOutCirc: e => Math.sqrt(1 - (e -= 1) * e), easeInOutCirc: e => (e /= .5) < 1 ? -.5 * (Math.sqrt(1 - e * e) - 1) : .5 * (Math.sqrt(1 - (e -= 2) * e) + 1), easeInElastic: e => X(e) ? e : Ce(e, .075, .3), easeOutElastic: e => X(e) ? e : Fe(e, .075, .3), easeInOutElastic(e) { return X(e) ? e : e < .5 ? .5 * Ce(e * 2, .1125, .45) : .5 + .5 * Fe(e * 2 - 1, .1125, .45); }, easeInBack(e) { return e * e * ((1.70158 + 1) * e - 1.70158); }, easeOutBack(e) { return (e -= 1) * e * ((1.70158 + 1) * e + 1.70158) + 1; }, easeInOutBack(e) { let t = 1.70158; return (e /= .5) < 1 ? .5 * (e * e * (((t *= 1.525) + 1) * e - t)) : .5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2); }, easeInBounce: e => 1 - ce.easeOutBounce(1 - e), easeOutBounce(e) { return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375; }, easeInOutBounce: e => e < .5 ? ce.easeInBounce(e * 2) * .5 : ce.easeOutBounce(e * 2 - 1) * .5 + .5 };
function ge(e) { if (e && typeof e == "object") {
    let t = e.toString();
    return t === "[object CanvasPattern]" || t === "[object CanvasGradient]";
} return !1; }
function wr(e) { return ge(e) ? e : new D(e); }
function fe(e) { return ge(e) ? e : new D(e).saturate(.5).darken(.1).hexString(); }
var Dt = ["x", "y", "borderWidth", "radius", "tension"], Nt = ["color", "borderColor", "backgroundColor"];
function Yt(e) { e.set("animation", { delay: void 0, duration: 1e3, easing: "easeOutQuart", fn: void 0, from: void 0, loop: void 0, to: void 0, type: void 0 }), e.describe("animation", { _fallback: !1, _indexable: !1, _scriptable: t => t !== "onProgress" && t !== "onComplete" && t !== "fn" }), e.set("animations", { colors: { type: "color", properties: Nt }, numbers: { type: "number", properties: Dt } }), e.describe("animations", { _fallback: "animation" }), e.set("transitions", { active: { animation: { duration: 400 } }, resize: { animation: { duration: 0 } }, show: { animations: { colors: { from: "transparent" }, visible: { type: "boolean", duration: 0 } } }, hide: { animations: { colors: { to: "transparent" }, visible: { type: "boolean", easing: "linear", fn: t => t | 0 } } } }); }
function Ht(e) { e.set("layout", { autoPadding: !0, padding: { top: 0, right: 0, bottom: 0, left: 0 } }); }
var Ie = new Map;
function zt(e, t) { t = t || {}; let n = e + JSON.stringify(t), r = Ie.get(n); return r || (r = new Intl.NumberFormat(e, t), Ie.set(n, r)), r; }
function $t(e, t, n) { return zt(t, n).format(e); }
var Xe = { values(e) { return x(e) ? e : "" + e; }, numeric(e, t, n) { if (e === 0)
        return "0"; let r = this.chart.options.locale, o, i = e; if (n.length > 1) {
        let f = Math.max(Math.abs(n[0].value), Math.abs(n[n.length - 1].value));
        (f < 1e-4 || f > 1e15) && (o = "scientific"), i = qt(e, n);
    } let s = ue(Math.abs(i)), a = isNaN(s) ? 1 : Math.max(Math.min(-1 * Math.floor(s), 20), 0), c = { notation: o, minimumFractionDigits: a, maximumFractionDigits: a }; return Object.assign(c, this.options.ticks.format), $t(e, r, c); }, logarithmic(e, t, n) { if (e === 0)
        return "0"; let r = n[t].significand || e / Math.pow(10, Math.floor(ue(e))); return [1, 2, 3, 5, 10, 15].includes(r) || t > .8 * n.length ? Xe.numeric.call(this, e, t, n) : ""; } };
function qt(e, t) { let n = t.length > 3 ? t[2].value - t[1].value : t[1].value - t[0].value; return Math.abs(n) >= 1 && e !== Math.floor(e) && (n = e - Math.floor(e)), n; }
var Xt = { formatters: Xe };
function Kt(e) { e.set("scale", { display: !0, offset: !1, reverse: !1, beginAtZero: !1, bounds: "ticks", clip: !0, grace: 0, grid: { display: !0, lineWidth: 1, drawOnChartArea: !0, drawTicks: !0, tickLength: 8, tickWidth: (t, n) => n.lineWidth, tickColor: (t, n) => n.color, offset: !1 }, border: { display: !0, dash: [], dashOffset: 0, width: 1 }, title: { display: !1, text: "", padding: { top: 4, bottom: 4 } }, ticks: { minRotation: 0, maxRotation: 50, mirror: !1, textStrokeWidth: 0, textStrokeColor: "", padding: 3, display: !0, autoSkip: !0, autoSkipPadding: 3, labelOffset: 0, callback: Xt.formatters.values, minor: {}, major: {}, align: "center", crossAlign: "near", showLabelBackdrop: !1, backdropColor: "rgba(255, 255, 255, 0.75)", backdropPadding: 2 } }), e.route("scale.ticks", "color", "", "color"), e.route("scale.grid", "color", "", "borderColor"), e.route("scale.border", "color", "", "borderColor"), e.route("scale.title", "color", "", "color"), e.describe("scale", { _fallback: !1, _scriptable: t => !t.startsWith("before") && !t.startsWith("after") && t !== "callback" && t !== "parser", _indexable: t => t !== "borderDash" && t !== "tickBorderDash" && t !== "dash" }), e.describe("scales", { _fallback: "scale" }), e.describe("scale.ticks", { _scriptable: t => t !== "backdropPadding" && t !== "callback", _indexable: t => t !== "backdropPadding" }); }
var Ut = Object.create(null), Zt = Object.create(null);
function Y(e, t) { if (!t)
    return e; let n = t.split("."); for (let r = 0, o = n.length; r < o; ++r) {
    let i = n[r];
    e = e[i] || (e[i] = Object.create(null));
} return e; }
function le(e, t, n) { return typeof t == "string" ? G(Y(e, t), n) : G(Y(e, ""), t); }
var he = class {
    constructor(t, n) { this.animation = void 0, this.backgroundColor = "rgba(0,0,0,0.1)", this.borderColor = "rgba(0,0,0,0.1)", this.color = "#666", this.datasets = {}, this.devicePixelRatio = r => r.chart.platform.getDevicePixelRatio(), this.elements = {}, this.events = ["mousemove", "mouseout", "click", "touchstart", "touchmove"], this.font = { family: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif", size: 12, style: "normal", lineHeight: 1.2, weight: null }, this.hover = {}, this.hoverBackgroundColor = (r, o) => fe(o.backgroundColor), this.hoverBorderColor = (r, o) => fe(o.borderColor), this.hoverColor = (r, o) => fe(o.color), this.indexAxis = "x", this.interaction = { mode: "nearest", intersect: !0, includeInvisible: !1 }, this.maintainAspectRatio = !0, this.onHover = null, this.onClick = null, this.parsing = !0, this.plugins = {}, this.responsive = !0, this.scale = void 0, this.scales = {}, this.showLine = !0, this.drawActiveElementsOnTop = !0, this.describe(t), this.apply(n); }
    set(t, n) { return le(this, t, n); }
    get(t) { return Y(this, t); }
    describe(t, n) { return le(Zt, t, n); }
    override(t, n) { return le(Ut, t, n); }
    route(t, n, r, o) { let i = Y(this, t), s = Y(this, r), a = "_" + n; Object.defineProperties(i, { [a]: { value: i[n], writable: !0 }, [n]: { enumerable: !0, get() { let c = this[a], f = s[o]; return _(c) ? Object.assign({}, f, c) : C(c, f); }, set(c) { this[a] = c; } } }); }
    apply(t) { t.forEach(n => n(this)); }
}, Qt = new he({ _scriptable: e => !e.startsWith("on"), _indexable: e => e !== "events", hover: { _fallback: "interaction" }, interaction: { _scriptable: !1, _indexable: !1 } }, [Yt, Ht, Kt]);
function Gt(e) { return !e || j(e.size) || j(e.family) ? null : (e.style ? e.style + " " : "") + (e.weight ? e.weight + " " : "") + e.size + "px " + e.family; }
function ve(e, t, n, r, o) { let i = t[o]; return i || (i = t[o] = e.measureText(o).width, n.push(o)), i > r && (r = i), r; }
function Or(e, t, n, r) { r = r || {}; let o = r.data = r.data || {}, i = r.garbageCollect = r.garbageCollect || []; r.font !== t && (o = r.data = {}, i = r.garbageCollect = [], r.font = t), e.save(), e.font = t; let s = 0, a = n.length, c, f, l, d, g; for (c = 0; c < a; c++)
    if (d = n[c], d != null && !x(d))
        s = ve(e, o, i, s, d);
    else if (x(d))
        for (f = 0, l = d.length; f < l; f++)
            g = d[f], g != null && !x(g) && (s = ve(e, o, i, s, g)); e.restore(); let b = i.length / 2; if (b > n.length) {
    for (c = 0; c < b; c++)
        delete o[i[c]];
    i.splice(0, b);
} return s; }
function Pr(e, t, n) { let r = e.currentDevicePixelRatio, o = n !== 0 ? Math.max(n / 2, .5) : 0; return Math.round((t - o) * r) / r + o; }
function Tr(e, t) { !t && !e || (t = t || e.getContext("2d"), t.save(), t.resetTransform(), t.clearRect(0, 0, e.width, e.height), t.restore()); }
function kr(e, t, n, r) { Vt(e, t, n, r, null); }
function Vt(e, t, n, r, o) { let i, s, a, c, f, l, d, g, b = t.pointStyle, m = t.rotation, h = t.radius, u = (m || 0) * At; if (b && typeof b == "object" && (i = b.toString(), i === "[object HTMLImageElement]" || i === "[object HTMLCanvasElement]")) {
    e.save(), e.translate(n, r), e.rotate(u), e.drawImage(b, -b.width / 2, -b.height / 2, b.width, b.height), e.restore();
    return;
} if (!(isNaN(h) || h <= 0)) {
    switch (e.beginPath(), b) {
        default:
            o ? e.ellipse(n, r, o / 2, h, 0, 0, S) : e.arc(n, r, h, 0, S), e.closePath();
            break;
        case "triangle":
            l = o ? o / 2 : h, e.moveTo(n + Math.sin(u) * l, r - Math.cos(u) * h), u += Te, e.lineTo(n + Math.sin(u) * l, r - Math.cos(u) * h), u += Te, e.lineTo(n + Math.sin(u) * l, r - Math.cos(u) * h), e.closePath();
            break;
        case "rectRounded":
            f = h * .516, c = h - f, s = Math.cos(u + R) * c, d = Math.cos(u + R) * (o ? o / 2 - f : c), a = Math.sin(u + R) * c, g = Math.sin(u + R) * (o ? o / 2 - f : c), e.arc(n - d, r - a, f, u - y, u - O), e.arc(n + g, r - s, f, u - O, u), e.arc(n + d, r + a, f, u, u + O), e.arc(n - g, r + s, f, u + O, u + y), e.closePath();
            break;
        case "rect":
            if (!m) {
                c = Math.SQRT1_2 * h, l = o ? o / 2 : c, e.rect(n - l, r - c, 2 * l, 2 * c);
                break;
            }
            u += R;
        case "rectRot":
            d = Math.cos(u) * (o ? o / 2 : h), s = Math.cos(u) * h, a = Math.sin(u) * h, g = Math.sin(u) * (o ? o / 2 : h), e.moveTo(n - d, r - a), e.lineTo(n + g, r - s), e.lineTo(n + d, r + a), e.lineTo(n - g, r + s), e.closePath();
            break;
        case "crossRot": u += R;
        case "cross":
            d = Math.cos(u) * (o ? o / 2 : h), s = Math.cos(u) * h, a = Math.sin(u) * h, g = Math.sin(u) * (o ? o / 2 : h), e.moveTo(n - d, r - a), e.lineTo(n + d, r + a), e.moveTo(n + g, r - s), e.lineTo(n - g, r + s);
            break;
        case "star":
            d = Math.cos(u) * (o ? o / 2 : h), s = Math.cos(u) * h, a = Math.sin(u) * h, g = Math.sin(u) * (o ? o / 2 : h), e.moveTo(n - d, r - a), e.lineTo(n + d, r + a), e.moveTo(n + g, r - s), e.lineTo(n - g, r + s), u += R, d = Math.cos(u) * (o ? o / 2 : h), s = Math.cos(u) * h, a = Math.sin(u) * h, g = Math.sin(u) * (o ? o / 2 : h), e.moveTo(n - d, r - a), e.lineTo(n + d, r + a), e.moveTo(n + g, r - s), e.lineTo(n - g, r + s);
            break;
        case "line":
            s = o ? o / 2 : Math.cos(u) * h, a = Math.sin(u) * h, e.moveTo(n - s, r - a), e.lineTo(n + s, r + a);
            break;
        case "dash":
            e.moveTo(n, r), e.lineTo(n + Math.cos(u) * (o ? o / 2 : h), r + Math.sin(u) * h);
            break;
        case !1:
            e.closePath();
            break;
    }
    e.fill(), t.borderWidth > 0 && e.stroke();
} }
function Ae(e, t, n) { return n = n || .5, !t || e && e.x > t.left - n && e.x < t.right + n && e.y > t.top - n && e.y < t.bottom + n; }
function Rr(e, t) { e.save(), e.beginPath(), e.rect(t.left, t.top, t.right - t.left, t.bottom - t.top), e.clip(); }
function Cr(e) { e.restore(); }
function Fr(e, t, n, r, o) { if (!t)
    return e.lineTo(n.x, n.y); if (o === "middle") {
    let i = (t.x + n.x) / 2;
    e.lineTo(i, t.y), e.lineTo(i, n.y);
}
else
    o === "after" != !!r ? e.lineTo(t.x, n.y) : e.lineTo(n.x, t.y); e.lineTo(n.x, n.y); }
function Ir(e, t, n, r) { if (!t)
    return e.lineTo(n.x, n.y); e.bezierCurveTo(r ? t.cp1x : t.cp2x, r ? t.cp1y : t.cp2y, r ? n.cp2x : n.cp1x, r ? n.cp2y : n.cp1y, n.x, n.y); }
function Jt(e, t) { t.translation && e.translate(t.translation[0], t.translation[1]), j(t.rotation) || e.rotate(t.rotation), t.color && (e.fillStyle = t.color), t.textAlign && (e.textAlign = t.textAlign), t.textBaseline && (e.textBaseline = t.textBaseline); }
function en(e, t, n, r, o) { if (o.strikethrough || o.underline) {
    let i = e.measureText(r), s = t - i.actualBoundingBoxLeft, a = t + i.actualBoundingBoxRight, c = n - i.actualBoundingBoxAscent, f = n + i.actualBoundingBoxDescent, l = o.strikethrough ? (c + f) / 2 : f;
    e.strokeStyle = e.fillStyle, e.beginPath(), e.lineWidth = o.decorationWidth || 2, e.moveTo(s, l), e.lineTo(a, l), e.stroke();
} }
function tn(e, t) { let n = e.fillStyle; e.fillStyle = t.color, e.fillRect(t.left, t.top, t.width, t.height), e.fillStyle = n; }
function vr(e, t, n, r, o, i = {}) { let s = x(t) ? t : [t], a = i.strokeWidth > 0 && i.strokeColor !== "", c, f; for (e.save(), e.font = o.string, Jt(e, i), c = 0; c < s.length; ++c)
    f = s[c], i.backdrop && tn(e, i.backdrop), a && (i.strokeColor && (e.strokeStyle = i.strokeColor), j(i.strokeWidth) || (e.lineWidth = i.strokeWidth), e.strokeText(f, n, r, i.maxWidth)), e.fillText(f, n, r, i.maxWidth), en(e, n, r, f, i), r += Number(o.lineHeight); e.restore(); }
function Ar(e, t) { let { x: n, y: r, w: o, h: i, radius: s } = t; e.arc(n + s.topLeft, r + s.topLeft, s.topLeft, 1.5 * y, y, !0), e.lineTo(n, r + i - s.bottomLeft), e.arc(n + s.bottomLeft, r + i - s.bottomLeft, s.bottomLeft, y, O, !0), e.lineTo(n + o - s.bottomRight, r + i), e.arc(n + o - s.bottomRight, r + i - s.bottomRight, s.bottomRight, O, 0, !0), e.lineTo(n + o, r + s.topRight), e.arc(n + o - s.topRight, r + s.topRight, s.topRight, 0, -O, !0), e.lineTo(n + s.topLeft, r); }
var nn = /^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/, rn = /^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/;
function on(e, t) { let n = ("" + e).match(nn); if (!n || n[1] === "normal")
    return t * 1.2; switch (e = +n[2], n[3]) {
    case "px": return e;
    case "%":
        e /= 100;
        break;
} return t * e; }
var sn = e => +e || 0;
function Ke(e, t) { let n = {}, r = _(t), o = r ? Object.keys(t) : t, i = _(e) ? r ? s => C(e[s], e[t[s]]) : s => e[s] : () => e; for (let s of o)
    n[s] = sn(i(s)); return n; }
function an(e) { return Ke(e, { top: "y", right: "x", bottom: "y", left: "x" }); }
function Br(e) { return Ke(e, ["topLeft", "topRight", "bottomLeft", "bottomRight"]); }
function jr(e) { let t = an(e); return t.width = t.left + t.right, t.height = t.top + t.bottom, t; }
function Er(e, t) { e = e || {}, t = t || Qt.font; let n = C(e.size, t.size); typeof n == "string" && (n = parseInt(n, 10)); let r = C(e.style, t.style); r && !("" + r).match(rn) && (console.warn('Invalid font style specified: "' + r + '"'), r = void 0); let o = { family: C(e.family, t.family), lineHeight: on(C(e.lineHeight, t.lineHeight), n), size: n, style: r, weight: C(e.weight, t.weight), string: "" }; return o.string = Gt(o), o; }
function Wr(e, t, n, r) { let o = !0, i, s, a; for (i = 0, s = e.length; i < s; ++i)
    if (a = e[i], a !== void 0 && (t !== void 0 && typeof a == "function" && (a = a(t), o = !1), n !== void 0 && x(a) && (a = a[n % a.length], o = !1), a !== void 0))
        return r && !o && (r.cacheable = !1), a; }
function Lr(e, t, n) { let { min: r, max: o } = e, i = Tt(t, (o - r) / 2), s = (a, c) => n && a === 0 ? 0 : a + c; return { min: s(r, -Math.abs(i)), max: s(o, i) }; }
function cn(e, t) { return Object.assign(Object.create(e), t); }
function Ue(e, t = [""], n, r, o = () => e[0]) { let i = n || e; typeof r > "u" && (r = Ge("_fallback", e)); let s = { [Symbol.toStringTag]: "Object", _cacheable: !0, _scopes: e, _rootScopes: i, _fallback: r, _getTarget: o, override: a => Ue([a, ...e], t, i, r) }; return new Proxy(s, { deleteProperty(a, c) { return delete a[c], delete a._keys, delete e[0][c], !0; }, get(a, c) { return Ze(a, c, () => pn(c, t, e, a)); }, getOwnPropertyDescriptor(a, c) { return Reflect.getOwnPropertyDescriptor(a._scopes[0], c); }, getPrototypeOf() { return Reflect.getPrototypeOf(e[0]); }, has(a, c) { return je(a).includes(c); }, ownKeys(a) { return je(a); }, set(a, c, f) { let l = a._storage || (a._storage = o()); return a[c] = l[c] = f, delete a._keys, !0; } }); }
function ee(e, t, n, r) { let o = { _cacheable: !1, _proxy: e, _context: t, _subProxy: n, _stack: new Set, _descriptors: fn(e, r), setContext: i => ee(e, i, n, r), override: i => ee(e.override(i), t, n, r) }; return new Proxy(o, { deleteProperty(i, s) { return delete i[s], delete e[s], !0; }, get(i, s, a) { return Ze(i, s, () => un(i, s, a)); }, getOwnPropertyDescriptor(i, s) { return i._descriptors.allKeys ? Reflect.has(e, s) ? { enumerable: !0, configurable: !0 } : void 0 : Reflect.getOwnPropertyDescriptor(e, s); }, getPrototypeOf() { return Reflect.getPrototypeOf(e); }, has(i, s) { return Reflect.has(e, s); }, ownKeys() { return Reflect.ownKeys(e); }, set(i, s, a) { return e[s] = a, delete i[s], !0; } }); }
function fn(e, t = { scriptable: !0, indexable: !0 }) { let { _scriptable: n = t.scriptable, _indexable: r = t.indexable, _allKeys: o = t.allKeys } = e; return { allKeys: o, scriptable: n, indexable: r, isScriptable: V(n) ? n : () => n, isIndexable: V(r) ? r : () => r }; }
var ln = (e, t) => e ? e + He(t) : t, be = (e, t) => _(t) && e !== "adapters" && (Object.getPrototypeOf(t) === null || t.constructor === Object);
function Ze(e, t, n) { if (Object.prototype.hasOwnProperty.call(e, t) || t === "constructor")
    return e[t]; let r = n(); return e[t] = r, r; }
function un(e, t, n) { let { _proxy: r, _context: o, _subProxy: i, _descriptors: s } = e, a = r[t]; return V(a) && s.isScriptable(t) && (a = dn(t, a, e, n)), x(a) && a.length && (a = hn(t, a, e, s.isIndexable)), be(t, a) && (a = ee(a, o, i && i[t], s)), a; }
function dn(e, t, n, r) { let { _proxy: o, _context: i, _subProxy: s, _stack: a } = n; if (a.has(e))
    throw new Error("Recursion detected: " + Array.from(a).join("->") + "->" + e); a.add(e); let c = t(i, s || r); return a.delete(e), be(e, c) && (c = me(o._scopes, o, e, c)), c; }
function hn(e, t, n, r) { let { _proxy: o, _context: i, _subProxy: s, _descriptors: a } = n; if (typeof i.index < "u" && r(e))
    return t[i.index % t.length]; if (_(t[0])) {
    let c = t, f = o._scopes.filter(l => l !== c);
    t = [];
    for (let l of c) {
        let d = me(f, o, e, l);
        t.push(ee(d, i, s && s[e], a));
    }
} return t; }
function Qe(e, t, n) { return V(e) ? e(t, n) : e; }
var gn = (e, t) => e === !0 ? t : typeof e == "string" ? Ye(t, e) : void 0;
function bn(e, t, n, r, o) { for (let i of t) {
    let s = gn(n, i);
    if (s) {
        e.add(s);
        let a = Qe(s._fallback, n, o);
        if (typeof a < "u" && a !== n && a !== r)
            return a;
    }
    else if (s === !1 && typeof r < "u" && n !== r)
        return null;
} return !1; }
function me(e, t, n, r) { let o = t._rootScopes, i = Qe(t._fallback, n, r), s = [...e, ...o], a = new Set; a.add(r); let c = Be(a, s, n, i || n, r); return c === null || typeof i < "u" && i !== n && (c = Be(a, s, i, c, r), c === null) ? !1 : Ue(Array.from(a), [""], o, i, () => mn(t, n, r)); }
function Be(e, t, n, r, o) { for (; n;)
    n = bn(e, t, n, r, o); return n; }
function mn(e, t, n) { let r = e._getTarget(); t in r || (r[t] = {}); let o = r[t]; return x(o) && _(n) ? n : o || {}; }
function pn(e, t, n, r) { let o; for (let i of t)
    if (o = Ge(ln(i, e), n), typeof o < "u")
        return be(e, o) ? me(n, r, e, o) : o; }
function Ge(e, t) { for (let n of t) {
    if (!n)
        continue;
    let r = n[e];
    if (typeof r < "u")
        return r;
} }
function je(e) { let t = e._keys; return t || (t = e._keys = yn(e._scopes)), t; }
function yn(e) { let t = new Set; for (let n of e)
    for (let r of Object.keys(n).filter(o => !o.startsWith("_")))
        t.add(r); return Array.from(t); }
function Dr(e, t, n, r) { let { iScale: o } = e, { key: i = "r" } = this._parsing, s = new Array(r), a, c, f, l; for (a = 0, c = r; a < c; ++a)
    f = a + n, l = t[f], s[a] = { r: o.parse(Ye(l, i), f) }; return s; }
var _n = Number.EPSILON || 1e-14, E = (e, t) => t < e.length && !e[t].skip && e[t], Ve = e => e === "x" ? "y" : "x";
function Mn(e, t, n, r) { let o = e.skip ? t : e, i = t, s = n.skip ? t : n, a = Re(i, o), c = Re(s, i), f = a / (a + c), l = c / (a + c); f = isNaN(f) ? 0 : f, l = isNaN(l) ? 0 : l; let d = r * f, g = r * l; return { previous: { x: i.x - d * (s.x - o.x), y: i.y - d * (s.y - o.y) }, next: { x: i.x + g * (s.x - o.x), y: i.y + g * (s.y - o.y) } }; }
function xn(e, t, n) { let r = e.length, o, i, s, a, c, f = E(e, 0); for (let l = 0; l < r - 1; ++l)
    if (c = f, f = E(e, l + 1), !(!c || !f)) {
        if (ze(t[l], 0, _n)) {
            n[l] = n[l + 1] = 0;
            continue;
        }
        o = n[l] / t[l], i = n[l + 1] / t[l], a = Math.pow(o, 2) + Math.pow(i, 2), !(a <= 9) && (s = 3 / Math.sqrt(a), n[l] = o * s * t[l], n[l + 1] = i * s * t[l]);
    } }
function Sn(e, t, n = "x") { let r = Ve(n), o = e.length, i, s, a, c = E(e, 0); for (let f = 0; f < o; ++f) {
    if (s = a, a = c, c = E(e, f + 1), !a)
        continue;
    let l = a[n], d = a[r];
    s && (i = (l - s[n]) / 3, a[`cp1${n}`] = l - i, a[`cp1${r}`] = d - i * t[f]), c && (i = (c[n] - l) / 3, a[`cp2${n}`] = l + i, a[`cp2${r}`] = d + i * t[f]);
} }
function wn(e, t = "x") { let n = Ve(t), r = e.length, o = Array(r).fill(0), i = Array(r), s, a, c, f = E(e, 0); for (s = 0; s < r; ++s)
    if (a = c, c = f, f = E(e, s + 1), !!c) {
        if (f) {
            let l = f[t] - c[t];
            o[s] = l !== 0 ? (f[n] - c[n]) / l : 0;
        }
        i[s] = a ? f ? ke(o[s - 1]) !== ke(o[s]) ? 0 : (o[s - 1] + o[s]) / 2 : o[s - 1] : o[s];
    } xn(e, o, i), Sn(e, i, t); }
function K(e, t, n) { return Math.max(Math.min(e, n), t); }
function On(e, t) { let n, r, o, i, s, a = Ae(e[0], t); for (n = 0, r = e.length; n < r; ++n)
    s = i, i = a, a = n < r - 1 && Ae(e[n + 1], t), i && (o = e[n], s && (o.cp1x = K(o.cp1x, t.left, t.right), o.cp1y = K(o.cp1y, t.top, t.bottom)), a && (o.cp2x = K(o.cp2x, t.left, t.right), o.cp2y = K(o.cp2y, t.top, t.bottom))); }
function Nr(e, t, n, r, o) { let i, s, a, c; if (t.spanGaps && (e = e.filter(f => !f.skip)), t.cubicInterpolationMode === "monotone")
    wn(e, o);
else {
    let f = r ? e[e.length - 1] : e[0];
    for (i = 0, s = e.length; i < s; ++i)
        a = e[i], c = Mn(f, a, e[Math.min(i + 1, s - (r ? 0 : 1)) % s], t.tension), a.cp1x = c.previous.x, a.cp1y = c.previous.y, a.cp2x = c.next.x, a.cp2y = c.next.y, f = a;
} t.capBezierPoints && On(e, n); }
function Pn() { return typeof window < "u" && typeof document < "u"; }
function Tn(e) { let t = e.parentNode; return t && t.toString() === "[object ShadowRoot]" && (t = t.host), t; }
function te(e, t, n) { let r; return typeof e == "string" ? (r = parseInt(e, 10), e.indexOf("%") !== -1 && (r = r / 100 * t.parentNode[n])) : r = e, r; }
var ne = e => e.ownerDocument.defaultView.getComputedStyle(e, null);
function kn(e, t) { return ne(e).getPropertyValue(t); }
var Rn = ["top", "right", "bottom", "left"];
function F(e, t, n) { let r = {}; n = n ? "-" + n : ""; for (let o = 0; o < 4; o++) {
    let i = Rn[o];
    r[i] = parseFloat(e[t + "-" + i + n]) || 0;
} return r.width = r.left + r.right, r.height = r.top + r.bottom, r; }
var Cn = (e, t, n) => (e > 0 || t > 0) && (!n || !n.shadowRoot);
function Fn(e, t) { let n = e.touches, r = n && n.length ? n[0] : e, { offsetX: o, offsetY: i } = r, s = !1, a, c; if (Cn(o, i, e.target))
    a = o, c = i;
else {
    let f = t.getBoundingClientRect();
    a = r.clientX - f.left, c = r.clientY - f.top, s = !0;
} return { x: a, y: c, box: s }; }
function Yr(e, t) { if ("native" in e)
    return e; let { canvas: n, currentDevicePixelRatio: r } = t, o = ne(n), i = o.boxSizing === "border-box", s = F(o, "padding"), a = F(o, "border", "width"), { x: c, y: f, box: l } = Fn(e, n), d = s.left + (l && a.left), g = s.top + (l && a.top), { width: b, height: m } = t; return i && (b -= s.width + a.width, m -= s.height + a.height), { x: Math.round((c - d) / b * n.width / r), y: Math.round((f - g) / m * n.height / r) }; }
function In(e, t, n) { let r, o; if (t === void 0 || n === void 0) {
    let i = e && Tn(e);
    if (!i)
        t = e.clientWidth, n = e.clientHeight;
    else {
        let s = i.getBoundingClientRect(), a = ne(i), c = F(a, "border", "width"), f = F(a, "padding");
        t = s.width - f.width - c.width, n = s.height - f.height - c.height, r = te(a.maxWidth, i, "clientWidth"), o = te(a.maxHeight, i, "clientHeight");
    }
} return { width: t, height: n, maxWidth: r || J, maxHeight: o || J }; }
var U = e => Math.round(e * 10) / 10;
function Hr(e, t, n, r) { let o = ne(e), i = F(o, "margin"), s = te(o.maxWidth, e, "clientWidth") || J, a = te(o.maxHeight, e, "clientHeight") || J, c = In(e, t, n), { width: f, height: l } = c; if (o.boxSizing === "content-box") {
    let g = F(o, "border", "width"), b = F(o, "padding");
    f -= b.width + g.width, l -= b.height + g.height;
} return f = Math.max(0, f - i.width), l = Math.max(0, r ? f / r : l - i.height), f = U(Math.min(f, s, c.maxWidth)), l = U(Math.min(l, a, c.maxHeight)), f && !l && (l = U(f / 2)), (t !== void 0 || n !== void 0) && r && c.height && l > c.height && (l = c.height, f = U(Math.floor(l * r))), { width: f, height: l }; }
function zr(e, t, n) { let r = t || 1, o = Math.floor(e.height * r), i = Math.floor(e.width * r); e.height = Math.floor(e.height), e.width = Math.floor(e.width); let s = e.canvas; return s.style && (n || !s.style.height && !s.style.width) && (s.style.height = `${e.height}px`, s.style.width = `${e.width}px`), e.currentDevicePixelRatio !== r || s.height !== o || s.width !== i ? (e.currentDevicePixelRatio = r, s.height = o, s.width = i, e.ctx.setTransform(r, 0, 0, r, 0, 0), !0) : !1; }
var $r = (function () { let e = !1; try {
    let t = { get passive() { return e = !0, !1; } };
    Pn() && (window.addEventListener("test", null, t), window.removeEventListener("test", null, t));
}
catch { } return e; })();
function qr(e, t) { let n = kn(e, t), r = n && n.match(/^(\d+)(\.\d+)?px$/); return r ? +r[1] : void 0; }
function B(e, t, n, r) { return { x: e.x + n * (t.x - e.x), y: e.y + n * (t.y - e.y) }; }
function Xr(e, t, n, r) { return { x: e.x + n * (t.x - e.x), y: r === "middle" ? n < .5 ? e.y : t.y : r === "after" ? n < 1 ? e.y : t.y : n > 0 ? t.y : e.y }; }
function Kr(e, t, n, r) { let o = { x: e.cp2x, y: e.cp2y }, i = { x: t.cp1x, y: t.cp1y }, s = B(e, o, n), a = B(o, i, n), c = B(i, t, n), f = B(s, a, n), l = B(a, c, n); return B(f, l, n); }
var vn = function (e, t) { return { x(n) { return e + e + t - n; }, setWidth(n) { t = n; }, textAlign(n) { return n === "center" ? n : n === "right" ? "left" : "right"; }, xPlus(n, r) { return n - r; }, leftForLtr(n, r) { return n - r; } }; }, An = function () { return { x(e) { return e; }, setWidth(e) { }, textAlign(e) { return e; }, xPlus(e, t) { return e + t; }, leftForLtr(e, t) { return e; } }; };
function Ur(e, t, n) { return e ? vn(t, n) : An(); }
function Zr(e, t) { let n, r; (t === "ltr" || t === "rtl") && (n = e.canvas.style, r = [n.getPropertyValue("direction"), n.getPropertyPriority("direction")], n.setProperty("direction", t, "important"), e.prevTextDirection = r); }
function Qr(e, t) { t !== void 0 && (delete e.prevTextDirection, e.canvas.style.setProperty("direction", t[0], t[1])); }
function Je(e) { return e === "angle" ? { between: Et, compare: jt, normalize: k } : { between: Wt, compare: (t, n) => t - n, normalize: t => t }; }
function Ee({ start: e, end: t, count: n, loop: r, style: o }) { return { start: e % n, end: t % n, loop: r && (t - e + 1) % n === 0, style: o }; }
function Bn(e, t, n) { let { property: r, start: o, end: i } = n, { between: s, normalize: a } = Je(r), c = t.length, { start: f, end: l, loop: d } = e, g, b; if (d) {
    for (f += c, l += c, g = 0, b = c; g < b && s(a(t[f % c][r]), o, i); ++g)
        f--, l--;
    f %= c, l %= c;
} return l < f && (l += c), { start: f, end: l, loop: d, style: e.style }; }
function jn(e, t, n) { if (!n)
    return [e]; let { property: r, start: o, end: i } = n, s = t.length, { compare: a, between: c, normalize: f } = Je(r), { start: l, end: d, loop: g, style: b } = Bn(e, t, n), m = [], h = !1, u = null, p, I, W, et = () => c(o, W, p) && a(o, W) !== 0, tt = () => a(i, p) === 0 || c(i, W, p), nt = () => h || et(), rt = () => !h || tt(); for (let v = l, pe = l; v <= d; ++v)
    I = t[v % s], !I.skip && (p = f(I[r]), p !== W && (h = c(p, o, i), u === null && nt() && (u = a(p, o) === 0 ? v : pe), u !== null && rt() && (m.push(Ee({ start: u, end: v, loop: g, count: s, style: b })), u = null), pe = v, W = p)); return u !== null && m.push(Ee({ start: u, end: d, loop: g, count: s, style: b })), m; }
function Gr(e, t) { let n = [], r = e.segments; for (let o = 0; o < r.length; o++) {
    let i = jn(r[o], e.points, t);
    i.length && n.push(...i);
} return n; }
function En(e, t, n, r) { let o = 0, i = t - 1; if (n && !r)
    for (; o < t && !e[o].skip;)
        o++; for (; o < t && e[o].skip;)
    o++; for (o %= t, n && (i += o); i > o && e[i % t].skip;)
    i--; return i %= t, { start: o, end: i }; }
function Wn(e, t, n, r) { let o = e.length, i = [], s = t, a = e[t], c; for (c = t + 1; c <= n; ++c) {
    let f = e[c % o];
    f.skip || f.stop ? a.skip || (r = !1, i.push({ start: t % o, end: (c - 1) % o, loop: r }), t = s = f.stop ? c : null) : (s = c, a.skip && (t = c)), a = f;
} return s !== null && i.push({ start: t % o, end: s % o, loop: r }), i; }
function Vr(e, t) { let n = e.points, r = e.options.spanGaps, o = n.length; if (!o)
    return []; let i = !!e._loop, { start: s, end: a } = En(n, o, i, r); if (r === !0)
    return We(e, [{ start: s, end: a, loop: i }], n, t); let c = a < s ? a + o : a, f = !!e._fullLoop && s === 0 && a === o - 1; return We(e, Wn(n, s, c, f), n, t); }
function We(e, t, n, r) { return !r || !r.setContext || !n ? t : Ln(e, t, n, r); }
function Ln(e, t, n, r) { let o = e._chart.getContext(), i = Le(e.options), { _datasetIndex: s, options: { spanGaps: a } } = e, c = n.length, f = [], l = i, d = t[0].start, g = d; function b(m, h, u, p) { let I = a ? -1 : 1; if (m !== h) {
    for (m += c; n[m % c].skip;)
        m -= I;
    for (; n[h % c].skip;)
        h += I;
    m % c !== h % c && (f.push({ start: m % c, end: h % c, loop: u, style: p }), l = p, d = h % c);
} } for (let m of t) {
    d = a ? d : m.start;
    let h = n[d % c], u;
    for (g = d + 1; g <= m.end; g++) {
        let p = n[g % c];
        u = Le(r.setContext(cn(o, { type: "segment", p0: h, p1: p, p0DataIndex: (g - 1) % c, p1DataIndex: g % c, datasetIndex: s }))), Dn(u, l) && b(d, g - 1, m.loop, l), h = p, l = u;
    }
    d < g - 1 && b(d, g - 1, m.loop, l);
} return f; }
function Le(e) { return { backgroundColor: e.backgroundColor, borderCapStyle: e.borderCapStyle, borderDash: e.borderDash, borderDashOffset: e.borderDashOffset, borderJoinStyle: e.borderJoinStyle, borderWidth: e.borderWidth, borderColor: e.borderColor }; }
function Dn(e, t) { if (!t)
    return !1; let n = [], r = function (o, i) { return ge(i) ? (n.includes(i) || n.push(i), n.indexOf(i)) : i; }; return JSON.stringify(e, r) !== JSON.stringify(t, r); }
function Z(e, t, n) { return e.options.clip ? e[n] : t[n]; }
function Nn(e, t) { let { xScale: n, yScale: r } = e; return n && r ? { left: Z(n, t, "left"), right: Z(n, t, "right"), top: Z(r, t, "top"), bottom: Z(r, t, "bottom") } : t; }
function Jr(e, t) { let n = t._clip; if (n.disabled)
    return !1; let r = Nn(t, e.chartArea); return { left: n.left === !1 ? 0 : r.left - (n.left === !0 ? 0 : n.left), right: n.right === !1 ? e.width : r.right + (n.right === !0 ? 0 : n.right), top: n.top === !1 ? 0 : r.top - (n.top === !0 ? 0 : n.top), bottom: n.bottom === !1 ? e.height : r.bottom + (n.bottom === !0 ? 0 : n.bottom) }; }
export { zn as a, $n as b, j as c, x as d, _ as e, De as f, qn as g, C as h, Xn as i, Tt as j, Kn as k, Un as l, Zn as m, Q as n, kt as o, G as p, Rt as q, Ct as r, Qn as s, Ft as t, Ye as u, He as v, Gn as w, V as x, Vn as y, Jn as z, y as A, S as B, vt as C, J as D, At as E, O as F, R as G, Te as H, ue as I, ke as J, ze as K, er as L, tr as M, nr as N, rr as O, or as P, ir as Q, sr as R, ar as S, cr as T, Re as U, jt as V, k as W, Et as X, de as Y, fr as Z, Wt as _, $e as $, q as aa, lr as ba, ur as ca, dr as da, hr as ea, gr as fa, br as ga, Lt as ha, mr as ia, pr as ja, yr as ka, _r as la, Mr as ma, xr as na, Sr as oa, ce as pa, ge as qa, wr as ra, fe as sa, $t as ta, Xt as ua, Ut as va, Zt as wa, Qt as xa, Gt as ya, ve as za, Or as Aa, Pr as Ba, Tr as Ca, kr as Da, Vt as Ea, Ae as Fa, Rr as Ga, Cr as Ha, Fr as Ia, Ir as Ja, vr as Ka, Ar as La, on as Ma, Ke as Na, an as Oa, Br as Pa, jr as Qa, Er as Ra, Wr as Sa, Lr as Ta, cn as Ua, Ue as Va, ee as Wa, fn as Xa, Dr as Ya, Mn as Za, wn as _a, Nr as $a, Pn as ab, Tn as bb, kn as cb, Yr as db, Hr as eb, zr as fb, $r as gb, qr as hb, B as ib, Xr as jb, Kr as kb, Ur as lb, Zr as mb, Qr as nb, jn as ob, Gr as pb, Vr as qb, Jr as rb };
/*! Bundled license information:

@kurkle/color/dist/color.esm.js:
  (*!
   * @kurkle/color v0.3.4
   * https://github.com/kurkle/color#readme
   * (c) 2024 Jukka Kurkela
   * Released under the MIT License
   *)

chart.js/dist/chunks/helpers.dataset.js:
  (*!
   * Chart.js v4.5.0
   * https://www.chartjs.org
   * (c) 2025 Chart.js Contributors
   * Released under the MIT License
   *)
*/
