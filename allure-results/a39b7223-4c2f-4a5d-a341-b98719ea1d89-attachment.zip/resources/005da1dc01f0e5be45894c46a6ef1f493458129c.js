import { isObservable as e, of as o } from "rxjs";
function f(r) { return e(r) ? r : o(r); }
export { f as a };
