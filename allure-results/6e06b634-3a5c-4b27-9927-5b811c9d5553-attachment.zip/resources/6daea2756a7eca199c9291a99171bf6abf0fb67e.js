import { b as t } from "@nf-internal/chunk-RXMLTE5A";
import * as o from "@angular/core";
import "@angular/core";
var p = (() => { class e {
    static \u0275fac = function (i) { return new (i || e); };
    static \u0275mod = o.\u0275\u0275defineNgModule({ type: e });
    static \u0275inj = o.\u0275\u0275defineInjector({ imports: [t, t] });
} return e; })();
export { p as a };
