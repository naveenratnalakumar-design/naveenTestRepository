import { a as c, b as d } from "@nf-internal/chunk-OI5KCOOP";
import { a, c as b } from "@nf-internal/chunk-3C63DHR6";
import "@nf-internal/chunk-66YHNWRR";
export { d as BidiModule, a as DIR_DOCUMENT, c as Dir, b as Directionality };
