function t(e) { }
export { t as a }; /*! Bundled license information:

@angular/core/fesm2022/weak_ref.mjs:
  (**
   * @license Angular v20.2.1
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)
*/
